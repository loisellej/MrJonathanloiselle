#!/bin/bash
# Script pour déployer le bot de trading directement depuis Replit vers Hetzner
# Usage: ./deploy_from_replit.sh

# Adresse IP du serveur Hetzner
SERVER_IP="168.119.248.8"

# Demander le mot de passe SSH de manière sécurisée
echo -n "Entrez le mot de passe SSH du serveur Hetzner (ne sera pas affiché): "
read -s SSH_PASSWORD
echo ""
REMOTE_DIR="/opt/trading_bot"

echo "=== DÉPLOIEMENT DIRECT DEPUIS REPLIT VERS HETZNER ==="
echo "Serveur: $SERVER_IP"
echo "Répertoire distant: $REMOTE_DIR"

# Installation de sshpass pour permettre la connexion SSH avec mot de passe
echo "Configuration de l'environnement..."
apt-get update > /dev/null 2>&1
apt-get install -y sshpass > /dev/null 2>&1

# Accepter automatiquement la clé du serveur distant
export SSHPASS=$SSH_PASSWORD
sshpass -e ssh -o StrictHostKeyChecking=no root@$SERVER_IP "echo 'Connexion SSH établie avec succès'"

if [ $? -ne 0 ]; then
  echo "Erreur: Impossible de se connecter au serveur Hetzner."
  exit 1
fi

# Création du répertoire distant
echo "Création du répertoire sur le serveur Hetzner..."
sshpass -e ssh root@$SERVER_IP "mkdir -p $REMOTE_DIR"

# Préparation des fichiers à transférer
echo "Préparation des fichiers pour le transfert..."
mkdir -p _deploy_tmp
cp ultra_volatility_trader.py _deploy_tmp/
cp day_trader.py _deploy_tmp/ 2>/dev/null || true
cp direct_kraken_api.py _deploy_tmp/ 2>/dev/null || true
cp check_status.py _deploy_tmp/ 2>/dev/null || true

# Scripts de contrôle
cat > _deploy_tmp/start_bot.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
echo "Démarrage du bot de trading..."
nohup python3 ultra_volatility_trader.py > trading.log 2>&1 &
echo $! > bot.pid
echo "Bot démarré avec PID: $(cat bot.pid)"
EOF

cat > _deploy_tmp/stop_bot.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
if [ -f bot.pid ]; then
  PID=$(cat bot.pid)
  echo "Arrêt du bot (PID: $PID)..."
  kill $PID
  rm bot.pid
  echo "Bot arrêté."
else
  echo "Aucun PID trouvé. Le bot n'est peut-être pas en cours d'exécution."
fi
EOF

cat > _deploy_tmp/check_status.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
if [ -f bot.pid ]; then
  PID=$(cat bot.pid)
  if ps -p $PID > /dev/null; then
    echo "Le bot est en cours d'exécution (PID: $PID)"
    echo "Dernières lignes du journal:"
    tail -n 15 trading.log
  else
    echo "Le bot s'est arrêté de manière inattendue!"
    rm bot.pid
  fi
else
  echo "Le bot n'est pas en cours d'exécution."
fi
EOF

cat > _deploy_tmp/setup_env.sh << 'EOF'
#!/bin/bash
# Configuration de l'environnement pour les clés API
echo "Configuration des clés API Kraken..."
read -p "Entrez votre clé API Kraken: " API_KEY
read -p "Entrez votre clé secrète API Kraken: " API_SECRET

# Modification du fichier ultra_volatility_trader.py pour insérer les clés
sed -i "s/API_KEY = \".*\"/API_KEY = \"$API_KEY\"/" ultra_volatility_trader.py
sed -i "s/API_SECRET = \".*\"/API_SECRET = \"$API_SECRET\"/" ultra_volatility_trader.py

echo "Configuration terminée avec succès!"
EOF

cat > _deploy_tmp/setup.sh << 'EOF'
#!/bin/bash
echo "Installation des dépendances..."
apt-get update
apt-get install -y python3 python3-pip

echo "Installation des packages Python..."
pip3 install krakenex requests numpy

echo "Configuration des permissions..."
chmod +x start_bot.sh stop_bot.sh check_status.sh setup_env.sh

echo "Configuration terminée avec succès!"
echo ""
echo "ÉTAPE SUIVANTE: Configurez vos clés API avec ./setup_env.sh"
EOF

# Rendre les scripts exécutables
chmod +x _deploy_tmp/*.sh

# Transfert des fichiers vers Hetzner
echo "Transfert des fichiers vers Hetzner..."
for file in _deploy_tmp/*; do
  echo "  Transfert de $(basename $file)..."
  sshpass -e scp $file root@$SERVER_IP:$REMOTE_DIR/
done

# Exécution du script d'installation sur Hetzner
echo "Exécution du script d'installation sur Hetzner..."
sshpass -e ssh root@$SERVER_IP "cd $REMOTE_DIR && ./setup.sh"

# Nettoyage local
rm -rf _deploy_tmp

echo "=== DÉPLOIEMENT TERMINÉ AVEC SUCCÈS ==="
echo ""
echo "Votre bot de trading a été déployé sur votre serveur Hetzner!"
echo ""
echo "Étapes suivantes (à exécuter sur votre serveur Hetzner):"
echo "1. Connectez-vous: ssh root@$SERVER_IP"
echo "2. Allez dans le répertoire: cd $REMOTE_DIR"
echo "3. Configurez vos clés API: ./setup_env.sh"
echo "4. Démarrez le bot: ./start_bot.sh"
echo ""
echo "Pour vérifier l'état plus tard:"
echo "ssh root@$SERVER_IP \"cd $REMOTE_DIR && ./check_status.sh\""