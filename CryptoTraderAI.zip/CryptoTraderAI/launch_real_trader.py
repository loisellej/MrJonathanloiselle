#!/usr/bin/env python3
"""
TRADER CRYPTOMONNAIES ULTRA-PERFORMANT (MODE RÉEL)
- Analyse tous les actifs disponibles
- Échanges en temps réel sur Kraken
- Reconnaissance automatique des actifs de valeur
- Système d'analyse de sentiments et news
- Gains visés: 20-50% par mois
"""
import os
import sys
import logging
from advanced_real_trader import AdvancedRealTrader

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('trader_logs.txt')
    ]
)
logger = logging.getLogger(__name__)

def main():
    """Fonction principale qui démarre le trader en mode réel"""
    # Vérifier que les clés API sont disponibles
    api_key = os.environ.get('KRAKEN_API_KEY')
    api_secret = os.environ.get('KRAKEN_API_SECRET')
    
    if not api_key or not api_secret:
        logger.error("Erreur: Clés API Kraken non trouvées dans les variables d'environnement")
        logger.error("Veuillez définir KRAKEN_API_KEY et KRAKEN_API_SECRET")
        sys.exit(1)
    
    # Afficher un message d'avertissement
    logger.warning("=" * 80)
    logger.warning("ATTENTION: VOUS ALLEZ DÉMARRER LE TRADER EN MODE RÉEL")
    logger.warning("Des transactions réelles seront effectuées avec vos fonds")
    logger.warning("=" * 80)
    
    try:
        # Créer et démarrer le trader
        logger.info("Création du trader avec les clés API...")
        trader = AdvancedRealTrader(api_key=api_key, api_secret=api_secret)
        
        # Afficher les balances initiales
        balances = trader.refresh_balances()
        logger.info(f"Balances initiales: {balances}")
        
        # Trouver les actifs volatils
        volatile_assets = trader.find_volatile_assets(max_assets=10)
        logger.info(f"Actifs volatils identifiés: {volatile_assets}")
        
        # Démarrer le trader
        logger.info("Démarrage du trader...")
        trader.start()
        
        # Afficher les actions disponibles
        logger.info("Le trader est en cours d'exécution. Actions disponibles:")
        logger.info("- Ctrl+C pour arrêter")
        logger.info("- Accédez à http://localhost:5000 pour le dashboard")
        
        # Maintenir le thread principal actif
        try:
            while True:
                # Afficher les statuts toutes les 5 minutes
                import time
                time.sleep(300)
                status = trader.get_status()
                logger.info(f"Statut du trader: {status['running']}, Total: {status['total_value_usdt']} USDT")
        except KeyboardInterrupt:
            logger.info("Interruption détectée, arrêt du trader...")
            trader.stop()
            logger.info("Trader arrêté avec succès.")
    
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution du trader: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()