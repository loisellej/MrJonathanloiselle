import logging
import time
import random
import math
from datetime import datetime, timedelta
import threading

logger = logging.getLogger(__name__)

class TradingBot:
    def __init__(self, exchange_connector, sentiment_analyzer, risk_per_trade=0.9, volatility_threshold=5.0):
        """
        Initialisation du bot de trading avec les paramètres principaux.
        """
        self.exchange = exchange_connector
        self.sentiment_analyzer = sentiment_analyzer
        self.risk_per_trade = risk_per_trade
        self.volatility_threshold = volatility_threshold  # Seuil minimum de volatilité pour trader un actif
        
        # Données internes
        self.entry_prices = {}
        self.price_history = {}  # Historique des prix récents pour calculer la volatilité
        self.volatile_assets = []  # Liste des actifs suffisamment volatils pour être tradés
        self.asset_volatility = {}  # Stockage de la volatilité calculée pour chaque actif
        self.lock = threading.Lock()  # Sécurité pour les mises à jour multi-thread
        
    def get_balances(self):
        """Récupère les soldes actuels depuis l'exchange"""
        try:
            return self.exchange.get_balances()
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des soldes: {str(e)}")
            return {"USDT": 0, "BTC": 0, "ETH": 0}
    
    def get_ticker_price(self, symbol):
        """Récupère le prix actuel d'une paire de trading"""
        try:
            return self.exchange.get_ticker_price(symbol)
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {symbol}: {str(e)}")
            # Utiliser le dernier prix connu si disponible
            asset = symbol.split('/')[0]
            if asset in self.price_history and len(self.price_history[asset]) > 0:
                return self.price_history[asset][-1]
            # Valeurs par défaut en cas d'échec
            if "BTC" in symbol:
                return random.uniform(10000, 20000)
            elif "ETH" in symbol:
                return random.uniform(1000, 2000)
            return 0
    
    def analyze_sentiment(self, asset):
        """Analyse le sentiment pour une crypto-monnaie spécifique"""
        try:
            return self.sentiment_analyzer.analyze_crypto_sentiment(asset)
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse du sentiment pour {asset}: {str(e)}")
            return 0
    
    def calculate_trade_size(self, asset_balance, price, volatility=None, asset=None):
        """Calcule la taille appropriée de la transaction en fonction du solde disponible et de la volatilité"""
        available_balance = asset_balance * price if price > 0 else 0
        
        # Adjust risk based on volatility if provided
        risk_modifier = 1.0
        if volatility is not None and volatility > 0:
            # Increase risk for higher volatility assets (more profit potential)
            risk_modifier = min(2.5, 1.0 + (volatility / 15.0))  # More aggressive scaling for volatile assets
        
        # For GARI, we can use full position sizing (100%) as requested by user
        if asset == 'GARI':
            # Use entire GARI balance (100%) but account for trading fees
            # Usually fees are around 0.16-0.26% on Kraken, so we'll keep a small buffer
            fee_buffer = 0.005  # 0.5% buffer for trading fees and price fluctuations
            return asset_balance * (1.0 - fee_buffer)  # 99.5% of balance to account for fees
            
        # Calculate bubble score and momentum for more aggressive position sizing
        bubble_score = self.asset_volatility.get(f"{asset}_bubble_score", 0) if asset else 0
        momentum_score = self.calculate_momentum(asset) if asset else 0
        
        # Further increase for extremely bullish and volatile assets (bubble detection)
        if bubble_score > 0.7 and momentum_score > 0.6:
            # For assets in a potential bubble with strong momentum, increase position size
            # to capitalize on the rapid price movement
            risk_modifier *= 1.5
        elif bubble_score > 0.8:
            # Even without momentum, a very high bubble score warrants higher position size
            risk_modifier *= 1.3
            
        trade_size = available_balance * self.risk_per_trade * risk_modifier
        return trade_size
    
    def calculate_volatility(self, asset):
        """Calcule la volatilité d'un actif basée sur l'historique récent des prix"""
        if asset not in self.price_history or len(self.price_history[asset]) < 5:
            return 0
            
        prices = self.price_history[asset][-10:]  # Use last 10 price points
        if not prices:
            return 0
            
        # Calculate percentage changes between consecutive prices
        changes = []
        for i in range(1, len(prices)):
            if prices[i-1] == 0:
                continue
            pct_change = abs(prices[i] - prices[i-1]) / prices[i-1] * 100
            changes.append(pct_change)
            
        # Return average of absolute percentage changes
        if changes:
            return sum(changes) / len(changes)
        return 0
    
    def update_price_history(self, asset, price):
        """Met à jour l'historique des prix pour un actif"""
        with self.lock:
            if asset not in self.price_history:
                self.price_history[asset] = []
                
            # Keep a limited history (last 20 price points)
            self.price_history[asset].append(price)
            if len(self.price_history[asset]) > 20:
                self.price_history[asset] = self.price_history[asset][-20:]
    
    def update_volatile_assets(self, all_assets):
        """Update the list of volatile assets to trade based on price movements"""
        with self.lock:
            # Calculate volatility for each asset
            for asset in all_assets:
                if asset == "USDT":  # Skip stable coins
                    continue
                    
                try:
                    # Get current price and update history
                    price = self.get_ticker_price(f"{asset}/USDT")
                    self.update_price_history(asset, price)
                    
                    # Calculate volatility
                    volatility = self.calculate_volatility(asset)
                    self.asset_volatility[asset] = volatility
                    
                    # Calculate bubble score (if asset has enough price history)
                    bubble_score = self.calculate_bubble_score(asset)
                    if bubble_score is not None:
                        self.asset_volatility[f"{asset}_bubble_score"] = bubble_score
                    
                    # Check if it meets the threshold for trading
                    is_bubble = bubble_score is not None and bubble_score > 0.7  # 70% confidence it's a bubble
                    
                    if volatility >= self.volatility_threshold or is_bubble:
                        if asset not in self.volatile_assets:
                            if is_bubble:
                                logger.info(f"Adding {asset} to volatile assets list - POTENTIAL BUBBLE DETECTED (score: {bubble_score:.2f})")
                            else:
                                logger.info(f"Adding {asset} to volatile assets list (volatility: {volatility:.2f}%)")
                            self.volatile_assets.append(asset)
                    elif asset in self.volatile_assets:
                        logger.info(f"Removing {asset} from volatile assets list (volatility: {volatility:.2f}%)")
                        self.volatile_assets.remove(asset)
                except Exception as e:
                    logger.error(f"Error checking volatility for {asset}: {str(e)}")
    
    def calculate_momentum(self, asset):
        """Calculate momentum score for an asset (-1 to 1)"""
        if asset not in self.price_history or len(self.price_history[asset]) < 8:
            return 0
            
        prices = self.price_history[asset]
        
        # Calculate short-term trend (last 3 periods)
        short_term = prices[-1] - prices[-3] if len(prices) >= 3 else 0
        
        # Calculate medium-term trend (last 8 periods)
        medium_term = prices[-1] - prices[-8] if len(prices) >= 8 else 0
        
        # Normalize trends based on current price
        if prices[-1] > 0:
            short_term_normalized = short_term / prices[-1]
            medium_term_normalized = medium_term / prices[-1]
            
            # Combine trends with more weight on recent movement
            momentum = (short_term_normalized * 0.7) + (medium_term_normalized * 0.3)
            
            # Normalize to -1 to 1 range
            momentum = max(-1, min(1, momentum * 10))
            return momentum
            
        return 0
        
    def has_strong_momentum(self, asset):
        """Check if asset has strong positive momentum"""
        momentum = self.calculate_momentum(asset)
        volatility = self.asset_volatility.get(asset, 0)
        bubble_score = self.asset_volatility.get(f"{asset}_bubble_score", 0)
        
        # Strong momentum is defined as positive momentum + high volatility or bubble formation
        strong_momentum = (
            momentum > 0.3 and 
            (volatility > self.volatility_threshold * 1.5 or 
             (bubble_score is not None and bubble_score > 0.5))
        )
        
        return strong_momentum
    
    def dynamic_stop_loss(self, current_price, entry_price, momentum_factor=1.5, volatility=None, asset=None):
        """
        Calcule un stop-loss dynamique basé sur le mouvement du prix, le momentum et la volatilité
        Retourne un stop-loss intelligent qui protège le capital tout en permettant le day trading
        """
        # Cas spécial pour AUDIO - stop-loss fixe à 0.08 comme demandé par l'utilisateur
        if asset == 'AUDIO':
            logger.info(f"Stop-loss fixe pour AUDIO à 0.08 comme demandé par l'utilisateur")
            return 0.08
            
        # Si pas de prix d'entrée connu, stop-loss conservateur à 5% sous le prix actuel
        if entry_price == 0 or entry_price is None:
            return current_price * 0.95
        
        # Stop-loss de base à 10% sous le prix d'entrée (protection du capital)
        base_stop_loss = entry_price * 0.9
        
        # Mode spécial pour les actifs très volatils
        if volatility is not None and volatility > 0:
            # Plus l'actif est volatil, plus le stop-loss doit être large pour éviter les sorties prématurées
            # Mais avec des limites strictes pour éviter des pertes trop importantes
            volatility_adjustment = min(1.0 + (volatility / 20.0), 2.0)  # Plafond à 2x la volatilité
            min_protection = max(0.8, 0.9 - (volatility / 100.0))  # Au moins 80% de protection
            
            # Ajuster le stop-loss de base selon la volatilité
            base_stop_loss = entry_price * min_protection
            logger.debug(f"Stop-loss ajusté pour volatilité {volatility:.2f}% sur {asset}: {base_stop_loss:.6f}")
        
        # Gestion du trailing stop-loss si nous sommes en profit
        if current_price > entry_price:
            # Calcul du pourcentage de profit actuel
            profit_percentage = (current_price / entry_price) - 1
            trailing_stop = current_price * 0.95  # Par défaut 5% sous le prix actuel
            
            # Déterminer le type de stop-loss à utiliser en fonction du profit
            if profit_percentage >= 0.4:  # +40% ou plus
                # Protection forte des gains significatifs - stop-loss serré à 7% sous le prix actuel
                trailing_stop = current_price * 0.93
                
            elif profit_percentage >= 0.2:  # +20% à +40%
                # Protection modérée des gains moyens - stop-loss à 10% sous le prix actuel
                trailing_stop = current_price * 0.90
                
            elif profit_percentage >= 0.1:  # +10% à +20%
                # Stop-loss qui protège contre les retournements mais dépend du momentum
                protection = 0.85 if momentum_factor > 1.2 else 0.88
                trailing_stop = current_price * protection
            
            # Utiliser le stop-loss le plus protecteur (le plus élevé) entre le stop-loss de base et le trailing
            return max(base_stop_loss, trailing_stop)
        
        # Si pas de profit, retourner le stop-loss de base
        return base_stop_loss
    
    def execute_trade_logic(self, asset, force_trade_percentage=None):
        """
        Execute the trading logic for a specific asset
        
        Args:
            asset (str): The asset to evaluate for trading
            force_trade_percentage (float, optional): If set, forces a buy with this percentage of USDT balance
        
        Special trading plan for AUDIO:
        - Fixed stop-loss at 0.08 regardless of volatility or momentum
        - More cautious buying near all-time highs (>0.10)
        - Scale out of positions starting at 0.095 with 25% of the position
        - Hold remaining position for potential further upside
        """
        result = {
            "trade_executed": False,
            "asset": asset
        }
        
        try:
            symbol = f"{asset}/USDT"
            balances = self.get_balances()
            price = self.get_ticker_price(symbol)
            sentiment = self.analyze_sentiment(asset)
            
            # Update price history for volatility calculation
            self.update_price_history(asset, price)
            volatility = self.asset_volatility.get(asset, 0)
            bubble_score = self.asset_volatility.get(f"{asset}_bubble_score", 0)
            
            # Debug logs
            logger.info(f"Asset: {asset}, Price: {price}, Sentiment: {sentiment}, Volatility: {volatility}%, Bubble Score: {bubble_score}")
            
            # Handle forced trade if specified
            if force_trade_percentage is not None and force_trade_percentage > 0:
                usdt_balance = balances.get("USDT", 0)
                if usdt_balance > 0:
                    trade_amount = (usdt_balance * force_trade_percentage) / price
                    if trade_amount * price >= 1:  # Minimum $1 trade
                        logger.info(f"FORCED BUY: {asset} - Using {force_trade_percentage*100}% of USDT balance ({usdt_balance * force_trade_percentage} USDT)")
                        buy_result = self.exchange.buy(symbol, trade_amount)
                        if buy_result:
                            result["trade_executed"] = True
                            result["action"] = "buy (forced)"
                            result["amount"] = trade_amount
                            result["forced_percentage"] = force_trade_percentage
                            self.entry_prices[asset] = price
                            return result
            
            # Special handling for GARI - we want to analyze if it should be traded for something more bullish
            gari_balance = balances.get('GARI', 0)
            if asset == 'GARI' and gari_balance > 0:
                # Check if there are better opportunities than holding GARI
                if sentiment < 0 or (bubble_score < 0.3 and volatility < self.volatility_threshold):
                    # Look for opportunities to trade GARI for more bullish assets
                    result["considering_trade"] = "Looking for better opportunities than GARI"
                else:
                    # GARI looks good, keep holding
                    result["considering_trade"] = "GARI performing well, holding position"
            
            # Store current price as entry price if not set
            if asset not in self.entry_prices:
                self.entry_prices[asset] = price
            
            # Check for strong momentum
            has_momentum = self.has_strong_momentum(asset)
            momentum_score = self.calculate_momentum(asset)
            
            # Calculate dynamic stop-loss considering volatility and momentum
            stop_loss = self.dynamic_stop_loss(
                price, 
                self.entry_prices[asset], 
                volatility=volatility,
                asset=asset
            )
            result["stop_loss"] = stop_loss
            
            # Include momentum and bubble information in result
            result["momentum"] = momentum_score
            result["bubble_score"] = bubble_score
            result["has_strong_momentum"] = has_momentum
            
            # Check if stop-loss triggered or scaling out is needed
            if asset in balances and balances[asset] > 0:
                # Start implementing scaling out strategy for all assets
                # Check if we have an entry price
                if asset in self.entry_prices and self.entry_prices[asset] > 0:
                    entry_price = self.entry_prices[asset]
                    
                    # Check how many times we've already scaled out for this asset
                    scale_out_count = self.asset_volatility.get(f"{asset}_scale_out_count", 0)
                    
                    # Calculate profit levels for scaling out
                    # For AUDIO, we use fixed price levels as requested
                    if asset == 'AUDIO':
                        # Special case for AUDIO - use fixed price levels
                        if scale_out_count >= 2:
                            # Already scaled out twice, actively manage remaining 50%
                            # Look for signs of momentum weakening or pullback
                            momentum_score = self.calculate_momentum(asset)
                            sentiment = self.analyze_sentiment(asset)
                            
                            # Day trading mode for the remaining 50%:
                            # 1. Sell on momentum reversal or sentiment drop
                            # 2. Sell on negative divergence or resistance touch
                            # 3. Consider market volatility and price action speed
                            
                            # Calculer la vitesse du mouvement de prix (accélération)
                            price_history = self.price_history.get(asset, [])
                            price_acceleration = 0
                            if len(price_history) >= 3:
                                # Calculer l'accélération du prix (la variation de la vitesse)
                                last_change = (price_history[-1] - price_history[-2]) / price_history[-2] if price_history[-2] > 0 else 0
                                previous_change = (price_history[-2] - price_history[-3]) / price_history[-3] if price_history[-3] > 0 else 0
                                price_acceleration = last_change - previous_change
                            
                            # Ajouter des critères de day trading plus dynamiques
                            if ((momentum_score < 0.2 and price > entry_price * 1.3) or       # Momentum s'affaiblissant à profit élevé
                                (sentiment < -0.1 and price > entry_price * 1.15) or          # Sentiment devenant négatif
                                (momentum_score < -0.2) or                                    # Fort momentum baissier
                                (price_acceleration < -0.02 and price > entry_price * 1.1) or # Ralentissement soudain après un gain
                                (price < price_history[-2] * 0.97 and price > entry_price * 1.1)):  # Baisse brutale de 3% après un gain
                                
                                # Sell remaining position
                                trade_size = balances[asset]  # Remaining position
                                logger.info(f"AUDIO day trading: Selling remaining {trade_size} at {price} - momentum weakening")
                                self.exchange.sell(symbol, trade_size)
                                result["trade_executed"] = True
                                result["action"] = "sell (day trading - momentum shift)"
                                result["amount"] = trade_size
                                # Reset scale-out counter
                                self.asset_volatility[f"{asset}_scale_out_count"] = 0
                                return result
                        
                        # First two scale-out levels remain the same
                        elif price >= 0.105 and scale_out_count < 2:
                            # Scale out another 25% at 0.105 (high profit)
                            trade_size = balances[asset] * 0.25  # 25% of remaining position
                            logger.info(f"AUDIO reached 0.105, scaling out 25% of position ({trade_size} AUDIO)")
                            self.exchange.sell(symbol, trade_size)
                            
                            # Enregistrer cette prise de profit dans les résultats
                            result["trade_executed"] = True
                            result["action"] = "sell (scale-out tier 2)"
                            result["amount"] = trade_size
                            
                            # Increment scale-out counter
                            self.asset_volatility[f"{asset}_scale_out_count"] = scale_out_count + 1
                            
                            # Calculer les conditions pour day trading immédiatement
                            # Pas de return pour continuer le trading en mode day trading
                            
                        elif price >= 0.095 and scale_out_count < 1:
                            # Scale out 25% at 0.095
                            trade_size = balances[asset] * 0.25  # 25% of position
                            logger.info(f"AUDIO reached 0.095, scaling out 25% of position ({trade_size} AUDIO)")
                            self.exchange.sell(symbol, trade_size)
                            
                            # Enregistrer la transaction
                            result["trade_executed"] = True
                            result["action"] = "sell (scale-out tier 1)"
                            result["amount"] = trade_size
                            
                            # Increment scale-out counter
                            self.asset_volatility[f"{asset}_scale_out_count"] = 1
                            
                            # Continuer en mode day trading - pas de return
                            
                    else:
                        # For other assets, use percentage-based scaling out and day trading
                        if scale_out_count >= 2:
                            # Already scaled out twice (50%), now actively day trade the rest
                            momentum_score = self.calculate_momentum(asset)
                            sentiment = self.analyze_sentiment(asset)
                            volatility = self.asset_volatility.get(asset, 0)
                            
                            # Check for signs of weakening momentum to sell in day trading mode
                            if ((momentum_score < 0.1 and price > entry_price * 1.5) or   # Strong profit but weakening momentum
                                (sentiment < -0.2) or                                     # Sentiment turning significantly negative
                                (momentum_score < -0.3) or                               # Strong downward momentum
                                (volatility > self.volatility_threshold * 2 and momentum_score < 0)):  # High volatility + negative momentum
                                
                                # Sell remaining position
                                trade_size = balances[asset]  # Remaining position
                                logger.info(f"{asset} day trading: Selling remaining {trade_size} at {price} - market conditions changing")
                                self.exchange.sell(symbol, trade_size)
                                result["trade_executed"] = True
                                result["action"] = "sell (day trading - market shift)"
                                result["amount"] = trade_size
                                # Reset scale-out counter
                                self.asset_volatility[f"{asset}_scale_out_count"] = 0
                                return result
                                
                        # Tier 2: 40% profit - scale out 25% 
                        elif price >= entry_price * 1.40 and scale_out_count < 2:
                            trade_size = balances[asset] * 0.25  # 25% of position
                            logger.info(f"{asset} reached 40% profit, scaling out 25% of position ({trade_size} {asset})")
                            self.exchange.sell(symbol, trade_size)
                            
                            # Enregistrer la transaction
                            result["trade_executed"] = True
                            result["action"] = "sell (scale-out tier 2)"
                            result["amount"] = trade_size
                            
                            # Increment scale-out counter
                            self.asset_volatility[f"{asset}_scale_out_count"] = scale_out_count + 1
                            
                            # Mode day trading continu - ne pas quitter avec return
                            
                        # Tier 1: 20% profit - scale out 25%
                        elif price >= entry_price * 1.20 and scale_out_count < 1:
                            trade_size = balances[asset] * 0.25  # 25% of position
                            logger.info(f"{asset} reached 20% profit, scaling out 25% of position ({trade_size} {asset})")
                            self.exchange.sell(symbol, trade_size)
                            
                            # Enregistrer la transaction
                            result["trade_executed"] = True
                            result["action"] = "sell (scale-out tier 1)"
                            result["amount"] = trade_size
                            
                            # Increment scale-out counter
                            self.asset_volatility[f"{asset}_scale_out_count"] = 1
                            
                            # Mode day trading continu - pas de return pour continuer l'analyse
                
                # Gestion du stop-loss intelligente - priorité absolue pour protéger le capital
                if price <= stop_loss and self.entry_prices[asset] > 0:
                    # Vérifier si c'est un actif avec un fort momentum qui est simplement en cours de correction
                    # Dans ce cas, on adapte le stop loss plutôt que de vendre
                    strong_momentum_exception = (
                        has_momentum and 
                        momentum_score > 0.6 and  # Momentum fort
                        price > self.entry_prices[asset] * 1.15 and  # Toujours en bon profit (>15%)
                        volatility < self.volatility_threshold * 2.5  # Volatilité pas trop excessive
                    )
                    
                    bubble_score_exception = (
                        bubble_score > 0.8 and  # Forte indication de bulle
                        price > self.entry_prices[asset] * 1.3 and  # Très bon profit (>30%)
                        sentiment > 0  # Sentiment toujours positif
                    )
                    
                    # Vérifier l'accélération du prix récente
                    recent_trend_down = False
                    if asset in self.price_history and len(self.price_history[asset]) >= 3:
                        p1, p2, p3 = self.price_history[asset][-3:]
                        # Si on a trois baisses consécutives, c'est une tendance baissière claire
                        if p3 < p2 < p1 and (p1 - p3) / p1 > 0.05:  # Baisse de plus de 5% sur les 3 derniers points
                            recent_trend_down = True
                            logger.info(f"{asset} en baisse constante sur les 3 derniers points: {p1} > {p2} > {p3}")
                    
                    # Exception pour les actifs à fort momentum ou en bulle, mais pas s'ils sont en tendance baissière
                    if (strong_momentum_exception or bubble_score_exception) and not recent_trend_down:
                        # Actif spécial avec fort momentum/bulle - adapter le stop loss au lieu de vendre
                        logger.info(f"Adaptation du stop-loss pour {asset} en raison d'un fort momentum/bulle (prix: {price}, entrée: {self.entry_prices[asset]})")
                        # Mettre à jour le stop loss à 15% sous le prix actuel pour laisser courir les profits
                        dynamic_stop = price * 0.85
                        # Mais ne jamais descendre sous l'ancien stop loss (protection minimale)
                        new_stop = max(stop_loss * 0.9, dynamic_stop)
                        result["stop_loss"] = new_stop
                        logger.info(f"Nouveau stop-loss dynamique pour {asset}: {new_stop}")
                    else:
                        # Stop-loss déclenché - vendre tout
                        trade_size = balances[asset]
                        if trade_size > 0:
                            logger.info(f"STOP-LOSS DÉCLENCHÉ pour {asset} à {price} (entrée: {self.entry_prices[asset]}, stop: {stop_loss})")
                            self.exchange.sell(symbol, trade_size)
                            result["trade_executed"] = True
                            result["action"] = "sell (stop-loss)"
                            result["amount"] = trade_size
                            # Réinitialiser l'état de scaling out
                            self.asset_volatility[f"{asset}_scale_out_count"] = 0
                            # Mise à jour du prix d'entrée au prix actuel (pour référence future)
                            self.entry_prices[asset] = price
                            return result  # Sortir après un stop-loss
            
            # Trading based on sentiment, but considering volatility and bubbles
            # Only trade assets with sufficient volatility for profit potential
            if volatility >= self.volatility_threshold or asset in ["BTC", "ETH"] or bubble_score > 0.7:
                # Enhance buy signal if asset has strong momentum or bubble score
                buy_threshold = 0.1
                if bubble_score > 0.7:
                    buy_threshold = 0
                elif has_momentum:
                    buy_threshold = -0.05  # Even slightly negative sentiment is acceptable for strong momentum assets
                
                if sentiment > buy_threshold:
                    # For AUDIO, be more cautious at higher price levels
                    if asset == 'AUDIO' and price > 0.10:
                        logger.info(f"Being more cautious with AUDIO as price ({price}) is near all-time high")
                        # Require stronger signals to buy near ATH
                        if sentiment < 0.4 or bubble_score < 0.5:
                            logger.info(f"Skipping AUDIO buy at high price due to insufficient bullish signals")
                            return result
                    
                    # Positive sentiment or momentum - buy
                    usdt_balance = balances.get("USDT", 0)
                    gari_balance = balances.get("GARI", 0)
                    
                    # If we have a large GARI balance and limited USDT, we can sell some GARI to buy other assets
                    # Only if GARI sentiment is weak or another asset has a much stronger momentum
                    gari_sentiment = self.analyze_sentiment('GARI') if 'GARI' in balances and balances['GARI'] > 0 else 0
                    
                    # If current asset has stronger signals than GARI, implement GARI trading to fund this
                    if (usdt_balance < 10 and gari_balance > 0 and 
                        asset != 'GARI' and 
                        (gari_sentiment < 0 or 
                         (bubble_score > 0.8 and sentiment > 0.5) or
                         (has_momentum and momentum_score > 0.7 and sentiment > 0.3))):
                        
                        # Determine how much GARI to sell based on opportunity strength
                        gari_trade_percentage = 0.10  # Start with 10% of GARI
                        
                        # Scale up based on how strong the opportunity is
                        if bubble_score > 0.9 and sentiment > 0.7:
                            # Extremely strong bubble signal - use up to entire balance minus fees
                            gari_trade_percentage = 0.995  # 99.5% (leaving 0.5% for fees)
                        elif bubble_score > 0.8 or (has_momentum and momentum_score > 0.8):
                            # Very strong signal - use up to 75%
                            gari_trade_percentage = 0.75
                        elif bubble_score > 0.7 or (has_momentum and momentum_score > 0.6):
                            # Strong signal - use up to 50%
                            gari_trade_percentage = 0.50
                        elif gari_sentiment < -0.3:
                            # GARI looks bearish - use up to 30%
                            gari_trade_percentage = 0.30
                        
                        gari_trade_amount = gari_balance * gari_trade_percentage
                        
                        logger.info(f"Not enough USDT, selling {gari_trade_percentage*100:.1f}% GARI to buy {asset} with strong signals")
                        result["gari_trade"] = f"Selling {gari_trade_percentage*100:.1f}% GARI to buy {asset}"
                        
                        try:
                            # Execute the GARI sell to get USDT
                            gari_sell_order = self.exchange.sell("GARI/USDT", gari_trade_amount)
                            
                            if gari_sell_order:
                                # Successfully sold GARI, now we have USDT to use for the current trade
                                # We need to update USDT balance
                                # This is approximate since we don't know exact filled price and fees
                                gari_price = self.get_ticker_price("GARI/USDT")
                                estimated_usdt = gari_trade_amount * gari_price * 0.998  # Account for ~0.2% fees
                                usdt_balance += estimated_usdt
                                
                                logger.info(f"Sold {gari_trade_amount} GARI for approximately {estimated_usdt} USDT")
                                result["gari_sold"] = f"Sold {gari_trade_amount} GARI for {estimated_usdt} USDT"
                        except Exception as e:
                            logger.error(f"Error selling GARI to fund {asset} purchase: {str(e)}")
                            result["gari_trade_error"] = str(e)
                    
                    if usdt_balance > 0:
                        # Increase position size for high momentum/bubble assets
                        position_multiplier = 1.0
                        if bubble_score > 0.8:
                            position_multiplier = 1.5  # 50% larger position for bubble assets
                        elif has_momentum and momentum_score > 0.7:
                            position_multiplier = 1.3  # 30% larger position for high momentum
                            
                        trade_size = self.calculate_trade_size(usdt_balance / price, price, volatility, asset) * position_multiplier
                        if trade_size > 0:
                            self.exchange.buy(symbol, trade_size)
                            result["trade_executed"] = True
                            result["action"] = "buy"
                            result["amount"] = trade_size
                            result["volatility"] = volatility
                            self.entry_prices[asset] = price
                
                elif sentiment < -0.1:
                    # Negative sentiment - sell
                    # BUT, if this is a momentum asset in profit, don't sell based solely on sentiment
                    asset_balance = balances.get(asset, 0)
                    if asset_balance > 0:
                        # Check if we should ignore the sell signal due to strong momentum
                        if has_momentum and momentum_score > 0.5 and price > self.entry_prices[asset] * 1.1:
                            logger.info(f"Ignoring negative sentiment for {asset} due to strong momentum")
                        else:
                            # No strong momentum, proceed with sell
                            trade_size = self.calculate_trade_size(asset_balance, price, volatility)
                            if trade_size > 0:
                                self.exchange.sell(symbol, trade_size)
                                result["trade_executed"] = True
                                result["action"] = "sell"
                                result["amount"] = trade_size
                                result["volatility"] = volatility
                                self.entry_prices[asset] = price
            
            return result
            
        except Exception as e:
            logger.error(f"Error executing trade logic for {asset}: {str(e)}")
            return result
            
    def calculate_bubble_score(self, asset):
        """
        Calculate a bubble score for an asset based on price history
        Return value from 0 (not a bubble) to 1 (definitely a bubble)
        """
        if asset not in self.price_history or len(self.price_history[asset]) < 10:
            return None  # Not enough data
            
        prices = self.price_history[asset]
        
        if not prices or prices[-1] == 0:
            return None
            
        # Calculate basic metrics
        current_price = prices[-1]
        avg_price = sum(prices) / len(prices)
        price_ratio = current_price / avg_price if avg_price > 0 else 1
            
        # Calculate price acceleration (second derivative)
        price_changes = []
        for i in range(1, len(prices)):
            if prices[i-1] > 0:
                price_changes.append((prices[i] - prices[i-1]) / prices[i-1])
                
        if len(price_changes) < 5:
            return None
        
        # Calculate if changes are accelerating (bubble characteristic)
        price_accelerations = []
        for i in range(1, len(price_changes)):
            price_accelerations.append(price_changes[i] - price_changes[i-1])
            
        # Positive acceleration indicates bubble formation
        avg_acceleration = sum(price_accelerations) / len(price_accelerations) if price_accelerations else 0
        
        # Calculate exponential growth score (key bubble characteristic)
        # Fit exponential curve and check fit quality
        try:
            x = list(range(len(prices)))
            y = prices
            log_y = [math.log(p) if p > 0 else 0 for p in y]
            valid_indices = [i for i, v in enumerate(log_y) if v > 0]
            
            if len(valid_indices) < 5:
                return None
                
            fit_x = [x[i] for i in valid_indices]
            fit_y = [log_y[i] for i in valid_indices]
            
            # Simple linear regression on log values to detect exponential growth
            n = len(fit_x)
            sum_x = sum(fit_x)
            sum_y = sum(fit_y)
            sum_x2 = sum(x*x for x in fit_x)
            sum_xy = sum(x*y for x, y in zip(fit_x, fit_y))
            
            # Calculate slope (exponential growth rate)
            m = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
            
            # Calculate exponential fit score (normalized exponential growth rate)
            exp_fit_score = math.tanh(m * 10) if m > 0 else 0  # Only positive growth rates matter for bubbles
            
            # Volume spike detection (not actually available but would be a factor)
            volume_spike_score = 0.5  # Placeholder without actual volume data
            
            # Calculate combined bubble score
            # Weightings can be adjusted based on importance of each factor
            bubble_score = (
                0.3 * price_ratio / 3.0 +  # Price ratio (capped at 3x average)
                0.3 * (avg_acceleration * 10 + 0.5) +  # Acceleration (normalized)
                0.4 * exp_fit_score      # Exponential growth fit
            )
            
            # Normalize to 0-1 range
            bubble_score = max(0, min(1, bubble_score))
            
            return bubble_score
            
        except Exception as e:
            logger.error(f"Error calculating bubble score for {asset}: {str(e)}")
            return None
    
    def get_top_volatile_assets(self, max_assets=None):
        """Get ALL volatile assets to trade, sorted by volatility with increased weighting"""
        # Create a thread-safe copy of the volatility data to avoid lock contention
        try:
            # Get volatility data for all assets
            volatility_data = dict(self.asset_volatility)
            
            # Calculate combined scores for each asset based on multiple factors
            asset_scores = {}
            
            for asset, volatility in volatility_data.items():
                # Skip bubble score entries and non-numeric volatility values
                if "_bubble_score" in asset or not isinstance(volatility, (int, float)) or asset == "USDT":
                    continue
                
                # Skip assets with insufficient volatility
                if volatility < self.volatility_threshold:
                    continue
                
                # Get bubble score if available
                bubble_score = volatility_data.get(f"{asset}_bubble_score", 0)
                
                # Calculate momentum score (or use 0 if not available)
                try:
                    momentum_score = self.calculate_momentum(asset)
                except:
                    momentum_score = 0
                
                # Heavily prioritize volatility (3x weight)
                # Also consider bubble potential (very high weight) and momentum
                combined_score = (volatility * 3) + (bubble_score * 50) + (momentum_score * 30)
                
                # Apply scaling out strategy to high-performing assets automatically
                # Check if we have an entry price to calculate percentage gain
                if asset in self.entry_prices and self.entry_prices[asset] > 0:
                    price = self.get_ticker_price(f"{asset}/USDT")
                    entry = self.entry_prices[asset]
                    # If asset has gained substantially, increase its score to ensure we trade it
                    if price >= entry * 1.20:  # 20% gain
                        logger.info(f"{asset} has 20%+ gain (entry: {entry}, current: {price}), boosting priority")
                        combined_score += 20  # Boost score to ensure we keep trading it
                
                # Exclude BTC, ETH and SOL completely as per user request
                if asset in ["BTC", "ETH", "XBT", "SOL", "SOLANA"]:
                    combined_score = -1  # Negative score will put them at the bottom of the list
                
                # Store the asset with all its scores
                asset_scores[asset] = {
                    "asset": asset,
                    "volatility": volatility,
                    "bubble_score": bubble_score,
                    "momentum_score": momentum_score,
                    "combined_score": combined_score
                }
            
            # Convert to list and sort by combined score (highest first)
            sorted_assets = sorted(
                list(asset_scores.values()),
                key=lambda x: x["combined_score"],
                reverse=True
            )
            
            # Log the top assets for debugging
            if sorted_assets:
                top_5 = sorted_assets[:5] if len(sorted_assets) >= 5 else sorted_assets
                logger.info(f"Top volatile assets with scores: {top_5}")
            
            # Limit assets if specified
            if max_assets is not None and max_assets > 0:
                return sorted_assets[:max_assets]
                
            return sorted_assets
        except Exception as e:
            logger.error(f"Error in get_top_volatile_assets: {str(e)}")
            return []  # Return empty list in case of error
