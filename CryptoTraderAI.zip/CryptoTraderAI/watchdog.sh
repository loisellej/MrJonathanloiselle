#!/bin/bash
while true; do
    # Vérifier si les processus sont toujours en cours d'exécution
    if ! ps -p $BOT_PID > /dev/null; then
        echo "$(date): Bot arrêté, redémarrage..." >> system_status.log
        nohup python3 ultra_stable_bot.py > bot_output.log 2>&1 &
        BOT_PID=$!
        echo "BOT_PID=$BOT_PID" >> system_status.log
    fi
    
    if ! ps -p $SUPERVISOR_PID > /dev/null; then
        echo "$(date): Superviseur arrêté, redémarrage..." >> system_status.log
        nohup python3 never_stop.py > supervisor_output.log 2>&1 &
        SUPERVISOR_PID=$!
        echo "SUPERVISOR_PID=$SUPERVISOR_PID" >> system_status.log
    fi
    
    # Attendre avant la prochaine vérification
    sleep 60
done
