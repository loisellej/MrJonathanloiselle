#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Module pour exécuter immédiatement un trade réel
Ce script force un trade réel maintenant sur les actifs les plus volatils
"""

import os
import time
import logging
import random
import krakenex

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("execute_trade.log"),
        logging.StreamHandler()
    ]
)

def get_api_credentials():
    """Récupère les clés API depuis les variables d'environnement"""
    api_key = os.environ.get("KRAKEN_API_KEY")
    api_secret = os.environ.get("KRAKEN_API_SECRET")
    
    if not api_key or not api_secret:
        logging.error("Clés API Kraken non trouvées dans les variables d'environnement")
        return None, None
    
    return api_key, api_secret

def get_balances(k):
    """Récupère les balances du compte Kraken"""
    try:
        response = k.query_private('Balance')
        if response.get('error'):
            logging.error(f"Erreur lors de la récupération des balances: {response['error']}")
            return {}
        
        balances = response.get('result', {})
        
        # Convertir les chaînes en nombres flottants
        formatted_balances = {}
        for asset, balance in balances.items():
            formatted_balances[asset] = float(balance)
        
        return formatted_balances
    except Exception as e:
        logging.error(f"Exception lors de la récupération des balances: {e}")
        return {}

def get_asset_pairs(k):
    """Récupère la liste des paires d'actifs disponibles sur Kraken"""
    try:
        response = k.query_public('AssetPairs')
        if response.get('error'):
            logging.error(f"Erreur lors de la récupération des paires d'actifs: {response['error']}")
            return {}
        
        return response.get('result', {})
    except Exception as e:
        logging.error(f"Exception lors de la récupération des paires d'actifs: {e}")
        return {}

def get_ticker(k, pair):
    """Récupère les informations de ticker pour une paire d'actifs"""
    for _ in range(3):  # Essayer 3 fois en cas d'erreur
        try:
            response = k.query_public('Ticker', {'pair': pair})
            if response.get('error'):
                logging.warning(f"Erreur ticker (tentative {_+1}/3): {response['error']} pour {pair}")
                time.sleep(0.5)
                continue
            
            return response.get('result', {})
        except Exception as e:
            logging.warning(f"Exception ticker (tentative {_+1}/3): {e} pour {pair}")
            time.sleep(0.5)
    
    logging.error(f"Impossible de récupérer le ticker pour {pair} après 3 tentatives")
    return {}

def get_volatility(k, pair):
    """Calcule la volatilité d'une paire d'actifs basée sur le ticker"""
    ticker_data = get_ticker(k, pair)
    if not ticker_data or pair not in ticker_data:
        return 0.0
    
    try:
        high = float(ticker_data[pair]['h'][0])
        low = float(ticker_data[pair]['l'][0])
        last = float(ticker_data[pair]['c'][0])
        
        # Calculer la volatilité comme l'amplitude High-Low en pourcentage du prix actuel
        if last > 0:
            volatility = ((high - low) / last) * 100
            return volatility
        return 0.0
    except (KeyError, ValueError, ZeroDivisionError) as e:
        logging.warning(f"Erreur lors du calcul de la volatilité pour {pair}: {e}")
        return 0.0

def find_volatile_pairs(k, quote="ZUSD", min_volume=10000, max_pairs=10):
    """Trouve les paires les plus volatiles parmi celles disponibles"""
    logging.info("Recherche des paires les plus volatiles...")
    
    all_pairs = get_asset_pairs(k)
    volatile_pairs = []
    
    # Filtrer les paires qui correspondent à nos critères
    for pair_name, pair_data in all_pairs.items():
        # Vérifier que la paire utilise la devise de cotation spécifiée
        if not pair_name.endswith(quote):
            continue
        
        # Récupérer la volatilité
        volatility = get_volatility(k, pair_name)
        
        # Ajouter la paire à notre liste si la volatilité est mesurable
        if volatility > 0:
            volatile_pairs.append({
                'pair': pair_name,
                'volatility': volatility,
                'base': pair_data.get('base', ''),
                'quote': pair_data.get('quote', '')
            })
    
    # Trier par volatilité décroissante
    volatile_pairs.sort(key=lambda x: x['volatility'], reverse=True)
    
    # Limiter au nombre demandé
    return volatile_pairs[:max_pairs]

def execute_market_order(k, pair, type, volume):
    """Exécute un ordre au marché"""
    try:
        # Ajouter un nonce supplémentaire pour éviter les erreurs de nonce
        rand_nonce = random.randint(1000, 100000)
        
        params = {
            'pair': pair,
            'type': type,  # 'buy' ou 'sell'
            'ordertype': 'market',
            'volume': str(volume),
            'nonce': str(int(time.time() * 1000) + rand_nonce)
        }
        
        logging.info(f"Exécution de l'ordre: {type} {volume} {pair}")
        response = k.query_private('AddOrder', params)
        
        if response.get('error'):
            logging.error(f"Erreur lors de l'exécution de l'ordre: {response['error']}")
            return None
        
        logging.info(f"Ordre exécuté avec succès: {response.get('result')}")
        return response.get('result')
    except Exception as e:
        logging.error(f"Exception lors de l'exécution de l'ordre: {e}")
        return None

def execute_volatile_trade():
    """Exécute un trade sur un actif volatil"""
    # Récupérer les clés API
    api_key, api_secret = get_api_credentials()
    if not api_key or not api_secret:
        return False
    
    # Initialiser l'API Kraken
    k = krakenex.API(api_key, api_secret)
    
    # Récupérer les balances
    balances = get_balances(k)
    if not balances:
        logging.error("Impossible de récupérer les balances")
        return False
    
    # Vérifier s'il y a assez d'USD pour trader
    usd_balance = balances.get('ZUSD', 0)
    if usd_balance < 2:
        logging.warning(f"Solde USD insuffisant pour trader: {usd_balance}")
        
        # Rechercher un autre actif à vendre
        for asset, balance in balances.items():
            # Ignorer USD et les actifs avec solde insignifiant
            if asset == 'ZUSD' or balance < 0.001:
                continue
            
            # Trouver une paire de trading pour cet actif
            pair_name = None
            for pair in get_asset_pairs(k).keys():
                if pair.startswith(asset) and pair.endswith('ZUSD'):
                    pair_name = pair
                    break
            
            if pair_name:
                # Calculer le montant à vendre (50% de la position)
                sell_amount = balance * 0.5
                logging.info(f"Tentative de vente de {sell_amount} {asset} via {pair_name}")
                
                # Exécuter l'ordre de vente
                result = execute_market_order(k, pair_name, 'sell', sell_amount)
                if result:
                    logging.info(f"Vente réussie: {result}")
                    time.sleep(5)  # Attendre que l'ordre soit traité
                    balances = get_balances(k)  # Mettre à jour les balances
                    usd_balance = balances.get('ZUSD', 0)
                    break
    
    # Si toujours pas assez d'USD, abandonner
    if usd_balance < 2:
        logging.error("Impossible de libérer suffisamment d'USD pour trader")
        return False
    
    # Trouver les paires volatiles
    volatile_pairs = find_volatile_pairs(k)
    if not volatile_pairs:
        logging.error("Aucune paire volatile trouvée")
        return False
    
    # Choisir la paire la plus volatile
    target_pair = volatile_pairs[0]
    logging.info(f"Paire la plus volatile: {target_pair['pair']} (volatilité: {target_pair['volatility']:.2f}%)")
    
    # Calculer le montant à acheter (95% du solde USD disponible)
    buy_amount_usd = usd_balance * 0.95
    
    # Obtenir le prix actuel
    ticker = get_ticker(k, target_pair['pair'])
    if not ticker or target_pair['pair'] not in ticker:
        logging.error(f"Impossible de récupérer le prix pour {target_pair['pair']}")
        return False
    
    # Calculer le volume en unités de l'actif de base
    current_price = float(ticker[target_pair['pair']]['c'][0])
    volume = buy_amount_usd / current_price
    
    # Arrondir à 8 décimales (standard pour les crypto)
    volume = round(volume, 8)
    
    logging.info(f"Achat de {volume} {target_pair['base']} à environ {current_price} USD")
    
    # Exécuter l'ordre d'achat
    result = execute_market_order(k, target_pair['pair'], 'buy', volume)
    if not result:
        logging.error("Échec de l'exécution de l'ordre d'achat")
        return False
    
    logging.info(f"Trade exécuté avec succès: {result}")
    logging.info(f"TRANSACTION ID: {result.get('txid', ['AUCUN'])[0]}")
    
    return True

if __name__ == "__main__":
    logging.info("=== EXÉCUTION D'UN TRADE RÉEL IMMÉDIAT ===")
    
    success = execute_volatile_trade()
    
    if success:
        logging.info("✅ Trade exécuté avec succès")
    else:
        logging.error("❌ Échec de l'exécution du trade")