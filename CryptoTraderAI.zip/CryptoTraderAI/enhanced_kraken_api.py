#!/usr/bin/env python3
"""
API Kraken Améliorée
Version améliorée de l'API Kraken avec gestion robuste des nonces et retry
Résout les problèmes d'erreur de nonce ('EAPI:Invalid nonce')
"""
import time
import logging
import krakenex
from kraken_nonce_manager import get_new_nonce, reset_kraken_nonce

logger = logging.getLogger("EnhancedKrakenAPI")

class EnhancedKrakenAPI:
    """
    API Kraken améliorée avec gestion robuste des nonces
    et mécanisme de retry en cas d'erreur
    """
    def __init__(self, api_key, api_secret, retry_attempts=3, retry_delay=0.5):
        """
        Initialise l'API Kraken améliorée
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
            retry_attempts (int): Nombre de tentatives en cas d'erreur
            retry_delay (float): Délai entre les tentatives (en secondes)
        """
        self.k = krakenex.API(api_key, api_secret)
        self.retry_attempts = retry_attempts
        self.retry_delay = retry_delay
        self.is_initialized = True
        
        # Remplacer la fonction de génération de nonce par notre gestionnaire avancé
        self.k.nonce = get_new_nonce
    
    def query_public(self, method, req=None):
        """
        Exécute une requête publique avec retry
        
        Args:
            method (str): Méthode API publique
            req (dict, optional): Paramètres de la requête
        
        Returns:
            dict: Résultat de la requête
        """
        req = req or {}
        for attempt in range(self.retry_attempts):
            try:
                result = self.k.query_public(method, req)
                if 'error' in result and result['error']:
                    error_msg = result['error'][0] if result['error'] else 'Unknown error'
                    logger.warning(f"Erreur API publique ({attempt+1}/{self.retry_attempts}): {error_msg}")
                    if attempt == self.retry_attempts - 1:
                        return result  # Retourner le résultat avec erreur après toutes les tentatives
                    time.sleep(self.retry_delay * (attempt + 1))  # Délai exponentiel
                    continue
                return result  # Succès
                
            except Exception as e:
                logger.warning(f"Exception dans query_public ({attempt+1}/{self.retry_attempts}): {e}")
                if attempt == self.retry_attempts - 1:
                    raise  # Relancer l'exception après toutes les tentatives
                time.sleep(self.retry_delay * (attempt + 1))  # Délai exponentiel
    
    def query_private(self, method, req=None):
        """
        Exécute une requête privée avec gestion des nonces et retry
        
        Args:
            method (str): Méthode API privée
            req (dict, optional): Paramètres de la requête
        
        Returns:
            dict: Résultat de la requête
        """
        req = req or {}
        for attempt in range(self.retry_attempts):
            try:
                # Utilisation de notre gestionnaire de nonce avancé
                result = self.k.query_private(method, req)
                
                if 'error' in result and result['error']:
                    error_msg = result['error'][0] if result['error'] else 'Unknown error'
                    logger.warning(f"Erreur API privée ({attempt+1}/{self.retry_attempts}): {error_msg}")
                    
                    # Gérer spécifiquement l'erreur de nonce
                    if 'EAPI:Invalid nonce' in error_msg:
                        logger.info("Erreur de nonce détectée, réinitialisation...")
                        if attempt == self.retry_attempts - 1:
                            # Réinitialiser le nonce en cas d'échec persistant
                            reset_kraken_nonce()
                            logger.warning("Nonce réinitialisé après échecs multiples")
                        # Nouvelle tentative après un délai
                        time.sleep(self.retry_delay * (attempt + 1))
                        continue
                    
                    # Autres erreurs non récupérables
                    if attempt == self.retry_attempts - 1:
                        return result  # Retourner le résultat avec erreur après toutes les tentatives
                    
                    time.sleep(self.retry_delay * (attempt + 1))  # Délai exponentiel
                    continue
                
                return result  # Succès
                
            except Exception as e:
                logger.warning(f"Exception dans query_private ({attempt+1}/{self.retry_attempts}): {e}")
                if attempt == self.retry_attempts - 1:
                    raise  # Relancer l'exception après toutes les tentatives
                time.sleep(self.retry_delay * (attempt + 1))  # Délai exponentiel

def create_enhanced_api(api_key, api_secret):
    """
    Crée une instance de l'API Kraken améliorée
    
    Args:
        api_key (str): Clé API Kraken
        api_secret (str): Clé secrète API Kraken
    
    Returns:
        EnhancedKrakenAPI: Instance de l'API Kraken améliorée
    """
    return EnhancedKrakenAPI(api_key, api_secret)

# Test de l'API si ce script est exécuté directement
if __name__ == "__main__":
    import os
    from dotenv import load_dotenv
    
    # Configurer le logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Charger les clés API depuis .env
    load_dotenv()
    api_key = os.environ.get('KRAKEN_API_KEY')
    api_secret = os.environ.get('KRAKEN_API_SECRET')
    
    if not api_key or not api_secret:
        logger.error("❌ Clés API non trouvées dans .env")
        exit(1)
    
    print("Test de l'API Kraken Améliorée")
    print("-----------------------------")
    
    # Créer l'API
    api = create_enhanced_api(api_key, api_secret)
    
    # Tester une requête publique
    print("📊 Test d'une requête publique (Time)...")
    time_result = api.query_public('Time')
    print(f"  Résultat: {time_result}")
    
    # Tester une requête privée
    print("\n🔒 Test d'une requête privée (Balance)...")
    balance_result = api.query_private('Balance')
    
    if 'error' in balance_result and balance_result['error']:
        print(f"  ❌ Erreur: {balance_result['error']}")
    else:
        print(f"  ✅ Balance récupérée avec succès")
        # Afficher les balances non nulles
        balances = []
        for asset, amount in balance_result['result'].items():
            amount_float = float(amount)
            if amount_float > 0.001:  # Ignorer les très petits soldes
                balances.append(f"{asset}: {amount_float:.6f}")
        
        if balances:
            print(f"  Balances: {', '.join(balances)}")
        else:
            print("  Aucune balance significative trouvée")
    
    print("\n✅ Test terminé")