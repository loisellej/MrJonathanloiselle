#!/bin/bash
# Script de démarrage automatique pour le bot de trading sur Replit

echo "=== DÉMARRAGE DU BOT DE TRADING ==="
date

# Arrêter toute instance précédente du bot
if [ -f trader.pid ]; then
    PREVIOUS_PID=$(cat trader.pid)
    if ps -p $PREVIOUS_PID > /dev/null; then
        echo "Arrêt de l'instance précédente du bot (PID: $PREVIOUS_PID)..."
        kill $PREVIOUS_PID
        sleep 2
    fi
    rm trader.pid
fi

# Vérifier les clés API Kraken
echo "Vérification des clés API Kraken..."
if [ -z "$KRAKEN_API_KEY" ] || [ -z "$KRAKEN_API_SECRET" ]; then
    echo "⚠️ ATTENTION: Clés API Kraken non trouvées dans les variables d'environnement!"
    echo "Veuillez configurer vos clés API Kraken en utilisant l'une des méthodes suivantes:"
    echo "1. ./update_api_keys.py (pour configurer des secrets Replit)"
    echo "2. ./update_api_keys_direct.py (pour mettre à jour directement le fichier)"
    exit 1
fi

# Exporter les variables d'environnement des clés API Kraken
# Ces valeurs sont stockées dans les secrets de Replit
export KRAKEN_API_KEY="$KRAKEN_API_KEY"
export KRAKEN_API_SECRET="$KRAKEN_API_SECRET"

# Démarrer le bot de trading en arrière-plan
echo "Démarrage du bot de trading en arrière-plan..."
python3 ultra_volatility_trader.py > trading.log 2>&1 &
TRADER_PID=$!
echo $TRADER_PID > trader.pid
echo "Bot démarré avec PID: $TRADER_PID"

# Vérifier l'état du bot après 5 secondes
echo "Vérification de l'état du bot..."
sleep 5
if ps -p $TRADER_PID > /dev/null; then
    echo "Bot démarré avec succès!"
    
    # Vérifier les premiers logs pour détecter des erreurs
    if grep -q "EAPI:Invalid key" trading.log; then
        echo "⚠️ ERREUR DÉTECTÉE: Clés API Kraken invalides!"
        echo "Veuillez configurer vos clés API Kraken en utilisant l'une des méthodes suivantes:"
        echo "1. ./update_api_keys.py (pour configurer des secrets Replit)"
        echo "2. ./update_api_keys_direct.py (pour mettre à jour directement le fichier)"
        kill $TRADER_PID
        rm trader.pid
        exit 1
    fi
else
    echo "Erreur: Le bot n'a pas démarré correctement."
    exit 1
fi

echo "=== BOT DE TRADING DÉMARRÉ AVEC SUCCÈS ==="
echo "Les logs sont disponibles dans trading.log"
echo ""
echo "Vous pouvez vérifier l'état du bot à tout moment avec:"
echo "  python3 check_status.py"
echo ""

# Garder le script en cours d'exécution pour que Replit continue à fonctionner
# Afficher les dernières lignes du log toutes les 60 secondes
while true; do
    echo "----- $(date) -----"
    echo "État actuel du bot (PID: $TRADER_PID):"
    
    # Vérifier si le bot tourne toujours
    if ! ps -p $TRADER_PID > /dev/null; then
        echo "⚠️ ALERTE: Le bot s'est arrêté! Tentative de redémarrage..."
        
        # Redémarrer le bot
        python3 ultra_volatility_trader.py > trading.log 2>&1 &
        TRADER_PID=$!
        echo $TRADER_PID > trader.pid
        echo "Bot redémarré avec nouveau PID: $TRADER_PID"
    fi
    
    # Afficher les dernières entrées du journal
    tail -n 15 trading.log
    
    # Afficher les balances actuelles
    echo ""
    echo "Dernières transactions et balances:"
    python3 check_status.py
    
    # Attendre avant la prochaine vérification
    echo ""
    echo "Prochaine actualisation dans 60 secondes..."
    sleep 60
done