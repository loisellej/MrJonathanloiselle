#!/usr/bin/env python3
"""
Script pour démarrer le bot de trading en mode 24/7 avec les clés API intégrées
Ce script est conçu pour être exécuté sur Replit et fonctionner en continu
"""
import os
import time
import logging
import threading
import krakenex
import concurrent.futures
from datetime import datetime
from dotenv import load_dotenv

# Charger les variables d'environnement depuis .env
load_dotenv()

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("trader_24_7.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Performance logger
perf_logger = logging.getLogger("performance")
perf_handler = logging.FileHandler("performance_metrics.log")
perf_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(message)s'))
perf_logger.addHandler(perf_handler)
perf_logger.setLevel(logging.INFO)

def log_performance(stage, start_time, asset=None):
    """Log les métriques de performance d'une étape
    
    Args:
        stage (str): Nom de l'étape (fetch_data, analyze, etc.)
        start_time (float): Temps de démarrage (time.perf_counter())
        asset (str, optional): Actif concerné
    """
    duration_ms = (time.perf_counter() - start_time) * 1000
    asset_info = f" [{asset}]" if asset else ""
    perf_logger.info(f"{stage}{asset_info}: {duration_ms:.3f} ms")

# Clés API Kraken - importation depuis le module centralisé
from api_keys import get_api_credentials
API_KEY, API_SECRET = get_api_credentials()
logger.info(f"Clés API: {API_KEY[:5]}...{API_KEY[-5:] if API_KEY else 'MANQUANTE'}")

# Crypto-monnaies à surveiller pour opportunities
WATCH_LIST = [
    "ZEREBRO", "MANA", "FTM", "GARI", "AVAX", "LINK", "DOGE", "SHIB", "MATIC",
    "DOT", "ADA", "ATOM", "XRP", "SAND", "ALGO", "ENJ", "1INCH", "AAVE", "KAVA", "DYDX"
]

# Crypto-monnaies à exclure (selon la demande du client)
EXCLUDE_LIST = ["BTC", "ETH", "SOL"]

class VolatilityTrader:
    def __init__(self):
        """Initialise le trader multiasset"""
        self.k = krakenex.API(API_KEY, API_SECRET)
        self.running = False
        self.threads = []
        
        # Cache pour les prix et les scores
        self.price_cache = {}
        self.volatility_scores = {}
        self.trend_scores = {}
        self.combined_scores = {}
        self.last_analysis_time = 0  # Dernière analyse complète
        
        # Positions actuelles
        self.current_positions = {}
        self.usd_balance = 0
        
        # État des trades
        self.pending_trades = {}
        self.trade_history = []
        
        # Paramètres de trading
        self.check_interval = 5  # secondes - vérification très fréquente
        self.analysis_interval = 60  # secondes - analyse complète chaque minute
        self.min_trade_value_usd = 5  # Valeur minimale pour trader
        
        logger.info("✅ Trader Multiasset initialisé")
    
    def update_balances(self):
        """Mise à jour des balances du compte"""
        try:
            balances = self.k.query_private('Balance')
            
            if 'error' in balances and balances['error']:
                logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
                return False
            
            self.current_positions = {}
            self.usd_balance = float(balances['result'].get('ZUSD', 0))
            
            for asset, balance in balances['result'].items():
                if asset == 'ZUSD':
                    continue
                    
                balance_float = float(balance)
                if balance_float > 0.001:  # Ignorer les très petits soldes
                    self.current_positions[asset] = balance_float
            
            logger.info(f"Balances mises à jour: {len(self.current_positions)} actifs trouvés")
            logger.info(f"Solde USD: {self.usd_balance} USD")
            
            # Journaliser les actifs avec un solde significatif
            significant_assets = []
            for asset, balance in self.current_positions.items():
                try:
                    # Obtenir le prix actuel
                    price = self.get_price(asset)
                    if price:
                        usd_value = price * balance
                        
                        if usd_value > self.min_trade_value_usd:
                            significant_assets.append(f"{asset}: {balance:.4f} (~{usd_value:.2f} USD)")
                except Exception as e:
                    logger.warning(f"Impossible d'obtenir le prix pour {asset}: {e}")
            
            if significant_assets:
                logger.info(f"Actifs significatifs: {', '.join(significant_assets)}")
            
            return True
        except Exception as e:
            logger.error(f"Erreur lors de la mise à jour des balances: {e}")
            return False
    
    def get_price(self, asset):
        """Obtenir le prix actuel d'un actif"""
        start_time = time.perf_counter()
        try:
            # Vérifier si on a un prix en cache récent (<3 secondes)
            if asset in self.price_cache:
                cache_age = time.time() - self.price_cache[asset]['timestamp']
                if cache_age < 3.0:  # Utiliser le cache pour 3 secondes max
                    log_performance("get_price_cache", start_time, asset)
                    return self.price_cache[asset]['price']
            
            # Sinon, requête à l'API
            pair = f"{asset}USD"
            api_start = time.perf_counter()
            ticker = self.k.query_public('Ticker', {'pair': pair})
            log_performance("kraken_api_ticker", api_start, asset)
            
            if 'error' in ticker and ticker['error']:
                # Essayer avec USDT si USD ne fonctionne pas
                pair = f"{asset}USDT"
                ticker = self.k.query_public('Ticker', {'pair': pair})
            
            if 'error' in ticker and ticker['error']:
                logger.warning(f"Paire {asset}/USD et {asset}/USDT non disponible")
                return None
            
            # Récupérer le prix de clôture
            price = float(ticker['result'][list(ticker['result'].keys())[0]]['c'][0])
            
            # Mettre à jour le cache
            self.price_cache[asset] = {
                'price': price,
                'timestamp': time.time()
            }
            
            log_performance("get_price_total", start_time, asset)
            return price
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {asset}: {e}")
            return None
    
    def analyze_volatility(self, asset):
        """Analyser la volatilité d'un actif"""
        start_time = time.perf_counter()
        try:
            # Obtenir les données OHLC
            pair = f"{asset}USD"
            api_start = time.perf_counter()
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})  # 5 minutes
            log_performance("kraken_api_ohlc", api_start, asset)
            
            if 'error' in ohlc and ohlc['error']:
                # Essayer avec USDT
                pair = f"{asset}USDT"
                ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Données OHLC non disponibles pour {asset}")
                return 0
            
            # Récupérer les dernières données
            calc_start = time.perf_counter()
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Extraire les prix de clôture
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]
            
            # Calculer les variations en pourcentage
            changes = [abs(close_prices[i] - close_prices[i-1]) / close_prices[i-1] * 100 
                      for i in range(1, len(close_prices))]
            
            # Donner plus de poids aux changements récents
            weighted_volatility = 0
            weight_sum = 0
            
            for i, change in enumerate(changes):
                # Poids plus élevé pour les changements récents
                weight = (i + 1) ** 2
                weighted_volatility += change * weight
                weight_sum += weight
            
            volatility = weighted_volatility / weight_sum if weight_sum > 0 else 0
            log_performance("volatility_calculation", calc_start, asset)
            
            # Mettre à jour le cache de volatilité
            self.volatility_scores[asset] = volatility
            
            log_performance("volatility_analysis_total", start_time, asset)
            return volatility
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de volatilité pour {asset}: {e}")
            return 0
    
    def analyze_trend(self, asset):
        """Analyser la tendance d'un actif"""
        try:
            pair = f"{asset}USD"
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})
            
            if 'error' in ohlc and ohlc['error']:
                # Essayer avec USDT
                pair = f"{asset}USDT"
                ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Données OHLC non disponibles pour {asset}")
                return 0
            
            # Récupérer les dernières données
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Extraire les prix de clôture
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]
            
            # Tendance globale (20 périodes)
            overall_trend = (close_prices[-1] / close_prices[0] - 1) * 100
            
            # Tendance récente (5 périodes)
            recent_trend = (close_prices[-1] / close_prices[-6] - 1) * 100 if len(close_prices) >= 6 else 0
            
            # Score de tendance combiné (70% récent, 30% global)
            trend_score = recent_trend * 0.7 + overall_trend * 0.3
            
            # Mettre à jour le cache de tendance
            self.trend_scores[asset] = trend_score
            
            return trend_score
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de tendance pour {asset}: {e}")
            return 0
    
    def find_best_opportunities(self):
        """Trouver les meilleures opportunités de trading"""
        try:
            # Vérifier si une analyse complète est nécessaire (toutes les minutes)
            current_time = time.time()
            force_analysis = (current_time - self.last_analysis_time) >= self.analysis_interval
            
            if not force_analysis and self.combined_scores:
                # Utiliser les résultats précédents s'ils existent et sont récents
                return sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True)
            
            # Mise à jour de l'heure de dernière analyse
            self.last_analysis_time = current_time
            logger.info("⚡ ANALYSE MINUTE PAR MINUTE: recherche des meilleures opportunités...")
            
            # Construire la liste des actifs à analyser
            assets_to_analyze = list(set(WATCH_LIST) | set(self.current_positions.keys()))
            assets_to_analyze = [asset for asset in assets_to_analyze if asset not in EXCLUDE_LIST]
            
            # Réinitialiser les scores
            self.combined_scores = {}
            
            for asset in assets_to_analyze:
                try:
                    # Vérifier si le prix est disponible
                    price = self.get_price(asset)
                    if not price:
                        continue
                    
                    # Analyser la volatilité
                    volatility = self.analyze_volatility(asset)
                    
                    # Analyser la tendance
                    trend = self.analyze_trend(asset)
                    
                    # Score combiné: 60% volatilité, 40% tendance
                    # Tendance positive valorisée, tendance négative pénalisée
                    trend_factor = 1 if trend > 0 else -2
                    combined_score = (volatility * 0.6) + (abs(trend) * trend_factor * 0.4)
                    
                    # Stocker le score
                    self.combined_scores[asset] = combined_score
                    
                    logger.info(f"{asset}: Volatilité {volatility:.2f}%, Tendance {trend:+.2f}%, Score {combined_score:.2f}")
                    
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse de {asset}: {e}")
            
            # Trier par score
            sorted_opportunities = sorted(
                self.combined_scores.items(), 
                key=lambda x: x[1], 
                reverse=True
            )
            
            # Retourner les meilleures opportunités
            return sorted_opportunities
        except Exception as e:
            logger.error(f"Erreur lors de la recherche d'opportunités: {e}")
            return []
    
    def sell_asset(self, asset, reason="TARGET_PROFIT"):
        """Vendre un actif"""
        try:
            if asset not in self.current_positions or self.current_positions[asset] <= 0:
                logger.warning(f"Impossible de vendre {asset}: aucune position")
                return False
            
            balance = self.current_positions[asset]
            price = self.get_price(asset)
            
            if not price:
                logger.warning(f"Impossible de vendre {asset}: prix non disponible")
                return False
            
            pair = f"{asset}USD"
            
            # Vérifier si la paire existe
            try:
                self.k.query_public('Ticker', {'pair': pair})
            except:
                # Essayer avec USDT
                pair = f"{asset}USDT"
            
            # Arrondir le volume à 8 décimales maximum
            volume = round(balance, 8)
            
            # Exécuter l'ordre
            order = self.k.query_private('AddOrder', {
                'pair': pair,
                'type': 'sell',
                'ordertype': 'market',
                'volume': str(volume)
            })
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur lors de la vente de {asset}: {order['error']}")
                return False
            
            # Enregistrer le trade
            trade_record = {
                'asset': asset,
                'action': 'sell',
                'reason': reason,
                'volume': volume,
                'price': price,
                'timestamp': time.time(),
                'order_id': order['result'].get('txid', ['unknown'])[0]
            }
            self.trade_history.append(trade_record)
            
            logger.info(f"✅ {reason}: Vente de {volume} {asset} à ~{price} USD")
            
            # Mettre à jour les balances
            self.update_balances()
            
            return True
        except Exception as e:
            logger.error(f"Erreur lors de la vente de {asset}: {e}")
            return False
    
    def buy_asset(self, asset, usd_amount=None):
        """Acheter un actif"""
        try:
            # Vérifier le solde USD
            if self.usd_balance <= 5:  # Minimum 5 USD
                logger.warning(f"Solde USD insuffisant pour acheter {asset}: {self.usd_balance} USD")
                return False
            
            # Déterminer le montant à utiliser
            if not usd_amount or usd_amount > self.usd_balance:
                # Utiliser 95% du solde USD disponible
                usd_amount = self.usd_balance * 0.95
            
            # Vérifier si le montant est suffisant
            if usd_amount < 5:  # Minimum 5 USD par transaction
                logger.warning(f"Montant insuffisant pour acheter {asset}: {usd_amount} USD")
                return False
            
            # Obtenir le prix actuel
            price = self.get_price(asset)
            if not price:
                logger.warning(f"Impossible d'acheter {asset}: prix non disponible")
                return False
            
            # Calculer le volume à acheter
            volume = usd_amount / price
            
            # Arrondir le volume à 8 décimales maximum
            volume = round(volume, 8)
            
            pair = f"{asset}USD"
            
            # Vérifier si la paire existe
            try:
                self.k.query_public('Ticker', {'pair': pair})
            except:
                # Essayer avec USDT
                pair = f"{asset}USDT"
            
            # Exécuter l'ordre
            order = self.k.query_private('AddOrder', {
                'pair': pair,
                'type': 'buy',
                'ordertype': 'market',
                'volume': str(volume)
            })
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur lors de l'achat de {asset}: {order['error']}")
                return False
            
            # Enregistrer le trade
            trade_record = {
                'asset': asset,
                'action': 'buy',
                'volume': volume,
                'price': price,
                'usd_amount': usd_amount,
                'timestamp': time.time(),
                'order_id': order['result'].get('txid', ['unknown'])[0]
            }
            self.trade_history.append(trade_record)
            
            logger.info(f"✅ Achat de {volume} {asset} à ~{price} USD (Total: {usd_amount:.2f} USD)")
            
            # Mettre à jour les balances
            self.update_balances()
            
            return True
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {asset}: {e}")
            return False
    
    def check_positions(self):
        """Vérifier toutes les positions pour stop loss ou take profit"""
        try:
            for asset, balance in list(self.current_positions.items()):
                if asset in EXCLUDE_LIST or balance <= 0:
                    continue
                
                price = self.get_price(asset)
                if not price:
                    continue
                
                # Vérifier si on a un prix d'entrée pour cet actif
                entry_price = None
                for trade in reversed(self.trade_history):
                    if trade['asset'] == asset and trade['action'] == 'buy':
                        entry_price = trade['price']
                        break
                
                if not entry_price:
                    continue
                
                # Calculer le pourcentage de profit/perte
                profit_pct = (price / entry_price - 1) * 100
                
                # Stop loss ultra-serré (0.5-0.8%)
                stop_loss_pct = -0.8
                
                # Take profit (2-3%)
                take_profit_pct = 2.5
                
                # Vérifier le stop loss
                if profit_pct <= stop_loss_pct:
                    logger.info(f"⚠️ STOP LOSS pour {asset}: {profit_pct:.2f}%")
                    self.sell_asset(asset, reason="STOP_LOSS")
                # Vérifier le take profit
                elif profit_pct >= take_profit_pct:
                    logger.info(f"💰 TAKE PROFIT pour {asset}: +{profit_pct:.2f}%")
                    self.sell_asset(asset, reason="TAKE_PROFIT")
                else:
                    logger.debug(f"{asset}: Profit actuel {profit_pct:.2f}%")
        except Exception as e:
            logger.error(f"Erreur lors de la vérification des positions: {e}")
    
    def evaluate_new_opportunities(self):
        """Évaluer les nouvelles opportunités de trading"""
        try:
            # Vérifier si on a assez d'USD pour de nouvelles positions
            if self.usd_balance < 10:  # Minimum 10 USD pour un nouveau trade
                logger.info(f"Pas assez d'USD pour de nouvelles opportunités: {self.usd_balance:.2f} USD")
                return
            
            # Trouver les meilleures opportunités
            opportunities = self.find_best_opportunities()
            
            if not opportunities:
                logger.info("Aucune opportunité de trading trouvée")
                return
            
            # Filtrer pour ne garder que les actifs avec un score positif et élevé
            good_opportunities = [(asset, score) for asset, score in opportunities if score > 3.0]
            
            if not good_opportunities:
                logger.info("Aucune opportunité avec un score suffisant")
                return
            
            # Prendre la meilleure opportunité
            best_asset, best_score = good_opportunities[0]
            
            # Vérifier si on a déjà une position sur cet actif
            if best_asset in self.current_positions and self.current_positions[best_asset] > 0:
                logger.info(f"Position existante sur {best_asset}, score: {best_score:.2f}")
                return
            
            # Acheter le meilleur actif
            logger.info(f"Meilleure opportunité: {best_asset} (Score: {best_score:.2f})")
            
            # Utiliser 95% du solde USD disponible
            usd_amount = self.usd_balance * 0.95
            
            result = self.buy_asset(best_asset, usd_amount)
            if result:
                logger.info(f"✅ Nouvelle position ouverte sur {best_asset}")
            else:
                logger.warning(f"❌ Impossible d'ouvrir une position sur {best_asset}")
        except Exception as e:
            logger.error(f"Erreur lors de l'évaluation des opportunités: {e}")
    
    def trading_loop(self):
        """Boucle principale de trading"""
        try:
            self.update_balances()
            logger.info("Scan minute par minute des opportunités de marché")
            
            # Vérifier les positions existantes
            self.check_positions()
            
            # Évaluer de nouvelles opportunités
            self.evaluate_new_opportunities()
            
            # Enregistrer les statistiques
            with open("trading_stats.txt", "a") as f:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                balances = [f"{asset}:{amt:.4f}" for asset, amt in self.current_positions.items()]
                f.write(f"{timestamp} | USD:{self.usd_balance:.2f} | {','.join(balances)}\n")
            
        except Exception as e:
            logger.error(f"Erreur dans la boucle de trading: {e}")
    
    def start(self):
        """Démarrer le trader"""
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        self.running = True
        logger.info("⚡ DÉMARRAGE DE LA BOUCLE DE TRADING ULTRA-VOLATIL (ANALYSE MINUTE PAR MINUTE)")
        
        # Démarrer le trader
        self.update_balances()
        logger.info("🚀 Trader volatil démarré")
        
        # Boucle principale
        while self.running:
            try:
                self.trading_loop()
                
                # Attendre l'intervalle de vérification
                time.sleep(self.check_interval)
            except Exception as e:
                logger.error(f"Erreur dans la boucle principale: {e}")
                time.sleep(5)  # Attendre un peu en cas d'erreur
        
        return True
    
    def stop(self):
        """Arrêter le trader"""
        self.running = False
        logger.info("Arrêt du trader")
        return True


def main():
    """Fonction principale"""
    try:
        logger.info("=== DÉMARRAGE DU TRADER VOLATIL 24/7 SUR REPLIT ===")
        logger.info("Création du trader...")
        trader = VolatilityTrader()
        
        # Ajouter un hook pour gérer les interruptions
        def handle_exit(*args):
            logger.info("Signal d'arrêt reçu, arrêt propre du trader...")
            trader.stop()
            logger.info("Trader arrêté")
            os._exit(0)
        
        # Boucle de surveillance de l'état du trader
        def watchdog():
            try:
                while trader.running:
                    time.sleep(60)  # Vérifier chaque minute
                    
                    # Créer un fichier heartbeat
                    with open("trader_heartbeat.txt", "w") as f:
                        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        f.write(f"Trader actif: {timestamp}\n")
                    
                    # TODO: Ajouter d'autres vérifications d'état si nécessaire
            except Exception as e:
                logger.error(f"Erreur dans le watchdog: {e}")
        
        # Démarrer le trader
        trader_thread = threading.Thread(target=trader.start)
        trader_thread.daemon = True
        trader_thread.start()
        
        # Démarrer le watchdog
        watchdog_thread = threading.Thread(target=watchdog)
        watchdog_thread.daemon = True
        watchdog_thread.start()
        
        # Attendre que le thread principal se termine
        trader_thread.join()
        
    except Exception as e:
        logger.error(f"Erreur critique dans le main: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    # Afficher un grand message de démarrage
    logger.info("""
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
TRADER 24/7 DÉMARRE - MODE TEMPS RÉEL KRAKEN 
Analyse minute par minute - Stop loss ultra-serré (0.5-0.8%)
Trades volatilité + momentum - Target profit 2-3% par trade
Clés API intégrées - Fonctionnement continu sur Replit
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    """)
    
    # Exécuter la fonction principale
    exit_code = main()
    sys.exit(exit_code)