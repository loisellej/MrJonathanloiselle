#!/bin/bash
# Script pour déployer le bot de trading directement depuis Replit vers Hetzner
# en utilisant l'authentification par clé SSH

SERVER_IP="168.119.248.8"
REMOTE_DIR="/opt/trading_bot"
SSH_KEY_PATH="$HOME/.ssh/hetzner_key"

echo "=== DÉPLOIEMENT DIRECT DEPUIS REPLIT VERS HETZNER ==="
echo "Serveur: $SERVER_IP"
echo "Répertoire distant: $REMOTE_DIR"
echo "Utilisation de la clé SSH: $SSH_KEY_PATH"

# Vérifier si la clé SSH existe
if [ ! -f "$SSH_KEY_PATH" ]; then
  echo "Erreur: Clé SSH non trouvée. Exécutez d'abord ./setup_ssh_key.sh"
  exit 1
fi

# Vérifier la connexion SSH
ssh -i $SSH_KEY_PATH -o StrictHostKeyChecking=no root@$SERVER_IP "echo 'Connexion SSH établie avec succès'"

if [ $? -ne 0 ]; then
  echo "Erreur: Impossible de se connecter au serveur Hetzner avec la clé SSH."
  exit 1
fi

# Création du répertoire distant
echo "Création du répertoire sur le serveur Hetzner..."
ssh -i $SSH_KEY_PATH root@$SERVER_IP "mkdir -p $REMOTE_DIR"

# Préparation des fichiers à transférer
echo "Préparation des fichiers pour le transfert..."
mkdir -p _deploy_tmp

# Copier le fichier principal du trader ultra-volatil
if [ -f "ultra_volatility_trader.py" ]; then
  cp ultra_volatility_trader.py _deploy_tmp/
else
  echo "Warning: Le fichier ultra_volatility_trader.py n'existe pas."
  # Utiliser le fichier day_trader.py comme alternative
  if [ -f "day_trader.py" ]; then
    cp day_trader.py _deploy_tmp/main_trader.py
    # Mise à jour du script de démarrage pour utiliser main_trader.py
    MAIN_TRADER_SCRIPT="main_trader.py"
  else
    echo "Erreur: Aucun fichier trader trouvé."
    exit 1
  fi
fi

# Copier d'autres fichiers importants s'ils existent
cp day_trader.py _deploy_tmp/ 2>/dev/null || true
cp direct_kraken_api.py _deploy_tmp/ 2>/dev/null || true
cp check_status.py _deploy_tmp/ 2>/dev/null || true
cp exchange_connector.py _deploy_tmp/ 2>/dev/null || true
cp sentiment_analyzer.py _deploy_tmp/ 2>/dev/null || true

# Déterminer le script principal à exécuter
if [ -z "$MAIN_TRADER_SCRIPT" ]; then
  MAIN_TRADER_SCRIPT="ultra_volatility_trader.py"
fi

# Scripts de contrôle
cat > _deploy_tmp/start_bot.sh << EOF
#!/bin/bash
cd \$(dirname \$0)
echo "Démarrage du bot de trading..."
nohup python3 $MAIN_TRADER_SCRIPT > trading.log 2>&1 &
echo \$! > bot.pid
echo "Bot démarré avec PID: \$(cat bot.pid)"
EOF

cat > _deploy_tmp/stop_bot.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
if [ -f bot.pid ]; then
  PID=$(cat bot.pid)
  echo "Arrêt du bot (PID: $PID)..."
  kill $PID
  rm bot.pid
  echo "Bot arrêté."
else
  echo "Aucun PID trouvé. Le bot n'est peut-être pas en cours d'exécution."
fi
EOF

cat > _deploy_tmp/check_status.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
if [ -f bot.pid ]; then
  PID=$(cat bot.pid)
  if ps -p $PID > /dev/null; then
    echo "Le bot est en cours d'exécution (PID: $PID)"
    echo "Dernières lignes du journal:"
    tail -n 15 trading.log
  else
    echo "Le bot s'est arrêté de manière inattendue!"
    rm bot.pid
  fi
else
  echo "Le bot n'est pas en cours d'exécution."
fi
EOF

cat > _deploy_tmp/setup_env.sh << 'EOF'
#!/bin/bash
# Configuration de l'environnement pour les clés API
echo "Configuration des clés API Kraken..."
read -p "Entrez votre clé API Kraken: " API_KEY
read -p "Entrez votre clé secrète API Kraken: " API_SECRET

# Trouver le fichier principal du trader
if [ -f "ultra_volatility_trader.py" ]; then
  TRADER_FILE="ultra_volatility_trader.py"
elif [ -f "main_trader.py" ]; then
  TRADER_FILE="main_trader.py"
else
  echo "Erreur: Fichier trader introuvable!"
  exit 1
fi

# Modification du fichier trader pour insérer les clés
echo "Mise à jour des clés API dans $TRADER_FILE..."
if grep -q "API_KEY\s*=" $TRADER_FILE; then
  sed -i "s/API_KEY\s*=\s*\".*\"/API_KEY = \"$API_KEY\"/" $TRADER_FILE
else
  # Ajouter les clés API au début du fichier
  TMP_FILE=$(mktemp)
  echo "API_KEY = \"$API_KEY\"" > $TMP_FILE
  echo "API_SECRET = \"$API_SECRET\"" >> $TMP_FILE
  echo "" >> $TMP_FILE
  cat $TRADER_FILE >> $TMP_FILE
  mv $TMP_FILE $TRADER_FILE
fi

if grep -q "API_SECRET\s*=" $TRADER_FILE; then
  sed -i "s/API_SECRET\s*=\s*\".*\"/API_SECRET = \"$API_SECRET\"/" $TRADER_FILE
fi

echo "Configuration terminée avec succès!"
EOF

cat > _deploy_tmp/setup.sh << 'EOF'
#!/bin/bash
echo "Installation des dépendances..."
apt-get update
apt-get install -y python3 python3-pip

echo "Installation des packages Python..."
pip3 install krakenex ccxt requests numpy vaderSentiment

echo "Configuration des permissions..."
chmod +x start_bot.sh stop_bot.sh check_status.sh setup_env.sh

echo "Configuration terminée avec succès!"
echo ""
echo "ÉTAPE SUIVANTE: Configurez vos clés API avec ./setup_env.sh"
EOF

# Rendre les scripts exécutables
chmod +x _deploy_tmp/*.sh

# Transfert des fichiers vers Hetzner
echo "Transfert des fichiers vers Hetzner..."
for file in _deploy_tmp/*; do
  echo "  Transfert de $(basename $file)..."
  scp -i $SSH_KEY_PATH $file root@$SERVER_IP:$REMOTE_DIR/
done

# Exécution du script d'installation sur Hetzner
echo "Exécution du script d'installation sur Hetzner..."
ssh -i $SSH_KEY_PATH root@$SERVER_IP "cd $REMOTE_DIR && ./setup.sh"

# Nettoyage local
rm -rf _deploy_tmp

echo "=== DÉPLOIEMENT TERMINÉ AVEC SUCCÈS ==="
echo ""
echo "Votre bot de trading a été déployé sur votre serveur Hetzner!"
echo ""
echo "Étapes suivantes (à exécuter sur votre serveur Hetzner):"
echo "1. Connectez-vous: ssh -i $SSH_KEY_PATH root@$SERVER_IP"
echo "2. Allez dans le répertoire: cd $REMOTE_DIR"
echo "3. Configurez vos clés API: ./setup_env.sh"
echo "4. Démarrez le bot: ./start_bot.sh"
echo ""
echo "Pour vérifier l'état plus tard:"
echo "ssh -i $SSH_KEY_PATH root@$SERVER_IP \"cd $REMOTE_DIR && ./check_status.sh\""