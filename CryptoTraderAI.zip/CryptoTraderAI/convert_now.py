import ccxt
import time
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "9/KUxib19lkk7FukHnbupTEBYHIFcKsKtGAEW3/krj89u0jC/fYhrwfD"
API_SECRET = "RKJ9m8mLgfDNO7bMEvxubD6bY/avyqsQGe6Ev1APMBvBFCvBjXpKGyI5rmR1iJT8U5aVbuHJoY0OI9cprH9qSg=="

# Liste des actifs volatils à cibler
VOLATILE_ASSETS = ['AUDIO', 'GARI', 'DOGE', 'SHIB', 'MATIC', 'MANA']

def convert_to_volatile():
    """Convertit tous les actifs disponibles en cryptos volatiles"""
    logger.info("=== DÉMARRAGE DE LA CONVERSION VERS DES CRYPTOS VOLATILES ===")
    logger.info(f"Date et heure: {datetime.now().isoformat()}")
    
    try:
        # Initialiser l'exchange
        exchange = ccxt.kraken({
            'apiKey': API_KEY,
            'secret': API_SECRET,
            'enableRateLimit': True
        })
        
        # Charger les marchés
        markets = exchange.load_markets()
        logger.info(f"Marchés chargés: {len(markets)} paires disponibles")
        
        # Récupérer les balances
        balances = exchange.fetch_balance()
        
        # Afficher les balances non nulles
        logger.info("Balances actuelles:")
        for asset, balance in balances['total'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Vendre tous les actifs non-stables pour USD/USDT
        for asset, balance in balances['free'].items():
            # Ignorer les stablecoins et les petits montants
            if asset in ['USD', 'USDT', 'USDC'] or float(balance) < 1.0:
                continue
            
            # Chercher une paire pour vendre cet actif
            symbol = None
            
            # Essayer USD
            symbol_usd = f"{asset}/USD"
            if symbol_usd in markets:
                symbol = symbol_usd
            
            # Essayer USDT
            if not symbol:
                symbol_usdt = f"{asset}/USDT"
                if symbol_usdt in markets:
                    symbol = symbol_usdt
            
            if symbol:
                logger.info(f"Vente de {float(balance) * 0.95} {asset} via {symbol}")
                try:
                    # Vendre 95% pour tenir compte des frais
                    order = exchange.create_market_sell_order(symbol, float(balance) * 0.95)
                    logger.info(f"Vente effectuée: {order}")
                except Exception as e:
                    logger.error(f"Erreur lors de la vente de {asset}: {e}")
        
        # Attendre que les ventes soient finalisées
        logger.info("Attente de la finalisation des ventes...")
        time.sleep(5)
        
        # Récupérer les nouvelles balances
        new_balances = exchange.fetch_balance()
        
        # Récupérer les soldes USD/USDT
        usd_balance = float(new_balances['free'].get('USD', 0))
        usdt_balance = float(new_balances['free'].get('USDT', 0))
        
        logger.info(f"Solde USD: {usd_balance}, Solde USDT: {usdt_balance}")
        
        # Acheter des actifs volatils
        purchased = False
        
        # D'abord avec USD
        if usd_balance > 5:
            for asset in VOLATILE_ASSETS:
                symbol = f"{asset}/USD"
                if symbol in markets:
                    logger.info(f"Achat de {asset} avec {usd_balance * 0.95} USD via {symbol}")
                    try:
                        order = exchange.create_market_buy_order(symbol, None, {'cost': usd_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        purchased = True
                        break
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat de {asset}: {e}")
        
        # Ensuite avec USDT si disponible
        if not purchased and usdt_balance > 5:
            for asset in VOLATILE_ASSETS:
                symbol = f"{asset}/USDT"
                if symbol in markets:
                    logger.info(f"Achat de {asset} avec {usdt_balance * 0.95} USDT via {symbol}")
                    try:
                        order = exchange.create_market_buy_order(symbol, None, {'cost': usdt_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        purchased = True
                        break
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat de {asset}: {e}")
        
        # Afficher les nouvelles balances après la conversion
        final_balances = exchange.fetch_balance()
        
        logger.info("Balances finales après conversion:")
        for asset, balance in final_balances['total'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        if purchased:
            logger.info("✅ CONVERSION RÉUSSIE!")
            return True
        else:
            logger.warning("⚠️ Aucun achat d'actif volatil n'a pu être effectué")
            return False
        
    except Exception as e:
        logger.error(f"❌ Erreur critique lors de la conversion: {e}")
        return False

if __name__ == "__main__":
    if convert_to_volatile():
        print("\n✅ CONVERSION TERMINÉE AVEC SUCCÈS!")
    else:
        print("\n⚠️ La conversion n'a pas pu être complétée entièrement")