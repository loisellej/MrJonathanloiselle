#!/usr/bin/env python3
"""
Script pour vérifier l'état du bot de trading sur Replit
"""

import os
import json
import subprocess
import datetime
import time
import ccxt

def get_pid_status():
    """Vérifie si le bot est en cours d'exécution selon le fichier PID"""
    if not os.path.exists('trader.pid'):
        return {
            'running': False,
            'pid': None,
            'message': "Le bot n'est pas en cours d'exécution (aucun fichier PID trouvé)"
        }
    
    with open('trader.pid', 'r') as f:
        pid = f.read().strip()
    
    # Vérifier si le processus existe toujours
    try:
        os.kill(int(pid), 0)  # Signal 0 ne fait rien mais vérifie si le processus existe
        return {
            'running': True,
            'pid': pid,
            'message': f"Le bot est en cours d'exécution avec PID {pid}"
        }
    except:
        return {
            'running': False,
            'pid': pid,
            'message': f"Le bot s'est arrêté de manière inattendue (PID {pid} introuvable)"
        }

def get_last_log_entries(n=20):
    """Récupère les N dernières entrées du journal"""
    if not os.path.exists('trading.log'):
        return ["Aucun fichier journal trouvé"]
    
    try:
        # Utiliser tail pour récupérer les dernières lignes
        result = subprocess.run(['tail', '-n', str(n), 'trading.log'], 
                               capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout.splitlines()
        else:
            return [f"Erreur lors de la lecture du journal: {result.stderr}"]
    except Exception as e:
        return [f"Erreur: {str(e)}"]

def get_account_balances():
    """Récupère les balances du compte Kraken si possible"""
    try:
        # Récupérer les clés API des variables d'environnement
        api_key = os.environ.get('KRAKEN_API_KEY')
        api_secret = os.environ.get('KRAKEN_API_SECRET')
        
        if not api_key or not api_secret:
            return {
                'status': 'error',
                'message': "Clés API Kraken non configurées dans les variables d'environnement"
            }
        
        # Initialiser Kraken via ccxt
        kraken = ccxt.kraken({
            'apiKey': api_key,
            'secret': api_secret
        })
        
        # Récupérer les balances
        balances = kraken.fetch_balance()
        
        # Filtrer pour ne garder que les balances non nulles
        non_zero = {
            currency: float(amount) 
            for currency, amount in balances['total'].items() 
            if float(amount) > 0
        }
        
        return {
            'status': 'success',
            'balances': non_zero,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
    except Exception as e:
        return {
            'status': 'error',
            'message': f"Erreur lors de la récupération des balances: {str(e)}"
        }

def check_account_status():
    """Vérifie et affiche le statut complet du compte et du bot"""
    status = {
        'timestamp': datetime.datetime.now().isoformat(),
        'bot_status': get_pid_status(),
        'balances': get_account_balances(),
        'last_logs': get_last_log_entries(20)
    }
    
    print(json.dumps(status, indent=2))
    return status

if __name__ == '__main__':
    check_account_status()