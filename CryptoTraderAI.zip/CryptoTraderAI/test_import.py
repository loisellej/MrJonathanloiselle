#!/usr/bin/env python3
"""
Script de test pour vérifier l'import des modules
"""
import sys
import traceback

print("=== Test d'import des modules ===")

# Test d'import des optimisations
try:
    import optimizations
    print("✅ Module optimizations importé avec succès")
    print(f"   - Initialisation: {optimizations.initialize()}")
except Exception as e:
    print(f"❌ Erreur lors de l'import du module optimizations: {e}")
    traceback.print_exc()

# Test d'import du système d'initialisation
try:
    import init_optimized_system
    print("✅ Module init_optimized_system importé avec succès")
except Exception as e:
    print(f"❌ Erreur lors de l'import du module init_optimized_system: {e}")
    traceback.print_exc()

# Test d'import du trader
try:
    import auto_trader_verified
    print("✅ Module auto_trader_verified importé avec succès")
except Exception as e:
    print(f"❌ Erreur lors de l'import du module auto_trader_verified: {e}")
    traceback.print_exc()

print("=== Tests terminés ===")