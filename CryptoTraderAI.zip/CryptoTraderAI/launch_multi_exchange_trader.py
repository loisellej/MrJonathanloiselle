#!/usr/bin/env python3
"""
LANCEUR DU TRADER MULTI-EXCHANGE 24/7
- Démarre le trader avec connexion à Kraken et autres exchanges
- Recherche automatique des cryptos ultra-volatiles en uptrend
- Mode day trading intensif
- Trading continu 24h/24 et 7j/7
"""
import os
import sys
import logging
from multi_exchange_trader import MultiExchangeTrader

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('trading_logs.txt')
    ]
)
logger = logging.getLogger(__name__)

def check_api_keys():
    """
    Vérifie que les clés API nécessaires sont définies
    
    Returns:
        bool: True si les clés Kraken sont disponibles
    """
    kraken_api_key = os.environ.get("KRAKEN_API_KEY")
    kraken_api_secret = os.environ.get("KRAKEN_API_SECRET")
    
    if not kraken_api_key or not kraken_api_secret:
        logger.error("Clés API Kraken non trouvées! Définissez KRAKEN_API_KEY et KRAKEN_API_SECRET")
        print("ERREUR: Clés API Kraken manquantes!")
        print("Pour utiliser le système, vous devez définir les variables d'environnement:")
        print("  KRAKEN_API_KEY: Votre clé API Kraken")
        print("  KRAKEN_API_SECRET: Votre clé secrète API Kraken")
        return False
    
    return True

def check_additional_exchanges():
    """
    Vérifie si des clés pour d'autres exchanges sont disponibles
    
    Returns:
        list: Liste des exchanges supplémentaires configurés
    """
    additional_exchanges = []
    
    # Liste des exchanges à vérifier
    exchanges = [
        'binance',
        'kucoin',
        'huobi',
        'okx',
        'gate',
        'bybit',
        'bitget',
        'mexc'
    ]
    
    for exchange in exchanges:
        api_key = os.environ.get(f"{exchange.upper()}_API_KEY")
        api_secret = os.environ.get(f"{exchange.upper()}_API_SECRET")
        
        if api_key and api_secret:
            additional_exchanges.append(exchange)
    
    return additional_exchanges

def main():
    """Fonction principale pour lancer le trader multi-exchange"""
    print("=" * 80)
    print("LANCEMENT DU SYSTÈME DE TRADING CRYPTO ULTRA-PERFORMANT 24/7")
    print("Version: 1.0.0")
    print("=" * 80)
    
    # Vérifier que les clés API Kraken sont disponibles (obligatoire)
    if not check_api_keys():
        return False
    
    # Vérifier les exchanges supplémentaires
    additional_exchanges = check_additional_exchanges()
    
    if additional_exchanges:
        print(f"Exchanges supplémentaires configurés: {', '.join(additional_exchanges).upper()}")
    else:
        print("Aucun exchange supplémentaire configuré. Utilisation de Kraken uniquement.")
    
    # Afficher un avertissement
    print("\n" + "!" * 80)
    print("ATTENTION: SYSTÈME DE TRADING EN MODE RÉEL")
    print("Ce système va effectuer des trades réels avec vos fonds!")
    print("Il est optimisé pour les cryptos ultra-volatiles en uptrend.")
    print("Objectif: 20-50% de gains mensuels")
    print("!" * 80 + "\n")
    
    # Demander confirmation
    confirm = input("Êtes-vous sûr de vouloir démarrer le trading en mode réel? (oui/non): ")
    
    if confirm.lower() not in ["oui", "o", "yes", "y"]:
        print("Lancement annulé.")
        return False
    
    # Initialiser et démarrer le trader
    try:
        print("\nInitialisation du système de trading multi-exchange...")
        trader = MultiExchangeTrader()
        
        # Afficher le statut initial
        status = trader.get_status()
        print(f"\nSolde total détecté: ${status['total_value_usd']:.2f}")
        
        print("\nDémarrage du système de trading 24/7...")
        trader.start()
        
        print("\n" + "=" * 80)
        print("SYSTÈME DE TRADING DÉMARRÉ AVEC SUCCÈS!")
        print("Le système fonctionne maintenant en arrière-plan et effectuera des trades")
        print("selon la stratégie de day trading ultra-volatile en uptrend.")
        print("Pour arrêter, utilisez Ctrl+C")
        print("=" * 80)
        
        # Afficher les mises à jour de statut en continu
        try:
            while True:
                import time
                time.sleep(300)  # Mise à jour toutes les 5 minutes
                
                # Récupérer le statut
                status = trader.get_status()
                
                print(f"\nSTATUT DU SYSTÈME ({time.strftime('%H:%M:%S')}):")
                print(f"Solde total: ${status['total_value_usd']:.2f}")
                
                # Afficher les positions ouvertes
                if status['open_positions']:
                    print("Positions ouvertes:")
                    for pos in status['open_positions']:
                        print(f"  {pos['asset']} sur {pos['exchange']}: {pos['profit_pct']:+.2f}% "
                             f"(${pos['current_price']:.4f})")
                else:
                    print("Aucune position ouverte actuellement. Recherche d'opportunités...")
                
        except KeyboardInterrupt:
            print("\nArrêt demandé. Fermeture du système de trading...")
            trader.stop()
            print("Système de trading arrêté avec succès.")
        
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors du lancement du trader: {e}")
        print(f"\nERREUR: {e}")
        print("Le lancement du système de trading a échoué.")
        return False

if __name__ == "__main__":
    main()