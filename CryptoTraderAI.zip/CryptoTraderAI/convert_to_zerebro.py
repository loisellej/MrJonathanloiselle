import krakenex
import time
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

def convert_mana_to_zerebro():
    """Convertit MANA en ZEREBRO"""
    print("\n🚀 CONVERSION DE MANA VERS ZEREBRO\n")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # 1. Annuler tous les ordres existants
        logger.info("=== ANNULATION DES ORDRES EXISTANTS ===")
        
        open_orders = k.query_private('OpenOrders')
        if 'error' in open_orders and open_orders['error']:
            logger.error(f"Erreur lors de la récupération des ordres ouverts: {open_orders['error']}")
        elif len(open_orders['result']['open']) > 0:
            logger.info(f"Annulation de {len(open_orders['result']['open'])} ordres...")
            
            for order_id in open_orders['result']['open'].keys():
                logger.info(f"Annulation de l'ordre {order_id}...")
                cancel_result = k.query_private('CancelOrder', {'txid': order_id})
                
                if 'error' in cancel_result and cancel_result['error']:
                    logger.error(f"Erreur lors de l'annulation de l'ordre {order_id}: {cancel_result['error']}")
                else:
                    logger.info(f"✅ Ordre {order_id} annulé avec succès")
        else:
            logger.info("Aucun ordre ouvert à annuler")
        
        # 2. Vérifier le solde MANA
        logger.info("=== VÉRIFICATION DES BALANCES ===")
        
        balances = k.query_private('Balance')
        if 'error' in balances and balances['error']:
            logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
            return False
        
        mana_balance = float(balances['result'].get('MANA', 0))
        
        if mana_balance < 10:
            logger.error(f"Solde MANA insuffisant pour la conversion: {mana_balance}")
            return False
        
        logger.info(f"Solde MANA disponible: {mana_balance}")
        
        # 3. Vendre MANA pour USD
        logger.info("=== VENTE DE MANA POUR USD ===")
        
        # Récupérer le prix actuel de MANA
        ticker = k.query_public('Ticker', {'pair': 'MANAUSD'})
        if 'error' in ticker and ticker['error']:
            logger.error(f"Erreur lors de la récupération du prix de MANA: {ticker['error']}")
            return False
        
        mana_price = float(ticker['result']['MANAUSD']['c'][0])
        logger.info(f"Prix actuel de MANA: {mana_price} USD")
        
        # Calculer la valeur en USD
        estimated_usd = mana_balance * mana_price
        logger.info(f"Valeur estimée en USD: {estimated_usd} USD")
        
        # Vendre MANA (100% du solde)
        logger.info(f"Vente de {mana_balance} MANA à environ {mana_price} USD")
        
        sell_order = k.query_private('AddOrder', {
            'pair': 'MANAUSD',
            'type': 'sell',
            'ordertype': 'market',
            'volume': str(mana_balance)
        })
        
        if 'error' in sell_order and sell_order['error']:
            logger.error(f"Erreur lors de la vente de MANA: {sell_order['error']}")
            return False
        
        # Récupérer l'ID de l'ordre
        sell_order_txid = sell_order['result']['txid'][0]
        logger.info(f"✅ Ordre de vente placé avec succès: ID {sell_order_txid}")
        
        # Attendre la confirmation de l'exécution
        logger.info("Attente de la confirmation de l'exécution...")
        time.sleep(5)
        
        # Vérifier l'état de l'ordre
        order_status = k.query_private('QueryOrders', {'txid': sell_order_txid})
        
        if 'error' in order_status and order_status['error']:
            logger.error(f"Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
        else:
            logger.info(f"État de l'ordre: {order_status['result'][sell_order_txid]['status']}")
        
        # 4. Récupérer le nouveau solde USD
        new_balances = k.query_private('Balance')
        if 'error' in new_balances and new_balances['error']:
            logger.error(f"Erreur lors de la récupération des nouvelles balances: {new_balances['error']}")
            return False
        
        usd_balance = float(new_balances['result'].get('ZUSD', 0))
        logger.info(f"Nouveau solde USD: {usd_balance} USD")
        
        if usd_balance < 10:
            logger.error(f"Solde USD insuffisant pour l'achat de ZEREBRO: {usd_balance}")
            return False
        
        # 5. Récupérer le prix actuel de ZEREBRO
        ticker = k.query_public('Ticker', {'pair': 'ZEREBROUSD'})
        if 'error' in ticker and ticker['error']:
            logger.error(f"Erreur lors de la récupération du prix de ZEREBRO: {ticker['error']}")
            return False
        
        zerebro_price = float(ticker['result']['ZEREBROUSD']['c'][0])
        logger.info(f"Prix actuel de ZEREBRO: {zerebro_price} USD")
        
        # 6. Calculer la quantité de ZEREBRO à acheter (95% du solde USD pour tenir compte des frais)
        amount_to_spend = usd_balance * 0.95
        amount_to_buy = amount_to_spend / zerebro_price
        
        # Arrondir à 6 décimales pour éviter les erreurs de volume
        amount_to_buy = round(amount_to_buy, 6)
        
        logger.info(f"Achat de {amount_to_buy} ZEREBRO à environ {zerebro_price} USD")
        
        # 7. Acheter ZEREBRO
        buy_order = k.query_private('AddOrder', {
            'pair': 'ZEREBROUSD',
            'type': 'buy',
            'ordertype': 'market',
            'volume': str(amount_to_buy)
        })
        
        if 'error' in buy_order and buy_order['error']:
            # Si l'erreur est liée au volume minimal, essayer avec un coût fixe
            if 'EOrder:Invalid order' in str(buy_order['error']) or 'EOrder:Low order volume' in str(buy_order['error']):
                logger.info(f"Tentative d'achat avec un coût fixe...")
                
                buy_order = k.query_private('AddOrder', {
                    'pair': 'ZEREBROUSD',
                    'type': 'buy',
                    'ordertype': 'market',
                    'cost': str(amount_to_spend)
                })
            
            if 'error' in buy_order and buy_order['error']:
                logger.error(f"Erreur lors de l'achat de ZEREBRO: {buy_order['error']}")
                return False
        
        # Récupérer l'ID de l'ordre
        buy_order_txid = buy_order['result']['txid'][0]
        logger.info(f"✅ Ordre d'achat placé avec succès: ID {buy_order_txid}")
        
        # Attendre la confirmation de l'exécution
        logger.info("Attente de la confirmation de l'exécution...")
        time.sleep(5)
        
        # Vérifier l'état de l'ordre
        order_status = k.query_private('QueryOrders', {'txid': buy_order_txid})
        
        if 'error' in order_status and order_status['error']:
            logger.error(f"Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
        else:
            logger.info(f"État de l'ordre: {order_status['result'][buy_order_txid]['status']}")
        
        # 8. Vérifier les nouvelles balances
        final_balances = k.query_private('Balance')
        if 'error' in final_balances and final_balances['error']:
            logger.error(f"Erreur lors de la récupération des balances finales: {final_balances['error']}")
        else:
            logger.info("=== BALANCES FINALES ===")
            for asset, balance in final_balances['result'].items():
                if float(balance) > 0.001:
                    logger.info(f"  {asset}: {balance}")
        
        # 9. Enregistrer les détails de la transaction
        with open('zerebro_trades.log', 'a') as f:
            f.write(f"[{datetime.now().isoformat()}] VENTE: {mana_balance} MANA à {mana_price} USD (ID: {sell_order_txid})\n")
            f.write(f"[{datetime.now().isoformat()}] ACHAT: {amount_to_buy} ZEREBRO à {zerebro_price} USD (ID: {buy_order_txid})\n")
            f.write(f"[{datetime.now().isoformat()}] RAISONS: ZEREBRO a un score de volatilité plus élevé (5.31 vs 2.38) et une tendance plus forte (+34.98% vs +8.66%)\n")
            f.write("-" * 50 + "\n")
        
        print("\n✅ CONVERSION RÉUSSIE: MANA -> ZEREBRO")
        print(f"   Raisons: ZEREBRO a une volatilité de 3.93% et une tendance de +34.98%")
        print(f"   C'est un meilleur choix que MANA (volatilité 2.19%, tendance +8.66%)")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors de la conversion: {e}")
        return False

if __name__ == "__main__":
    convert_mana_to_zerebro()