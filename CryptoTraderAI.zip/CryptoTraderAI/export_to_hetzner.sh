#!/bin/bash
# Script pour exporter le bot de trading vers Hetzner
# Usage: ./export_to_hetzner.sh <votre_adresse_ip_hetzner>

if [ -z "$1" ]; then
  echo "Erreur: Veuillez spécifier l'adresse IP de votre serveur Hetzner"
  echo "Usage: ./export_to_hetzner.sh <votre_adresse_ip_hetzner>"
  exit 1
fi

SERVER_IP=$1
REMOTE_DIR="/opt/trading_bot"

echo "=== EXPORTATION DU BOT DE TRADING VERS HETZNER ==="
echo "Serveur: $SERVER_IP"
echo "Répertoire distant: $REMOTE_DIR"

# Demande de confirmation
read -p "Voulez-vous continuer? (y/n): " confirm
if [ "$confirm" != "y" ]; then
  echo "Exportation annulée."
  exit 0
fi

# Création du répertoire distant
echo "Création du répertoire distant sur Hetzner..."
ssh root@$SERVER_IP "mkdir -p $REMOTE_DIR"

# Création d'un paquet temporaire avec tous les fichiers nécessaires
echo "Préparation des fichiers locaux..."
mkdir -p _export_tmp
cp ultra_volatility_trader.py _export_tmp/
cp day_trader.py _export_tmp/ 2>/dev/null || true
cp direct_kraken_api.py _export_tmp/ 2>/dev/null || true
cp check_status.py _export_tmp/ 2>/dev/null || true

# Scripts de contrôle
cat > _export_tmp/start_bot.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
echo "Démarrage du bot de trading..."
nohup python3 ultra_volatility_trader.py > trading.log 2>&1 &
echo $! > bot.pid
echo "Bot démarré avec PID: $(cat bot.pid)"
EOF

cat > _export_tmp/stop_bot.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
if [ -f bot.pid ]; then
  PID=$(cat bot.pid)
  echo "Arrêt du bot (PID: $PID)..."
  kill $PID
  rm bot.pid
  echo "Bot arrêté."
else
  echo "Aucun PID trouvé. Le bot n'est peut-être pas en cours d'exécution."
fi
EOF

cat > _export_tmp/check_status.sh << 'EOF'
#!/bin/bash
cd $(dirname $0)
if [ -f bot.pid ]; then
  PID=$(cat bot.pid)
  if ps -p $PID > /dev/null; then
    echo "Le bot est en cours d'exécution (PID: $PID)"
    echo "Dernières lignes du journal:"
    tail -n 15 trading.log
  else
    echo "Le bot s'est arrêté de manière inattendue!"
    rm bot.pid
  fi
else
  echo "Le bot n'est pas en cours d'exécution."
fi
EOF

cat > _export_tmp/setup.sh << 'EOF'
#!/bin/bash
echo "Installation des dépendances..."
apt-get update
apt-get install -y python3 python3-pip

echo "Installation des packages Python..."
pip3 install krakenex requests numpy

echo "Configuration des permissions..."
chmod +x start_bot.sh stop_bot.sh check_status.sh

echo "Configuration terminée avec succès!"
EOF

cat > _export_tmp/README.md << 'EOF'
# Bot de Trading Ultra-Volatil

## Installation
1. Exécutez `./setup.sh` pour installer les dépendances

## Utilisation
- `./start_bot.sh` - Démarrer le bot
- `./stop_bot.sh` - Arrêter le bot
- `./check_status.sh` - Vérifier l'état du bot et afficher les derniers logs

## Fichiers de log
Les logs sont disponibles dans `trading.log`
EOF

# Rendre les scripts exécutables
chmod +x _export_tmp/*.sh

# Transfert des fichiers vers Hetzner
echo "Transfert des fichiers vers Hetzner..."
scp -r _export_tmp/* root@$SERVER_IP:$REMOTE_DIR/

# Nettoyage local
rm -rf _export_tmp

echo "Exécution du script d'installation sur Hetzner..."
ssh root@$SERVER_IP "cd $REMOTE_DIR && ./setup.sh"

echo "=== EXPORTATION TERMINÉE AVEC SUCCÈS ==="
echo ""
echo "Pour démarrer le bot:"
echo "1. Connectez-vous à votre serveur: ssh root@$SERVER_IP"
echo "2. Allez dans le répertoire: cd $REMOTE_DIR"
echo "3. Démarrez le bot: ./start_bot.sh"
echo ""
echo "Pour vérifier l'état du bot:"
echo "ssh root@$SERVER_IP \"cd $REMOTE_DIR && ./check_status.sh\""
echo ""
echo "Pour arrêter le bot:"
echo "ssh root@$SERVER_IP \"cd $REMOTE_DIR && ./stop_bot.sh\""