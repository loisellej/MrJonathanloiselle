import os
import ccxt
import time
import logging

logger = logging.getLogger(__name__)

class KrakenIntegration:
    """Intégration avec l'API Kraken"""
    
    def __init__(self, api_key=None, api_secret=None):
        """
        Initialise l'intégration Kraken
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
        """
        self.api_key = api_key or os.environ.get("KRAKEN_API_KEY")
        self.api_secret = api_secret or os.environ.get("KRAKEN_API_SECRET")
        self.kraken = None
        self.is_connected = False
        
        # Initialiser la connexion
        self._initialize_connection()
    
    def _initialize_connection(self):
        """Initialise la connexion à l'API Kraken"""
        try:
            # Créer l'instance ccxt
            self.kraken = ccxt.kraken({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'timeout': 30000
            })
            
            # Vérifier la connexion
            self.kraken.load_markets()
            self.is_connected = True
            logger.info("Connexion à Kraken établie avec succès")
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de l'initialisation de la connexion à Kraken: {e}")
            self.is_connected = False
            return False
    
    def get_balances(self):
        """
        Récupère les balances du compte
        
        Returns:
            dict: Balances par actif
        """
        try:
            if not self.is_connected:
                logger.error("Non connecté à Kraken")
                return {}
            
            balances = {}
            response = self.kraken.fetch_balance()
            
            # Extraire les balances
            for asset, balance in response['total'].items():
                if balance > 0:
                    balances[asset] = balance
            
            return balances
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances: {e}")
            return {}
    
    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel d'un symbole
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            
        Returns:
            float: Prix actuel ou None si non disponible
        """
        try:
            if not self.is_connected:
                logger.error("Non connecté à Kraken")
                return None
            
            ticker = self.kraken.fetch_ticker(symbol)
            return ticker['last']
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {symbol}: {e}")
            return None
    
    def get_ohlcv(self, symbol, timeframe='1h', limit=24):
        """
        Récupère les données OHLCV pour un symbole
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            timeframe (str): Intervalle de temps
            limit (int): Nombre de points de données
            
        Returns:
            list: Données OHLCV
        """
        try:
            if not self.is_connected:
                logger.error("Non connecté à Kraken")
                return []
            
            ohlcv = self.kraken.fetch_ohlcv(symbol, timeframe, limit=limit)
            return ohlcv
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des OHLCV pour {symbol}: {e}")
            return []
    
    def place_buy_order(self, symbol, amount):
        """
        Place un ordre d'achat
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            amount (float): Quantité à acheter
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        try:
            if not self.is_connected:
                logger.error("Non connecté à Kraken")
                return None
            
            logger.info(f"Placement d'un ordre d'achat pour {amount} {symbol}")
            order = self.kraken.create_market_buy_order(symbol, amount)
            
            return order
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre d'achat: {e}")
            return None
    
    def place_sell_order(self, symbol, amount):
        """
        Place un ordre de vente
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            amount (float): Quantité à vendre
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        try:
            if not self.is_connected:
                logger.error("Non connecté à Kraken")
                return None
            
            logger.info(f"Placement d'un ordre de vente pour {amount} {symbol}")
            order = self.kraken.create_market_sell_order(symbol, amount)
            
            return order
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre de vente: {e}")
            return None