import base64
import hashlib
import hmac
import time
import urllib.parse
import requests
import json
import os

def get_kraken_signature(urlpath, data, secret):
    # Convertir la clé secrète base64 en binaire
    secret = base64.b64decode(secret)
    
    # Créer le message à signer
    message = urlpath.encode() + hashlib.sha256((str(data['nonce']) + urllib.parse.urlencode(data)).encode()).digest()
    
    # Calculer la signature HMAC
    signature = hmac.new(secret, message, hashlib.sha512).digest()
    
    # Encoder la signature en base64
    return base64.b64encode(signature).decode()

def kraken_request(uri_path, data, api_key, api_sec):
    # Configuration du serveur Kraken
    api_url = "https://api.kraken.com"
    
    # Ajouter le nonce à la requête
    data['nonce'] = str(int(time.time() * 1000))
    
    # Établir les en-têtes
    headers = {
        'API-Key': api_key,
        'API-Sign': get_kraken_signature(uri_path, data, api_sec)
    }
    
    # Faire la requête
    resp = requests.post(api_url + uri_path, headers=headers, data=data)
    
    # Retourner la réponse
    return resp.json()

# Récupérer les clés depuis les variables d'environnement
api_key = os.environ.get('KRAKEN_API_KEY')
api_sec = os.environ.get('KRAKEN_API_SECRET')

# Check if keys are not None or empty
if not api_key or not api_sec:
    print("Erreur: Les clés API ne sont pas définies dans les variables d'environnement.")
    exit(1)

print("Tentative de connexion à Kraken...")
print(f"Clé API: {api_key[:4]}...{api_key[-4:]}")  # Affiche seulement le début et la fin de la clé

# Vérifier les clés API
try:
    # Requête pour obtenir les soldes
    response = kraken_request('/0/private/Balance', {}, api_key, api_sec)
    print("\nRéponse du serveur Kraken:")
    print(json.dumps(response, indent=2))
    
    # Vérifier si la requête a réussi
    if response.get('error') and response['error']:
        print(f"Erreur: {response['error']}")
    else:
        print("\nConnexion réussie! Voici vos soldes:")
        balances = response.get('result', {})
        
        if not balances:
            print("Aucun solde trouvé.")
        else:
            for asset, amount in balances.items():
                print(f"  {asset}: {amount}")
    
except Exception as e:
    print(f"Erreur lors de la connexion à Kraken: {e}")
    
print("\nTentative de récupération des paires de trading...")
try:
    # Cette requête ne nécessite pas d'authentification
    public_response = requests.get("https://api.kraken.com/0/public/AssetPairs")
    pairs = public_response.json()
    
    if pairs.get('error') and pairs['error']:
        print(f"Erreur: {pairs['error']}")
    else:
        print(f"Nombre de paires disponibles: {len(pairs.get('result', {}))}")
        print("Exemples de paires: " + ", ".join(list(pairs.get('result', {}).keys())[:5]))
        
except Exception as e:
    print(f"Erreur lors de la récupération des paires: {e}")