#!/usr/bin/env python3
"""
Gestionnaire de files d'attente optimisé pour le trader "Béton Armé"
Utilise un système de files d'attente pour exécuter les tâches de manière ordonnée
et limiter la consommation de ressources sur Replit
"""
import os
import time
import queue
import threading
import logging
import json
from datetime import datetime, timedelta
from functools import wraps

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("queue_manager.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("QueueManager")

class OptimizedQueueManager:
    """
    Gestionnaire de files d'attente pour l'exécution contrôlée des tâches
    Permet d'organiser l'exécution des tâches pour éviter de surcharger Replit
    """
    
    # Priorités prédéfinies
    PRIORITY_CRITICAL = 0  # Exécution immédiate (stop-loss, etc.)
    PRIORITY_HIGH = 3      # Exécution rapide (trading, etc.)
    PRIORITY_NORMAL = 5    # Exécution normale
    PRIORITY_LOW = 8       # Exécution à faible priorité (stats, etc.)
    PRIORITY_BACKGROUND = 10  # Tâches d'arrière-plan
    
    def __init__(self, max_workers=2):
        """
        Initialise le gestionnaire de files d'attente
        
        Args:
            max_workers (int): Nombre maximum de workers
        """
        self.standard_queue = queue.Queue()  # File d'attente standard
        self.priority_queue = queue.PriorityQueue()  # File prioritaire (ordre d'exécution)
        self.delayed_queue = []  # Liste de tâches planifiées [(timestamp, task), ...]
        
        # Statistiques
        self.stats = {
            'tasks_completed': 0,
            'tasks_failed': 0,
            'average_processing_time': 0,
            'total_processing_time': 0
        }
        
        # Cooldown entre les tâches similaires
        self.cooldowns = {}  # {task_type: last_execution_time}
        
        # Configuration
        self.max_workers = max_workers
        self.running = True
        self.workers = []
        
        # Sauvegarde d'état pour les tâches longues
        self.state_file = "queue_state.json"
        self.load_state()
        
        # Démarrer les threads
        self._start_workers()
        
        logger.info(f"Gestionnaire de files d'attente initialisé avec {max_workers} workers")
    
    def _start_workers(self):
        """Démarre les threads de traitement des tâches"""
        # Thread pour tâches prioritaires
        priority_worker = threading.Thread(target=self._process_priority_queue)
        priority_worker.daemon = True
        priority_worker.start()
        self.workers.append(priority_worker)
        
        # Thread pour tâches standard
        for i in range(self.max_workers - 1):  # -1 car un worker est déjà pour la file prioritaire
            worker = threading.Thread(target=self._process_standard_queue)
            worker.daemon = True
            worker.start()
            self.workers.append(worker)
        
        # Thread pour tâches planifiées
        delayed_worker = threading.Thread(target=self._process_delayed_tasks)
        delayed_worker.daemon = True
        delayed_worker.start()
        self.workers.append(delayed_worker)
        
        logger.info(f"Démarrage de {len(self.workers)} threads workers")
    
    def load_state(self):
        """Charge l'état depuis le fichier de sauvegarde"""
        try:
            if os.path.exists(self.state_file):
                with open(self.state_file, 'r') as f:
                    state = json.load(f)
                    self.stats = state.get('stats', self.stats)
                    
                    # Charger les tâches planifiées
                    delayed_tasks = state.get('delayed_tasks', [])
                    for task in delayed_tasks:
                        if task[0] > time.time():  # Seulement si dans le futur
                            self.delayed_queue.append(task)
                    
                    logger.info(f"État chargé: {len(self.delayed_queue)} tâches planifiées")
        except Exception as e:
            logger.error(f"Erreur lors du chargement de l'état: {e}")
    
    def save_state(self):
        """Sauvegarde l'état dans un fichier"""
        try:
            state = {
                'stats': self.stats,
                'delayed_tasks': [
                    # Convertir les objets fonction en noms pour la sérialisation
                    [task[0], task[1].__name__ if hasattr(task[1], '__name__') else str(task[1])]
                    for task in self.delayed_queue
                ]
            }
            
            with open(self.state_file, 'w') as f:
                json.dump(state, f)
                
            logger.debug("État sauvegardé")
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde de l'état: {e}")
    
    def _process_priority_queue(self):
        """Thread de traitement de la file d'attente prioritaire"""
        logger.info("Démarrage du thread de la file prioritaire")
        
        while self.running:
            try:
                # Obtenir une tâche prioritaire
                try:
                    priority, task_id, task_info = self.priority_queue.get(timeout=1)
                    task, args, kwargs = task_info
                    
                    start_time = time.time()
                    
                    try:
                        # Exécuter la tâche
                        result = task(*args, **kwargs)
                        
                        processing_time = time.time() - start_time
                        self._update_stats(processing_time, success=True)
                        
                        # Marquer la tâche comme terminée
                        self.priority_queue.task_done()
                        
                        logger.debug(f"Tâche prioritaire {priority}:{task_id} terminée en {processing_time:.3f}s")
                        
                    except Exception as e:
                        logger.error(f"Erreur dans tâche prioritaire {task_id}: {e}")
                        self._update_stats(time.time() - start_time, success=False)
                        self.priority_queue.task_done()
                    
                    # Courte pause entre les tâches
                    time.sleep(0.1)
                    
                except queue.Empty:
                    # Pas de tâche, attendre un peu
                    time.sleep(0.5)
                    
            except Exception as e:
                logger.error(f"Erreur dans le thread de la file prioritaire: {e}")
                time.sleep(1)
    
    def _process_standard_queue(self):
        """Thread de traitement de la file d'attente standard"""
        logger.info("Démarrage d'un thread de la file standard")
        
        while self.running:
            try:
                # Obtenir une tâche standard
                try:
                    task_info = self.standard_queue.get(timeout=1)
                    task, args, kwargs = task_info
                    
                    start_time = time.time()
                    
                    try:
                        # Exécuter la tâche
                        result = task(*args, **kwargs)
                        
                        processing_time = time.time() - start_time
                        self._update_stats(processing_time, success=True)
                        
                        # Marquer la tâche comme terminée
                        self.standard_queue.task_done()
                        
                        logger.debug(f"Tâche standard {task.__name__ if hasattr(task, '__name__') else 'anonymous'} "
                                   f"terminée en {processing_time:.3f}s")
                        
                    except Exception as e:
                        logger.error(f"Erreur dans tâche standard: {e}")
                        self._update_stats(time.time() - start_time, success=False)
                        self.standard_queue.task_done()
                    
                    # Pause plus longue entre les tâches standard
                    time.sleep(0.2)
                    
                except queue.Empty:
                    # Pas de tâche, attendre un peu
                    time.sleep(0.5)
                    
            except Exception as e:
                logger.error(f"Erreur dans le thread de la file standard: {e}")
                time.sleep(1)
    
    def _process_delayed_tasks(self):
        """Thread de traitement des tâches planifiées"""
        logger.info("Démarrage du thread des tâches planifiées")
        
        while self.running:
            try:
                now = time.time()
                tasks_to_execute = []
                
                # Trouver les tâches à exécuter
                for task in list(self.delayed_queue):
                    execution_time, task_func, args, kwargs = task
                    if now >= execution_time:
                        tasks_to_execute.append((task_func, args, kwargs))
                        self.delayed_queue.remove(task)
                
                # Exécuter les tâches
                for task_func, args, kwargs in tasks_to_execute:
                    self.add_task(task_func, *args, **kwargs)
                
                # Sauvegarder l'état régulièrement
                if int(now) % 300 < 1:  # ~tous les 5 minutes
                    self.save_state()
                
                # Pause entre les vérifications
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Erreur dans le thread des tâches planifiées: {e}")
                time.sleep(5)
    
    def _update_stats(self, processing_time, success=True):
        """
        Met à jour les statistiques de traitement
        
        Args:
            processing_time (float): Temps de traitement en secondes
            success (bool): Si la tâche a réussi
        """
        if success:
            self.stats['tasks_completed'] += 1
        else:
            self.stats['tasks_failed'] += 1
        
        # Mettre à jour le temps moyen de traitement
        total_tasks = self.stats['tasks_completed'] + self.stats['tasks_failed']
        if total_tasks > 0:
            self.stats['total_processing_time'] += processing_time
            self.stats['average_processing_time'] = (
                self.stats['total_processing_time'] / total_tasks
            )
    
    def add_task(self, task, *args, **kwargs):
        """
        Ajoute une tâche à la file d'attente standard
        
        Args:
            task (callable): Fonction à exécuter
            *args, **kwargs: Arguments de la fonction
        """
        self.standard_queue.put((task, args, kwargs))
        logger.debug(f"Tâche ajoutée à la file standard: {task.__name__ if hasattr(task, '__name__') else 'anonymous'}")
    
    def add_priority_task(self, priority, task_id, task, *args, **kwargs):
        """
        Ajoute une tâche à la file d'attente prioritaire
        
        Args:
            priority (int): Priorité de la tâche (0-10, 0 étant la plus haute)
            task_id (str): Identifiant unique de la tâche
            task (callable): Fonction à exécuter
            *args, **kwargs: Arguments de la fonction
        """
        self.priority_queue.put((priority, task_id, (task, args, kwargs)))
        logger.debug(f"Tâche ajoutée à la file prioritaire: {priority}:{task_id}")
    
    def schedule_task(self, delay_seconds, task, *args, **kwargs):
        """
        Planifie une tâche pour exécution future
        
        Args:
            delay_seconds (float): Délai en secondes
            task (callable): Fonction à exécuter
            *args, **kwargs: Arguments de la fonction
        """
        execution_time = time.time() + delay_seconds
        self.delayed_queue.append((execution_time, task, args, kwargs))
        self.delayed_queue.sort(key=lambda x: x[0])  # Trier par heure d'exécution
        
        logger.debug(f"Tâche planifiée dans {delay_seconds}s: "
                   f"{task.__name__ if hasattr(task, '__name__') else 'anonymous'}")
    
    def add_task_with_cooldown(self, task_type, cooldown_seconds, task, *args, **kwargs):
        """
        Ajoute une tâche avec un temps de repos entre les exécutions
        
        Args:
            task_type (str): Type de tâche (pour identifier le cooldown)
            cooldown_seconds (float): Temps minimum entre deux exécutions
            task (callable): Fonction à exécuter
            *args, **kwargs: Arguments de la fonction
            
        Returns:
            bool: True si la tâche a été ajoutée, False si en cooldown
        """
        now = time.time()
        
        # Vérifier si le type de tâche est en cooldown
        if task_type in self.cooldowns:
            last_execution = self.cooldowns[task_type]
            if now - last_execution < cooldown_seconds:
                # Encore en cooldown
                logger.debug(f"Tâche {task_type} ignorée, encore en cooldown "
                           f"({now - last_execution:.1f}s/{cooldown_seconds}s)")
                return False
        
        # Ajouter la tâche
        self.standard_queue.put((task, args, kwargs))
        
        # Mettre à jour le timestamp du cooldown
        self.cooldowns[task_type] = now
        
        logger.debug(f"Tâche {task_type} ajoutée avec cooldown de {cooldown_seconds}s")
        return True
    
    def stop(self):
        """Arrête le gestionnaire de files d'attente"""
        logger.info("Arrêt du gestionnaire de files d'attente")
        self.running = False
        
        # Attendre que les workers terminent
        for worker in self.workers:
            worker.join(timeout=1)
        
        # Sauvegarder l'état
        self.save_state()
        
        logger.info("Gestionnaire de files d'attente arrêté")
    
    def get_stats(self):
        """
        Récupère les statistiques du gestionnaire
        
        Returns:
            dict: Statistiques
        """
        return {
            **self.stats,
            'standard_queue_size': self.standard_queue.qsize(),
            'priority_queue_size': self.priority_queue.qsize(),
            'delayed_tasks': len(self.delayed_queue),
            'cooldowns': {k: time.time() - v for k, v in self.cooldowns.items()}
        }


# Décorateurs pratiques
def with_priority(priority, task_id_prefix=None):
    """
    Décorateur pour exécuter une fonction avec une priorité spécifique
    
    Args:
        priority (int): Priorité de la tâche
        task_id_prefix (str, optional): Préfixe pour l'identifiant de tâche
        
    Returns:
        callable: Décorateur
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Obtenir le gestionnaire de files d'attente
            queue_manager = get_queue_manager()
            
            # Générer un identifiant de tâche
            task_id = f"{task_id_prefix or func.__name__}_{time.time()}"
            
            # Ajouter la tâche à la file d'attente prioritaire
            queue_manager.add_priority_task(priority, task_id, func, *args, **kwargs)
            
            # Retourner l'identifiant de la tâche
            return task_id
        return wrapper
    return decorator


def with_cooldown(task_type, cooldown_seconds):
    """
    Décorateur pour exécuter une fonction avec un cooldown
    
    Args:
        task_type (str): Type de tâche (pour identifier le cooldown)
        cooldown_seconds (float): Temps minimum entre deux exécutions
        
    Returns:
        callable: Décorateur
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Obtenir le gestionnaire de files d'attente
            queue_manager = get_queue_manager()
            
            # Ajouter la tâche avec cooldown
            added = queue_manager.add_task_with_cooldown(
                task_type, cooldown_seconds, func, *args, **kwargs
            )
            
            # Retourner si la tâche a été ajoutée
            return added
        return wrapper
    return decorator


def delayed(delay_seconds):
    """
    Décorateur pour exécuter une fonction avec un délai
    
    Args:
        delay_seconds (float): Délai en secondes
        
    Returns:
        callable: Décorateur
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Obtenir le gestionnaire de files d'attente
            queue_manager = get_queue_manager()
            
            # Planifier la tâche
            queue_manager.schedule_task(delay_seconds, func, *args, **kwargs)
            
            # Retourner None
            return None
        return wrapper
    return decorator


# Singleton pour accéder au gestionnaire
_queue_manager_instance = None

def get_queue_manager():
    """
    Récupère l'instance unique du gestionnaire de files d'attente
    
    Returns:
        OptimizedQueueManager: Instance du gestionnaire
    """
    global _queue_manager_instance
    if _queue_manager_instance is None:
        _queue_manager_instance = OptimizedQueueManager()
    return _queue_manager_instance


def initialize_queue_system():
    """
    Initialise le système de files d'attente
    
    Returns:
        OptimizedQueueManager: Instance du gestionnaire
    """
    return get_queue_manager()