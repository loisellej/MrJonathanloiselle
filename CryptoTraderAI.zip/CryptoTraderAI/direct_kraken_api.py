import os
import sys
import time
import json
import base64
import hashlib
import hmac
import urllib.request
import urllib.parse
import urllib.error
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class KrakenAPI:
    def __init__(self, api_key=None, api_secret=None):
        """Initialisation de l'API Kraken"""
        self.api_key = api_key or os.environ.get('KRAKEN_API_KEY')
        self.api_secret = api_secret or os.environ.get('KRAKEN_API_SECRET')
        self.api_url = "https://api.kraken.com"
        self.api_version = "0"
        
        if not self.api_key or not self.api_secret:
            logger.error("Les clés API Kraken ne sont pas configurées")
            raise ValueError("Clés API manquantes")
    
    def _get_kraken_signature(self, urlpath, data):
        """
        Génère une signature pour l'authentification auprès de l'API Kraken
        """
        # Convertir la clé secrète de base64 en binaire
        try:
            secret = base64.b64decode(self.api_secret)
        except Exception as e:
            logger.error(f"Erreur lors du décodage de la clé secrète: {e}")
            raise ValueError("Clé API secrète invalide")
        
        # Créer le message à signer
        message = data['nonce'] + urlpath + urllib.parse.urlencode(data)
        
        # Générer la signature
        signature = hmac.new(secret, message.encode(), hashlib.sha256)
        digest = signature.digest()
        signature_b64 = base64.b64encode(digest).decode()
        
        return signature_b64
    
    def query_private(self, method, data=None):
        """
        Envoie une requête privée (nécessitant une authentification) à l'API Kraken
        """
        if data is None:
            data = {}
        
        # Ajouter un nonce pour éviter les rejeux
        data['nonce'] = str(int(time.time() * 1000))
        
        # Construire l'URL de l'API
        urlpath = f"/{self.api_version}/private/{method}"
        url = self.api_url + urlpath
        
        # Générer la signature
        signature = self._get_kraken_signature(urlpath, data)
        
        # Préparer les headers
        headers = {
            'API-Key': self.api_key,
            'API-Sign': signature,
            'User-Agent': 'Kraken Direct Trader'
        }
        
        # Préparer la requête
        try:
            # Convertir les données en format approprié
            post_data = urllib.parse.urlencode(data).encode()
            req = urllib.request.Request(url, post_data, headers)
            
            # Envoyer la requête
            with urllib.request.urlopen(req) as response:
                response_data = response.read().decode()
                result = json.loads(response_data)
                
                # Vérifier s'il y a des erreurs
                if result.get('error') and len(result['error']) > 0:
                    raise Exception(f"Erreur API Kraken: {result['error']}")
                
                return result.get('result', {})
        
        except urllib.error.HTTPError as e:
            logger.error(f"Erreur HTTP lors de la requête à l'API Kraken: {e.code} - {e.reason}")
            raise
        except Exception as e:
            logger.error(f"Erreur lors de la requête à l'API Kraken: {e}")
            raise
    
    def query_public(self, method, data=None):
        """
        Envoie une requête publique (ne nécessitant pas d'authentification) à l'API Kraken
        """
        if data is None:
            data = {}
        
        # Construire l'URL de l'API
        urlpath = f"/{self.api_version}/public/{method}"
        url = self.api_url + urlpath
        
        if data:
            url += '?' + urllib.parse.urlencode(data)
        
        # Préparer la requête
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Kraken Direct Trader'})
            
            # Envoyer la requête
            with urllib.request.urlopen(req) as response:
                response_data = response.read().decode()
                result = json.loads(response_data)
                
                # Vérifier s'il y a des erreurs
                if result.get('error') and len(result['error']) > 0:
                    raise Exception(f"Erreur API Kraken: {result['error']}")
                
                return result.get('result', {})
        
        except urllib.error.HTTPError as e:
            logger.error(f"Erreur HTTP lors de la requête à l'API Kraken: {e.code} - {e.reason}")
            raise
        except Exception as e:
            logger.error(f"Erreur lors de la requête à l'API Kraken: {e}")
            raise
    
    def get_balances(self):
        """
        Récupère les soldes du compte
        """
        try:
            balances = self.query_private('Balance')
            return balances
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des soldes: {e}")
            return {}
    
    def get_ticker(self, pair):
        """
        Récupère les informations de ticker pour une paire
        """
        try:
            ticker = self.query_public('Ticker', {'pair': pair})
            return ticker
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du ticker pour {pair}: {e}")
            return {}
    
    def place_order(self, pair, order_type, order_side, volume, price=None):
        """
        Place un ordre sur Kraken
        """
        try:
            order_data = {
                'pair': pair,
                'type': order_side,  # buy or sell
                'ordertype': order_type,  # market, limit, etc.
                'volume': str(volume)
            }
            
            # Ajouter le prix si c'est un ordre limite
            if order_type == 'limit' and price:
                order_data['price'] = str(price)
            
            result = self.query_private('AddOrder', order_data)
            return result
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre: {e}")
            return {'error': str(e)}
    
    def get_asset_pairs(self):
        """
        Récupère les informations sur les paires disponibles
        """
        try:
            asset_pairs = self.query_public('AssetPairs')
            return asset_pairs
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des paires: {e}")
            return {}
    
    def convert_to_volatile(self):
        """
        Convertit les actifs en cryptos volatiles
        """
        logger.info("=== CONVERSION DIRECTE VERS DES CRYPTOS VOLATILES ===")
        
        # Liste d'actifs volatils cibles par priorité
        target_assets = ['AUDIO', 'GARI', 'SHIB', 'MATIC', 'DOGE', 'MANA', 'LUNA']
        
        try:
            # Récupérer les soldes
            balances = self.get_balances()
            if not balances:
                logger.error("Impossible de récupérer les soldes du compte")
                return False
            
            logger.info(f"Soldes récupérés: {balances}")
            
            # Récupérer les paires disponibles
            asset_pairs = self.get_asset_pairs()
            if not asset_pairs:
                logger.error("Impossible de récupérer les paires disponibles")
                return False
            
            # Identifier les paires pour vendre les actifs non-volatils
            sell_orders = []
            
            for asset, balance in balances.items():
                # Ignorer les stablecoins et les petits montants
                if asset in ['ZUSD', 'USDT', 'USDC'] or float(balance) < 1.0:
                    continue
                
                # Trouver une paire pour vendre l'actif
                sell_pair = None
                
                # Vérifier si on peut vendre vers USD
                pair_name = f"X{asset}ZUSD"
                alt_pair_name = f"{asset}USD"
                
                if pair_name in asset_pairs:
                    sell_pair = pair_name
                elif alt_pair_name in asset_pairs:
                    sell_pair = alt_pair_name
                else:
                    # Essayer USDT
                    pair_name = f"{asset}USDT"
                    if pair_name in asset_pairs:
                        sell_pair = pair_name
                
                if sell_pair:
                    sell_orders.append({
                        'asset': asset,
                        'balance': float(balance),
                        'pair': sell_pair
                    })
            
            # Exécuter les ordres de vente
            for order in sell_orders:
                logger.info(f"Vente de {order['balance']} {order['asset']} via {order['pair']}")
                
                try:
                    # Garder 5% en réserve pour les frais
                    volume = order['balance'] * 0.95
                    
                    # Placer l'ordre de vente
                    result = self.place_order(order['pair'], 'market', 'sell', volume)
                    logger.info(f"Résultat de la vente: {result}")
                    
                    # Attendre la confirmation
                    time.sleep(5)
                except Exception as e:
                    logger.error(f"Erreur lors de la vente de {order['asset']}: {e}")
            
            # Après les ventes, récupérer le nouveau solde USD/USDT
            new_balances = self.get_balances()
            usd_balance = float(new_balances.get('ZUSD', 0))
            usdt_balance = float(new_balances.get('USDT', 0))
            
            logger.info(f"Nouveau solde: USD={usd_balance}, USDT={usdt_balance}")
            
            # Si on a un solde significatif, acheter un actif volatil
            success = False
            
            for target in target_assets:
                # Essayer d'acheter avec USD
                if usd_balance > 1.0:
                    buy_pair = f"X{target}ZUSD"
                    alt_buy_pair = f"{target}USD"
                    
                    if buy_pair in asset_pairs:
                        try:
                            logger.info(f"Achat de {target} avec {usd_balance * 0.95} USD via {buy_pair}")
                            result = self.place_order(buy_pair, 'market', 'buy', usd_balance * 0.95)
                            logger.info(f"Résultat de l'achat: {result}")
                            success = True
                            break
                        except Exception as e:
                            logger.error(f"Erreur lors de l'achat de {target}: {e}")
                    elif alt_buy_pair in asset_pairs:
                        try:
                            logger.info(f"Achat de {target} avec {usd_balance * 0.95} USD via {alt_buy_pair}")
                            result = self.place_order(alt_buy_pair, 'market', 'buy', usd_balance * 0.95)
                            logger.info(f"Résultat de l'achat: {result}")
                            success = True
                            break
                        except Exception as e:
                            logger.error(f"Erreur lors de l'achat de {target}: {e}")
                
                # Essayer d'acheter avec USDT
                if usdt_balance > 1.0:
                    buy_pair = f"{target}USDT"
                    
                    if buy_pair in asset_pairs:
                        try:
                            logger.info(f"Achat de {target} avec {usdt_balance * 0.95} USDT via {buy_pair}")
                            result = self.place_order(buy_pair, 'market', 'buy', usdt_balance * 0.95)
                            logger.info(f"Résultat de l'achat: {result}")
                            success = True
                            break
                        except Exception as e:
                            logger.error(f"Erreur lors de l'achat de {target}: {e}")
            
            return success
        
        except Exception as e:
            logger.error(f"Erreur générale lors de la conversion: {e}")
            return False


if __name__ == "__main__":
    # Exécuter la conversion
    try:
        kraken = KrakenAPI()
        result = kraken.convert_to_volatile()
        
        if result:
            logger.info("Conversion réussie!")
            sys.exit(0)
        else:
            logger.error("Échec de la conversion")
            sys.exit(1)
    
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution: {e}")
        sys.exit(1)