#!/usr/bin/env python3
"""
Gestionnaire de ressources optimisé pour le trader "Béton Armé"
Implémente des techniques avancées de gestion des ressources pour Replit:
- Cache optimisé pour les prix et données répétitives
- Limitation des requêtes API
- Gestion efficace des logs
- File d'attente pour les tâches
- Surveillance des ressources mémoire/CPU
"""
import time
import queue
import threading
import logging
import psutil
import os
import json
from datetime import datetime, timedelta
from functools import lru_cache
import gc

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("resource_manager.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("ResourceManager")

class OptimizedResourceManager:
    """
    Gestionnaire de ressources optimisé pour environnements contraints (comme Replit)
    Implémente des mécanismes sophistiqués d'économie de ressources:
    - Caching avancé avec TTL (time-to-live)
    - Rate limiting intelligent
    - Gestion de files d'attente pour les tâches lourdes
    - Monitoring de ressources avec ajustement automatique
    """
    
    def __init__(self, exchange_connector=None):
        """
        Initialise le gestionnaire avec le connecteur d'échange
        
        Args:
            exchange_connector: Connecteur à l'exchange (option)
        """
        self.exchange = exchange_connector
        
        # Initialisation du cache
        self.price_cache = {}  # Format: {symbol: {'price': float, 'timestamp': float}}
        self.data_cache = {}   # Format: {key: {'data': any, 'timestamp': float, 'ttl': int}}
        
        # Configuration du rate limiting
        self.api_call_timestamps = []
        self.max_calls_per_minute = 60  # Peut être ajusté selon les limites de l'API
        
        # File d'attente pour les tâches
        self.task_queue = queue.Queue()
        self.priority_task_queue = queue.PriorityQueue()  # Pour les tâches critiques
        
        # Statistiques d'utilisation
        self.usage_stats = {
            'api_calls': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'tasks_processed': 0,
            'rate_limit_delays': 0
        }
        
        # Paramètres de performance
        self.cache_ttl = 60  # 60 secondes par défaut
        self.rate_limit_cooldown = 0.1  # 100ms entre les appels API
        
        # Surveillance des ressources
        self.high_load_threshold = 80  # % d'utilisation CPU/mémoire
        self.extreme_load_threshold = 90
        
        # Horodatage de la dernière rotation des logs
        self.last_log_rotation = time.time()
        
        # Démarrer les threads de travail
        self.running = True
        self.start_worker_threads()
        
        logger.info("Gestionnaire de ressources optimisé initialisé")
    
    def start_worker_threads(self):
        """Démarre les threads de traitement et de surveillance"""
        # Thread de traitement des tâches standard
        self.task_thread = threading.Thread(target=self._process_task_queue)
        self.task_thread.daemon = True
        self.task_thread.start()
        
        # Thread de traitement des tâches prioritaires
        self.priority_thread = threading.Thread(target=self._process_priority_queue)
        self.priority_thread.daemon = True
        self.priority_thread.start()
        
        # Thread de surveillance des ressources
        self.monitor_thread = threading.Thread(target=self._monitor_resources)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        # Thread de nettoyage du cache
        self.cleanup_thread = threading.Thread(target=self._cleanup_old_cache)
        self.cleanup_thread.daemon = True
        self.cleanup_thread.start()
        
        logger.info("Threads de gestion des ressources démarrés")
    
    def stop(self):
        """Arrête tous les threads de gestion des ressources"""
        self.running = False
        
        # Attendre que les threads se terminent (max 5 secondes)
        threads = [
            self.task_thread, 
            self.priority_thread, 
            self.monitor_thread,
            self.cleanup_thread
        ]
        
        for thread in threads:
            if thread.is_alive():
                thread.join(timeout=1)
        
        logger.info("Gestionnaire de ressources arrêté")
    
    def _process_task_queue(self):
        """Thread de traitement des tâches standard"""
        logger.info("Démarrage du thread de traitement des tâches standard")
        
        while self.running:
            try:
                # Vérifier s'il y a une tâche à exécuter
                try:
                    task, args, kwargs = self.task_queue.get(timeout=1)
                    
                    # Vérifier la charge système avant d'exécuter
                    if self._is_system_overloaded():
                        # Si système surchargé, remettre la tâche en file et attendre
                        self.task_queue.put((task, args, kwargs))
                        time.sleep(0.5)
                        continue
                    
                    # Exécuter la tâche
                    task(*args, **kwargs)
                    self.usage_stats['tasks_processed'] += 1
                    self.task_queue.task_done()
                    
                    # Bref délai entre les tâches pour économiser les ressources
                    time.sleep(0.1)
                    
                except queue.Empty:
                    # Pas de tâche disponible, attendre un peu
                    time.sleep(0.5)
            
            except Exception as e:
                logger.error(f"Erreur dans le traitement de la file de tâches: {e}")
                time.sleep(1)  # Pause plus longue en cas d'erreur
    
    def _process_priority_queue(self):
        """Thread de traitement des tâches prioritaires"""
        logger.info("Démarrage du thread de traitement des tâches prioritaires")
        
        while self.running:
            try:
                # Vérifier s'il y a une tâche prioritaire à exécuter
                try:
                    priority, task_id, (task, args, kwargs) = self.priority_task_queue.get(timeout=1)
                    
                    # Les tâches prioritaires s'exécutent même en cas de surcharge système
                    # mais avec une brève pause si charge extrême
                    if self._is_system_critically_overloaded():
                        time.sleep(0.2)
                    
                    # Exécuter la tâche prioritaire
                    logger.debug(f"Exécution de tâche prioritaire {priority}: {task_id}")
                    task(*args, **kwargs)
                    self.usage_stats['tasks_processed'] += 1
                    self.priority_task_queue.task_done()
                    
                except queue.Empty:
                    # Pas de tâche prioritaire, attendre un peu
                    time.sleep(0.5)
            
            except Exception as e:
                logger.error(f"Erreur dans le traitement des tâches prioritaires: {e}")
                time.sleep(1)
    
    def _monitor_resources(self):
        """Thread de surveillance des ressources système"""
        logger.info("Démarrage du thread de surveillance des ressources")
        
        while self.running:
            try:
                # Obtenir l'utilisation CPU et mémoire
                cpu_percent = psutil.cpu_percent(interval=1)
                memory_percent = psutil.virtual_memory().percent
                
                # Vérifier si les logs ont besoin de rotation
                self._check_log_rotation()
                
                # Journaliser l'utilisation des ressources toutes les 5 minutes
                if int(time.time()) % 300 < 2:  # ~toutes les 5 minutes
                    logger.info(f"Utilisation des ressources - CPU: {cpu_percent}%, "
                               f"Mémoire: {memory_percent}%")
                    logger.info(f"Statistiques - API: {self.usage_stats['api_calls']}, "
                               f"Cache hits: {self.usage_stats['cache_hits']}, "
                               f"Misses: {self.usage_stats['cache_misses']}")
                
                # Ajuster les paramètres de performance en fonction de la charge
                self._adjust_performance_settings(cpu_percent, memory_percent)
                
                # Libérer la mémoire si nécessaire
                if memory_percent > 75:
                    self._free_memory()
                
                time.sleep(10)  # Vérifier toutes les 10 secondes
                
            except Exception as e:
                logger.error(f"Erreur dans la surveillance des ressources: {e}")
                time.sleep(30)  # Pause plus longue en cas d'erreur
    
    def _cleanup_old_cache(self):
        """Thread de nettoyage des anciennes entrées de cache"""
        logger.info("Démarrage du thread de nettoyage du cache")
        
        while self.running:
            try:
                now = time.time()
                
                # Nettoyer le cache de prix
                for symbol in list(self.price_cache.keys()):
                    if now - self.price_cache[symbol]['timestamp'] > self.cache_ttl:
                        del self.price_cache[symbol]
                
                # Nettoyer le cache de données
                for key in list(self.data_cache.keys()):
                    entry = self.data_cache[key]
                    if now - entry['timestamp'] > entry.get('ttl', self.cache_ttl):
                        del self.data_cache[key]
                
                # Nettoyer les timestamps d'appels API
                self.api_call_timestamps = [
                    t for t in self.api_call_timestamps if now - t < 60
                ]
                
                # Nettoyage toutes les 30 secondes
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Erreur dans le nettoyage du cache: {e}")
                time.sleep(60)
    
    def _check_log_rotation(self):
        """Vérifie si une rotation des logs est nécessaire"""
        now = time.time()
        
        # Rotation quotidienne ou si fichier > 5 Mo
        if (now - self.last_log_rotation > 86400 or  # 24 heures
            (os.path.exists("resource_manager.log") and 
             os.path.getsize("resource_manager.log") > 5 * 1024 * 1024)):
            
            try:
                # Renommer le fichier log actuel
                if os.path.exists("resource_manager.log"):
                    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                    os.rename(
                        "resource_manager.log", 
                        f"resource_manager_{timestamp}.log"
                    )
                
                # Reconfigurer le logging
                for handler in logger.handlers[:]:
                    if isinstance(handler, logging.FileHandler):
                        handler.close()
                        logger.removeHandler(handler)
                
                file_handler = logging.FileHandler("resource_manager.log")
                file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
                logger.addHandler(file_handler)
                
                self.last_log_rotation = now
                logger.info("Rotation des logs effectuée")
                
                # Nettoyer les anciens fichiers logs (garder 7 jours)
                self._cleanup_old_logs()
                
            except Exception as e:
                logger.error(f"Erreur lors de la rotation des logs: {e}")
    
    def _cleanup_old_logs(self):
        """Nettoie les anciens fichiers de logs (> 7 jours)"""
        try:
            cutoff = time.time() - (7 * 86400)  # 7 jours
            for filename in os.listdir('.'):
                if filename.startswith('resource_manager_') and filename.endswith('.log'):
                    filepath = os.path.join('.', filename)
                    file_mod_time = os.path.getmtime(filepath)
                    if file_mod_time < cutoff:
                        os.remove(filepath)
                        logger.debug(f"Ancien fichier log supprimé: {filename}")
        
        except Exception as e:
            logger.error(f"Erreur lors du nettoyage des anciens logs: {e}")
    
    def _adjust_performance_settings(self, cpu_percent, memory_percent):
        """
        Ajuste les paramètres de performance en fonction de la charge système
        
        Args:
            cpu_percent (float): Pourcentage d'utilisation CPU
            memory_percent (float): Pourcentage d'utilisation mémoire
        """
        # Calculer un score de charge (0-100)
        load_score = max(cpu_percent, memory_percent)
        
        # Ajuster le TTL du cache
        if load_score > 85:
            # Augmenter la durée du cache pour réduire les rafraîchissements
            self.cache_ttl = 120  # 2 minutes
        elif load_score > 70:
            self.cache_ttl = 90   # 1.5 minutes
        else:
            self.cache_ttl = 60   # 1 minute
        
        # Ajuster le cooldown entre appels API
        if load_score > 85:
            self.rate_limit_cooldown = 0.5  # 500ms
        elif load_score > 70:
            self.rate_limit_cooldown = 0.25  # 250ms
        else:
            self.rate_limit_cooldown = 0.1  # 100ms
    
    def _is_system_overloaded(self):
        """
        Vérifie si le système est en surcharge
        
        Returns:
            bool: True si le système est surchargé
        """
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory_percent = psutil.virtual_memory().percent
        
        return cpu_percent > self.high_load_threshold or memory_percent > self.high_load_threshold
    
    def _is_system_critically_overloaded(self):
        """
        Vérifie si le système est en surcharge critique
        
        Returns:
            bool: True si le système est en surcharge critique
        """
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory_percent = psutil.virtual_memory().percent
        
        return cpu_percent > self.extreme_load_threshold or memory_percent > self.extreme_load_threshold
    
    def _free_memory(self):
        """Libère de la mémoire en cas de besoin"""
        # Forcer le garbage collector
        gc.collect()
        
        # Vider les caches si la charge est très élevée
        if psutil.virtual_memory().percent > 90:
            logger.warning("Charge mémoire critique, vidage des caches")
            self.price_cache = {}
            self.data_cache = {}
    
    def get_cached_price(self, symbol):
        """
        Récupère le prix depuis le cache ou via API
        
        Args:
            symbol (str): Symbole de la paire (ex: "BTC/USD")
            
        Returns:
            float: Prix actuel ou None si non disponible
        """
        now = time.time()
        
        # Vérifier le cache
        if symbol in self.price_cache:
            cache_entry = self.price_cache[symbol]
            if now - cache_entry['timestamp'] < self.cache_ttl:
                self.usage_stats['cache_hits'] += 1
                return cache_entry['price']
        
        # Cache miss, obtenir via API
        self.usage_stats['cache_misses'] += 1
        
        # Vérifier le rate limiting
        self._check_rate_limit()
        
        try:
            # Obtenir le prix via exchange connector
            if self.exchange:
                price = self.exchange.get_ticker_price(symbol)
                
                # Mettre à jour le cache
                if price:
                    self.price_cache[symbol] = {
                        'price': price,
                        'timestamp': now
                    }
                
                self.usage_stats['api_calls'] += 1
                self.api_call_timestamps.append(now)
                
                return price
            
            return None
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {symbol}: {e}")
            return None
    
    def cache_data(self, key, data, ttl=None):
        """
        Stocke des données dans le cache
        
        Args:
            key (str): Clé d'identification
            data (any): Données à mettre en cache
            ttl (int, optional): Durée de vie en secondes
        """
        if ttl is None:
            ttl = self.cache_ttl
            
        self.data_cache[key] = {
            'data': data,
            'timestamp': time.time(),
            'ttl': ttl
        }
    
    def get_cached_data(self, key, fetch_func=None, ttl=None):
        """
        Récupère des données depuis le cache ou via la fonction de récupération
        
        Args:
            key (str): Clé d'identification
            fetch_func (callable, optional): Fonction à appeler si cache miss
            ttl (int, optional): Durée de vie en secondes
            
        Returns:
            any: Données du cache ou résultat de fetch_func
        """
        now = time.time()
        
        # Vérifier le cache
        if key in self.data_cache:
            cache_entry = self.data_cache[key]
            entry_ttl = cache_entry.get('ttl', self.cache_ttl)
            if now - cache_entry['timestamp'] < entry_ttl:
                self.usage_stats['cache_hits'] += 1
                return cache_entry['data']
        
        # Cache miss
        self.usage_stats['cache_misses'] += 1
        
        # Si pas de fonction de récupération, retourner None
        if fetch_func is None:
            return None
        
        # Vérifier le rate limiting si c'est un appel API
        self._check_rate_limit()
        
        try:
            # Obtenir les données via la fonction
            data = fetch_func()
            
            # Mettre à jour le cache
            if data is not None:
                self.cache_data(key, data, ttl)
            
            self.usage_stats['api_calls'] += 1
            self.api_call_timestamps.append(now)
            
            return data
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des données pour {key}: {e}")
            return None
    
    def _check_rate_limit(self):
        """
        Vérifie et applique le rate limiting
        Ajoute un délai si nécessaire pour respecter la limite d'appels API
        """
        now = time.time()
        
        # Nettoyer les appels plus vieux que 1 minute
        self.api_call_timestamps = [
            t for t in self.api_call_timestamps if now - t < 60
        ]
        
        # Vérifier le nombre d'appels dans la dernière minute
        if len(self.api_call_timestamps) >= self.max_calls_per_minute:
            # Calculer le temps à attendre
            wait_time = 60 - (now - min(self.api_call_timestamps))
            wait_time = max(wait_time, self.rate_limit_cooldown)
            
            logger.debug(f"Rate limit atteint, attente de {wait_time:.2f}s")
            self.usage_stats['rate_limit_delays'] += 1
            
            time.sleep(wait_time)
        
        # Toujours ajouter un petit délai entre les appels
        time.sleep(self.rate_limit_cooldown)
    
    def add_task(self, task, *args, **kwargs):
        """
        Ajoute une tâche à la file d'attente standard
        
        Args:
            task (callable): Fonction à exécuter
            *args, **kwargs: Arguments à passer à la fonction
        """
        self.task_queue.put((task, args, kwargs))
    
    def add_priority_task(self, priority, task_id, task, *args, **kwargs):
        """
        Ajoute une tâche à la file d'attente prioritaire
        
        Args:
            priority (int): Priorité (0-10, 0 étant la plus haute)
            task_id (str): Identifiant unique de la tâche
            task (callable): Fonction à exécuter
            *args, **kwargs: Arguments à passer à la fonction
        """
        self.priority_task_queue.put((priority, task_id, (task, args, kwargs)))
    
    def get_system_stats(self):
        """
        Récupère les statistiques du système
        
        Returns:
            dict: Statistiques système et d'utilisation
        """
        return {
            'cpu': psutil.cpu_percent(),
            'memory': psutil.virtual_memory().percent,
            'disk': psutil.disk_usage('/').percent,
            'api_calls': self.usage_stats['api_calls'],
            'cache_hits': self.usage_stats['cache_hits'],
            'cache_misses': self.usage_stats['cache_misses'],
            'tasks_processed': self.usage_stats['tasks_processed'],
            'rate_limit_delays': self.usage_stats['rate_limit_delays'],
            'price_cache_size': len(self.price_cache),
            'data_cache_size': len(self.data_cache),
            'task_queue_size': self.task_queue.qsize(),
            'priority_queue_size': self.priority_task_queue.qsize()
        }
    
    def clear_caches(self):
        """Vide tous les caches"""
        self.price_cache = {}
        self.data_cache = {}
        logger.info("Caches vidés")
    
    @lru_cache(maxsize=128)
    def cached_calculation(self, *args):
        """
        Exécute un calcul avec mise en cache automatique
        Cette méthode doit être utilisée comme un décorateur pour les calculs fréquents
        
        Args:
            *args: Arguments servant de clé de cache
            
        Returns:
            any: Résultat du calcul
        """
        # Cette méthode est juste un exemple d'utilisation de lru_cache
        # Le calcul réel dépend de comment la méthode est utilisée
        result = sum(args)
        return result


# Fonctions utilitaires globales
def batch_api_calls(exchange, method_name, params_list, batch_size=5):
    """
    Exécute des appels API par lots pour économiser des ressources
    
    Args:
        exchange: Connecteur d'échange avec les méthodes API
        method_name (str): Nom de la méthode à appeler
        params_list (list): Liste des paramètres pour chaque appel
        batch_size (int): Taille du lot
        
    Returns:
        list: Résultats des appels API
    """
    results = []
    method = getattr(exchange, method_name)
    
    # Traiter par lots
    for i in range(0, len(params_list), batch_size):
        batch = params_list[i:i+batch_size]
        
        # Exécuter les appels
        for params in batch:
            try:
                if isinstance(params, dict):
                    result = method(**params)
                else:
                    result = method(*params)
                results.append(result)
            except Exception as e:
                logger.error(f"Erreur batch API {method_name}: {e}")
                results.append(None)
        
        # Pause pour éviter de surcharger l'API
        time.sleep(0.5)
    
    return results


def setup_resource_optimized_exchange(exchange_connector):
    """
    Configure un exchange connector avec des optimisations de ressources
    
    Args:
        exchange_connector: Connecteur d'échange existant
        
    Returns:
        OptimizedResourceManager: Gestionnaire de ressources optimisé
    """
    resource_manager = OptimizedResourceManager(exchange_connector)
    
    # Créer un wrapper autour des méthodes de l'exchange
    original_get_ticker = exchange_connector.get_ticker_price
    
    def optimized_get_ticker(symbol):
        """Version optimisée de get_ticker_price avec caching"""
        return resource_manager.get_cached_price(symbol)
    
    # Remplacer la méthode originale
    exchange_connector.get_ticker_price = optimized_get_ticker
    
    return resource_manager