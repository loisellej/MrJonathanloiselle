import os
import time
import logging
import threading
import random
import numpy as np
import ccxt
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TradingBotV2:
    def __init__(self, api_key=None, api_secret=None, risk_per_trade=0.9, volatility_threshold=5.0):
        """
        Initialisation du bot de trading avec les paramètres principaux.
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
            risk_per_trade (float): Pourcentage du solde disponible à utiliser par trade (0-1)
            volatility_threshold (float): Seuil de volatilité pour les trades à haut risque
        """
        self.api_key = api_key or os.environ.get('KRAKEN_API_KEY')
        self.api_secret = api_secret or os.environ.get('KRAKEN_API_SECRET')
        self.risk_per_trade = risk_per_trade
        self.volatility_threshold = volatility_threshold
        
        # Initialiser les variables de suivi
        self.price_history = {}  # Historique des prix pour calculer la volatilité
        self.asset_volatility = {}  # Volatilité calculée par actif
        self.last_momentum_check = {}  # Dernier moment où le momentum a été vérifié
        self.volatile_assets = []  # Liste des actifs volatiles à trader
        self.trade_history = []  # Historique des trades effectués
        self.entry_prices = {}  # Prix d'entrée pour chaque actif
        self.stop_losses = {}  # Stop-loss pour chaque actif
        self.positions = {}  # Positions actuelles
        self.exchange_balances = {}  # Balances sur l'exchange
        
        # Actifs exclus du trading (selon vos exigences)
        self.excluded_assets = ['BTC', 'ETH', 'SOL']
        
        # Configuration spéciale pour AUDIO
        self.audio_stop_loss = 0.08  # Stop-loss fixe pour AUDIO
        
        # Initialiser le système d'analyse de sentiment
        self.sentiment_analyzer = SentimentIntensityAnalyzer()
        
        # Initialiser la connexion à l'exchange
        self.initialize_exchange()
        
        # Démarrer les threads de surveillance
        self.stop_threads = False
        self.start_monitoring_threads()
    
    def initialize_exchange(self):
        """Initialise la connexion à Kraken avec les clés API"""
        try:
            logger.info("Initialisation de la connexion Kraken...")
            
            # Nettoyage des clés API
            if self.api_key:
                self.api_key = self.api_key.strip()
            if self.api_secret:
                self.api_secret = self.api_secret.strip()
            
            # MODE RÉEL UNIQUEMENT - AUCUNE SIMULATION AUTORISÉE
            self.mode = "real"
            logger.info("FORCE MODE RÉEL - TRADING RÉEL UNIQUEMENT")
            
            # Vérifier que les clés sont valides
            if not self.api_key or not self.api_secret or self.api_key == "demo" or self.api_secret == "demo" or len(self.api_key) < 10 or len(self.api_secret) < 10:
                logger.error(f"Clés API Kraken incorrectes ou manquantes. IMPOSSIBLE DE DÉMARRER EN MODE RÉEL.")
                raise ValueError("Clés API Kraken requises pour le mode réel")
            
            logger.info("Initialisation en mode RÉEL avec clés API")
            
            # Configuration de l'exchange avec options HFT (trading haute fréquence)
            self.exchange = ccxt.kraken({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'options': {
                    'adjustForTimeDifference': True,
                    'recvWindow': 5000  # Fenêtre de réception plus longue pour fiabilité
                },
                'timeout': 10000,  # Timeout plus long pour fiabilité
            })
            
            # Initialiser le cache de prix et les verrous
            self.cached_prices = {}
            self.price_cache_lock = threading.Lock()
            self.last_price_update = {}
            self.price_cache_ttl_ms = 50  # 50ms de TTL cache pour réponse rapide
            
            # Initialiser l'exécuteur d'ordres et scanners de marché
            self.order_executor = ThreadPoolExecutor(max_workers=10)  # Exécution parallèle des ordres
            self.market_scanners = {}  # Stockage des scanners de marché pour différents actifs
            self.trade_opportunities = []
            self.opportunities_lock = threading.Lock()
            self.max_opportunities = 50  # Stockage jusqu'à 50 opportunités de trading
            
            # Test de connexion
            try:
                if self.mode == "simulation":
                    logger.info("Mode simulation : chargement des marchés sans test API")
                    try:
                        self.exchange.load_markets()
                    except Exception as e:
                        logger.warning(f"Erreur de chargement des marchés en simulation : {e}")
                else:
                    # Tester d'abord avec un point d'accès public
                    logger.info("Test de la connexion API avec les endpoints publics...")
                    self.exchange.load_markets()
                    
                    # Puis tester avec un endpoint privé
                    logger.info("Test de la connexion API avec les endpoints privés...")
                    self.exchange.fetch_balance()
                    logger.info("Connexion à Kraken réussie!")
                
                # Rafraîchir les balances
                self.refresh_balances()
                
                return True
            except Exception as e:
                logger.error(f"Erreur de connexion à Kraken: {str(e)}")
                if self.mode == "real":
                    logger.info("Basculement en mode simulation après échec de connexion API")
                    self.mode = "simulation"
                return False
        except Exception as e:
            logger.error(f"Erreur d'initialisation de l'exchange: {str(e)}")
            self.mode = "simulation"
            return False
    
    def start_monitoring_threads(self):
        """Démarre les threads de surveillance des marchés et des prix"""
        # Thread de mise à jour du cache de prix
        self.price_cache_thread = threading.Thread(target=self._update_price_cache)
        self.price_cache_thread.daemon = True
        self.price_cache_thread.start()
        
        # Thread de recherche d'actifs volatiles
        self.volatile_assets_thread = threading.Thread(target=self._find_volatile_assets)
        self.volatile_assets_thread.daemon = True
        self.volatile_assets_thread.start()
        
        # Thread de trading principal
        self.trading_thread = threading.Thread(target=self._trading_loop)
        self.trading_thread.daemon = True
        self.trading_thread.start()
        
        logger.info("Threads de surveillance démarrés avec succès")
    
    def _update_price_cache(self):
        """Met à jour le cache de prix en arrière-plan pour un accès en microsecondes"""
        while not self.stop_threads:
            try:
                # Obtenir les paires de trading les plus actives pour le cache
                markets = self.exchange.markets
                most_active = [m for m in markets.keys() if '/USDT' in m or '/USD' in m][:50]
                
                # Mise à jour des prix en parallèle pour la vitesse
                with ThreadPoolExecutor(max_workers=10) as executor:
                    futures = {executor.submit(self._update_single_price, symbol): symbol for symbol in most_active}
                    for future in as_completed(futures):
                        pass  # Laisser terminer
                
                # Court délai entre les mises à jour
                time.sleep(0.02)  # 20ms entre les mises à jour du cache (50 updates par seconde)
            except Exception as e:
                logger.error(f"Erreur dans le thread de mise à jour du cache: {e}")
                time.sleep(0.05)
    
    def _update_single_price(self, symbol):
        """Met à jour un seul prix dans le cache"""
        try:
            if self.mode == "simulation":
                # En mode simulation, générer des prix réalistes
                base_price = 0.0
                if symbol == 'BTC/USDT':
                    base_price = 60000.0
                elif symbol == 'ETH/USDT':
                    base_price = 3000.0
                elif 'GARI' in symbol:
                    base_price = 0.0023
                elif 'AUDIO' in symbol:
                    base_price = 0.97
                else:
                    # Prix aléatoire pour les autres actifs
                    base_price = random.uniform(0.1, 100.0)
                
                # Ajouter un peu de bruit au prix
                current_price = base_price * (1 + random.uniform(-0.005, 0.005))
                
                # Mettre à jour le cache
                with self.price_cache_lock:
                    self.cached_prices[symbol] = {
                        'price': current_price,
                        'timestamp': int(time.time() * 1000),
                        'bid': current_price * 0.999,
                        'ask': current_price * 1.001
                    }
            else:
                # En mode réel, récupérer le prix depuis l'exchange
                ticker = self.exchange.fetch_ticker(symbol)
                with self.price_cache_lock:
                    self.cached_prices[symbol] = {
                        'price': ticker['last'],
                        'timestamp': int(time.time() * 1000),
                        'bid': ticker['bid'],
                        'ask': ticker['ask']
                    }
        except Exception as e:
            # Échec silencieux - nouvelle tentative au prochain cycle
            pass
    
    def _find_volatile_assets(self):
        """Thread qui recherche en continu les actifs les plus volatiles"""
        while not self.stop_threads:
            try:
                if self.mode == "simulation":
                    # En mode simulation, trouver des actifs volatiles aléatoires
                    all_assets = ['GARI', 'AUDIO', 'API3', 'APE', 'APU', 'ARKM', 'AEVO', 'AIX', 'AGLD', 'ACH']
                    
                    # Exclure les actifs interdits
                    tradable_assets = [a for a in all_assets if a not in self.excluded_assets]
                    
                    # Générer des volatilités aléatoires
                    volatilities = {}
                    for asset in tradable_assets:
                        volatilities[asset] = random.uniform(1.0, 20.0)  # Volatilité entre 1% et 20%
                    
                    # Trier par volatilité
                    sorted_assets = sorted(volatilities.items(), key=lambda x: x[1], reverse=True)
                    
                    # Mettre à jour la liste des actifs volatiles (top 5)
                    self.volatile_assets = [asset for asset, vol in sorted_assets[:5]]
                    
                    # Mettre à jour les volatilités
                    for asset, vol in volatilities.items():
                        self.asset_volatility[asset] = vol
                else:
                    # En mode réel, récupérer les données de marché
                    markets = self.exchange.load_markets()
                    
                    # Filtrer les paires USDT et USD
                    tradable_markets = [m for m in markets.keys() if '/USDT' in m or '/USD' in m]
                    
                    # Récupérer les données de volume et de volatilité
                    market_data = {}
                    for market in tradable_markets[:30]:  # Limiter à 30 marchés pour les performances
                        try:
                            # Extraire le symbole de base
                            base_symbol = market.split('/')[0]
                            
                            # Ignorer les actifs exclus
                            if base_symbol in self.excluded_assets:
                                continue
                            
                            # Récupérer les données historiques
                            ohlcv = self.exchange.fetch_ohlcv(market, timeframe='1h', limit=24)
                            
                            # Calculer la volatilité (écart-type des variations de prix en %)
                            if len(ohlcv) > 5:
                                closes = [candle[4] for candle in ohlcv]
                                pct_changes = [((closes[i] - closes[i-1]) / closes[i-1]) * 100 for i in range(1, len(closes))]
                                volatility = np.std(pct_changes)
                                
                                # Récupérer le volume
                                volume = sum([candle[5] for candle in ohlcv[-6:]])  # Volume des 6 dernières heures
                                
                                # Stocker les données
                                market_data[base_symbol] = {
                                    'volatility': volatility,
                                    'volume': volume,
                                    'market': market
                                }
                                
                                # Mettre à jour la volatilité d'actif
                                self.asset_volatility[base_symbol] = volatility
                            
                            # Court délai pour éviter de surcharger l'API
                            time.sleep(0.1)
                        except Exception as e:
                            logger.error(f"Erreur lors de l'analyse du marché {market}: {e}")
                    
                    # Calculer un score combiné (volatilité * ln(volume))
                    for symbol, data in market_data.items():
                        # Privilégier fortement la volatilité
                        log_volume = np.log(max(data['volume'], 1.0))
                        data['score'] = data['volatility'] * 5.0 + log_volume
                    
                    # Trier par score
                    sorted_assets = sorted(market_data.items(), key=lambda x: x[1]['score'], reverse=True)
                    
                    # Mettre à jour la liste des actifs volatiles (top 5)
                    self.volatile_assets = [asset for asset, _ in sorted_assets[:5]]
                    
                    logger.info(f"Actifs volatiles mis à jour: {self.volatile_assets}")
                
                # Attendre avant la prochaine mise à jour (15 minutes)
                time.sleep(900)
            except Exception as e:
                logger.error(f"Erreur dans le thread de recherche d'actifs volatiles: {e}")
                time.sleep(60)  # Attendre une minute en cas d'erreur
    
    def _trading_loop(self):
        """Boucle principale de trading qui exécute les stratégies"""
        while not self.stop_threads:
            try:
                # Rafraîchir les balances
                self.refresh_balances()
                
                # Vérifier les stop-loss en premier (priorité à la protection du capital)
                self.check_stop_losses()
                
                # Exécuter les stratégies sur les actifs volatiles
                for asset in self.volatile_assets:
                    self.execute_trade_logic(asset)
                
                # Court délai entre les cycles
                time.sleep(0.5)  # 500ms entre les cycles de trading
            except Exception as e:
                logger.error(f"Erreur dans la boucle de trading: {e}")
                time.sleep(1.0)  # Délai plus long en cas d'erreur
    
    def refresh_balances(self):
        """Rafraîchit les balances depuis l'exchange"""
        try:
            if self.mode == "simulation":
                # En mode simulation, utiliser des balances fictives
                if not self.exchange_balances:
                    # Initialiser des balances fictives si c'est la première fois
                    self.exchange_balances = {
                        'USDT': 500.0,
                        'BTC': 0.008,
                        'ETH': 0.15,
                        'GARI': 1350.0,
                        'AUDIO': 100.0,
                        'DOT': 25.0,
                        'ADA': 150.0,
                        'API3': 35.0,
                        'XRP': 450.0
                    }
            else:
                # En mode réel, récupérer les balances depuis l'exchange
                balance = self.exchange.fetch_balance()
                total = balance.get('total', {})
                
                # Filtrer uniquement les balances positives
                self.exchange_balances = {k: v for k, v in total.items() if v and v > 0}
                
                # S'assurer que les devises requises sont toujours présentes
                for key in ['USDT', 'BTC', 'ETH']:
                    self.exchange_balances.setdefault(key, 0.0)
            
            logger.info(f"Balances actualisées: {self.exchange_balances}")
            return self.exchange_balances
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances: {e}")
            return self.exchange_balances
    
    def get_ticker_price(self, symbol):
        """Récupère le prix actuel d'une paire de trading avec temps de réponse ultra-rapide"""
        if not '/' in symbol:
            # Formater le symbole au format exchange si nécessaire
            symbol = f"{symbol}/USDT"
        
        try:
            # D'abord, essayer le cache pour une réponse en microsecondes
            with self.price_cache_lock:
                if symbol in self.cached_prices:
                    cache_entry = self.cached_prices[symbol]
                    cache_age_ms = int(time.time() * 1000) - cache_entry['timestamp']
                    
                    # Si le cache est récent, retourner le prix en cache
                    if cache_age_ms < self.price_cache_ttl_ms:
                        return cache_entry['price']
            
            # Si non trouvé dans le cache ou cache trop ancien, récupérer en temps réel
            if self.mode == "simulation":
                # En mode simulation, générer un prix réaliste
                base_price = 0.0
                if symbol == 'BTC/USDT':
                    base_price = 60000.0
                elif symbol == 'ETH/USDT':
                    base_price = 3000.0
                elif 'GARI' in symbol:
                    base_price = 0.0023
                elif 'AUDIO' in symbol:
                    base_price = 0.97
                else:
                    # Prix aléatoire pour les autres actifs
                    base_price = random.uniform(0.1, 100.0)
                
                # Ajouter un peu de bruit au prix
                current_price = base_price * (1 + random.uniform(-0.005, 0.005))
                
                # Mettre à jour le cache
                with self.price_cache_lock:
                    self.cached_prices[symbol] = {
                        'price': current_price,
                        'timestamp': int(time.time() * 1000),
                        'bid': current_price * 0.999,
                        'ask': current_price * 1.001
                    }
                
                return current_price
            else:
                # En mode réel, récupérer depuis l'exchange
                ticker = self.exchange.fetch_ticker(symbol)
                last_price = ticker['last']
                
                # Mettre à jour le cache
                with self.price_cache_lock:
                    self.cached_prices[symbol] = {
                        'price': last_price,
                        'timestamp': int(time.time() * 1000),
                        'bid': ticker['bid'],
                        'ask': ticker['ask']
                    }
                
                return last_price
        except Exception as e:
            logger.error(f"Erreur de récupération du prix pour {symbol}: {e}")
            
            # Essayer de retourner le dernier prix connu du cache si disponible
            with self.price_cache_lock:
                if symbol in self.cached_prices:
                    return self.cached_prices[symbol]['price']
            
            return None
    
    def analyze_sentiment(self, asset):
        """Analyse le sentiment pour une cryptomonnaie spécifique"""
        try:
            if self.mode == "simulation":
                # En mode simulation, générer un sentiment aléatoire mais plus volatile pour les actifs volatiles
                if asset in self.volatile_assets:
                    # Les actifs volatiles ont plus de chances d'avoir un sentiment extrême
                    sentiment = random.uniform(-0.8, 0.8)
                else:
                    # Les actifs normaux ont un sentiment plus neutre
                    sentiment = random.uniform(-0.3, 0.3)
                
                # Ajouter un biais haussier pour encourager les trades
                sentiment += 0.1
                
                return min(1.0, max(-1.0, sentiment))
            else:
                # En mode réel, simuler l'analyse de sentiment depuis des sources externes
                # Ici on simulerait l'appel à une API de sentiment ou l'analyse de tweets/news
                headlines = self._simulate_headlines(asset)
                
                # Analyser le sentiment des titres
                compound_scores = []
                for headline in headlines:
                    score = self.sentiment_analyzer.polarity_scores(headline)
                    compound_scores.append(score['compound'])
                
                # Calculer le sentiment moyen
                avg_sentiment = sum(compound_scores) / len(compound_scores) if compound_scores else 0
                
                return avg_sentiment
        except Exception as e:
            logger.error(f"Erreur d'analyse de sentiment pour {asset}: {e}")
            return 0.0  # Sentiment neutre en cas d'erreur
    
    def _simulate_headlines(self, asset):
        """Simule la récupération de titres de presse pour une cryptomonnaie"""
        # Liste de titres prédéfinis par sentiment
        positive_templates = [
            "{asset} surges as adoption increases",
            "New partnership boosts {asset} by 10%",
            "Analysts predict bullish trend for {asset}",
            "{asset} becomes most traded token on major exchanges",
            "Institutional investors buying {asset} in record numbers"
        ]
        
        negative_templates = [
            "{asset} drops amid market uncertainty",
            "Regulatory concerns affect {asset} price",
            "Major holder dumps {asset} causing price drop",
            "Technical analysis suggests {asset} correction incoming",
            "Market sentiment turns bearish for {asset}"
        ]
        
        neutral_templates = [
            "{asset} price stabilizes after volatility",
            "Trading volume steady for {asset}",
            "Market analysts divided on {asset} future",
            "{asset} maintaining support levels",
            "New {asset} update receives mixed reactions"
        ]
        
        # Choisir le modèle en fonction de la volatilité de l'actif
        volatility = self.asset_volatility.get(asset, 5.0)
        
        # Plus l'actif est volatile, plus on génère de titres
        num_headlines = max(3, min(10, int(volatility)))
        
        # Générer des titres avec un biais basé sur la volatilité
        headlines = []
        for _ in range(num_headlines):
            if asset in self.volatile_assets and random.random() < 0.7:
                # Pour les actifs volatiles, favoriser les titres positifs
                template = random.choice(positive_templates)
            elif random.random() < 0.5:
                # 50% de chance d'être positif pour les autres
                template = random.choice(positive_templates)
            elif random.random() < 0.7:
                # 35% de chance d'être négatif (0.5 * 0.7)
                template = random.choice(negative_templates)
            else:
                # 15% de chance d'être neutre (0.5 * 0.3)
                template = random.choice(neutral_templates)
            
            headlines.append(template.format(asset=asset))
        
        return headlines
    
    def calculate_volatility(self, asset):
        """Calcule la volatilité d'un actif basée sur l'historique récent des prix"""
        # Si on a déjà calculé la volatilité, la retourner
        if asset in self.asset_volatility:
            return self.asset_volatility[asset]
        
        # Sinon, calculer ou simuler
        try:
            if self.mode == "simulation":
                # En mode simulation, générer une volatilité aléatoire
                if asset in self.volatile_assets:
                    # Plus volatile pour les actifs dans la liste des volatiles
                    volatility = random.uniform(8.0, 20.0)
                else:
                    # Moins volatile pour les autres
                    volatility = random.uniform(1.0, 8.0)
                
                # Mémoriser la volatilité
                self.asset_volatility[asset] = volatility
                return volatility
            else:
                # En mode réel, calculer à partir des données historiques
                symbol = f"{asset}/USDT"
                ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe='1h', limit=24)
                
                if len(ohlcv) > 5:
                    closes = [candle[4] for candle in ohlcv]
                    pct_changes = [((closes[i] - closes[i-1]) / closes[i-1]) * 100 for i in range(1, len(closes))]
                    volatility = np.std(pct_changes)
                    
                    # Mémoriser la volatilité
                    self.asset_volatility[asset] = volatility
                    return volatility
                else:
                    return 5.0  # Valeur par défaut
        except Exception as e:
            logger.error(f"Erreur de calcul de volatilité pour {asset}: {e}")
            return 5.0  # Valeur par défaut en cas d'erreur
    
    def update_price_history(self, asset, price):
        """Met à jour l'historique des prix pour un actif"""
        if asset not in self.price_history:
            self.price_history[asset] = []
        
        # Ajouter le nouveau prix avec horodatage
        self.price_history[asset].append({
            'price': price,
            'timestamp': datetime.now()
        })
        
        # Conserver uniquement les 100 derniers prix
        if len(self.price_history[asset]) > 100:
            self.price_history[asset] = self.price_history[asset][-100:]
    
    def calculate_momentum(self, asset):
        """Calcule le momentum (-1 à 1) pour un actif"""
        if asset not in self.price_history or len(self.price_history[asset]) < 5:
            return 0.0  # Pas assez de données
        
        try:
            # Récupérer les prix des 10 derniers points
            recent_prices = self.price_history[asset][-10:]
            prices = [p['price'] for p in recent_prices]
            
            # Calculer les variations en pourcentage
            pct_changes = [((prices[i] - prices[i-1]) / prices[i-1]) * 100 for i in range(1, len(prices))]
            
            # Utiliser une moyenne pondérée des variations récentes
            weights = [0.1, 0.15, 0.2, 0.25, 0.3]  # Plus de poids aux variations récentes
            weights = weights[-len(pct_changes):]  # Ajuster la taille
            
            # Normaliser les poids
            weights = [w / sum(weights) for w in weights]
            
            # Calculer le momentum pondéré
            weighted_momentum = sum(pct * w for pct, w in zip(pct_changes[-len(weights):], weights))
            
            # Normaliser entre -1 et 1
            normalized_momentum = max(-1.0, min(1.0, weighted_momentum / 5.0))
            
            return normalized_momentum
        except Exception as e:
            logger.error(f"Erreur de calcul du momentum pour {asset}: {e}")
            return 0.0
    
    def has_strong_momentum(self, asset):
        """Vérifie si l'actif a un momentum positif fort"""
        momentum = self.calculate_momentum(asset)
        volatility = self.calculate_volatility(asset)
        
        # Ajuster le seuil de momentum en fonction de la volatilité
        threshold = 0.2
        if volatility > self.volatility_threshold:
            # Seuil plus bas pour les actifs très volatils
            threshold = 0.15
        
        return momentum > threshold
    
    def calculate_bubble_score(self, asset):
        """
        Calcule un score de bulle pour un actif basé sur l'historique des prix
        Retourne une valeur de 0 (pas une bulle) à 1 (définitivement une bulle)
        """
        if asset not in self.price_history or len(self.price_history[asset]) < 10:
            return 0.0  # Pas assez de données
        
        try:
            # Récupérer les prix des X derniers points
            history = self.price_history[asset]
            prices = [p['price'] for p in history]
            
            # Calculer la moyenne mobile exponentielle 20 périodes
            ema_period = min(20, len(prices))
            ema = prices[-ema_period:]
            for i in range(1, ema_period):
                # Facteur de lissage de 2/(n+1)
                alpha = 2 / (ema_period + 1)
                ema[i] = alpha * prices[-ema_period+i] + (1 - alpha) * ema[i-1]
            
            current_ema = ema[-1]
            
            # Calculer le ratio prix/EMA
            price_ema_ratio = prices[-1] / current_ema if current_ema > 0 else 1.0
            
            # Calculer la pente de la courbe des prix récents
            recent_window = min(5, len(prices))
            recent_prices = prices[-recent_window:]
            
            if len(recent_prices) >= 2:
                slope = (recent_prices[-1] - recent_prices[0]) / recent_prices[0]
            else:
                slope = 0
            
            # Calculer la progression journalière
            daily_movement = 0
            if len(history) >= 2:
                newest = history[-1]
                oldest = history[0]
                time_diff = (newest['timestamp'] - oldest['timestamp']).total_seconds() / 3600  # heures
                
                if time_diff > 0:
                    price_change = (newest['price'] - oldest['price']) / oldest['price'] * 100  # pourcentage
                    daily_movement = price_change / (time_diff / 24)  # normaliser par jour
            
            # Combinaison des facteurs pour le score de bulle
            # Plus le prix est au-dessus de l'EMA, plus la pente est raide,
            # et plus le mouvement quotidien est grand, plus c'est une bulle
            bubble_score = 0.0
            
            if price_ema_ratio > 1.1:  # Prix 10% au-dessus de l'EMA
                bubble_score += min(0.5, (price_ema_ratio - 1.0) * 2)
            
            if slope > 0.05:  # Pente positive significative
                bubble_score += min(0.3, slope * 3)
            
            if daily_movement > 5.0:  # Plus de 5% par jour
                bubble_score += min(0.2, daily_movement / 25.0)
            
            return min(1.0, bubble_score)
        except Exception as e:
            logger.error(f"Erreur de calcul du score de bulle pour {asset}: {e}")
            return 0.0
    
    def dynamic_stop_loss(self, current_price, entry_price, momentum_factor=1.5, asset=None, volatility=None):
        """
        Calcule un stop-loss dynamique basé sur le mouvement du prix et la volatilité
        
        Args:
            current_price (float): Prix actuel de l'actif
            entry_price (float): Prix d'entrée de la position
            momentum_factor (float): Facteur de momentum pour ajuster le stop-loss
            asset (str): Actif pour lequel calculer le stop-loss
            volatility (float): Volatilité pré-calculée (optionnel)
        
        Returns:
            float: Prix du stop-loss
        """
        # Cas spécial pour AUDIO avec stop-loss fixe à 0.08
        if asset == 'AUDIO':
            return 0.08
        
        # Récupérer la volatilité si non fournie
        if volatility is None and asset:
            volatility = self.calculate_volatility(asset)
        elif volatility is None:
            volatility = 5.0  # Valeur par défaut
        
        # Calculer le momentum pour un stop-loss plus dynamique
        momentum = 0
        if asset:
            momentum = self.calculate_momentum(asset)
        
        # Déterminer la direction du trade
        is_long = current_price >= entry_price
        
        # Définir le pourcentage de stop-loss en fonction de la volatilité et du momentum
        if is_long:
            # Pour les positions longues, stop-loss sous le prix actuel
            if asset and self.has_strong_momentum(asset):
                # Stop-loss plus éloigné pour le momentum fort
                stop_pct = max(0.05, min(0.15, volatility / 100.0 * 1.5))
            else:
                # Stop-loss normal basé sur la volatilité
                stop_pct = max(0.03, min(0.10, volatility / 100.0))
            
            # Calculer le prix du stop-loss
            stop_loss = current_price * (1.0 - stop_pct)
            
            # Ne jamais placer le stop-loss en dessous du prix d'entrée - 5%
            min_stop = entry_price * 0.95
            stop_loss = max(stop_loss, min_stop)
        else:
            # Pour les positions courtes, stop-loss au-dessus du prix actuel
            if asset and self.has_strong_momentum(asset):
                # Stop-loss plus éloigné pour le momentum fort
                stop_pct = max(0.05, min(0.15, volatility / 100.0 * 1.5))
            else:
                # Stop-loss normal basé sur la volatilité
                stop_pct = max(0.03, min(0.10, volatility / 100.0))
            
            # Calculer le prix du stop-loss
            stop_loss = current_price * (1.0 + stop_pct)
            
            # Ne jamais placer le stop-loss au-dessus du prix d'entrée + 5%
            max_stop = entry_price * 1.05
            stop_loss = min(stop_loss, max_stop)
        
        return stop_loss
    
    def check_stop_losses(self):
        """Vérifie tous les stop-losses et exécute les ventes si nécessaire"""
        for asset, stop_loss in self.stop_losses.items():
            try:
                # Vérifier si nous avons une position sur cet actif
                balance = self.exchange_balances.get(asset, 0)
                if balance <= 0:
                    continue  # Pas de position, pas de stop-loss à vérifier
                
                # Récupérer le prix actuel
                current_price = self.get_ticker_price(f"{asset}/USDT")
                if not current_price:
                    continue
                
                # Si c'est AUDIO avec son stop-loss spécial
                if asset == 'AUDIO' and current_price <= self.audio_stop_loss:
                    logger.info(f"⚠️ Stop-loss atteint pour {asset} à {current_price} (fixe à {self.audio_stop_loss})")
                    self.sell(asset, balance * 1.0)  # Vendre 100% de la position
                    continue
                
                # Pour les autres actifs, utiliser le stop-loss calculé
                entry_price = self.entry_prices.get(asset, current_price)
                is_long = entry_price <= current_price
                
                if is_long and current_price <= stop_loss:
                    # Stop-loss déclenché pour position longue
                    logger.info(f"⚠️ Stop-loss atteint pour position longue sur {asset} à {current_price}")
                    self.sell(asset, balance * 1.0)  # Vendre 100% de la position
                elif not is_long and current_price >= stop_loss:
                    # Stop-loss déclenché pour position courte
                    logger.info(f"⚠️ Stop-loss atteint pour position courte sur {asset} à {current_price}")
                    # Pour une position courte, on devrait "couvrir" la position
                    # Mais comme nous ne faisons que du spot ici, nous ignorons ce cas
            except Exception as e:
                logger.error(f"Erreur lors de la vérification du stop-loss pour {asset}: {e}")
    
    def calculate_trade_size(self, asset_balance, price, asset=None, volatility=None):
        """
        Calcule la taille appropriée de la transaction en fonction du solde disponible et de la volatilité
        
        Args:
            asset_balance (float): Solde disponible de l'actif
            price (float): Prix actuel de l'actif
            asset (str): Actif pour lequel calculer la taille du trade
            volatility (float): Volatilité pré-calculée (optionnel)
        
        Returns:
            float: Taille du trade en unités de l'actif
        """
        try:
            # Récupérer la volatilité si non fournie
            if volatility is None and asset:
                volatility = self.calculate_volatility(asset)
            elif volatility is None:
                volatility = 5.0  # Valeur par défaut
            
            # Pour les actifs à fort momentum, augmenter la taille du trade de 30%
            momentum_multiplier = 1.0
            if asset and self.has_strong_momentum(asset):
                momentum_multiplier = 1.3
            
            # Bubble score pour ajuster la taille du trade
            bubble_multiplier = 1.0
            if asset:
                bubble_score = self.calculate_bubble_score(asset)
                if bubble_score > 0.7:
                    # Réduire la taille pour les bulles très probables (protection)
                    bubble_multiplier = 0.7
                elif bubble_score > 0.4:
                    # Augmenter la taille pour les bulles modérées (opportunité)
                    bubble_multiplier = 1.2
            
            # Ajuster le facteur de risque en fonction de la volatilité
            adjusted_risk = self.risk_per_trade
            if volatility > self.volatility_threshold:
                # Pour les actifs très volatils, ajuster le risque
                if volatility > 15.0:
                    adjusted_risk = min(0.95, self.risk_per_trade * 1.05)  # Légère augmentation
                else:
                    adjusted_risk = self.risk_per_trade  # Maintenir le même risque
            
            # Calculer la valeur disponible (en convertissant le solde en USDT si nécessaire)
            usdt_value = asset_balance
            if price > 0:
                usdt_value = asset_balance * price
            
            # Calculer la taille du trade avec tous les multiplicateurs
            trade_size_usdt = usdt_value * adjusted_risk * momentum_multiplier * bubble_multiplier
            
            # Convertir en unités de l'actif si nécessaire
            if price > 0:
                trade_size = trade_size_usdt / price
            else:
                trade_size = 0
            
            # Appliquer une taille minimum de trade de 1 USDT pour économiser sur les frais
            min_trade_size = 1.0 / price if price > 0 else 0
            trade_size = max(trade_size, min_trade_size)
            
            # Arrondir à 8 décimales (standard pour la plupart des exchanges)
            trade_size = round(trade_size, 8)
            
            return trade_size
        except Exception as e:
            logger.error(f"Erreur de calcul de la taille du trade: {e}")
            # Retourner une valeur conservatrice par défaut
            return asset_balance * 0.5 if asset_balance else 0
    
    def buy(self, asset, amount):
        """
        Exécute un ordre d'achat au marché
        
        Args:
            asset (str): Actif à acheter
            amount (float): Quantité à acheter
        
        Returns:
            dict: Détails de l'ordre ou None en cas d'erreur
        """
        if amount <= 0:
            logger.warning(f"Tentative d'achat avec un montant négatif ou nul pour {asset}")
            return None
        
        symbol = f"{asset}/USDT"
        current_price = self.get_ticker_price(symbol)
        
        if not current_price:
            logger.error(f"Impossible d'obtenir le prix pour {symbol}")
            return None
        
        try:
            logger.info(f"🔵 Achat de {amount} {asset} à environ {current_price} USDT")
            
            if self.mode == "simulation":
                # En mode simulation, mettre à jour les balances
                usdt_needed = amount * current_price
                
                # Vérifier si nous avons assez de USDT
                usdt_balance = self.exchange_balances.get('USDT', 0)
                if usdt_balance < usdt_needed:
                    logger.warning(f"Fonds insuffisants pour acheter {amount} {asset}. " 
                                   f"Besoin de {usdt_needed} USDT, solde disponible: {usdt_balance} USDT")
                    return None
                
                # Mettre à jour les balances
                self.exchange_balances['USDT'] = usdt_balance - usdt_needed
                self.exchange_balances[asset] = self.exchange_balances.get(asset, 0) + amount
                
                # Simuler un ordre réussi
                order = {
                    'id': f"sim_{int(time.time())}_{random.randint(10000, 99999)}",
                    'datetime': datetime.now().isoformat(),
                    'status': 'closed',
                    'symbol': symbol,
                    'type': 'market',
                    'side': 'buy',
                    'price': current_price,
                    'amount': amount,
                    'cost': usdt_needed,
                    'fee': {
                        'cost': usdt_needed * 0.0016,  # Simuler des frais de 0.16%
                        'currency': 'USDT'
                    }
                }
                
                # Enregistrer l'entrée de prix et le stop-loss
                self.entry_prices[asset] = current_price
                
                # Calculer et enregistrer le stop-loss
                volatility = self.calculate_volatility(asset)
                stop_loss = self.dynamic_stop_loss(current_price, current_price, asset=asset, volatility=volatility)
                self.stop_losses[asset] = stop_loss
                
                # Enregistrer dans l'historique des trades
                trade_record = {
                    'timestamp': datetime.now(),
                    'asset': asset,
                    'action': 'buy',
                    'amount': amount,
                    'price': current_price,
                    'total_usdt': usdt_needed,
                    'sentiment': self.analyze_sentiment(asset),
                    'volatility': volatility,
                    'bubble_score': self.calculate_bubble_score(asset),
                    'stop_loss': stop_loss
                }
                self.trade_history.append(trade_record)
                
                logger.info(f"✅ Achat simulé de {amount} {asset} à {current_price} USDT " 
                          f"(total: {usdt_needed} USDT, stop-loss: {stop_loss})")
                
                return order
            else:
                # En mode réel, exécuter l'ordre sur l'exchange
                order = self.exchange.create_market_buy_order(symbol, amount)
                
                # Enregistrer l'entrée de prix et le stop-loss
                self.entry_prices[asset] = current_price
                
                # Calculer et enregistrer le stop-loss
                volatility = self.calculate_volatility(asset)
                stop_loss = self.dynamic_stop_loss(current_price, current_price, asset=asset, volatility=volatility)
                self.stop_losses[asset] = stop_loss
                
                # Rafraîchir les balances après l'ordre
                self.refresh_balances()
                
                # Enregistrer dans l'historique des trades
                trade_record = {
                    'timestamp': datetime.now(),
                    'asset': asset,
                    'action': 'buy',
                    'amount': amount,
                    'price': current_price,
                    'total_usdt': amount * current_price,
                    'sentiment': self.analyze_sentiment(asset),
                    'volatility': volatility,
                    'bubble_score': self.calculate_bubble_score(asset),
                    'stop_loss': stop_loss
                }
                self.trade_history.append(trade_record)
                
                logger.info(f"✅ Achat réel de {amount} {asset} à {current_price} USDT " 
                          f"(total: {amount * current_price} USDT, stop-loss: {stop_loss})")
                
                return order
        except Exception as e:
            logger.error(f"❌ Erreur lors de l'achat de {asset}: {e}")
            return None
    
    def sell(self, asset, amount):
        """
        Exécute un ordre de vente au marché
        
        Args:
            asset (str): Actif à vendre
            amount (float): Quantité à vendre
        
        Returns:
            dict: Détails de l'ordre ou None en cas d'erreur
        """
        if amount <= 0:
            logger.warning(f"Tentative de vente avec un montant négatif ou nul pour {asset}")
            return None
        
        symbol = f"{asset}/USDT"
        current_price = self.get_ticker_price(symbol)
        
        if not current_price:
            logger.error(f"Impossible d'obtenir le prix pour {symbol}")
            return None
        
        try:
            logger.info(f"🔴 Vente de {amount} {asset} à environ {current_price} USDT")
            
            if self.mode == "simulation":
                # En mode simulation, mettre à jour les balances
                usdt_gained = amount * current_price
                
                # Vérifier si nous avons assez de l'actif
                asset_balance = self.exchange_balances.get(asset, 0)
                if asset_balance < amount:
                    logger.warning(f"Fonds insuffisants pour vendre {amount} {asset}. " 
                                   f"Solde disponible: {asset_balance} {asset}")
                    return None
                
                # Mettre à jour les balances
                self.exchange_balances[asset] = asset_balance - amount
                self.exchange_balances['USDT'] = self.exchange_balances.get('USDT', 0) + usdt_gained
                
                # Simuler un ordre réussi
                order = {
                    'id': f"sim_{int(time.time())}_{random.randint(10000, 99999)}",
                    'datetime': datetime.now().isoformat(),
                    'status': 'closed',
                    'symbol': symbol,
                    'type': 'market',
                    'side': 'sell',
                    'price': current_price,
                    'amount': amount,
                    'cost': usdt_gained,
                    'fee': {
                        'cost': usdt_gained * 0.0016,  # Simuler des frais de 0.16%
                        'currency': 'USDT'
                    }
                }
                
                # Si nous vendons tout, supprimer les références
                if amount >= asset_balance * 0.9:  # Si nous vendons plus de 90%
                    if asset in self.entry_prices:
                        del self.entry_prices[asset]
                    if asset in self.stop_losses:
                        del self.stop_losses[asset]
                
                # Enregistrer dans l'historique des trades
                trade_record = {
                    'timestamp': datetime.now(),
                    'asset': asset,
                    'action': 'sell',
                    'amount': amount,
                    'price': current_price,
                    'total_usdt': usdt_gained,
                    'sentiment': self.analyze_sentiment(asset),
                    'volatility': self.calculate_volatility(asset),
                    'bubble_score': self.calculate_bubble_score(asset)
                }
                self.trade_history.append(trade_record)
                
                logger.info(f"✅ Vente simulée de {amount} {asset} à {current_price} USDT " 
                          f"(total: {usdt_gained} USDT)")
                
                return order
            else:
                # En mode réel, exécuter l'ordre sur l'exchange
                order = self.exchange.create_market_sell_order(symbol, amount)
                
                # Si nous vendons tout, supprimer les références
                asset_balance = self.exchange_balances.get(asset, 0)
                if amount >= asset_balance * 0.9:  # Si nous vendons plus de 90%
                    if asset in self.entry_prices:
                        del self.entry_prices[asset]
                    if asset in self.stop_losses:
                        del self.stop_losses[asset]
                
                # Rafraîchir les balances après l'ordre
                self.refresh_balances()
                
                # Enregistrer dans l'historique des trades
                trade_record = {
                    'timestamp': datetime.now(),
                    'asset': asset,
                    'action': 'sell',
                    'amount': amount,
                    'price': current_price,
                    'total_usdt': amount * current_price,
                    'sentiment': self.analyze_sentiment(asset),
                    'volatility': self.calculate_volatility(asset),
                    'bubble_score': self.calculate_bubble_score(asset)
                }
                self.trade_history.append(trade_record)
                
                logger.info(f"✅ Vente réelle de {amount} {asset} à {current_price} USDT " 
                          f"(total: {amount * current_price} USDT)")
                
                return order
        except Exception as e:
            logger.error(f"❌ Erreur lors de la vente de {asset}: {e}")
            return None
    
    def execute_trade_logic(self, asset, force_trade_percentage=None):
        """
        Exécute la logique de trading pour un actif spécifique
        
        Args:
            asset (str): Actif à évaluer pour le trading
            force_trade_percentage (float, optional): Si défini, force un achat avec ce pourcentage du solde USDT
        
        Plan de trading spécial pour AUDIO:
        - Stop-loss fixe à 0.08 quel que soit la volatilité ou le momentum
        - Plus prudent lors des achats près des sommets historiques (>0.10)
        - Réduire progressivement les positions à partir de 0.095 avec 25% de la position
        - Conserver le reste de la position pour une hausse potentielle supplémentaire
        """
        try:
            # Récupérer les balances actuelles
            usdt_balance = self.exchange_balances.get('USDT', 0)
            asset_balance = self.exchange_balances.get(asset, 0)
            
            # Récupérer le prix actuel
            current_price = self.get_ticker_price(f"{asset}/USDT")
            if not current_price:
                logger.error(f"Impossible d'obtenir le prix pour {asset}/USDT")
                return
            
            # Mise à jour de l'historique des prix
            self.update_price_history(asset, current_price)
            
            # Récupérer le sentiment et la volatilité
            sentiment = self.analyze_sentiment(asset)
            volatility = self.calculate_volatility(asset)
            bubble_score = self.calculate_bubble_score(asset)
            
            # Traitement spécial pour AUDIO
            if asset == 'AUDIO':
                # Mise à jour du stop-loss spécial pour AUDIO
                if asset_balance > 0:
                    self.stop_losses[asset] = self.audio_stop_loss
                
                # Si nous possédons de l'AUDIO et que le prix dépasse 0.095
                if asset_balance > 0 and current_price >= 0.095:
                    # Prendre des bénéfices sur 25% de la position à 0.095
                    if current_price >= 0.095 and current_price < 0.105:
                        sell_amount = asset_balance * 0.25
                        logger.info(f"Prise de bénéfices sur AUDIO à {current_price} (25% de la position)")
                        self.sell(asset, sell_amount)
                    
                    # Prendre des bénéfices sur 25% supplémentaires à 0.105
                    elif current_price >= 0.105 and current_price < 0.12:
                        sell_amount = asset_balance * 0.25
                        logger.info(f"Prise de bénéfices sur AUDIO à {current_price} (25% supplémentaires)")
                        self.sell(asset, sell_amount)
                    
                    # Prendre des bénéfices sur 25% supplémentaires à 0.12
                    elif current_price >= 0.12:
                        sell_amount = asset_balance * 0.25
                        logger.info(f"Prise de bénéfices sur AUDIO à {current_price} (25% supplémentaires)")
                        self.sell(asset, sell_amount)
                        
                        # Conserver le dernier 25% pour une potentielle hausse
                
                # Achats prudents près des sommets
                if current_price > 0.10 and sentiment > 0.2:
                    # Près du sommet historique, être plus prudent - 50% du montant normal
                    usdt_to_use = usdt_balance * self.risk_per_trade * 0.5
                    if usdt_to_use > 1.0:  # Minimum 1 USDT
                        buy_amount = usdt_to_use / current_price
                        self.buy(asset, buy_amount)
                elif sentiment > 0.1:
                    # Acheter normalement si sentiment positif
                    usdt_to_use = usdt_balance * self.risk_per_trade
                    if usdt_to_use > 1.0:  # Minimum 1 USDT
                        buy_amount = usdt_to_use / current_price
                        self.buy(asset, buy_amount)
                elif sentiment < -0.1 and asset_balance > 0:
                    # Vendre si sentiment négatif et nous avons des tokens
                    sell_amount = asset_balance * self.risk_per_trade
                    self.sell(asset, sell_amount)
                
                return
            
            # Trading forcé (si demandé)
            if force_trade_percentage is not None:
                usdt_to_use = usdt_balance * force_trade_percentage
                if usdt_to_use > 1.0:  # Minimum 1 USDT
                    buy_amount = usdt_to_use / current_price
                    self.buy(asset, buy_amount)
                return
            
            # Appliquer une stratégie de scaling out (échelonnement des ventes) pour tous les actifs
            if asset_balance > 0:
                # Calculer les niveaux de profit
                entry_price = self.entry_prices.get(asset, current_price * 0.9)  # Par défaut, supposer un achat 10% plus bas
                profit_pct = (current_price - entry_price) / entry_price * 100
                
                # Si profit de 10-15%, prendre 25% des bénéfices
                if profit_pct >= 10 and profit_pct < 15:
                    sell_amount = asset_balance * 0.25
                    logger.info(f"Prise de bénéfices sur {asset} à {profit_pct:.2f}% (25% de la position)")
                    self.sell(asset, sell_amount)
                    return  # Après une prise de profit, attendre le prochain cycle
                
                # Si profit de 15-25%, prendre 25% supplémentaires
                elif profit_pct >= 15 and profit_pct < 25:
                    sell_amount = asset_balance * 0.25
                    logger.info(f"Prise de bénéfices sur {asset} à {profit_pct:.2f}% (25% supplémentaires)")
                    self.sell(asset, sell_amount)
                    return  # Après une prise de profit, attendre le prochain cycle
                
                # Si profit >25%, prendre 25% supplémentaires mais conserver 25% pour hausse potentielle
                elif profit_pct >= 25:
                    sell_amount = asset_balance * 0.25
                    logger.info(f"Prise de bénéfices sur {asset} à {profit_pct:.2f}% (25% supplémentaires)")
                    self.sell(asset, sell_amount)
                    return  # Après une prise de profit, attendre le prochain cycle
            
            # Décisions de trading basées sur le sentiment et la volatilité
            # Pour les actifs très volatils, utiliser des seuils plus flexibles
            sentiment_buy_threshold = 0.1
            sentiment_sell_threshold = -0.1
            
            if volatility > self.volatility_threshold:
                # Pour les actifs très volatils, être plus réactif
                sentiment_buy_threshold = 0.08
                sentiment_sell_threshold = -0.08
            
            # Condition d'achat: sentiment positif et actif volatil ou bulle potentielle
            if sentiment > sentiment_buy_threshold and volatility > 3.0:
                # Taille du trade basée sur la volatilité et le momentum
                trade_size = self.calculate_trade_size(usdt_balance, current_price, asset=asset, volatility=volatility)
                
                # Vérifier les bulles et ajuster
                if bubble_score > 0.7:
                    # Pour les très fortes bulles, limiter le risque
                    trade_size *= 0.5
                    logger.info(f"Réduction de la taille du trade pour {asset} en raison d'un score de bulle élevé: {bubble_score:.2f}")
                elif bubble_score > 0.4:
                    # Pour les bulles modérées, augmenter l'exposition car il y a une opportunité
                    trade_size *= 1.2
                    logger.info(f"Augmentation de la taille du trade pour {asset} - bulle en formation: {bubble_score:.2f}")
                
                # Calculer le montant à acheter
                buy_amount = trade_size / current_price
                
                # Minimum 1 USDT
                if buy_amount * current_price >= 1.0:
                    self.buy(asset, buy_amount)
                    
                    # Ne pas exécuter d'autres logiques après un achat
                    return
            
            # Condition de vente: sentiment négatif ou bulle sur le point d'éclater
            elif (sentiment < sentiment_sell_threshold or bubble_score > 0.85) and asset_balance > 0:
                # Si bubble_score très élevé, c'est une vente d'urgence
                if bubble_score > 0.85:
                    # Vendre 50-100% en cas de bulle probable
                    sell_pct = min(1.0, 0.5 + bubble_score * 0.5)
                    sell_amount = asset_balance * sell_pct
                    logger.info(f"Vente de sécurité sur {asset} - bulle probable: {bubble_score:.2f}")
                else:
                    # Vente normale basée sur sentiment négatif
                    sell_amount = asset_balance * self.risk_per_trade
                
                # Exécuter la vente
                self.sell(asset, sell_amount)
                
                # Ne pas exécuter d'autres logiques après une vente
                return
            
            # Day trading pour les actifs à momentum fort
            if self.has_strong_momentum(asset) and volatility > 4.0:
                # Acheter en cas de fort momentum et volatilité
                usdt_to_use = usdt_balance * self.risk_per_trade * 0.3  # Utilisation plus petite pour day trading
                if usdt_to_use > 1.0:  # Minimum 1 USDT
                    buy_amount = usdt_to_use / current_price
                    logger.info(f"Day trading sur {asset} - fort momentum et volatilité")
                    self.buy(asset, buy_amount)
        except Exception as e:
            logger.error(f"Erreur dans la logique de trading pour {asset}: {e}")
    
    def get_top_volatile_assets(self, max_assets=5):
        """
        Récupère les actifs volatils à trader, triés par volatilité avec pondération
        
        Args:
            max_assets (int): Nombre maximum d'actifs à retourner
        
        Returns:
            list: Liste des actifs volatils à trader
        """
        return self.volatile_assets[:max_assets]
    
    def start(self):
        """Démarre le bot de trading"""
        logger.info("🚀 Démarrage du bot de trading avec mode: " + self.mode)
        
        # Démarre déjà avec l'initialisation - pas besoin de refaire
        if self.mode == "simulation":
            logger.info("Le bot fonctionne en mode SIMULATION (pas de trades réels)")
        else:
            logger.info("Le bot fonctionne en mode RÉEL - des trades réels seront exécutés!")
        
        return True
    
    def stop(self):
        """Arrête le bot de trading"""
        logger.info("🛑 Arrêt du bot de trading...")
        self.stop_threads = True
        
        # Attendre la fin des threads
        if hasattr(self, 'price_cache_thread') and self.price_cache_thread.is_alive():
            self.price_cache_thread.join(timeout=1.0)
        
        if hasattr(self, 'volatile_assets_thread') and self.volatile_assets_thread.is_alive():
            self.volatile_assets_thread.join(timeout=1.0)
        
        if hasattr(self, 'trading_thread') and self.trading_thread.is_alive():
            self.trading_thread.join(timeout=1.0)
        
        logger.info("Bot de trading arrêté.")
        return True
    
    def convert_to_usdt(self, asset, percentage=1.0):
        """
        Convertit un pourcentage d'un actif en USDT
        
        Args:
            asset (str): Actif à convertir
            percentage (float): Pourcentage à convertir (0-1)
        
        Returns:
            bool: True si converti avec succès, False sinon
        """
        asset_balance = self.exchange_balances.get(asset, 0)
        if asset_balance <= 0:
            logger.warning(f"Pas de solde pour {asset}")
            return False
        
        # Calculer le montant à vendre
        sell_amount = asset_balance * percentage
        
        # Vendre l'actif
        result = self.sell(asset, sell_amount)
        return result is not None
    
    def convert_all_to_volatile(self):
        """
        Convertit tous les actifs significatifs en les cryptomonnaies les plus volatiles
        
        Returns:
            bool: True si au moins une conversion a réussi, False sinon
        """
        # Récupérer les balances actuelles
        self.refresh_balances()
        
        # Récupérer les actifs volatils
        volatile_assets = self.get_top_volatile_assets(max_assets=3)
        if not volatile_assets:
            logger.warning("Pas d'actifs volatils trouvés")
            return False
        
        # Compter le nombre de conversions réussies
        success_count = 0
        
        # Parcourir les balances et convertir les actifs significatifs
        for asset, balance in self.exchange_balances.items():
            # Ignorer USDT (sera utilisé pour acheter des actifs volatils)
            if asset == 'USDT':
                continue
            
            # Convertir uniquement les actifs avec un solde significatif (plus de ~1 USD)
            current_price = self.get_ticker_price(f"{asset}/USDT")
            if not current_price:
                continue
            
            usdt_value = balance * current_price
            if usdt_value >= 1.0:
                # Convertir l'actif en USDT
                logger.info(f"Conversion de {balance} {asset} (valeur: {usdt_value} USDT) en crypto volatile")
                result = self.convert_to_usdt(asset)
                if result:
                    success_count += 1
        
        # Rafraîchir les balances après les conversions
        self.refresh_balances()
        
        # Utiliser le solde USDT pour acheter des actifs volatils
        usdt_balance = self.exchange_balances.get('USDT', 0)
        if usdt_balance > 1.0:
            # Répartir le solde USDT entre les actifs volatils
            num_assets = min(len(volatile_assets), 3)  # Maximum 3 actifs
            usdt_per_asset = usdt_balance / num_assets
            
            for asset in volatile_assets[:num_assets]:
                # Calculer le montant à acheter
                current_price = self.get_ticker_price(f"{asset}/USDT")
                if not current_price or current_price <= 0:
                    continue
                
                buy_amount = usdt_per_asset / current_price
                
                # Acheter l'actif
                logger.info(f"Achat de l'actif volatil {asset} avec {usdt_per_asset} USDT")
                result = self.buy(asset, buy_amount)
                if result:
                    success_count += 1
        
        return success_count > 0
    
    def convert_to_btc(self, asset, percentage=1.0):
        """
        Convertit un actif en BTC (via USDT)
        
        Args:
            asset (str): Actif à convertir
            percentage (float): Pourcentage à convertir (0-1)
        
        Returns:
            bool: True si converti avec succès, False sinon
        """
        # D'abord, convertir l'actif en USDT
        if asset != 'USDT':
            result = self.convert_to_usdt(asset, percentage)
            if not result:
                return False
        
        # Rafraîchir les balances
        self.refresh_balances()
        
        # Acheter BTC avec USDT
        usdt_balance = self.exchange_balances.get('USDT', 0)
        if usdt_balance <= 1.0:
            logger.warning(f"Solde USDT insuffisant: {usdt_balance}")
            return False
        
        # Calculer le montant de BTC à acheter
        btc_price = self.get_ticker_price("BTC/USDT")
        if not btc_price or btc_price <= 0:
            logger.error("Impossible d'obtenir le prix BTC")
            return False
        
        buy_amount = usdt_balance / btc_price
        
        # Acheter BTC
        result = self.buy("BTC", buy_amount)
        return result is not None
    
    def convert_to_audio(self, asset, percentage=1.0):
        """
        Convertit un actif en AUDIO (via USDT)
        
        Args:
            asset (str): Actif à convertir
            percentage (float): Pourcentage à convertir (0-1)
        
        Returns:
            bool: True si converti avec succès, False sinon
        """
        # D'abord, convertir l'actif en USDT
        if asset != 'USDT':
            result = self.convert_to_usdt(asset, percentage)
            if not result:
                return False
        
        # Rafraîchir les balances
        self.refresh_balances()
        
        # Acheter AUDIO avec USDT
        usdt_balance = self.exchange_balances.get('USDT', 0)
        if usdt_balance <= 1.0:
            logger.warning(f"Solde USDT insuffisant: {usdt_balance}")
            return False
        
        # Calculer le montant d'AUDIO à acheter
        audio_price = self.get_ticker_price("AUDIO/USDT")
        if not audio_price or audio_price <= 0:
            logger.error("Impossible d'obtenir le prix AUDIO")
            return False
        
        buy_amount = usdt_balance / audio_price
        
        # Acheter AUDIO
        result = self.buy("AUDIO", buy_amount)
        return result is not None
    
    def get_status(self):
        """
        Récupère le statut actuel du bot et des positions
        
        Returns:
            dict: Statut complet du bot
        """
        try:
            self.refresh_balances()
            
            # Calculer la valeur totale du portefeuille
            total_value_usdt = 0.0
            balances_with_value = {}
            
            for asset, balance in self.exchange_balances.items():
                if balance <= 0:
                    continue
                
                if asset == 'USDT':
                    value_usdt = balance
                else:
                    price = self.get_ticker_price(f"{asset}/USDT")
                    if price:
                        value_usdt = balance * price
                    else:
                        value_usdt = 0.0
                
                balances_with_value[asset] = {
                    'balance': balance,
                    'value_usdt': value_usdt
                }
                total_value_usdt += value_usdt
            
            # Préparer les données des actifs volatils
            volatile_assets_data = []
            for asset in self.volatile_assets:
                price = self.get_ticker_price(f"{asset}/USDT")
                
                volatile_assets_data.append({
                    'asset': asset,
                    'price': price,
                    'volatility': self.calculate_volatility(asset),
                    'sentiment': self.analyze_sentiment(asset),
                    'bubble_score': self.calculate_bubble_score(asset)
                })
            
            # Préparer les données des trades récents
            recent_trades = self.trade_history[-10:] if self.trade_history else []
            
            # Retourner le statut complet
            return {
                'mode': self.mode,
                'balances': balances_with_value,
                'total_value_usdt': total_value_usdt,
                'volatile_assets': volatile_assets_data,
                'recent_trades': recent_trades,
                'active_positions': len([a for a, b in self.exchange_balances.items() if a != 'USDT' and b > 0])
            }
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du statut: {e}")
            return {
                'mode': self.mode,
                'error': str(e)
            }


# Fonction pour initialiser un bot avec les clés d'environnement
def initialize_bot():
    """Initialise et retourne un bot de trading avec les clés d'environnement"""
    api_key = os.environ.get('KRAKEN_API_KEY')
    api_secret = os.environ.get('KRAKEN_API_SECRET')
    
    bot = TradingBotV2(api_key=api_key, api_secret=api_secret, risk_per_trade=0.9, volatility_threshold=5.0)
    return bot


# Fonction principale pour tester le bot
if __name__ == "__main__":
    bot = initialize_bot()
    
    # Afficher les actifs volatils
    volatile_assets = bot.get_top_volatile_assets()
    logger.info(f"Actifs volatils détectés: {volatile_assets}")
    
    # Démarrer le bot
    bot.start()
    
    try:
        # Laisser le bot fonctionner en arrière-plan pendant un certain temps
        time.sleep(3600)  # 1 heure
    except KeyboardInterrupt:
        logger.info("Interruption du bot...")
    finally:
        # Arrêter le bot proprement
        bot.stop()