#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
BOT TRADING KRAKEN ULTRA-STABLE 24/7 - BÉTON ARMÉ
- Watchdog automatique qui surveille et relance le bot de trading
- Interface web complète pour le monitoring et le contrôle
- Système d'alertes Discord avancé
- Gestion des logs et nettoyage automatique
- Sauvegarde d'état multi-niveau pour reprise après crash
- Sécurité financière avec stop-loss global
- Maintenance planifiée quotidienne
- Auto-ajustement aux conditions du marché

Développé par Replit AI Expert - 2025
"""

import time
import json
import os
import threading
import subprocess
import requests
import logging
import psutil
import csv
import calendar
from flask import Flask, request, jsonify, render_template, redirect, url_for
from datetime import datetime, timedelta, date
import traceback

# === CONFIGURATION ===
DISCORD_WEBHOOK = os.environ.get("DISCORD_WEBHOOK", "")  # Configurer via les secrets Replit
RESTART_SECRET = "restart987"  # Clé secrète pour forcer un redémarrage
TIMEOUT_SECONDS = 600  # Temps maximum sans activité avant redémarrage (10 min)
AUTO_RESTART_HOUR_UTC = 0  # Heure du redémarrage quotidien (0 = minuit UTC)
LOG_FILE = "super_trader.log"
ERROR_LOG_FILE = "errors.log"
STATE_FILE = "trader_state.json"
HEARTBEAT_FILE = "bot_heartbeat.txt"
TRADE_HISTORY_FILE = "trade_history.json"
DAILY_REPORT_FILE = "daily_report.csv"
MAX_LOG_SIZE_MB = 5  # Taille maximum des logs en Mo

# Configuration des logs principaux
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)

# Configuration des logs d'erreur séparés
error_logger = logging.getLogger('error_logger')
error_logger.setLevel(logging.ERROR)
error_handler = logging.FileHandler(ERROR_LOG_FILE)
error_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
error_logger.addHandler(error_handler)

# === ÉTAT GLOBAL ===
state = {
    "position": None,
    "last_trade_time": time.time(),
    "last_trade": "",
    "uptime": time.time(),
    "start_time": time.time(),
    "balances": {},
    "total_balance_usd": 0.0,
    "volatile_assets": [],
    "trades_count": 0,
    "daily_trades_count": 0,
    "profits_total": 0.0,
    "daily_profit": 0.0,
    "status": "initialisé",
    "is_paused": False,
    "pause_until": None,
    "pause_reason": None,
    "daily_loss_percent": 0.0,
    "last_maintenance": None,
    "market_volatility": "normale",
    "trading_mode": "normal",
    "kraken_api_healthy": True,
    "bot_version": "2.0.0"
}

# Historique des trades
trade_history = []

# === FLASK SERVER ===
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "kraken_bot_secure_key")

@app.route('/')
def home():
    """Page d'accueil avec dashboard complet"""
    load_state()  # Recharger l'état le plus récent
    load_trade_history()  # Charger l'historique des trades
    
    uptime = round((time.time() - state.get("uptime", time.time())) / 3600, 2)
    uptime_str = f"{int(uptime)} heures {int((uptime % 1) * 60)} minutes"
    
    # Calculer le temps avant le prochain redémarrage programmé
    now = datetime.utcnow()
    next_restart = datetime(now.year, now.month, now.day, AUTO_RESTART_HOUR_UTC)
    if now.hour >= AUTO_RESTART_HOUR_UTC:
        next_restart += timedelta(days=1)
    time_to_restart = next_restart - now
    restart_in = f"{time_to_restart.seconds // 3600}h {(time_to_restart.seconds % 3600) // 60}m"
    
    # Vérifier si le bot est en pause
    pause_info = ""
    if state.get("is_paused", False) and state.get("pause_until"):
        pause_until = datetime.fromtimestamp(state["pause_until"])
        if pause_until > datetime.now():
            remaining = pause_until - datetime.now()
            pause_info = f"Bot en pause pour {state.get('pause_reason', 'raison inconnue')}. Reprise dans {remaining.seconds // 60} minutes."
    
    # Styles de statut
    status_class = "active"
    if state.get("status") in ["arrêté", "échec", "erreur"]:
        status_class = "inactive"
    elif state.get("is_paused", False):
        status_class = "paused"
    
    # Formater les balances pour affichage
    formatted_balances = []
    balances = state.get("balances", {})
    for asset, details in balances.items():
        if isinstance(details, dict):
            amount = details.get("amount", 0)
            usd_value = details.get("usd_value", 0)
            formatted_balances.append({
                "asset": asset.replace("X", "").replace("Z", ""),
                "amount": f"{amount:.8f}",
                "usd_value": f"${usd_value:.2f}"
            })
        else:
            # Gérer le cas où c'est juste un nombre
            formatted_balances.append({
                "asset": asset.replace("X", "").replace("Z", ""),
                "amount": f"{details:.8f}",
                "usd_value": "N/A"
            })
    
    # Récupérer les X derniers trades
    recent_trades = trade_history[-10:] if trade_history else []
    
    return f"""
    <html>
        <head>
            <title>Bot de Trading Ultra-Stable "Béton Armé"</title>
            <meta http-equiv="refresh" content="60">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background-color: #1a1a1a; color: #e0e0e0; }}
                .container {{ max-width: 1200px; margin: 0 auto; }}
                .header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }}
                .status {{ padding: 15px; border-radius: 5px; margin: 20px 0; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
                .active {{ background-color: #1e4620; color: #d4edda; }}
                .inactive {{ background-color: #721c24; color: #f8d7da; }}
                .paused {{ background-color: #856404; color: #fff3cd; }}
                .warning {{ background-color: #856404; color: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0; }}
                button {{ padding: 10px 15px; margin: 5px; background-color: #0c84e4; color: white; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s; }}
                button:hover {{ background-color: #0a6fc5; }}
                button.danger {{ background-color: #dc3545; }}
                button.danger:hover {{ background-color: #bd2130; }}
                button.warning {{ background-color: #ffc107; color: #212529; }}
                button.warning:hover {{ background-color: #e0a800; }}
                button.success {{ background-color: #28a745; }}
                button.success:hover {{ background-color: #218838; }}
                .panel {{ background-color: #2d2d2d; padding: 15px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
                .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }}
                h1, h2, h3 {{ color: #0c84e4; }}
                pre {{ background-color: #252525; padding: 10px; border-radius: 5px; overflow-x: auto; max-height: 300px; overflow-y: auto; }}
                table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
                th, td {{ padding: 8px; text-align: left; border-bottom: 1px solid #444; }}
                th {{ background-color: #333; }}
                tr:hover {{ background-color: #3a3a3a; }}
                .profit {{ color: #28a745; }}
                .loss {{ color: #dc3545; }}
                .badge {{ display: inline-block; padding: 3px 7px; border-radius: 10px; font-size: 12px; font-weight: bold; }}
                .badge-info {{ background-color: #17a2b8; color: white; }}
                .badge-warning {{ background-color: #ffc107; color: #212529; }}
                .badge-danger {{ background-color: #dc3545; color: white; }}
                .version {{ font-size: 12px; color: #888; margin-top: 20px; text-align: center; }}
                .footer {{ margin-top: 40px; text-align: center; font-size: 12px; color: #888; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Bot de Trading Ultra-Stable "Béton Armé" 🔒</h1>
                    <span class="badge badge-info">v{state.get("bot_version", "2.0.0")}</span>
                </div>
                
                <div class="status {status_class}">
                    <h2>📊 Statut: {state.get("status", "inconnu")}</h2>
                    <div class="grid">
                        <div>
                            <p>⏱️ Uptime: {uptime_str}</p>
                            <p>🔄 Prochain redémarrage planifié: {restart_in}</p>
                        </div>
                        <div>
                            <p>💰 Total trades: {state.get("trades_count", 0)} (aujourd'hui: {state.get("daily_trades_count", 0)})</p>
                            <p>💵 Profit total: <span class="{'profit' if state.get('profits_total', 0) >= 0 else 'loss'}">${state.get("profits_total", 0.0):.2f}</span></p>
                        </div>
                        <div>
                            <p>🧠 RAM utilisée: {psutil.virtual_memory().percent}%</p>
                            <p>📈 Mode trading: {state.get("trading_mode", "normal")}</p>
                        </div>
                    </div>
                    {f'<div class="warning">{pause_info}</div>' if pause_info else ''}
                </div>
                
                <div>
                    <button onclick="fetch('/api/restart?key={RESTART_SECRET}').then(() => alert('Redémarrage en cours...'))">
                        🔄 Redémarrer le Bot
                    </button>
                    <button onclick="location.reload()" class="success">
                        🔍 Actualiser
                    </button>
                    <button onclick="fetch('/api/force_trade').then(r => r.json()).then(data => alert('Trade forcé: ' + JSON.stringify(data)))" class="warning">
                        💸 Forcer un Trade
                    </button>
                    {'<button onclick="fetch(\'/api/resume\').then(() => location.reload())" class="success">▶️ Reprendre</button>' if state.get("is_paused", False) else '<button onclick="fetch(\'/api/pause?minutes=60\').then(() => location.reload())" class="danger">⏸️ Pause (1h)</button>'}
                </div>
                
                <div class="grid">
                    <div class="panel">
                        <h3>💎 Portefeuille</h3>
                        <p>Balance totale: <strong>${state.get("total_balance_usd", 0):.2f}</strong></p>
                        <table>
                            <tr>
                                <th>Actif</th>
                                <th>Quantité</th>
                                <th>Valeur USD</th>
                            </tr>
                            {''.join([f"<tr><td>{b['asset']}</td><td>{b['amount']}</td><td>{b['usd_value']}</td></tr>" for b in formatted_balances])}
                        </table>
                    </div>
                    
                    <div class="panel">
                        <h3>📝 Transactions Récentes</h3>
                        <table>
                            <tr>
                                <th>Date</th>
                                <th>Action</th>
                                <th>Paire</th>
                                <th>Résultat</th>
                            </tr>
                            {''.join([f"<tr><td>{t.get('timestamp', 'N/A')}</td><td>{t.get('action', 'N/A')}</td><td>{t.get('pair', 'N/A')}</td><td class=\"{'profit' if t.get('profit', 0) >= 0 else 'loss'}\">{'+' if t.get('profit', 0) >= 0 else ''}{t.get('profit', 'N/A')}</td></tr>" for t in recent_trades])}
                        </table>
                        <p>{state.get("last_trade", "Aucun trade récent")}</p>
                    </div>
                </div>
                
                <div class="panel">
                    <h3>⚙️ Statut du Système</h3>
                    <div class="grid">
                        <div>
                            <p>Surveillance active: <span class="badge badge-info">✓</span></p>
                            <p>API Kraken: <span class="badge {'badge-info' if state.get('kraken_api_healthy', True) else 'badge-danger'}">{state.get('kraken_api_healthy', True) and 'Fonctionnelle' or 'Problème détecté'}</span></p>
                            <p>Volatilité du marché: <span class="badge badge-warning">{state.get('market_volatility', 'normale')}</span></p>
                        </div>
                        <div>
                            <p>Perte journalière: <span class="{'badge badge-info' if state.get('daily_loss_percent', 0) < 3 else 'badge badge-danger'}">{state.get('daily_loss_percent', 0):.2f}%</span></p>
                            <p>Dernière maintenance: {state.get('last_maintenance') or 'Jamais'}</p>
                            <p>Logs: <span class="badge badge-info">Auto-nettoyage à {MAX_LOG_SIZE_MB}MB</span></p>
                        </div>
                    </div>
                </div>
                
                <div class="footer">
                    <p>📊 Consulter les <a href="/reports" style="color: #0c84e4;">rapports journaliers</a> | 📈 <a href="/status" style="color: #0c84e4;">API JSON</a></p>
                    <p>Bot de Trading Ultra-Stable "Béton Armé" - Une technologie de pointe développée pour la performance et la sécurité</p>
                </div>
            </div>
        </body>
    </html>
    """

@app.route('/reports')
def reports():
    """Page des rapports journaliers"""
    # Lire le rapport journalier s'il existe
    daily_reports = []
    if os.path.exists(DAILY_REPORT_FILE):
        try:
            with open(DAILY_REPORT_FILE, "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    daily_reports.append(row)
        except Exception as e:
            error_log(f"Erreur lors de la lecture du rapport journalier: {e}")
    
    # Inverser pour avoir les plus récents en premier
    daily_reports.reverse()
    
    return f"""
    <html>
        <head>
            <title>Rapports Journaliers - Bot Trading</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background-color: #1a1a1a; color: #e0e0e0; }}
                .container {{ max-width: 1200px; margin: 0 auto; }}
                h1, h2 {{ color: #0c84e4; }}
                table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
                th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #444; }}
                th {{ background-color: #333; }}
                tr:hover {{ background-color: #3a3a3a; }}
                .profit {{ color: #28a745; }}
                .loss {{ color: #dc3545; }}
                .back-link {{ margin-bottom: 20px; }}
                .back-link a {{ color: #0c84e4; text-decoration: none; }}
                .no-data {{ padding: 20px; background-color: #2d2d2d; border-radius: 5px; text-align: center; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Rapports Journaliers</h1>
                <div class="back-link">
                    <a href="/">← Retour au dashboard</a>
                </div>
                
                {'''<table>
                    <tr>
                        <th>Date</th>
                        <th>Trades</th>
                        <th>Volume</th>
                        <th>Profit/Perte</th>
                        <th>Performance</th>
                    </tr>
                    {''.join([f"<tr><td>{r.get('date', 'N/A')}</td><td>{r.get('trades_count', '0')}</td><td>${r.get('volume', '0')}</td><td class=\"{'profit' if float(r.get('profit_loss', 0)) >= 0 else 'loss'}\">${r.get('profit_loss', '0')}</td><td class=\"{'profit' if float(r.get('performance_pct', 0)) >= 0 else 'loss'}\">{'+'if float(r.get('performance_pct', 0)) > 0 else ''}{r.get('performance_pct', '0')}%</td></tr>" for r in daily_reports])}
                </table>''' if daily_reports else '<div class="no-data">Aucun rapport journalier disponible pour le moment.</div>'}
            </div>
        </body>
    </html>
    """

@app.route('/status')
def status_page():
    """Endpoint JSON pour obtenir l'état du bot"""
    load_state()  # Charger l'état le plus récent
    
    # Vérifier si le bot est en cours d'exécution
    bot_running = False
    if os.path.exists("auto_trader_pid.txt"):
        try:
            with open("auto_trader_pid.txt", "r") as f:
                pid = int(f.read().strip())
            # Vérifier si le processus existe
            try:
                os.kill(pid, 0)
                bot_running = True
            except:
                bot_running = False
        except:
            bot_running = False
    
    # Vérifier l'âge du heartbeat
    heartbeat_age = float('inf')
    if os.path.exists(HEARTBEAT_FILE):
        try:
            heartbeat_age = time.time() - os.path.getmtime(HEARTBEAT_FILE)
        except:
            pass
    
    # Vérifier les ressources systèmes
    mem = psutil.virtual_memory()
    
    # Ajouter des informations supplémentaires à l'état
    status_info = {
        "running": bot_running,
        "heartbeat_age": heartbeat_age,
        "status": "active" if bot_running and heartbeat_age < 300 and not state.get("is_paused", False) else "inactive" if not bot_running else "paused" if state.get("is_paused", False) else "unknown",
        "system": {
            "ram_used_percent": mem.percent,
            "ram_available_mb": mem.available / (1024 * 1024),
            "uptime_seconds": round(time.time() - state.get("uptime", time.time()), 2),
            "logs_size_kb": os.path.getsize(LOG_FILE) / 1024 if os.path.exists(LOG_FILE) else 0
        },
        **state
    }
    
    return jsonify(status_info)

@app.route('/api/restart')
def restart():
    """Endpoint pour redémarrer le bot via une requête HTTP"""
    if request.args.get("key") == RESTART_SECRET:
        logging.info("Redémarrage demandé via URL")
        send_discord_alert("🔁 Redémarrage manuel via /restart")
        
        # Mettre à jour l'état
        state["status"] = "redémarrage"
        save_state()
        
        # Tuer les processus du bot
        subprocess.run(["pkill", "-f", "auto_trader_verified.py"])
        subprocess.run(["pkill", "-f", "bot_logic.py"])
        time.sleep(2)
        
        # Redémarrer le bot
        subprocess.Popen(["bash", "keep_bot_alive.sh"])
        
        return jsonify({"success": True, "message": "Bot redémarré"})
    return jsonify({"success": False, "message": "Clé invalide"}), 403

@app.route('/api/pause')
def pause_bot():
    """Endpoint pour mettre le bot en pause"""
    try:
        # Récupérer la durée de pause en minutes (défaut: 60 minutes)
        minutes = int(request.args.get("minutes", 60))
        reason = request.args.get("reason", "pause manuelle")
        
        # Mettre à jour l'état
        state["is_paused"] = True
        state["pause_until"] = time.time() + (minutes * 60)
        state["pause_reason"] = reason
        state["status"] = "en pause"
        save_state()
        
        # Notifier Discord
        send_discord_alert(f"⏸️ Bot mis en pause pour {minutes} minutes. Raison: {reason}")
        
        return jsonify({
            "success": True, 
            "message": f"Bot mis en pause pour {minutes} minutes",
            "pause_until": datetime.fromtimestamp(state["pause_until"]).strftime("%Y-%m-%d %H:%M:%S")
        })
    except Exception as e:
        error_log(f"Erreur lors de la mise en pause du bot: {e}")
        return jsonify({"success": False, "message": f"Erreur: {str(e)}"})

@app.route('/api/resume')
def resume_bot():
    """Endpoint pour reprendre le bot après une pause"""
    try:
        # Mettre à jour l'état
        state["is_paused"] = False
        state["pause_until"] = None
        state["pause_reason"] = None
        state["status"] = "actif"
        save_state()
        
        # Notifier Discord
        send_discord_alert("▶️ Bot réactivé manuellement")
        
        return jsonify({"success": True, "message": "Bot réactivé"})
    except Exception as e:
        error_log(f"Erreur lors de la réactivation du bot: {e}")
        return jsonify({"success": False, "message": f"Erreur: {str(e)}"})

@app.route('/api/force_trade', methods=['GET', 'POST'])
def force_trade():
    """Endpoint pour forcer l'exécution d'un trade"""
    try:
        # Vérifier si le bot est en pause
        if state.get("is_paused", False):
            return jsonify({"success": False, "message": "Bot en pause - impossible d'exécuter un trade"})
        
        # Exécuter le script de trade forcé
        logging.info("Trade forcé demandé via API")
        result = subprocess.run(["python3", "execute_real_trade.py"], 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE,
                               text=True,
                               timeout=120)
        
        # Mettre à jour l'état
        state["last_trade_time"] = time.time()
        state["last_trade"] = f"Trade forcé via API à {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        state["trades_count"] = state.get("trades_count", 0) + 1
        state["daily_trades_count"] = state.get("daily_trades_count", 0) + 1
        save_state()
        
        # Notifier via Discord
        send_discord_alert("💸 Trade forcé via API")
        
        return jsonify({
            "success": True, 
            "message": "Trade forcé exécuté", 
            "output": result.stdout[-500:] if result.stdout else "Aucune sortie standard",
            "errors": result.stderr[-500:] if result.stderr else "Aucune erreur"
        })
    except Exception as e:
        error_trace = traceback.format_exc()
        error_log(f"Erreur lors du trade forcé: {e}\n{error_trace}")
        return jsonify({"success": False, "message": f"Erreur: {str(e)}"})

@app.route('/api/shadow_ban_test', methods=['GET', 'POST'])
def shadow_ban_test():
    """Endpoint pour tester si Kraken est en mode shadow ban / maintenance"""
    try:
        # Exécuter un test minuscule pour vérifier l'API Kraken
        logging.info("Test shadow ban demandé")
        result = subprocess.run(["python3", "-c", """
import os, krakenex, time
try:
    k = krakenex.API(os.environ.get('KRAKEN_API_KEY'), os.environ.get('KRAKEN_API_SECRET'))
    print("Test API publique:", "ok" if k.query_public('Time') else "erreur")
    balance = k.query_private('Balance')
    print("Test API privée:", "ok" if balance else "erreur")
    print("Shadow ban: non détecté")
except Exception as e:
    print(f"Erreur: {e}")
    print("Shadow ban: possible")
"""], 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE,
                               text=True,
                               timeout=30)
        
        # Analyser les résultats
        output = result.stdout + result.stderr
        is_shadow_banned = "Shadow ban: possible" in output
        
        # Mettre à jour l'état
        state["kraken_api_healthy"] = not is_shadow_banned
        save_state()
        
        if is_shadow_banned:
            send_discord_alert("⚠️ ALERTE: API Kraken potentiellement en shadow ban / maintenance !")
        
        return jsonify({
            "success": True,
            "shadow_ban_detected": is_shadow_banned,
            "output": output
        })
    except Exception as e:
        error_trace = traceback.format_exc()
        error_log(f"Erreur lors du test shadow ban: {e}\n{error_trace}")
        return jsonify({"success": False, "message": f"Erreur: {str(e)}"})

# === UTILITAIRES ===
def log(msg):
    """Journal avec horodatage et écriture fichier"""
    logging.info(msg)

def error_log(msg):
    """Journal des erreurs séparé"""
    error_logger.error(msg)
    logging.error(msg)  # Aussi dans le log principal

def update_heartbeat():
    """Met à jour le fichier heartbeat"""
    try:
        with open(HEARTBEAT_FILE, "w") as f:
            f.write(str(time.time()))
    except Exception as e:
        error_log(f"Erreur lors de la mise à jour du heartbeat: {e}")

def send_discord_alert(message):
    """Envoie une alerte sur Discord si configuré"""
    if not DISCORD_WEBHOOK:
        return
    
    try:
        formatted_message = f"🤖 **BOT TRADING**: {message}"
        
        # Ajouter la date et l'heure
        formatted_message += f"\n⏰ *{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*"
        
        # Ajouter des infos supplémentaires pour certains types d'alertes
        if "crash" in message.lower() or "erreur critique" in message.lower():
            formatted_message += "\n\n❌ **INCIDENT CRITIQUE**"
            
            # Ajouter des détails sur l'état du système
            mem = psutil.virtual_memory()
            formatted_message += f"\nRAM: {mem.percent}% utilisée"
            formatted_message += f"\nUptime: {round((time.time() - state.get('uptime', time.time())) / 3600, 2)} heures"
        
        requests.post(DISCORD_WEBHOOK, 
                      json={"content": formatted_message}, 
                      timeout=5)
    except Exception as e:
        error_log(f"Impossible d'envoyer une alerte Discord: {e}")

def save_state():
    """Sauvegarde l'état actuel dans un fichier JSON"""
    try:
        with open(STATE_FILE, "w") as f:
            json.dump(state, f)
    except Exception as e:
        error_log(f"Erreur lors de la sauvegarde de l'état: {e}")

def load_state():
    """Charge l'état depuis le fichier JSON"""
    global state
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f:
                loaded_state = json.load(f)
                # Mettre à jour l'état sans écraser les valeurs par défaut manquantes
                for key, value in loaded_state.items():
                    state[key] = value
        except Exception as e:
            error_log(f"Erreur lors du chargement de l'état: {e}")

def save_trade_history():
    """Sauvegarde l'historique des trades dans un fichier JSON"""
    try:
        with open(TRADE_HISTORY_FILE, "w") as f:
            json.dump(trade_history, f)
    except Exception as e:
        error_log(f"Erreur lors de la sauvegarde de l'historique des trades: {e}")

def load_trade_history():
    """Charge l'historique des trades depuis le fichier JSON"""
    global trade_history
    if os.path.exists(TRADE_HISTORY_FILE):
        try:
            with open(TRADE_HISTORY_FILE, "r") as f:
                trade_history = json.load(f)
        except Exception as e:
            error_log(f"Erreur lors du chargement de l'historique des trades: {e}")

def add_trade_to_history(trade_data):
    """Ajoute un trade à l'historique"""
    global trade_history
    # Charger l'historique actuel
    load_trade_history()
    
    # S'assurer que trade_data a un timestamp
    if "timestamp" not in trade_data:
        trade_data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Ajouter le nouveau trade
    trade_history.append(trade_data)
    
    # Sauvegarder l'historique mis à jour
    save_trade_history()
    
    # Mettre à jour l'état global
    state["last_trade"] = f"{trade_data.get('action', 'TRADE')} {trade_data.get('pair', '')} à {trade_data.get('timestamp', '')}"
    state["last_trade_time"] = time.time()
    state["trades_count"] = state.get("trades_count", 0) + 1
    state["daily_trades_count"] = state.get("daily_trades_count", 0) + 1
    
    # Mettre à jour les profits si disponible
    if "profit" in trade_data:
        profit = float(trade_data["profit"]) if isinstance(trade_data["profit"], (int, float, str)) else 0
        state["profits_total"] = state.get("profits_total", 0) + profit
        state["daily_profit"] = state.get("daily_profit", 0) + profit
    
    save_state()

def generate_daily_report():
    """Génère et enregistre un rapport journalier"""
    today = date.today().strftime("%Y-%m-%d")
    
    # Calculer les métriques
    trades_count = state.get("daily_trades_count", 0)
    profit_loss = state.get("daily_profit", 0)
    
    # Calculer le volume total des trades du jour
    volume = 0
    for trade in trade_history:
        if trade.get("timestamp", "").startswith(today):
            volume += float(trade.get("volume", 0)) if isinstance(trade.get("volume"), (int, float, str)) else 0
    
    # Calculer la performance en pourcentage
    performance_pct = 0
    total_balance = state.get("total_balance_usd", 0)
    if total_balance > 0:
        performance_pct = (profit_loss / (total_balance - profit_loss)) * 100 if (total_balance - profit_loss) > 0 else 0
    
    # Créer l'entrée du rapport
    report_entry = {
        "date": today,
        "trades_count": str(trades_count),
        "volume": f"{volume:.2f}",
        "profit_loss": f"{profit_loss:.2f}",
        "performance_pct": f"{performance_pct:.2f}",
        "balance_usd": f"{total_balance:.2f}"
    }
    
    # Vérifier si le fichier existe
    file_exists = os.path.exists(DAILY_REPORT_FILE)
    
    # Écrire dans le fichier CSV
    try:
        with open(DAILY_REPORT_FILE, "a" if file_exists else "w") as f:
            writer = csv.DictWriter(f, fieldnames=report_entry.keys())
            if not file_exists:
                writer.writeheader()
            writer.writerow(report_entry)
        
        # Notifier sur Discord
        send_discord_alert(f"📊 **Rapport journalier** - {today}\n" +
                          f"Trades: {trades_count}\n" +
                          f"Volume: ${volume:.2f}\n" +
                          f"Profit/Perte: ${profit_loss:.2f}\n" +
                          f"Performance: {'+' if performance_pct > 0 else ''}{performance_pct:.2f}%")
        
        # Réinitialiser les compteurs journaliers
        state["daily_trades_count"] = 0
        state["daily_profit"] = 0
        state["daily_loss_percent"] = 0
        save_state()
        
        return True
    except Exception as e:
        error_log(f"Erreur lors de la génération du rapport journalier: {e}")
        return False

def clean_logs():
    """Nettoie les fichiers de logs trop volumineux (max 5 Mo)"""
    try:
        for log_file in [LOG_FILE, ERROR_LOG_FILE, "auto_trader_output.log", "execute_trade.log", "trader_logic.log"]:
            if os.path.exists(log_file) and os.path.getsize(log_file) > (MAX_LOG_SIZE_MB * 1024 * 1024):
                # Sauvegarder les 1000 dernières lignes
                with open(log_file, "r") as f:
                    lines = f.readlines()[-1000:]
                # Réécrire le fichier avec seulement ces lignes
                with open(log_file, "w") as f:
                    f.writelines(lines)
                logging.info(f"Log {log_file} nettoyé (gardé 1000 dernières lignes)")
    except Exception as e:
        error_log(f"Erreur lors du nettoyage des logs: {e}")

def check_resources():
    """Vérifie l'utilisation des ressources système"""
    try:
        mem = psutil.virtual_memory()
        if mem.percent > 90:
            logging.warning(f"⚠️ Mémoire saturée ({mem.percent}%), redémarrage recommandé")
            send_discord_alert(f"⚠️ Alerte mémoire: {mem.percent}% utilisé - Redémarrage planifié")
            return False
        return True
    except Exception as e:
        error_log(f"Erreur lors de la vérification des ressources: {e}")
        return True

def daily_maintenance():
    """Exécute une maintenance quotidienne et redémarre le bot"""
    try:
        logging.info("Exécution de la maintenance quotidienne planifiée...")
        
        # Générer un rapport journalier
        generate_daily_report()
        
        # Nettoyer les logs
        clean_logs()
        
        # Mettre à jour l'état
        state["last_maintenance"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_state()
        
        # Envoyer une alerte
        send_discord_alert("🔧 Maintenance quotidienne exécutée - Redémarrage planifié")
        
        # Planifier un redémarrage propre
        logging.info("Redémarrage planifié après maintenance quotidienne")
        
        # Tuer les processus
        subprocess.run(["pkill", "-f", "auto_trader_verified.py"])
        subprocess.run(["pkill", "-f", "bot_logic.py"])
        time.sleep(5)
        
        # Redémarrer les bot
        subprocess.Popen(["bash", "keep_bot_alive.sh"])
        
        return True
    except Exception as e:
        error_trace = traceback.format_exc()
        error_log(f"Erreur lors de la maintenance quotidienne: {e}\n{error_trace}")
        return False

def test_kraken_api():
    """Teste l'API Kraken pour détecter un shadow ban"""
    try:
        # Appeler l'API interne
        result = subprocess.run(["python3", "-c", """
import os, krakenex, time
try:
    k = krakenex.API(os.environ.get('KRAKEN_API_KEY'), os.environ.get('KRAKEN_API_SECRET'))
    # Test de l'API publique
    time_result = k.query_public('Time')
    print("Test API publique:", "ok" if time_result and 'result' in time_result else "erreur")
    
    # Test de l'API privée (Balance)
    balance = k.query_private('Balance')
    print("Test API privée (Balance):", "ok" if balance and 'result' in balance else "erreur")
    
    # Shadow ban check: essayer de récupérer les ordres ouverts
    orders = k.query_private('OpenOrders')
    print("Test API privée (OpenOrders):", "ok" if orders and 'result' in orders else "erreur")
    
    print("Shadow ban: non détecté")
except Exception as e:
    print(f"Erreur: {e}")
    print("Shadow ban: possible")
"""], 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE,
                               text=True,
                               timeout=30)
        
        # Analyser la sortie
        output = result.stdout + result.stderr
        is_shadow_banned = "Shadow ban: possible" in output or "erreur" in output
        
        # Mettre à jour l'état
        state["kraken_api_healthy"] = not is_shadow_banned
        save_state()
        
        if is_shadow_banned:
            logging.warning("⚠️ Alerte: API Kraken potentiellement en shadow ban ou maintenance")
            send_discord_alert("⚠️ **ALERTE**: API Kraken potentiellement en shadow ban ou maintenance silencieuse. Le bot va réduire ses activités.")
            
            # Pause temporaire
            state["is_paused"] = True
            state["pause_until"] = time.time() + (30 * 60)  # 30 minutes
            state["pause_reason"] = "API Kraken en possible maintenance"
            save_state()
        
        return not is_shadow_banned
    except Exception as e:
        error_trace = traceback.format_exc()
        error_log(f"Erreur lors du test de l'API Kraken: {e}\n{error_trace}")
        return False

def is_maintenance_time():
    """Vérifie s'il est l'heure de la maintenance quotidienne"""
    now = datetime.utcnow()
    return now.hour == AUTO_RESTART_HOUR_UTC and now.minute < 5

def check_pause_status():
    """Vérifie si la pause est terminée"""
    if state.get("is_paused", False) and state.get("pause_until"):
        if time.time() > state["pause_until"]:
            # Fin de la pause
            state["is_paused"] = False
            state["pause_until"] = None
            state["pause_reason"] = None
            state["status"] = "actif"
            save_state()
            
            send_discord_alert("▶️ Bot réactivé automatiquement après pause")
            return False
        return True
    return False

# === BOUCLE DE SURVEILLANCE ===
def watchdog_loop():
    """Boucle principale du watchdog qui surveille et redémarre le bot"""
    last_maintenance_day = None
    last_api_test = 0
    
    while True:
        try:
            # Nettoyer les logs
            clean_logs()
            
            # Vérifier les ressources système
            check_resources()
            
            # Mettre à jour le heartbeat du superviseur
            update_heartbeat()
            
            # Vérifier si on est en pause
            is_paused = check_pause_status()
            
            # Vérifier s'il est temps de faire la maintenance quotidienne
            current_day = datetime.utcnow().day
            if current_day != last_maintenance_day and is_maintenance_time():
                daily_maintenance()
                last_maintenance_day = current_day
                continue  # Passer à l'itération suivante
            
            # Tester l'API Kraken toutes les heures
            if time.time() - last_api_test > 3600:  # 1 heure
                test_kraken_api()
                last_api_test = time.time()
            
            # Si on est en pause, ne pas vérifier le bot
            if is_paused:
                logging.info(f"Bot en pause. Reprise dans {(state.get('pause_until', 0) - time.time()) / 60:.1f} minutes.")
                time.sleep(60)
                continue
            
            # Vérifier si le bot est en cours d'exécution
            bot_running = False
            if os.path.exists("auto_trader_pid.txt"):
                try:
                    with open("auto_trader_pid.txt", "r") as f:
                        pid = int(f.read().strip())
                    # Vérifier si le processus existe
                    try:
                        os.kill(pid, 0)
                        bot_running = True
                    except:
                        bot_running = False
                except:
                    bot_running = False
            
            # Si le bot n'est pas en cours d'exécution, le démarrer
            if not bot_running:
                logging.info("⏳ Bot non détecté, démarrage...")
                # Mettre à jour l'état
                state["status"] = "redémarrage"
                save_state()
                
                # Notifier Discord
                send_discord_alert("🔄 Bot non détecté, démarrage en cours...")
                
                # Démarrer le bot via keep_bot_alive.sh
                subprocess.Popen(["bash", "keep_bot_alive.sh"])
                
                # Attendre que le bot démarre
                time.sleep(10)
                
                # Vérifier si le démarrage a réussi
                if os.path.exists("auto_trader_pid.txt"):
                    logging.info("✅ Bot démarré avec succès")
                    state["status"] = "actif"
                    save_state()
                else:
                    error_log("❌ Échec du démarrage du bot")
                    state["status"] = "échec"
                    save_state()
                    send_discord_alert("❌ Échec du démarrage du bot")
            else:
                # Bot en cours d'exécution, vérifier l'âge du heartbeat
                heartbeat_age = float('inf')
                if os.path.exists(HEARTBEAT_FILE):
                    try:
                        heartbeat_age = time.time() - os.path.getmtime(HEARTBEAT_FILE)
                    except:
                        pass
                
                if heartbeat_age > 600:  # Pas de signe de vie depuis 10 minutes (timeout configuré)
                    logging.warning(f"⚠️ Bot inactif (dernier signe de vie il y a {heartbeat_age:.1f}s), redémarrage...")
                    state["status"] = "inactif"
                    save_state()
                    send_discord_alert(f"⚠️ Bot inactif depuis {heartbeat_age:.0f}s, redémarrage...")
                    
                    # Tuer le processus
                    subprocess.run(["pkill", "-f", "auto_trader_verified.py"])
                    subprocess.run(["pkill", "-f", "bot_logic.py"])
                    time.sleep(2)
                    
                    # Redémarrer le bot
                    subprocess.Popen(["bash", "keep_bot_alive.sh"])
                else:
                    logging.info(f"✅ Bot en cours d'exécution (PID: {pid}, dernier signe de vie: {heartbeat_age:.1f}s)")
                    if state.get("status") != "en pause":
                        state["status"] = "actif" 
                    save_state()
            
            # Attendre avant la prochaine vérification
            time.sleep(60)  # Vérifier toutes les minutes
            
        except Exception as e:
            error_trace = traceback.format_exc()
            error_log(f"❌ Erreur dans la boucle de surveillance: {e}\n{error_trace}")
            send_discord_alert(f"❌ Erreur critique dans la surveillance: {str(e)}")
            time.sleep(60)  # Attendre avant de réessayer

# === DÉMARRER LE SERVEUR WEB ===
def start_web_server():
    """Démarre le serveur web Flask"""
    app.run(host="0.0.0.0", port=3000, debug=False)

# === FONCTION PRINCIPALE ===
if __name__ == "__main__":
    try:
        # Charger l'état initial
        load_state()
        
        # Charger l'historique des trades
        load_trade_history()
        
        # Envoyer une alerte de démarrage
        logging.info("🚀 DÉMARRAGE DU SUPERVISEUR DE BOT TRADING 'BÉTON ARMÉ'")
        send_discord_alert("🚀 Superviseur de bot 'Béton Armé' démarré")
        
        # Mettre à jour l'état
        state["uptime"] = time.time()
        state["start_time"] = time.time()
        state["status"] = "démarrage"
        state["bot_version"] = "2.0.0"
        save_state()
        
        # Nettoyer les logs au démarrage
        clean_logs()
        
        # Démarrer le serveur web dans un thread séparé
        web_thread = threading.Thread(target=start_web_server)
        web_thread.daemon = True
        web_thread.start()
        
        # Lancer la boucle de surveillance
        watchdog_loop()
    
    except Exception as e:
        error_trace = traceback.format_exc()
        error_log(f"❌ Erreur fatale dans le superviseur principal: {e}\n{error_trace}")
        send_discord_alert(f"🚨 ERREUR FATALE: {str(e)}")
        
        # Tenter de redémarrer proprement en cas d'erreur critique
        try:
            subprocess.Popen(["bash", "systeme_complet.sh"])
        except:
            pass
        
        # Sortie avec code d'erreur
        exit(1)