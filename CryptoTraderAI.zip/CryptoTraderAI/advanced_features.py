#!/usr/bin/env python3
"""
Fonctionnalités avancées pour le bot de trading "Béton Armé"
Contient des améliorations de sélection de paires, gestion du risque et analyse de marché
"""
import time
import logging
import numpy as np
import threading
import psutil
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("advanced_features.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("AdvancedFeatures")

class AdvancedFeatures:
    """
    Module d'extension avec fonctionnalités avancées pour le bot de trading
    Implémentation des optimisations prioritaires:
    1. Sélection dynamique des paires
    2. Trailing stop loss
    3. Analyse multi-indicateurs
    4. Monitoring de ressources
    """
    
    def __init__(self, exchange_connector):
        """
        Initialise le module avec connexion à l'exchange
        
        Args:
            exchange_connector: Connecteur d'échange existant (Kraken)
        """
        self.exchange = exchange_connector
        self.price_history = {}  # Historique des prix par symbole
        self.volatility_cache = {}  # Cache de volatilité
        self.volume_cache = {}  # Cache de volume
        self.liquidity_cache = {}  # Cache de liquidité
        
        # Paramètres de sélection des paires
        self.volatility_threshold = 0.5  # % min de volatilité
        self.volume_threshold = 100000  # Volume min en USD
        self.liquidity_threshold = 0.5  # Score min de liquidité (0-1)
        
        # Stop loss et trailing stop
        self.trailing_distances = {}  # Distances de trailing par symbole
        self.highest_prices = {}  # Prix les plus hauts atteints
        
        # Indicateurs techniques
        self.rsi_values = {}  # Valeurs RSI par symbole
        self.macd_values = {}  # Valeurs MACD par symbole
        self.ema_values = {}  # Valeurs EMA par symbole
        
        # Monitoring système
        self.system_stats = {
            'cpu': 0,
            'memory': 0,
            'disk': 0,
            'network': 0
        }
        
        # Démarrer les threads en arrière-plan
        self.running = True
        self.start_background_threads()
        
        logger.info("Module de fonctionnalités avancées initialisé")
    
    def start_background_threads(self):
        """Démarre les threads de mise à jour en arrière-plan"""
        # Thread de monitoring système
        self.system_monitor_thread = threading.Thread(target=self._system_monitor_loop)
        self.system_monitor_thread.daemon = True
        self.system_monitor_thread.start()
        
        # Thread de mise à jour des indicateurs
        self.indicators_thread = threading.Thread(target=self._update_indicators_loop)
        self.indicators_thread.daemon = True
        self.indicators_thread.start()
        
        logger.info("Threads de fonctionnalités avancées démarrés")
    
    def stop(self):
        """Arrête tous les threads en cours"""
        self.running = False
        
        # Attendre que les threads se terminent
        if hasattr(self, 'system_monitor_thread'):
            self.system_monitor_thread.join(timeout=2)
        
        if hasattr(self, 'indicators_thread'):
            self.indicators_thread.join(timeout=2)
        
        logger.info("Threads de fonctionnalités avancées arrêtés")
    
    def _system_monitor_loop(self):
        """Thread de surveillance continue des ressources système"""
        while self.running:
            try:
                self._update_system_stats()
                time.sleep(10)  # Mise à jour toutes les 10 secondes
            except Exception as e:
                logger.error(f"Erreur dans le monitoring système: {e}")
                time.sleep(30)  # Délai plus long en cas d'erreur
    
    def _update_indicators_loop(self):
        """Thread de mise à jour continue des indicateurs techniques"""
        while self.running:
            try:
                # Mettre à jour tous les indicateurs pour les paires actives
                with ThreadPoolExecutor(max_workers=4) as executor:
                    # Récupérer la liste des paires à surveiller
                    symbols = self.exchange.get_watched_pairs()
                    
                    # Mettre à jour les indicateurs en parallèle
                    futures = []
                    for symbol in symbols:
                        futures.append(executor.submit(self._update_indicators_for_symbol, symbol))
                
                time.sleep(60)  # Mise à jour chaque minute
            except Exception as e:
                logger.error(f"Erreur dans la mise à jour des indicateurs: {e}")
                time.sleep(120)  # Délai plus long en cas d'erreur
    
    def _update_system_stats(self):
        """Met à jour les statistiques système"""
        try:
            # CPU
            self.system_stats['cpu'] = psutil.cpu_percent(interval=1)
            
            # Mémoire
            memory = psutil.virtual_memory()
            self.system_stats['memory'] = memory.percent
            
            # Disque
            disk = psutil.disk_usage('/')
            self.system_stats['disk'] = disk.percent
            
            # Réseau (total des bytes envoyés/reçus)
            net_io = psutil.net_io_counters()
            self.system_stats['network'] = net_io.bytes_sent + net_io.bytes_recv
            
            # Logger si utilisation critique
            if self.system_stats['cpu'] > 80 or self.system_stats['memory'] > 80:
                logger.warning(f"Utilisation critique - CPU: {self.system_stats['cpu']}%, "
                              f"Mémoire: {self.system_stats['memory']}%")
                
                # Prendre des mesures si nécessaire
                if self.system_stats['cpu'] > 90 or self.system_stats['memory'] > 90:
                    self._take_resource_action()
        
        except Exception as e:
            logger.error(f"Erreur lors de la mise à jour des stats système: {e}")
    
    def _take_resource_action(self):
        """Actions à prendre en cas de ressources limitées"""
        # Réduire la fréquence de mise à jour des indicateurs
        # Mettre en pause certaines fonctionnalités non critiques
        # Logger l'action prise
        logger.warning("Mesures d'économie de ressources activées")
    
    def _update_indicators_for_symbol(self, symbol):
        """Met à jour tous les indicateurs pour un symbole"""
        try:
            # Récupérer les données OHLCV
            ohlcv = self.exchange.get_ohlcv(symbol, timeframe='1h', limit=100)
            if not ohlcv or len(ohlcv) < 30:
                return
            
            # Convertir en numpy array pour calculs plus rapides
            closes = np.array([candle[4] for candle in ohlcv])
            volumes = np.array([candle[5] for candle in ohlcv])
            
            # Calculer RSI
            self.rsi_values[symbol] = self._calculate_rsi(closes)
            
            # Calculer MACD
            self.macd_values[symbol] = self._calculate_macd(closes)
            
            # Calculer EMA
            self.ema_values[symbol] = {
                'ema9': self._calculate_ema(closes, 9),
                'ema21': self._calculate_ema(closes, 21)
            }
            
            # Mettre à jour la volatilité
            self.volatility_cache[symbol] = self._calculate_volatility(closes)
            
            # Mettre à jour le volume
            self.volume_cache[symbol] = np.mean(volumes[-24:])  # Volume moyen sur 24h
            
            # Mettre à jour la liquidité
            self.liquidity_cache[symbol] = self._calculate_liquidity_score(symbol)
            
        except Exception as e:
            logger.error(f"Erreur lors de la mise à jour des indicateurs pour {symbol}: {e}")
    
    def _calculate_rsi(self, prices, period=14):
        """Calcule le RSI pour une série de prix"""
        deltas = np.diff(prices)
        seed = deltas[:period+1]
        up = seed[seed >= 0].sum()/period
        down = -seed[seed < 0].sum()/period
        rs = up/down if down != 0 else 0
        rsi = np.zeros_like(prices)
        rsi[:period] = 100. - 100./(1. + rs)
        
        for i in range(period, len(prices)):
            delta = deltas[i-1]
            if delta > 0:
                upval = delta
                downval = 0
            else:
                upval = 0
                downval = -delta
                
            up = (up * (period - 1) + upval) / period
            down = (down * (period - 1) + downval) / period
            rs = up/down if down != 0 else 0
            rsi[i] = 100. - 100./(1. + rs)
        
        return rsi[-1]  # Retourne la valeur la plus récente
    
    def _calculate_macd(self, prices, fast=12, slow=26, signal=9):
        """Calcule le MACD pour une série de prix"""
        # EMA rapide
        ema_fast = self._calculate_ema(prices, fast)
        
        # EMA lent
        ema_slow = self._calculate_ema(prices, slow)
        
        # Ligne MACD
        macd_line = ema_fast - ema_slow
        
        # Ligne de signal
        signal_line = self._calculate_ema(np.array([macd_line]), signal)
        
        # Histogramme
        histogram = macd_line - signal_line
        
        return {
            'macd': macd_line,
            'signal': signal_line,
            'histogram': histogram
        }
    
    def _calculate_ema(self, prices, period):
        """Calcule l'EMA pour une série de prix"""
        if len(prices) < period:
            return None
            
        # Calculer le multiplicateur
        multiplier = 2 / (period + 1)
        
        # Initialiser l'EMA avec la première valeur
        ema = prices[:period].mean()
        
        # Calculer l'EMA pour chaque prix restant
        for price in prices[period:]:
            ema = (price - ema) * multiplier + ema
            
        return ema
    
    def _calculate_volatility(self, prices, window=24):
        """Calcule la volatilité sur une fenêtre donnée"""
        if len(prices) < window:
            return 0
            
        # Dernières N périodes
        recent_prices = prices[-window:]
        
        # Calcul des rendements en pourcentage
        returns = np.diff(recent_prices) / recent_prices[:-1]
        
        # Écart-type des rendements (volatilité)
        volatility = np.std(returns) * 100  # En pourcentage
        
        return volatility
    
    def _calculate_liquidity_score(self, symbol):
        """
        Calcule un score de liquidité entre 0 et 1
        Basé sur le volume, le spread et la profondeur du carnet d'ordres
        """
        try:
            # Récupérer le carnet d'ordres
            orderbook = self.exchange.get_orderbook(symbol, limit=10)
            if not orderbook:
                return 0
                
            # Calculer le spread
            best_ask = min([order[0] for order in orderbook['asks']])
            best_bid = max([order[0] for order in orderbook['bids']])
            spread_pct = (best_ask - best_bid) / best_bid * 100
            
            # Calculer la profondeur du carnet
            ask_depth = sum([order[1] for order in orderbook['asks']])
            bid_depth = sum([order[1] for order in orderbook['bids']])
            total_depth = ask_depth + bid_depth
            
            # Volume récent (24h)
            volume = self.volume_cache.get(symbol, 0)
            
            # Normaliser les valeurs
            norm_spread = max(0, 1 - (spread_pct / 2))  # Spread < 2% = bon (score élevé)
            norm_depth = min(1, total_depth / 1000000)  # Normaliser la profondeur
            norm_volume = min(1, volume / 5000000)  # Normaliser le volume
            
            # Score combiné (pondération personnalisable)
            liquidity_score = (
                norm_spread * 0.4 +
                norm_depth * 0.3 +
                norm_volume * 0.3
            )
            
            return max(0, min(1, liquidity_score))  # Entre 0 et 1
            
        except Exception as e:
            logger.error(f"Erreur lors du calcul de liquidité pour {symbol}: {e}")
            return 0
    
    def select_optimal_pairs(self, market_conditions='normal', max_pairs=5):
        """
        Sélectionne les meilleures paires à trader en fonction des conditions du marché
        
        Args:
            market_conditions (str): 'bull', 'bear', 'volatile', 'normal'
            max_pairs (int): Nombre maximum de paires à retourner
            
        Returns:
            list: Liste des meilleures paires à trader
        """
        try:
            # Récupérer toutes les paires disponibles
            all_pairs = self.exchange.get_available_pairs()
            
            # Filtrer les paires sans données suffisantes
            valid_pairs = [p for p in all_pairs if p in self.volatility_cache and p in self.volume_cache]
            
            # Créer un score pour chaque paire
            pair_scores = []
            
            for pair in valid_pairs:
                # Récupérer les métriques
                volatility = self.volatility_cache.get(pair, 0)
                volume = self.volume_cache.get(pair, 0)
                liquidity = self.liquidity_cache.get(pair, 0)
                
                # Trend score basé sur MACD et EMA
                trend_score = 0
                if pair in self.macd_values and pair in self.ema_values:
                    macd = self.macd_values[pair]['histogram']
                    ema9 = self.ema_values[pair]['ema9']
                    ema21 = self.ema_values[pair]['ema21']
                    
                    # MACD positif = bullish
                    if macd > 0:
                        trend_score += 0.5
                    
                    # EMA9 > EMA21 = bullish
                    if ema9 > ema21:
                        trend_score += 0.5
                
                # Score RSI (survente/surachat)
                rsi_score = 0
                if pair in self.rsi_values:
                    rsi = self.rsi_values[pair]
                    # RSI < 30 = survente (bon pour achat)
                    if rsi < 30:
                        rsi_score = 1
                    # RSI > 70 = surachat (mauvais pour achat)
                    elif rsi > 70:
                        rsi_score = 0
                    else:
                        rsi_score = 0.5  # Neutre
                
                # Ajuster les poids selon les conditions du marché
                if market_conditions == 'bull':
                    # Favoriser les paires avec forte tendance haussière
                    final_score = (
                        volatility * 0.2 +
                        volume * 0.1 +
                        liquidity * 0.2 +
                        trend_score * 0.4 +
                        rsi_score * 0.1
                    )
                
                elif market_conditions == 'bear':
                    # Favoriser les paires plus stables ou en survente
                    final_score = (
                        volatility * -0.1 +  # Moins de volatilité
                        volume * 0.2 +
                        liquidity * 0.3 +
                        trend_score * 0.1 +
                        rsi_score * 0.3  # Plus de poids sur RSI (chercher survente)
                    )
                
                elif market_conditions == 'volatile':
                    # Favoriser les paires liquides et moins volatiles
                    final_score = (
                        volatility * -0.2 +  # Pénaliser la volatilité
                        volume * 0.3 +
                        liquidity * 0.4 +  # Forte liquidité importante
                        trend_score * 0.0 +  # Ignorer la tendance
                        rsi_score * 0.1
                    )
                
                else:  # 'normal'
                    # Équilibre entre tous les facteurs
                    final_score = (
                        volatility * 0.2 +
                        volume * 0.2 +
                        liquidity * 0.2 +
                        trend_score * 0.2 +
                        rsi_score * 0.2
                    )
                
                # Ajouter à la liste
                pair_scores.append((pair, final_score))
            
            # Trier par score et prendre les N meilleures
            pair_scores.sort(key=lambda x: x[1], reverse=True)
            top_pairs = [pair for pair, score in pair_scores[:max_pairs]]
            
            logger.info(f"Paires optimales pour conditions {market_conditions}: {top_pairs}")
            return top_pairs
        
        except Exception as e:
            logger.error(f"Erreur lors de la sélection des paires: {e}")
            return []
    
    def trailing_stop_loss(self, symbol, entry_price, current_price=None, trailing_pct=1.5):
        """
        Calcule un trailing stop-loss qui suit le prix à mesure qu'il monte
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
            entry_price (float): Prix d'entrée
            current_price (float): Prix actuel (optionnel)
            trailing_pct (float): % de distance à maintenir
            
        Returns:
            tuple: (stop_loss_price, highest_recorded_price)
        """
        try:
            # Obtenir le prix actuel si non fourni
            if current_price is None:
                current_price = self.exchange.get_ticker_price(symbol)
                if not current_price:
                    return None, None
            
            # Initialiser highest_price s'il n'existe pas pour ce symbole
            if symbol not in self.highest_prices:
                self.highest_prices[symbol] = entry_price
            
            # Mettre à jour highest_price si le prix actuel est plus élevé
            if current_price > self.highest_prices[symbol]:
                self.highest_prices[symbol] = current_price
                logger.debug(f"Nouveau prix max pour {symbol}: {current_price}")
            
            # Calculer le stop-loss avec trailing
            trailing_distance = self.highest_prices[symbol] * (trailing_pct / 100)
            stop_loss = self.highest_prices[symbol] - trailing_distance
            
            # Ne jamais descendre sous le prix d'entrée
            if stop_loss < entry_price:
                stop_loss = entry_price
            
            # Enregistrer la distance de trailing actuelle
            self.trailing_distances[symbol] = trailing_distance
            
            return stop_loss, self.highest_prices[symbol]
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul du trailing stop pour {symbol}: {e}")
            return None, None
    
    def check_multi_indicators(self, symbol):
        """
        Vérifie plusieurs indicateurs pour confirmer un signal de trading
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            dict: Signaux de trading confirmés ou non
        """
        try:
            signals = {
                'buy': False,
                'sell': False,
                'confidence': 0,
                'reasons': []
            }
            
            # Vérifier RSI
            rsi_signal = None
            if symbol in self.rsi_values:
                rsi = self.rsi_values[symbol]
                if rsi < 30:
                    rsi_signal = 'buy'
                    signals['reasons'].append(f"RSI en survente: {rsi:.1f}")
                elif rsi > 70:
                    rsi_signal = 'sell'
                    signals['reasons'].append(f"RSI en surachat: {rsi:.1f}")
            
            # Vérifier MACD
            macd_signal = None
            if symbol in self.macd_values:
                macd = self.macd_values[symbol]
                if macd['histogram'] > 0 and macd['macd'] > macd['signal']:
                    macd_signal = 'buy'
                    signals['reasons'].append("MACD positif et croisement haussier")
                elif macd['histogram'] < 0 and macd['macd'] < macd['signal']:
                    macd_signal = 'sell'
                    signals['reasons'].append("MACD négatif et croisement baissier")
            
            # Vérifier EMA
            ema_signal = None
            if symbol in self.ema_values:
                ema = self.ema_values[symbol]
                if ema['ema9'] > ema['ema21']:
                    ema_signal = 'buy'
                    signals['reasons'].append("EMA9 au-dessus de EMA21")
                elif ema['ema9'] < ema['ema21']:
                    ema_signal = 'sell'
                    signals['reasons'].append("EMA9 sous EMA21")
            
            # Combiner les signaux pour confirmation
            buy_signals = sum(1 for s in [rsi_signal, macd_signal, ema_signal] if s == 'buy')
            sell_signals = sum(1 for s in [rsi_signal, macd_signal, ema_signal] if s == 'sell')
            
            # Calculer la confiance
            total_signals = 3  # RSI, MACD, EMA
            if buy_signals > sell_signals:
                signals['buy'] = True
                signals['confidence'] = buy_signals / total_signals
            elif sell_signals > buy_signals:
                signals['sell'] = True
                signals['confidence'] = sell_signals / total_signals
            
            return signals
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse multi-indicateurs pour {symbol}: {e}")
            return {'buy': False, 'sell': False, 'confidence': 0, 'reasons': []}
    
    def get_system_health(self):
        """
        Retourne l'état de santé du système
        
        Returns:
            dict: Métriques de santé système
        """
        return {
            'cpu_usage': self.system_stats['cpu'],
            'memory_usage': self.system_stats['memory'],
            'disk_usage': self.system_stats['disk'],
            'status': 'critical' if (self.system_stats['cpu'] > 80 or self.system_stats['memory'] > 80) else 'normal'
        }
    
    @lru_cache(maxsize=100)
    def is_profitable_pair(self, symbol, expected_price_move_pct):
        """
        Détermine si une paire est potentiellement rentable compte tenu des frais
        
        Args:
            symbol (str): Symbole de la paire
            expected_price_move_pct (float): Mouvement de prix attendu en %
            
        Returns:
            bool: True si la paire est potentiellement rentable
        """
        try:
            # Récupérer les frais de trading pour cette paire
            fees = self.exchange.get_trading_fees(symbol)
            if not fees:
                return False
            
            # Frais d'achat + vente
            total_fees_pct = fees['maker'] + fees['taker']
            
            # Marge après frais
            profit_after_fees = expected_price_move_pct - (total_fees_pct * 100)
            
            # Vérifier si la paire offre une marge suffisante
            min_profit_threshold = 0.5  # 0.5% minimum profit
            return profit_after_fees > min_profit_threshold
        
        except Exception as e:
            logger.error(f"Erreur lors de l'évaluation de rentabilité pour {symbol}: {e}")
            return False
    
    def get_market_conditions(self):
        """
        Détermine les conditions actuelles du marché
        
        Returns:
            str: 'bull', 'bear', 'volatile', ou 'normal'
        """
        try:
            # Utiliser BTC comme proxy pour les conditions générales
            btc_symbol = "BTC/USD"
            
            # Calculer la volatilité sur 24h
            volatility = self.volatility_cache.get(btc_symbol, 0)
            
            # Obtenir le RSI
            rsi = self.rsi_values.get(btc_symbol, 50)
            
            # Obtenir la tendance via MACD et EMA
            macd = self.macd_values.get(btc_symbol, {'histogram': 0})
            
            # Déterminer les conditions
            if volatility > 5:  # Plus de 5% de volatilité
                return 'volatile'
            elif rsi > 60 and macd['histogram'] > 0:
                return 'bull'
            elif rsi < 40 and macd['histogram'] < 0:
                return 'bear'
            else:
                return 'normal'
        
        except Exception as e:
            logger.error(f"Erreur lors de l'évaluation des conditions de marché: {e}")
            return 'normal'  # Par défaut
    
    def customize_stop_loss(self, symbol, base_stop_pct):
        """
        Personnalise le stop-loss en fonction des indicateurs techniques
        
        Args:
            symbol (str): Symbole de la paire
            base_stop_pct (float): % de stop-loss de base
            
        Returns:
            float: % de stop-loss personnalisé
        """
        try:
            # Récupérer RSI
            rsi = self.rsi_values.get(symbol, 50)
            
            # Récupérer volatilité
            volatility = self.volatility_cache.get(symbol, 0)
            
            # Ajuster en fonction de la volatilité
            volatility_factor = min(2, max(0.5, volatility / 2))
            
            # Ajuster en fonction du RSI
            rsi_factor = 1.0
            if rsi < 30:  # Survente, plus de marge
                rsi_factor = 1.2
            elif rsi > 70:  # Surachat, moins de marge
                rsi_factor = 0.8
            
            # Stop-loss personnalisé
            custom_stop_pct = base_stop_pct * volatility_factor * rsi_factor
            
            # Limiter entre 0.2% et 5%
            custom_stop_pct = min(5, max(0.2, custom_stop_pct))
            
            return custom_stop_pct
        
        except Exception as e:
            logger.error(f"Erreur lors de la personnalisation du stop-loss pour {symbol}: {e}")
            return base_stop_pct  # Retourner la valeur par défaut