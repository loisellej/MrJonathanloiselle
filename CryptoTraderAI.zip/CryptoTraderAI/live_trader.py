#!/usr/bin/env python3
"""
TRADER CRYPTO LIVE UNIQUEMENT - PAS DE SIMULATION
Ce module exécute des ordres d'achat et de vente en TEMPS RÉEL sur Kraken
Il est conçu pour opérer uniquement en mode LIVE trading
"""
import os
import time
import logging
import random
import threading
import krakenex
from datetime import datetime, timedelta
from api_keys import get_api_credentials

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("live_trader.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("LiveTrader")

# Récupération des clés API Kraken
API_KEY, API_SECRET = get_api_credentials()
if not API_KEY or not API_SECRET:
    logger.error("❌ ERREUR: Clés API manquantes. Le trader ne peut pas fonctionner en mode réel.")
    exit(1)

logger.info(f"✅ Clés API chargées: {API_KEY[:5]}...{API_KEY[-5:]}")

# Paires de trading ultra-volatiles à surveiller
VOLATILE_PAIRS = [
    "ZEREBRO/USD", "MANA/USD", "FTM/USD", "GARI/USD", 
    "AVAX/USD", "LINK/USD", "DOGE/USD", "SHIB/USD", 
    "MATIC/USD", "DOT/USD", "ADA/USD", "ATOM/USD", 
    "XRP/USD", "SAND/USD", "ALGO/USD", "ENJ/USD", 
    "1INCH/USD", "AAVE/USD", "KAVA/USD", "DYDX/USD"
]

# Paires exclues selon la demande du client
EXCLUDED_PAIRS = ["BTC/USD", "ETH/USD", "SOL/USD"]

class LiveTrader:
    """
    Classe pour exécuter des trades réels (JAMAIS EN SIMULATION)
    avec des stop-loss très serrés (0.5-0.8%)
    """
    
    def __init__(self):
        """Initialise le trader en mode réel"""
        self.k = krakenex.API(API_KEY, API_SECRET)
        self.running = False
        self.stop_event = threading.Event()
        
        # Données de marché
        self.price_cache = {}  # Cache des prix
        self.volatility_scores = {}  # Scores de volatilité
        self.trend_scores = {}  # Scores de tendance
        
        # Positions et ordres
        self.positions = {}  # Positions actuelles
        self.stop_losses = {}  # Stop-losses actifs
        self.usd_balance = 0  # Solde USD
        
        # Paramètres de trading
        self.stop_loss_pct = 0.5  # Stop-loss ultra-serré: 0.5%
        self.take_profit_pct = 2.5  # Objectif de profit: 2.5% (NET des frais)
        self.max_risk_per_trade = 0.1  # Max 10% du capital par trade
        self.check_interval = 1  # Vérifier le marché chaque seconde
        self.stop_loss_check_interval = 0.2  # Vérifier les stop-losses toutes les 200ms
        
        logger.info("✅ Trader LIVE initialisé (PAS DE SIMULATION)")
    
    def update_balances(self):
        """Récupère les soldes actuels depuis Kraken"""
        try:
            start_time = time.time()
            balances = self.k.query_private('Balance')
            
            if 'error' in balances and balances['error']:
                logger.error(f"Erreur Kraken: {balances['error']}")
                return False
            
            # Mise à jour des positions
            self.positions = {}
            
            # Récupération du solde USD
            self.usd_balance = float(balances['result'].get('ZUSD', 0))
            
            # Récupération des autres actifs
            for asset, balance in balances['result'].items():
                if asset == 'ZUSD':  # Déjà traité
                    continue
                
                balance_float = float(balance)
                if balance_float > 0.001:  # Ignorer les poussières
                    self.positions[asset] = balance_float
            
            logger.info(f"Balances mises à jour en {(time.time() - start_time)*1000:.1f}ms: "
                        f"{len(self.positions)} actifs, {self.usd_balance:.2f} USD")
            
            # Afficher les positions significatives (>1 USD)
            significant_positions = []
            for asset, balance in self.positions.items():
                try:
                    price = self.get_ticker_price(f"{asset}/USD")
                    if price:
                        usd_value = price * balance
                        if usd_value > 1:
                            significant_positions.append(f"{asset}: {balance:.4f} (~{usd_value:.2f}$)")
                except Exception as e:
                    logger.warning(f"Impossible d'évaluer {asset}: {e}")
            
            if significant_positions:
                logger.info(f"Positions significatives: {', '.join(significant_positions)}")
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances: {e}")
            return False
    
    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel avec temps de réponse en microsecondes
        Utilise un cache pour minimiser les appels API
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
        """
        try:
            # Vérifier le cache (validité: 3 secondes)
            now = time.time()
            if symbol in self.price_cache:
                if now - self.price_cache[symbol]['time'] < 3:
                    return self.price_cache[symbol]['price']
            
            # Convertir le format du symbole pour Kraken
            parts = symbol.split('/')
            asset = parts[0]
            quote = parts[1]
            
            # Formater selon les conventions Kraken
            if quote == 'USD':
                pair = f"X{asset}ZUSD"
            else:
                pair = f"X{asset}X{quote}"
            
            # Exception pour certains actifs
            if asset in ['ZEREBRO', 'GARI', 'MANA']:
                pair = f"{asset}{quote}"
            
            # Requête API
            ticker = self.k.query_public('Ticker', {'pair': pair})
            
            if 'error' in ticker and ticker['error']:
                logger.warning(f"Erreur ticker: {ticker['error']} pour {symbol}")
                return None
            
            # Extraction du prix
            result_key = list(ticker['result'].keys())[0]
            price = float(ticker['result'][result_key]['c'][0])
            
            # Mise à jour du cache
            self.price_cache[symbol] = {
                'price': price,
                'time': now
            }
            
            return price
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix de {symbol}: {e}")
            return None
    
    def analyze_volatility(self, symbol):
        """
        Analyse la volatilité d'une paire sur les dernières périodes
        Retourne un score de volatilité (plus élevé = plus volatile)
        """
        try:
            # Extraire l'actif du symbole
            asset = symbol.split('/')[0]
            
            # Requête API pour les données OHLC (bougies)
            pair = f"X{asset}ZUSD"
            if asset in ['ZEREBRO', 'GARI', 'MANA']:
                pair = f"{asset}USD"
            
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})  # 5 minutes
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Erreur OHLC: {ohlc['error']} pour {symbol}")
                return 0
            
            # Extraction des données OHLC
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Calcul de la volatilité sur les 20 dernières périodes
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]  # Prix de clôture
            
            # Calcul des variations en pourcentage
            changes = [abs(close_prices[i] - close_prices[i-1]) / close_prices[i-1] * 100 
                      for i in range(1, len(close_prices))]
            
            # Calcul de la volatilité pondérée (plus de poids aux changements récents)
            weighted_volatility = 0
            weight_sum = 0
            
            for i, change in enumerate(changes):
                weight = (i + 1) ** 2  # Poids croissant (plus récent = plus important)
                weighted_volatility += change * weight
                weight_sum += weight
            
            volatility = weighted_volatility / weight_sum if weight_sum > 0 else 0
            
            # Mise à jour du cache
            self.volatility_scores[symbol] = volatility
            
            return volatility
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de volatilité pour {symbol}: {e}")
            return 0
    
    def analyze_trend(self, symbol):
        """
        Analyse la tendance d'une paire sur les dernières périodes
        Retourne un score de tendance (positif = haussier, négatif = baissier)
        """
        try:
            # Extraire l'actif du symbole
            asset = symbol.split('/')[0]
            
            # Requête API pour les données OHLC (bougies)
            pair = f"X{asset}ZUSD"
            if asset in ['ZEREBRO', 'GARI', 'MANA']:
                pair = f"{asset}USD"
            
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})  # 5 minutes
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Erreur OHLC: {ohlc['error']} pour {symbol}")
                return 0
            
            # Extraction des données OHLC
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Extraction des prix de clôture
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]
            
            # Calcul de la tendance globale (20 périodes)
            overall_trend = (close_prices[-1] / close_prices[0] - 1) * 100
            
            # Calcul de la tendance récente (5 périodes)
            recent_trend = (close_prices[-1] / close_prices[-6] - 1) * 100 if len(close_prices) >= 6 else 0
            
            # Score de tendance combiné (70% récent, 30% global)
            trend_score = recent_trend * 0.7 + overall_trend * 0.3
            
            # Mise à jour du cache
            self.trend_scores[symbol] = trend_score
            
            return trend_score
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de tendance pour {symbol}: {e}")
            return 0
    
    def find_best_opportunities(self):
        """
        Identifie les meilleures opportunités de trading
        Retourne une liste triée des meilleures opportunités
        """
        opportunities = []
        
        for symbol in VOLATILE_PAIRS:
            if symbol.split('/')[0] in EXCLUDED_PAIRS:
                continue
            
            try:
                # Vérifier si le prix est disponible
                price = self.get_ticker_price(symbol)
                if not price:
                    continue
                
                # Analyser la volatilité et la tendance
                volatility = self.analyze_volatility(symbol)
                trend = self.analyze_trend(symbol)
                
                # Score combiné basé sur volatilité et tendance
                # Valoriser la tendance positive, pénaliser la tendance négative
                trend_factor = 1 if trend > 0 else -2
                combined_score = (volatility * 0.6) + (abs(trend) * trend_factor * 0.4)
                
                # Ajouter l'opportunité à la liste
                opportunities.append({
                    'symbol': symbol,
                    'price': price,
                    'volatility': volatility,
                    'trend': trend,
                    'score': combined_score
                })
                
                logger.info(f"{symbol}: Volatilité {volatility:.2f}%, Tendance {trend:+.2f}%, Score {combined_score:.2f}")
                
            except Exception as e:
                logger.error(f"Erreur lors de l'analyse de {symbol}: {e}")
        
        # Trier par score décroissant
        return sorted(opportunities, key=lambda x: x['score'], reverse=True)
    
    def calculate_position_size(self, symbol, price):
        """
        Calcule la taille optimale de la position pour un trade
        en fonction du capital disponible et du risque max par trade
        """
        # Calculer le montant maximal pour ce trade
        max_trade_amount = self.usd_balance * self.max_risk_per_trade
        
        # Limiter à un montant minimal de 5 USD
        trade_amount = max(5.0, max_trade_amount)
        
        # Limiter au solde disponible
        trade_amount = min(trade_amount, self.usd_balance * 0.95)  # 95% max du solde pour les frais
        
        # Calculer la quantité
        quantity = trade_amount / price
        
        logger.info(f"Position calculée pour {symbol}: {quantity:.6f} ({trade_amount:.2f} USD)")
        return quantity
    
    def execute_buy(self, symbol, quantity=None, percentage=None):
        """
        Exécute un ordre d'achat en temps réel
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
            quantity (float, optional): Quantité à acheter
            percentage (float, optional): Pourcentage du solde USD à utiliser
        """
        try:
            # Vérifier les paramètres
            if quantity is None and percentage is None:
                logger.error("Erreur: quantité ou pourcentage requis pour l'achat")
                return None
            
            # Extraire l'actif et la quote
            asset, quote = symbol.split('/')
            
            # Calculer la quantité si le pourcentage est fourni
            if percentage and not quantity:
                price = self.get_ticker_price(symbol)
                if not price:
                    logger.error(f"Impossible d'obtenir le prix pour {symbol}")
                    return None
                
                trade_amount = self.usd_balance * percentage
                quantity = trade_amount / price
            
            # Formater le symbole pour Kraken
            kraken_pair = f"{asset}{quote}"
            
            # Exécuter l'ordre d'achat en temps réel
            start_time = time.time()
            order = self.k.query_private('AddOrder', {
                'pair': kraken_pair,
                'type': 'buy',
                'ordertype': 'market',
                'volume': str(quantity)
            })
            
            execution_time = (time.time() - start_time) * 1000  # ms
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur d'achat: {order['error']}")
                return None
            
            # Récupérer les détails de l'ordre
            txid = order['result']['txid'][0] if 'txid' in order['result'] else None
            
            logger.info(f"✅ Achat exécuté: {quantity:.6f} {asset} ({execution_time:.2f}ms) - ID: {txid}")
            
            # Mettre à jour les balances
            self.update_balances()
            
            # Définir un stop-loss pour cette position
            self.set_stop_loss(symbol, price)
            
            return {
                'txid': txid,
                'symbol': symbol,
                'type': 'buy',
                'quantity': quantity,
                'execution_time_ms': execution_time
            }
            
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {symbol}: {e}")
            return None
    
    def execute_sell(self, symbol, quantity=None, percentage=None):
        """
        Exécute un ordre de vente en temps réel
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
            quantity (float, optional): Quantité à vendre
            percentage (float, optional): Pourcentage du solde de l'actif à vendre
        """
        try:
            # Vérifier les paramètres
            if quantity is None and percentage is None:
                logger.error("Erreur: quantité ou pourcentage requis pour la vente")
                return None
            
            # Extraire l'actif et la quote
            asset, quote = symbol.split('/')
            
            # Vérifier si l'actif est disponible
            if asset not in self.positions:
                logger.error(f"Actif {asset} non disponible dans le portefeuille")
                return None
            
            # Calculer la quantité si le pourcentage est fourni
            if percentage and not quantity:
                quantity = self.positions[asset] * percentage
            
            # Formater le symbole pour Kraken
            kraken_pair = f"{asset}{quote}"
            
            # Exécuter l'ordre de vente en temps réel
            start_time = time.time()
            order = self.k.query_private('AddOrder', {
                'pair': kraken_pair,
                'type': 'sell',
                'ordertype': 'market',
                'volume': str(quantity)
            })
            
            execution_time = (time.time() - start_time) * 1000  # ms
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur de vente: {order['error']}")
                return None
            
            # Récupérer les détails de l'ordre
            txid = order['result']['txid'][0] if 'txid' in order['result'] else None
            
            logger.info(f"✅ Vente exécutée: {quantity:.6f} {asset} ({execution_time:.2f}ms) - ID: {txid}")
            
            # Mettre à jour les balances
            self.update_balances()
            
            # Supprimer le stop-loss associé
            if symbol in self.stop_losses:
                del self.stop_losses[symbol]
            
            return {
                'txid': txid,
                'symbol': symbol,
                'type': 'sell',
                'quantity': quantity,
                'execution_time_ms': execution_time
            }
            
        except Exception as e:
            logger.error(f"Erreur lors de la vente de {symbol}: {e}")
            return None
    
    def set_stop_loss(self, symbol, entry_price=None):
        """
        Définit un stop-loss ultra-serré pour une position
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
            entry_price (float, optional): Prix d'entrée (si None, utilise le prix actuel)
        """
        try:
            # Obtenir le prix actuel si non fourni
            if not entry_price:
                entry_price = self.get_ticker_price(symbol)
                if not entry_price:
                    logger.error(f"Impossible d'obtenir le prix pour {symbol}")
                    return False
            
            # Calculer le prix du stop-loss (0.5-0.8% sous le prix d'entrée)
            stop_loss_pct = random.uniform(0.5, 0.8)  # Variation légère pour éviter les détections
            stop_loss_price = entry_price * (1 - stop_loss_pct / 100)
            
            # Enregistrer le stop-loss
            self.stop_losses[symbol] = {
                'price': stop_loss_price,
                'entry_price': entry_price,
                'percentage': stop_loss_pct,
                'time': time.time()
            }
            
            logger.info(f"⚠️ Stop-loss défini pour {symbol}: {stop_loss_price:.6f} ({stop_loss_pct:.2f}%)")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de la définition du stop-loss pour {symbol}: {e}")
            return False
    
    def check_stop_losses(self):
        """
        Vérifie tous les stop-losses et exécute les ventes si nécessaire
        Cette fonction est optimisée pour une exécution ultra-rapide (microsecondes)
        """
        for symbol, stop_loss in list(self.stop_losses.items()):
            try:
                # Obtenir le prix actuel
                current_price = self.get_ticker_price(symbol)
                if not current_price:
                    continue
                
                # Vérifier si le stop-loss est déclenché
                if current_price <= stop_loss['price']:
                    # Extraire l'actif
                    asset = symbol.split('/')[0]
                    
                    # Vérifier si l'actif est disponible
                    if asset not in self.positions:
                        del self.stop_losses[symbol]
                        continue
                    
                    logger.warning(f"⚠️ STOP-LOSS DÉCLENCHÉ pour {symbol} à {current_price:.6f}")
                    
                    # Vendre toute la position avec une exécution ultra-rapide
                    self.execute_sell(symbol, percentage=1.0)
                    
                    # Supprimer le stop-loss
                    del self.stop_losses[symbol]
                    
            except Exception as e:
                logger.error(f"Erreur lors de la vérification du stop-loss pour {symbol}: {e}")
    
    def check_take_profits(self):
        """
        Vérifie toutes les positions pour prendre des profits si les objectifs sont atteints
        """
        for symbol, stop_loss in list(self.stop_losses.items()):
            try:
                # Obtenir le prix actuel
                current_price = self.get_ticker_price(symbol)
                if not current_price:
                    continue
                
                # Calculer le prix de take-profit
                take_profit_price = stop_loss['entry_price'] * (1 + self.take_profit_pct / 100)
                
                # Vérifier si le take-profit est atteint
                if current_price >= take_profit_price:
                    # Extraire l'actif
                    asset = symbol.split('/')[0]
                    
                    # Vérifier si l'actif est disponible
                    if asset not in self.positions:
                        del self.stop_losses[symbol]
                        continue
                    
                    # Calculer le profit en pourcentage
                    profit_pct = (current_price / stop_loss['entry_price'] - 1) * 100
                    
                    logger.info(f"🎯 TAKE-PROFIT ATTEINT pour {symbol} à {current_price:.6f} "
                               f"(+{profit_pct:.2f}%)")
                    
                    # Vendre 50% de la position pour sécuriser des profits
                    self.execute_sell(symbol, percentage=0.5)
                    
                    # Mettre à jour le stop-loss au prix d'entrée (break-even)
                    self.stop_losses[symbol]['price'] = stop_loss['entry_price']
                    logger.info(f"🛡️ Stop-loss mis à jour au break-even pour {symbol}")
                    
            except Exception as e:
                logger.error(f"Erreur lors de la vérification du take-profit pour {symbol}: {e}")
    
    def trading_loop(self):
        """Boucle principale de trading - Analyse continue du marché"""
        last_opportunity_check = 0
        
        while not self.stop_event.is_set():
            try:
                current_time = time.time()
                
                # Vérifier les stop-losses à haute fréquence (200ms)
                self.check_stop_losses()
                
                # Vérifier les take-profits toutes les secondes
                if int(current_time * 10) % 10 == 0:  # ~chaque seconde
                    self.check_take_profits()
                
                # Rechercher de nouvelles opportunités chaque minute
                if current_time - last_opportunity_check > 60:
                    # Mettre à jour les balances
                    self.update_balances()
                    
                    # Trouver les meilleures opportunités
                    opportunities = self.find_best_opportunities()
                    
                    # Exécuter des trades si de bonnes opportunités sont disponibles
                    for opp in opportunities[:3]:  # Top 3 opportunités
                        if opp['score'] > 1.5 and opp['trend'] > 0:
                            # Vérifier si on a déjà une position
                            asset = opp['symbol'].split('/')[0]
                            if asset in self.positions and self.positions[asset] > 0:
                                logger.info(f"Position existante pour {asset}, pas de nouvel achat")
                                continue
                            
                            # Vérifier le solde USD
                            if self.usd_balance < 5:
                                logger.warning(f"Solde USD insuffisant: {self.usd_balance:.2f} $")
                                break
                            
                            # Calculer la position
                            quantity = self.calculate_position_size(opp['symbol'], opp['price'])
                            
                            # Exécuter l'achat
                            logger.info(f"🚀 Opportunité détectée: {opp['symbol']} (Score: {opp['score']:.2f})")
                            self.execute_buy(opp['symbol'], quantity=quantity)
                    
                    last_opportunity_check = current_time
                
                # Pause courte pour économiser les ressources CPU
                time.sleep(self.stop_loss_check_interval)
                
            except Exception as e:
                logger.error(f"Erreur dans la boucle de trading: {e}")
                time.sleep(1)  # Pause plus longue en cas d'erreur
    
    def start(self):
        """Démarrer le trader"""
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        try:
            # Vérifier les clés API
            if not API_KEY or not API_SECRET:
                logger.error("❌ ERREUR: Clés API manquantes. Le trader ne peut pas fonctionner en mode réel.")
                return False
            
            # Mettre à jour les balances
            if not self.update_balances():
                logger.error("❌ ERREUR: Impossible de récupérer les balances. Vérifiez les clés API.")
                return False
            
            # Réinitialiser l'événement d'arrêt
            self.stop_event.clear()
            
            # Démarrer la boucle de trading dans un thread
            self.trading_thread = threading.Thread(target=self.trading_loop)
            self.trading_thread.daemon = True
            self.trading_thread.start()
            
            self.running = True
            logger.info("✅ Trader démarré en mode LIVE")
            
            # Créer un fichier PID
            with open("trader.pid", "w") as f:
                f.write(str(os.getpid()))
            
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors du démarrage du trader: {e}")
            return False
    
    def stop(self):
        """Arrêter le trader"""
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        try:
            # Signaler l'arrêt
            self.stop_event.set()
            
            # Attendre la fin du thread (max 5 secondes)
            if hasattr(self, 'trading_thread'):
                self.trading_thread.join(5)
            
            self.running = False
            logger.info("✅ Trader arrêté")
            
            # Supprimer le fichier PID
            if os.path.exists("trader.pid"):
                os.remove("trader.pid")
            
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de l'arrêt du trader: {e}")
            return False

def start_trader():
    """Fonction principale pour démarrer le trader"""
    try:
        # Créer et démarrer le trader
        trader = LiveTrader()
        if trader.start():
            # Créer un thread de heartbeat
            def heartbeat_thread():
                while trader.running:
                    try:
                        # Écrire un heartbeat toutes les 10 secondes
                        with open("bot_heartbeat.txt", "w") as f:
                            f.write(f"Trader actif: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                        time.sleep(10)
                    except Exception as e:
                        logger.error(f"Erreur dans le heartbeat: {e}")
                        time.sleep(10)
            
            # Démarrer le thread de heartbeat
            heartbeat = threading.Thread(target=heartbeat_thread)
            heartbeat.daemon = True
            heartbeat.start()
            
            # Garder le processus principal en vie
            while trader.running:
                time.sleep(1)
                
                # Vérifier si le trader est toujours en cours d'exécution
                if not trader.trading_thread.is_alive():
                    logger.error("Thread de trading arrêté de manière inattendue, redémarrage...")
                    trader.stop()
                    time.sleep(1)
                    trader.start()
        
        return True
    
    except KeyboardInterrupt:
        logger.info("Arrêt du trader demandé par l'utilisateur")
        if 'trader' in locals():
            trader.stop()
        return False
    
    except Exception as e:
        logger.error(f"Erreur critique lors du démarrage du trader: {e}")
        return False

if __name__ == "__main__":
    # Démarrer le trader
    logger.info("Démarrage du trader en mode LIVE UNIQUEMENT...")
    start_trader()