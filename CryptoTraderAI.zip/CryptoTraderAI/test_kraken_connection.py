import os
import ccxt
import sys

def test_kraken_connection():
    """Test simple de la connexion à Kraken"""
    print("=== TEST DE CONNEXION À KRAKEN ===")
    
    try:
        # Récupérer les clés API
        api_key = os.environ.get('KRAKEN_API_KEY')
        api_secret = os.environ.get('KRAKEN_API_SECRET')
        
        print(f"API Key définie: {'Oui' if api_key else 'Non'}")
        print(f"API Secret définie: {'Oui' if api_secret else 'Non'}")
        
        # Créer l'objet exchange
        print("Initialisation de la connexion à Kraken...")
        exchange = ccxt.kraken({
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True
        })
        
        # Tester les fonctions publiques
        print("Test des fonctions publiques de l'API:")
        markets = exchange.load_markets()
        print(f"Nombre de marchés disponibles: {len(markets)}")
        print(f"Premier marché: {list(markets.keys())[0]}")
        
        # Tester l'authentification
        print("\nTest des fonctions privées de l'API (nécessite authentification):")
        try:
            balances = exchange.fetch_balance()
            print("✅ Authentification réussie! Balances récupérées.")
            
            # Afficher les balances non nulles
            print("\nBalances non nulles:")
            for asset, balance in balances['total'].items():
                if float(balance) > 0:
                    print(f"  {asset}: {balance}")
            return True
        except Exception as e:
            print(f"❌ Échec de l'authentification: {e}")
            if "Invalid key" in str(e):
                print("\nL'erreur 'Invalid key' peut être due à:")
                print("1. Clé API incorrecte ou mal copiée")
                print("2. Permissions insuffisantes (assurez-vous d'avoir activé 'Query Funds')")
                print("3. Restriction d'IP (vérifiez que les requêtes depuis Replit sont autorisées)")
            return False
    
    except Exception as e:
        print(f"Erreur générale: {e}")
        return False

if __name__ == "__main__":
    success = test_kraken_connection()
    sys.exit(0 if success else 1)