#!/usr/bin/env python3
"""
TRADER ZEREBRO SIMPLE ET EFFICACE
- Surveille ZEREBRO
- Vend quand le profit atteint 2-3%
- Stop-loss serré à 0.5-0.8%
"""
import krakenex
import time
import logging
from datetime import datetime, timedelta
import sys

# Configuration du logging vers la console et un fichier
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("zerebro_trades.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Connexion Kraken
k = krakenex.API(
    key="b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8",
    secret="+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="
)

def check_balance():
    """Vérifier notre solde ZEREBRO"""
    try:
        balance = k.query_private('Balance')
        if 'error' in balance and balance['error']:
            logger.error(f"Erreur balance: {balance['error']}")
            return 0
        
        zerebro_balance = float(balance['result'].get('ZEREBRO', 0))
        usd_balance = float(balance['result'].get('ZUSD', 0))
        
        logger.info(f"Solde actuel: {zerebro_balance:.2f} ZEREBRO, {usd_balance:.2f} USD")
        return zerebro_balance
    except Exception as e:
        logger.error(f"Erreur lors de la vérification du solde: {e}")
        return 0

def get_current_price():
    """Obtenir le prix actuel de ZEREBRO"""
    try:
        ticker = k.query_public('Ticker', {'pair': 'ZEREBROUSD'})
        if 'error' in ticker and ticker['error']:
            logger.error(f"Erreur ticker: {ticker['error']}")
            return None
        
        price = float(ticker['result']['ZEREBROUSD']['c'][0])
        return price
    except Exception as e:
        logger.error(f"Erreur lors de la récupération du prix: {e}")
        return None

def sell_zerebro(amount, reason="profit"):
    """Vendre ZEREBRO"""
    try:
        logger.info(f"VENTE de {amount:.2f} ZEREBRO - Raison: {reason}")
        order = k.query_private('AddOrder', {
            'pair': 'ZEREBROUSD',
            'type': 'sell',
            'ordertype': 'market',
            'volume': str(amount)
        })
        
        if 'error' in order and order['error']:
            logger.error(f"Erreur lors de la vente: {order['error']}")
            return False
        
        tx_id = order['result']['txid'][0]
        logger.info(f"✅ Vente réussie! ID Transaction: {tx_id}")
        return True
    except Exception as e:
        logger.error(f"Erreur lors de la vente: {e}")
        return False

def monitor_zerebro():
    """Surveiller le prix de ZEREBRO et vendre quand profitable"""
    # Vérifier notre solde
    zerebro_balance = check_balance()
    if zerebro_balance < 1:
        logger.warning("Solde ZEREBRO insuffisant pour trader")
        return
    
    # Obtenir le prix d'entrée
    entry_price = get_current_price()
    if not entry_price:
        logger.error("Impossible d'obtenir le prix d'entrée")
        return
    
    logger.info(f"Prix d'entrée: {entry_price:.6f} USD")
    
    # Définir les objectifs
    target_profit_rate = 0.025  # 2.5%
    stop_loss_rate = 0.006      # 0.6%
    
    target_price = entry_price * (1 + target_profit_rate)
    stop_loss_price = entry_price * (1 - stop_loss_rate)
    
    logger.info(f"OBJECTIF: {target_price:.6f} USD (+{target_profit_rate*100:.1f}%)")
    logger.info(f"STOP LOSS: {stop_loss_price:.6f} USD (-{stop_loss_rate*100:.1f}%)")
    
    # Surveiller le prix
    check_interval = 30  # secondes
    last_price = entry_price
    start_time = datetime.now()
    
    try:
        while True:
            current_price = get_current_price()
            if not current_price:
                time.sleep(check_interval)
                continue
            
            # Calculer le profit actuel
            profit_pct = (current_price / entry_price - 1) * 100
            time_elapsed = (datetime.now() - start_time).total_seconds() / 60  # minutes
            
            # Afficher status toutes les minutes
            if last_price != current_price:
                logger.info(f"Prix actuel: {current_price:.6f} USD (P&L: {profit_pct:+.2f}%, Durée: {time_elapsed:.1f}min)")
                last_price = current_price
            
            # Vérifier si objectif atteint
            if current_price >= target_price:
                logger.info(f"🎯 OBJECTIF DE PROFIT ATTEINT! (+{profit_pct:.2f}%)")
                if sell_zerebro(zerebro_balance, reason="profit target"):
                    logger.info(f"💰 Profit réalisé après {time_elapsed:.1f} minutes: +{profit_pct:.2f}%")
                    return
            
            # Vérifier si stop loss atteint
            if current_price <= stop_loss_price:
                logger.info(f"⚠️ STOP LOSS ATTEINT! ({profit_pct:.2f}%)")
                if sell_zerebro(zerebro_balance, reason="stop loss"):
                    logger.info(f"🛑 Stop loss exécuté après {time_elapsed:.1f} minutes: {profit_pct:.2f}%")
                    return
            
            time.sleep(check_interval)
    
    except KeyboardInterrupt:
        logger.info("Surveillance arrêtée par l'utilisateur")
    except Exception as e:
        logger.error(f"Erreur lors de la surveillance: {e}")

if __name__ == "__main__":
    logger.info("=" * 50)
    logger.info("DÉMARRAGE DU TRADER ZEREBRO SIMPLE")
    logger.info("=" * 50)
    
    # Vérifier que nous avons du ZEREBRO
    balance = check_balance()
    if balance < 1:
        logger.error("Pas assez de ZEREBRO pour trader")
        sys.exit(1)
    
    # Obtenir le prix actuel
    current_price = get_current_price()
    if current_price:
        logger.info(f"Prix actuel ZEREBRO: {current_price:.6f} USD")
        logger.info(f"Valeur du portefeuille ZEREBRO: {balance * current_price:.2f} USD")
    
    # Démarrer la surveillance
    logger.info("Démarrage de la surveillance du prix ZEREBRO")
    monitor_zerebro()