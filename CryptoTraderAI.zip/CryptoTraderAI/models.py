from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class APIKey(db.Model):
    """Stocke les clés API de manière sécurisée"""
    id = db.Column(db.Integer, primary_key=True)
    api_key = db.Column(db.String(255), nullable=False)
    api_secret = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime)

class Trade(db.Model):
    """Historique des trades exécutés (réels ou simulés)"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    asset = db.Column(db.String(50), nullable=False)
    action = db.Column(db.String(20), nullable=False)  # buy, sell, stop-loss
    amount = db.Column(db.Float, nullable=False)
    price = db.Column(db.Float, nullable=False)
    sentiment = db.Column(db.Float)
    volatility = db.Column(db.Float)
    bubble_score = db.Column(db.Float)

class AssetData(db.Model):
    """Données analysées par actif à un instant t"""
    id = db.Column(db.Integer, primary_key=True)
    asset = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    volatility = db.Column(db.Float)
    sentiment = db.Column(db.Float)
    bubble_score = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
class BotState(db.Model):
    """État et configuration du bot de trading"""
    id = db.Column(db.Integer, primary_key=True)
    running = db.Column(db.Boolean, default=False)
    started_at = db.Column(db.DateTime)
    stopped_at = db.Column(db.DateTime)
    config = db.Column(db.JSON)  # Paramètres de configuration