import krakenex
import time
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

def buy_volatile_crypto(crypto_to_buy="MANA", source_currency="ZUSD"):
    """Achète une crypto volatile avec le solde USD disponible"""
    logger.info(f"=== ACHAT DE {crypto_to_buy} AVEC {source_currency} ===")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Récupérer les balances
        balances = k.query_private('Balance')
        
        if 'error' in balances and balances['error']:
            logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
            return False
        
        # Vérifier le solde source
        source_balance = float(balances['result'].get(source_currency, 0))
        
        if source_balance < 5:
            logger.error(f"Solde {source_currency} insuffisant: {source_balance}")
            return False
        
        logger.info(f"Solde {source_currency} disponible: {source_balance}")
        
        # Construire la paire de trading
        if source_currency == "ZUSD":
            pair = f"{crypto_to_buy}USD"
        else:
            pair = f"{crypto_to_buy}{source_currency}"
        
        # Obtenir le prix actuel
        try:
            ticker = k.query_public('Ticker', {'pair': pair})
            
            if 'error' in ticker and ticker['error']:
                logger.error(f"Erreur lors de la récupération du prix: {ticker['error']}")
                return False
            
            current_price = float(ticker['result'][pair]['c'][0])
            logger.info(f"Prix actuel de {crypto_to_buy}: {current_price} {source_currency}")
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix: {e}")
            return False
        
        # Calculer la quantité à acheter (95% du solde disponible pour tenir compte des frais)
        amount_to_spend = source_balance * 0.95
        amount_to_buy = amount_to_spend / current_price
        
        # Arrondir à la précision adéquate pour éviter les erreurs de volume
        amount_to_buy = round(amount_to_buy, 6)
        
        logger.info(f"Achat de {amount_to_buy} {crypto_to_buy} pour environ {amount_to_spend} {source_currency}")
        
        # Placer l'ordre d'achat (market)
        try:
            buy_order = k.query_private('AddOrder', {
                'pair': pair,
                'type': 'buy',
                'ordertype': 'market',
                'volume': str(amount_to_buy)
            })
            
            if 'error' in buy_order and buy_order['error']:
                # Si l'erreur est liée au volume minimal, essayer avec un coût fixe
                if 'EOrder:Invalid order' in str(buy_order['error']) or 'EOrder:Low order volume' in str(buy_order['error']):
                    logger.info(f"Tentative d'achat avec un coût fixe...")
                    
                    buy_order = k.query_private('AddOrder', {
                        'pair': pair,
                        'type': 'buy',
                        'ordertype': 'market',
                        'cost': str(amount_to_spend)
                    })
                
                if 'error' in buy_order and buy_order['error']:
                    logger.error(f"Erreur lors de l'achat: {buy_order['error']}")
                    return False
            
            # Récupérer l'ID de l'ordre
            order_txid = buy_order['result']['txid'][0]
            logger.info(f"✅ Ordre d'achat placé avec succès: ID {order_txid}")
            
            # Attendre la confirmation de l'exécution
            logger.info("Attente de la confirmation de l'exécution...")
            time.sleep(5)
            
            # Vérifier l'état de l'ordre
            order_status = k.query_private('QueryOrders', {'txid': order_txid})
            
            if 'error' in order_status and order_status['error']:
                logger.error(f"Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
            else:
                logger.info(f"État de l'ordre: {order_status['result'][order_txid]['status']}")
                
            # Récupérer les nouvelles balances
            new_balances = k.query_private('Balance')
            if 'error' not in new_balances and not new_balances['error']:
                new_crypto_balance = float(new_balances['result'].get(crypto_to_buy, 0))
                logger.info(f"Nouveau solde {crypto_to_buy}: {new_crypto_balance}")
            
            # Enregistrer les détails de la transaction dans un fichier
            with open('mana_trades.log', 'a') as f:
                f.write(f"[{datetime.now().isoformat()}] ACHAT: {amount_to_buy} {crypto_to_buy} à {current_price} {source_currency}\n")
                f.write(f"[{datetime.now().isoformat()}] MONTANT: {amount_to_spend} {source_currency}\n")
                f.write(f"[{datetime.now().isoformat()}] ID ORDRE: {order_txid}\n")
                f.write("-" * 50 + "\n")
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de l'achat: {e}")
            return False
    
    except Exception as e:
        logger.error(f"Erreur générale: {e}")
        return False

if __name__ == "__main__":
    print("\n🚀 ACHAT IMMÉDIAT DE MANA AVEC USD\n")
    
    if buy_volatile_crypto("MANA", "ZUSD"):
        print("\n✅ ACHAT DE MANA RÉUSSI!")
    else:
        print("\n❌ ÉCHEC DE L'ACHAT DE MANA")