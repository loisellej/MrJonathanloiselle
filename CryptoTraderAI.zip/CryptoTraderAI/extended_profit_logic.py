#!/usr/bin/env python3
"""
Module d'extension des profits pour opportunités exceptionnelles
Permet au trader de maintenir une position au-delà de l'objectif standard de 3%
quand l'actif montre un momentum exceptionnel et des signaux de continuation
"""
import logging
import numpy as np
import time
from datetime import datetime, timedelta

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("extended_profits.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("ExtendedProfits")

class ExtendedProfitAnalyzer:
    """
    Analyseur de prolongation des profits pour opportunités exceptionnelles
    Évalue si une crypto montre des signes de continuation haussière
    au-delà des objectifs standard de profit
    """
    
    def __init__(self, exchange_connector, advanced_features):
        """
        Initialise l'analyseur avec la connexion à l'exchange
        
        Args:
            exchange_connector: Connecteur à l'exchange (Kraken)
            advanced_features: Module de fonctionnalités avancées
        """
        self.exchange = exchange_connector
        self.advanced = advanced_features
        
        # Seuils de détection d'opportunité exceptionnelle
        self.exceptional_momentum_threshold = 0.6  # Momentum très fort
        self.volume_increase_threshold = 1.5  # Augmentation de volume x1.5
        self.trend_strength_threshold = 0.7  # Force de tendance
        
        # Historique de prédictions pour validation
        self.prediction_history = {}
        
        logger.info("Module d'extension des profits initialisé")
    
    def should_extend_profit_target(self, symbol, current_profit_pct, holding_time_minutes):
        """
        Détermine si un actif doit continuer à être détenu au-delà de l'objectif standard
        
        Args:
            symbol (str): Symbole de la paire (ex: "ZEREBRO/USD")
            current_profit_pct (float): Profit actuel en pourcentage
            holding_time_minutes (int): Temps de détention en minutes
            
        Returns:
            tuple: (extend_decision, max_extension_pct, confidence)
        """
        try:
            # Par défaut, ne pas étendre
            extend_decision = False
            max_extension_pct = 0
            confidence = 0
            
            # Si profit inférieur à 3%, pas besoin d'analyser pour extension
            if current_profit_pct < 3.0:
                return (False, 0, 0)
            
            # Obtenir les métriques actuelles
            momentum = self._calculate_extended_momentum(symbol)
            volume_trend = self._analyze_volume_trend(symbol)
            buy_pressure = self._calculate_buy_pressure(symbol)
            continuation_signals = self._detect_continuation_pattern(symbol)
            
            # Vérifier si la paire surperforme le marché
            market_outperform = self._is_outperforming_market(symbol)
            
            # Facteurs pour la décision
            factors = [
                momentum > self.exceptional_momentum_threshold,  # Momentum exceptionnel
                volume_trend > self.volume_increase_threshold,  # Volume en hausse
                buy_pressure > 0.6,  # Forte pression d'achat
                len(continuation_signals) >= 2,  # Au moins 2 signaux de continuation
                market_outperform  # Surperforme le marché
            ]
            
            # Nombre de facteurs positifs
            positive_factors = sum(factors)
            
            # Calcul de la confiance
            confidence = positive_factors / len(factors)
            
            # Décision d'extension basée sur la confiance
            if confidence >= 0.6:  # Au moins 3/5 facteurs positifs
                extend_decision = True
                
                # Calculer l'extension de profit maximale en fonction de la confiance
                # et des paramètres de marché
                base_extension = 3.0  # Base de 3% supplémentaires
                confidence_boost = confidence * 3.0  # Jusqu'à 3% de plus selon la confiance
                momentum_boost = momentum * 4.0  # Jusqu'à 4% de plus selon le momentum
                
                max_extension_pct = min(base_extension + confidence_boost + momentum_boost, 10.0)
                
                # Logger la décision
                logger.info(f"OPPORTUNITÉ EXCEPTIONNELLE: {symbol} - Extension de profit au-delà de 3%")
                logger.info(f"Facteurs: Momentum={momentum:.2f}, Volume={volume_trend:.2f}, "
                          f"Pression d'achat={buy_pressure:.2f}, Signaux={len(continuation_signals)}")
                logger.info(f"Décision: Étendre jusqu'à {current_profit_pct + max_extension_pct:.2f}% "
                          f"(+{max_extension_pct:.2f}% supplémentaires), Confiance: {confidence:.2f}")
                
                # Enregistrer cette prédiction pour validation future
                self._record_prediction(symbol, current_profit_pct, max_extension_pct)
            
            return (extend_decision, max_extension_pct, confidence)
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse d'extension de profit pour {symbol}: {e}")
            return (False, 0, 0)
    
    def _calculate_extended_momentum(self, symbol):
        """
        Calcule un score de momentum étendu en utilisant plusieurs timeframes
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            float: Score de momentum entre 0 et 1
        """
        try:
            # Récupérer les données pour plusieurs timeframes
            ohlcv_1h = self.exchange.get_ohlcv(symbol, timeframe='1h', limit=24)
            ohlcv_15m = self.exchange.get_ohlcv(symbol, timeframe='15m', limit=20)
            ohlcv_5m = self.exchange.get_ohlcv(symbol, timeframe='5m', limit=12)
            
            if not all([ohlcv_1h, ohlcv_15m, ohlcv_5m]):
                return 0
            
            # Extraire les prix de clôture
            closes_1h = np.array([candle[4] for candle in ohlcv_1h])
            closes_15m = np.array([candle[4] for candle in ohlcv_15m])
            closes_5m = np.array([candle[4] for candle in ohlcv_5m])
            
            # Calculer les rendements
            returns_1h = (closes_1h[-1] / closes_1h[0]) - 1
            returns_15m = (closes_15m[-1] / closes_15m[0]) - 1
            returns_5m = (closes_5m[-1] / closes_5m[0]) - 1
            
            # Calculer l'accélération (dérivée seconde des prix)
            # Pour 5m: comparer les 6 dernières périodes aux 6 précédentes
            first_half_5m = closes_5m[0:6]
            second_half_5m = closes_5m[6:12]
            accel_5m = (np.mean(second_half_5m) / np.mean(first_half_5m)) - 1
            
            # Pondérer les différentes mesures
            momentum_score = (
                returns_1h * 0.2 +     # Tendance horaire (20%)
                returns_15m * 0.3 +    # Tendance 15min (30%)
                returns_5m * 0.3 +     # Tendance 5min (30%)
                accel_5m * 0.2         # Accélération récente (20%)
            )
            
            # Normaliser entre 0 et 1
            normalized_score = min(max(momentum_score * 5, 0), 1)
            
            return normalized_score
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul du momentum étendu pour {symbol}: {e}")
            return 0
    
    def _analyze_volume_trend(self, symbol):
        """
        Analyse la tendance du volume de trading récent
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            float: Ratio d'augmentation de volume (>1 = en hausse)
        """
        try:
            # Récupérer les données OHLCV récentes
            ohlcv = self.exchange.get_ohlcv(symbol, timeframe='5m', limit=24)
            if not ohlcv or len(ohlcv) < 24:
                return 1.0
            
            # Extraire les volumes
            volumes = np.array([candle[5] for candle in ohlcv])
            
            # Comparer le volume récent (12 dernières périodes) au volume précédent
            recent_volume = np.mean(volumes[-12:])
            previous_volume = np.mean(volumes[:-12])
            
            # Calculer le ratio d'augmentation
            if previous_volume > 0:
                volume_ratio = recent_volume / previous_volume
            else:
                volume_ratio = 1.0
            
            return volume_ratio
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse du volume pour {symbol}: {e}")
            return 1.0
    
    def _calculate_buy_pressure(self, symbol):
        """
        Calcule la pression d'achat basée sur le ratio de volume buy/sell
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            float: Score de pression d'achat entre 0 et 1
        """
        try:
            # Récupérer les trades récents
            trades = self.exchange.get_recent_trades(symbol, limit=100)
            if not trades:
                return 0.5  # Neutre par défaut
            
            # Séparer les trades d'achat et de vente
            buy_volume = sum(trade['amount'] for trade in trades if trade['side'] == 'buy')
            sell_volume = sum(trade['amount'] for trade in trades if trade['side'] == 'sell')
            
            # Calculer le ratio buy/sell
            total_volume = buy_volume + sell_volume
            if total_volume > 0:
                buy_ratio = buy_volume / total_volume
            else:
                buy_ratio = 0.5
            
            return buy_ratio
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul de la pression d'achat pour {symbol}: {e}")
            return 0.5
    
    def _detect_continuation_pattern(self, symbol):
        """
        Détecte les patterns de continuation haussière
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            list: Liste des patterns détectés
        """
        try:
            patterns = []
            
            # Récupérer les données
            ohlcv = self.exchange.get_ohlcv(symbol, timeframe='15m', limit=30)
            if not ohlcv or len(ohlcv) < 30:
                return patterns
            
            # Extraire OHLC
            opens = np.array([candle[1] for candle in ohlcv])
            highs = np.array([candle[2] for candle in ohlcv])
            lows = np.array([candle[3] for candle in ohlcv])
            closes = np.array([candle[4] for candle in ohlcv])
            
            # 1. Vérifier les bougies haussières consécutives
            consecutive_bullish = 0
            for i in range(-1, -6, -1):
                if closes[i] > opens[i]:
                    consecutive_bullish += 1
                else:
                    break
            
            if consecutive_bullish >= 3:
                patterns.append('consecutive_bullish')
            
            # 2. Vérifier le pattern de drapeau haussier
            # (tendance haussière suivie d'une consolidation)
            trend_section = closes[-10:-5]
            consolidation_section = closes[-5:]
            
            trend_increase = (trend_section[-1] / trend_section[0]) - 1
            consolidation_range = (max(consolidation_section) - min(consolidation_section)) / min(consolidation_section)
            
            if trend_increase > 0.03 and consolidation_range < 0.02:
                patterns.append('bull_flag')
            
            # 3. Vérifier le support sur EMA
            ema20 = self._calculate_ema(closes, 20)
            if ema20 and min(lows[-3:]) > ema20 * 0.995:
                patterns.append('ema_support')
            
            # 4. Vérifier le volume décroissant dans la consolidation
            recent_volumes = np.array([candle[5] for candle in ohlcv[-5:]])
            if np.all(np.diff(recent_volumes) < 0):
                patterns.append('decreasing_volume_consolidation')
            
            # 5. Vérifier le non-franchissement de haut précédent
            local_high = max(highs[-20:-5])
            if all(h < local_high * 1.01 for h in highs[-5:]):
                patterns.append('respecting_resistance')
            
            return patterns
        
        except Exception as e:
            logger.error(f"Erreur lors de la détection de patterns pour {symbol}: {e}")
            return []
    
    def _is_outperforming_market(self, symbol):
        """
        Vérifie si une paire surperforme le marché général
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            bool: True si la paire surperforme
        """
        try:
            # Utiliser BTC comme proxy pour le marché global
            market_symbol = "BTC/USD"
            
            # Récupérer les performances
            symbol_ohlcv = self.exchange.get_ohlcv(symbol, timeframe='1h', limit=6)
            market_ohlcv = self.exchange.get_ohlcv(market_symbol, timeframe='1h', limit=6)
            
            if not symbol_ohlcv or not market_ohlcv:
                return False
            
            # Calculer les performances
            symbol_perf = (symbol_ohlcv[-1][4] / symbol_ohlcv[0][4]) - 1
            market_perf = (market_ohlcv[-1][4] / market_ohlcv[0][4]) - 1
            
            # Surperforme si fait mieux que le marché + 1%
            return symbol_perf > (market_perf + 0.01)
        
        except Exception as e:
            logger.error(f"Erreur lors de la comparaison de marché pour {symbol}: {e}")
            return False
    
    def _calculate_ema(self, prices, period):
        """Calcule l'EMA pour une série de prix"""
        if len(prices) < period:
            return None
            
        # Calculer le multiplicateur
        multiplier = 2 / (period + 1)
        
        # Initialiser l'EMA avec la moyenne des premières valeurs
        ema = prices[:period].mean()
        
        # Calculer l'EMA pour chaque prix restant
        for price in prices[period:]:
            ema = (price - ema) * multiplier + ema
            
        return ema
    
    def _record_prediction(self, symbol, current_profit, extension):
        """
        Enregistre une prédiction pour validation future
        
        Args:
            symbol (str): Symbole de la paire
            current_profit (float): Profit actuel en %
            extension (float): Extension prévue en %
        """
        timestamp = datetime.now()
        
        if symbol not in self.prediction_history:
            self.prediction_history[symbol] = []
        
        self.prediction_history[symbol].append({
            'timestamp': timestamp,
            'current_profit': current_profit,
            'predicted_extension': extension,
            'actual_extension': None,  # Sera mis à jour plus tard
            'max_price': None,         # Sera mis à jour plus tard
            'validated': False         # Sera mis à jour plus tard
        })
        
        # Nettoyage des anciennes prédictions (plus de 7 jours)
        cutoff = datetime.now() - timedelta(days=7)
        self.prediction_history[symbol] = [
            p for p in self.prediction_history[symbol] 
            if p['timestamp'] > cutoff
        ]
    
    def get_dynamic_trailing_stop(self, symbol, current_price, entry_price, current_profit_pct):
        """
        Calcule un trailing stop dynamique adapté à l'extension de profit
        
        Args:
            symbol (str): Symbole de la paire
            current_price (float): Prix actuel
            entry_price (float): Prix d'entrée
            current_profit_pct (float): Profit actuel en %
            
        Returns:
            float: Prix du trailing stop
        """
        try:
            # Pour les profits standards (<3%), utiliser le trailing stop normal
            if current_profit_pct < 3.0:
                # Trailing standard (1.5%)
                return self.advanced.trailing_stop_loss(
                    symbol, entry_price, current_price, trailing_pct=1.5
                )[0]
            
            # Pour les profits étendus, adapter le trailing
            # 1. Plus le profit est grand, plus le trailing est large
            # 2. Jamais en dessous du profit minimum garanti (2%)
            base_profit_guarantee = 2.0  # Garantir au moins 2% de profit
            
            # Calculer le % de trailing basé sur le profit actuel
            # Formule: Plus le profit est grand, plus le % est grand (1.5% à 3%, 3% à 6%)
            trailing_pct = 1.5 + (current_profit_pct - 3.0) * 0.5
            trailing_pct = min(trailing_pct, 5.0)  # Max 5%
            
            # Calculer la distance en unités de prix
            trailing_distance = current_price * (trailing_pct / 100)
            
            # Le stop-loss ne doit jamais être en dessous du seuil de profit garanti
            min_stop_price = entry_price * (1 + base_profit_guarantee / 100)
            
            # Prix du stop-loss
            stop_price = current_price - trailing_distance
            
            # Garantir le profit minimum
            return max(stop_price, min_stop_price)
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul du trailing stop dynamique pour {symbol}: {e}")
            return entry_price  # En cas d'erreur, revenir au prix d'entrée

def integrate_extended_profit_logic(trader, symbol, entry_price, current_price, position_size, holding_time):
    """
    Fonction d'intégration à utiliser dans le trader principal
    
    Args:
        trader: Instance du trader
        symbol (str): Symbole de la paire
        entry_price (float): Prix d'entrée
        current_price (float): Prix actuel
        position_size (float): Taille de la position
        holding_time (int): Temps de détention en minutes
        
    Returns:
        tuple: (sell_decision, new_stop_loss, extended_target)
    """
    # Calcul du profit actuel
    current_profit_pct = ((current_price / entry_price) - 1) * 100
    
    # Créer l'analyseur s'il n'existe pas
    if not hasattr(trader, 'extended_profit_analyzer'):
        trader.extended_profit_analyzer = ExtendedProfitAnalyzer(
            trader.exchange, trader.advanced_features
        )
    
    # Décision d'extension
    extend, max_extension, confidence = trader.extended_profit_analyzer.should_extend_profit_target(
        symbol, current_profit_pct, holding_time
    )
    
    # Déterminer le nouvel objectif de profit si extension
    standard_target = 3.0  # Objectif standard en %
    extended_target = standard_target + max_extension if extend else standard_target
    
    # Ne pas vendre si on étend l'objectif
    sell_decision = current_profit_pct >= extended_target
    
    # Nouveau stop-loss adapté
    new_stop_loss = trader.extended_profit_analyzer.get_dynamic_trailing_stop(
        symbol, current_price, entry_price, current_profit_pct
    )
    
    if extend:
        logger.info(f"EXTENSION DE PROFIT pour {symbol}: "
                   f"Objectif étendu à {extended_target:.2f}% (vs 3% standard), "
                   f"Profit actuel: {current_profit_pct:.2f}%, "
                   f"Nouveau stop: {new_stop_loss:.6f}, "
                   f"Confiance: {confidence:.2f}")
    
    return sell_decision, new_stop_loss, extended_target