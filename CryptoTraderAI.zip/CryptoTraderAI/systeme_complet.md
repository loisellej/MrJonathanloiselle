# SYSTÈME DE TRADING CRYPTO COMPLET - "BÉTON ARMÉ"

## Architecture Optimisée - Version du 22 Avril 2025

Ce document décrit l'architecture complète du système de trading ultra-stable avec les dernières optimisations et améliorations.

## Composants du système

### 1. Système principal (init_optimized_system.py)
- Point d'entrée centralisé pour tout le système
- Gestion complète des processus et ressources
- Intégration des composants optimisés
- Watchdog intégré avec redémarrage automatique

### 2. Trader optimisé (auto_trader_verified.py)
- Exécute des ordres en direct sur Kraken avec vérification
- Utilise le système de scoring avancé pour les opportunités
- Analyse de volatilité et tendance en temps réel
- Gestion de position dynamique et trailing stop-loss
- Formule de score optimisée:
  ```python
  # Score combiné avec priorité à la volatilité
  trend_factor = 1.5 if trend > 0 else -1
  combined_score = (volatility * 2.5) + (abs(trend) * trend_factor * 0.5)
  ```

### 3. API client optimisé (optimized_api_client.py)
- Cache multi-niveaux (mémoire, disque, fichier)
- Retry avec jitter et backoff exponentiel
- Balancer de charge et limitation de débit
- Gestionnaire de nonce sécurisé pour Kraken
- Détection automatique des paires disponibles sur Kraken

### 4. Gestionnaire de ressources (optimized_resource_manager.py)
- Surveillance continue des ressources CPU/RAM
- Adaptation dynamique de la consommation
- Rotation des logs et nettoyage automatique
- Compression de données pour réduire l'empreinte

### 5. Gestionnaire de file d'attente (optimized_queue_manager.py)
- File d'attente prioritaire pour les tâches critiques
- Exécution parallèle mais contrôlée des requêtes
- Ordonnancement intelligent des opérations
- Robustesse face aux erreurs avec reprise automatique

### 6. Watchdog système (trading_guardian.py)
- Surveillance permanente des processus
- Détection des freezes et hangups
- Redémarrage intelligent en cas de problème
- Protection contre les crashs de Replit
- Système de heartbeat pour détecter les processus zombies

## Optimisations clés

### 1. Performance et stabilité
```python
def optimize_memory_usage():
    """Optimise l'utilisation de la mémoire"""
    gc.collect()  # Forcer le garbage collector
    
    # Limiter la taille du cache
    if len(price_cache) > MAX_CACHE_SIZE:
        # Supprimer les entrées les plus anciennes
        for key in sorted(price_cache, key=lambda k: price_cache[k]['time'])[:100]:
            del price_cache[key]
```

### 2. Gestion des erreurs API
```python
def api_request_with_retry(method, params=None, max_retries=3):
    """Exécute une requête API avec retry et backoff exponentiel"""
    for attempt in range(1, max_retries + 1):
        try:
            # Ajouter jitter pour éviter les tempêtes de requêtes
            jitter = random.uniform(0.1, 0.5)
            time.sleep((2 ** (attempt - 1)) + jitter)
            
            start_time = time.time()
            response = k.query_public(method, params)
            api_time = time.time() - start_time
            
            if 'error' in response and response['error']:
                logger.warning(f"Erreur API publique ({attempt}/{max_retries}): {response['error'][0]}")
                continue
            
            # Enregistrer les métriques de performance
            record_metric('api_response_time', api_time)
            return response
            
        except Exception as e:
            logger.error(f"Exception API ({attempt}/{max_retries}): {e}")
    
    return {'error': ['Max retries exceeded']}
```

### 3. Analyse optimisée des opportunités
```python
def find_best_opportunities():
    """Identifie les meilleures opportunités de trading avec priorité"""
    opportunities = []
    
    # Analyser d'abord les actifs à haute priorité
    high_priority_assets = select_high_priority_assets()
    for asset in high_priority_assets:
        # Analyser avec threads prioritaires
        add_priority_task(5, f"analyze_{asset}", analyze_symbol, asset)
    
    # Attendre les résultats (max 3 secondes)
    time.sleep(3)
    
    # Collecter et trier les résultats
    opportunities = sorted(results, key=lambda x: x['score'], reverse=True)
    return opportunities
```

## Stratégie de trading optimisée

### 1. Calcul de score avec priorité à la volatilité
```python
def get_trading_score(symbol):
    """Calcule un score de trading optimisé"""
    volatility = analyze_volatility(symbol)
    trend = analyze_trend(symbol)
    
    # Formule optimisée donnant plus de poids à la volatilité
    trend_factor = 1.5 if trend > 0 else -1
    combined_score = (volatility * 2.5) + (abs(trend) * trend_factor * 0.5)
    
    return combined_score
```

### 2. Sélection de paires améliorée
```python
def select_optimal_pairs(market_conditions='normal', max_pairs=5):
    """Sélectionne les meilleures paires à trader en fonction des conditions du marché"""
    # Création d'un score pour chaque paire basé sur volatilité, volume, liquidité
    # Priorise différents facteurs selon les conditions de marché
    
    if market_conditions == 'volatile':
        # Prioriser la liquidité et les volumes
        final_score = (
            volatility * 0.2 +
            volume * 0.4 +
            liquidity * 0.4  # Liquidité critique en marché volatile
        )
    elif market_conditions == 'bull':
        # Prioriser les actifs avec tendance positive forte
        final_score = (
            volatility * 0.3 +
            volume * 0.2 +
            liquidity * 0.2 +
            trend_score * 0.3  # Plus de poids à la tendance
        )
    else:  # 'normal' ou autre
        # Équilibre avec priorité à la volatilité
        final_score = (
            volatility * 0.5 +  # Double du poids normal
            volume * 0.2 +
            liquidity * 0.2 +
            trend_score * 0.1
        )
    
    # Trier et retourner les meilleures paires
    return top_scoring_pairs[:max_pairs]
```

### 3. Stop-loss dynamique et trailing
```python
def dynamic_stop_loss(entry_price, current_price, asset=None):
    """Calcule un stop-loss dynamique adapté au momentum et à la volatilité"""
    # Récupérer la volatilité récente
    volatility = get_asset_volatility(asset)
    
    # Base stop-loss serré (0.5-0.8%)
    base_stop_pct = random.uniform(0.5, 0.8)
    
    # Ajuster selon la volatilité (plus volatile = stop plus large)
    adjusted_stop_pct = base_stop_pct * (1 + (volatility / 5))
    
    # Si en profit, utiliser trailing stop
    if current_price > entry_price:
        profit_pct = (current_price / entry_price - 1) * 100
        trailing_pct = max(adjusted_stop_pct, profit_pct * 0.5)
        
        # Stop-loss ne peut jamais descendre
        stop_price = current_price * (1 - trailing_pct / 100)
    else:
        # Stop-loss standard
        stop_price = entry_price * (1 - adjusted_stop_pct / 100)
    
    return stop_price
```

## Intégration des optimisations

### 1. Moniteur de performances (performance_monitor.py)
```python
def monitor_and_optimize():
    """Surveille et optimise les performances en continu"""
    while True:
        # Mesurer les ressources actuelles
        cpu_usage = psutil.cpu_percent()
        ram_usage = psutil.virtual_memory().percent
        
        # Ajuster dynamiquement les paramètres
        if cpu_usage > 80 or ram_usage > 85:
            # Mode économie de ressources
            set_cache_ttl(300)  # Cache plus long
            set_polling_interval(120)  # Polling moins fréquent
            set_worker_threads(1)  # Moins de threads
        elif cpu_usage > 50 or ram_usage > 70:
            # Mode équilibré
            set_cache_ttl(180)
            set_polling_interval(60)
            set_worker_threads(2)
        else:
            # Mode performance
            set_cache_ttl(60)  # Cache court
            set_polling_interval(30)  # Polling fréquent
            set_worker_threads(4)  # Plus de threads
        
        # Enregistrer les métriques
        record_metrics('cpu', cpu_usage)
        record_metrics('ram', ram_usage)
        
        time.sleep(60)
```

### 2. Gestion file d'attente (optimized_queue_manager.py)
```python
class PriorityTaskQueue:
    """File d'attente prioritaire pour les tâches de trading"""
    def __init__(self):
        self.queues = {
            1: queue.Queue(),  # Basse priorité
            3: queue.Queue(),  # Priorité moyenne
            5: queue.Queue(),  # Haute priorité
            10: queue.Queue()  # Priorité critique
        }
        self.workers = []
        self.results = {}
        self.lock = threading.Lock()
        
    def add_task(self, priority, task_id, func, *args, **kwargs):
        """Ajoute une tâche à la file d'attente avec priorité"""
        with self.lock:
            self.queues[priority].put((task_id, func, args, kwargs))
    
    def get_result(self, task_id, timeout=None):
        """Récupère le résultat d'une tâche"""
        start_time = time.time()
        while timeout is None or time.time() - start_time < timeout:
            with self.lock:
                if task_id in self.results:
                    return self.results.pop(task_id)
            time.sleep(0.1)
        return None
```

## Sécurité et protection

### 1. Redémarrage automatique
```python
def watchdog_system():
    """Surveille et redémarre le système si nécessaire"""
    while True:
        try:
            # Vérifier les fichiers heartbeat
            for service, pid_file in SERVICES.items():
                if not os.path.exists(f"{service}_heartbeat.txt"):
                    logger.warning(f"Service {service} sans heartbeat, redémarrage")
                    restart_service(service)
                    continue
                    
                # Vérifier l'âge du heartbeat
                heartbeat_age = time.time() - os.path.getmtime(f"{service}_heartbeat.txt")
                if heartbeat_age > MAX_HEARTBEAT_AGE:
                    logger.warning(f"Heartbeat périmé pour {service} ({heartbeat_age:.1f}s)")
                    restart_service(service)
                    
            # Pause entre les vérifications
            time.sleep(15)
            
        except Exception as e:
            logger.error(f"Erreur du watchdog: {e}")
```

### 2. Protection des ressources Replit
```python
def protect_replit_resources():
    """Empêche la surconsommation des ressources Replit"""
    # Vérifier l'utilisation des ressources
    ram_usage = psutil.virtual_memory().percent
    cpu_usage = psutil.cpu_percent(interval=1)
    
    # Si RAM critique, libérer de la mémoire
    if ram_usage > 90:
        logger.warning(f"RAM CRITIQUE: {ram_usage}%, nettoyage d'urgence")
        # Vider les caches
        price_cache.clear()
        gc.collect()
        
    # Si CPU critique, ralentir les opérations
    if cpu_usage > 95:
        logger.warning(f"CPU CRITIQUE: {cpu_usage}%, ralentissement")
        global THROTTLING_ENABLED
        THROTTLING_ENABLED = True
        
        # Suspendre certaines opérations non essentielles
        suspend_background_tasks()
        time.sleep(5)  # Permettre au CPU de récupérer
```

## Futures améliorations planifiées

1. **Intégration multi-exchange**
   - Support simultané pour Kraken, Binance et Coinbase
   - Arbitrage inter-exchange pour opportunités supplémentaires

2. **Machine Learning pour prédiction**
   - Modèle de prédiction à court terme basé sur données historiques
   - Détection de patterns précédant les mouvements significatifs

3. **Analyse de sentiment avancée**
   - Suivi en temps réel des médias sociaux et news crypto
   - Corrélation entre sentiment et mouvements de prix

4. **Dashboard web temps réel**
   - Interface graphique complète pour monitoring
   - Alertes et notifications personnalisables