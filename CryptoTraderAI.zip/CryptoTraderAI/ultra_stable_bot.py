#!/usr/bin/env python3
"""
BOT DE TRADING ULTRA-STABLE 24/7
- Version simplifiée mais ultra-stable
- Boucle principale avec try/except globaux
- Redémarrage automatique en cas de crash
- Utilise toutes les positions pour trader
"""

import os
import time
import logging
import threading
import random
import signal
import sys
import ccxt
from datetime import datetime
import subprocess
from dotenv import load_dotenv

# Charger les variables d'environnement depuis .env
load_dotenv()

# Configuration du logging plus simple et robuste
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("trader_ultra_stable.log"),
        logging.StreamHandler()
    ]
)

# Variables globales
running = True
api_key = os.environ.get("KRAKEN_API_KEY")
api_secret = os.environ.get("KRAKEN_API_SECRET")
logging.info(f"Clés API: {api_key[:5]}...{api_key[-5:] if api_key else 'MANQUANTE'}")

def clean_logs():
    """Nettoie les logs trop volumineux"""
    try:
        log_files = ["trader_ultra_stable.log", "trader_24_7.log"]
        for log_file in log_files:
            if os.path.exists(log_file) and os.path.getsize(log_file) > 10 * 1024 * 1024:  # 10 MB
                # Sauvegarde et vide le fichier
                with open(f"{log_file}.bak", "w") as backup:
                    with open(log_file, "r") as original:
                        backup.write(original.read())
                # Vider le fichier
                with open(log_file, "w") as f:
                    f.write(f"Logs nettoyés le {datetime.now()}\n")
                logging.info(f"Fichier de log {log_file} nettoyé (taille > 10 MB)")
    except Exception as e:
        logging.error(f"Erreur lors du nettoyage des logs: {e}")

def update_heartbeat():
    """Met à jour le fichier heartbeat"""
    try:
        with open("trader_heartbeat.txt", "w") as f:
            f.write(f"{datetime.now()}")
    except Exception as e:
        logging.error(f"Erreur lors de la mise à jour du heartbeat: {e}")

def init_exchange():
    """Initialise la connexion à l'exchange Kraken"""
    try:
        exchange = ccxt.kraken({
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True,
            'options': {
                'adjustForTimeDifference': True,
                'recvWindow': 60000
            }
        })
        return exchange
    except Exception as e:
        logging.error(f"Erreur d'initialisation de l'exchange: {e}")
        time.sleep(10)  # Attendre avant de réessayer
        return None

def get_balances(exchange):
    """Récupère les balances depuis l'exchange"""
    try:
        balance_data = exchange.fetch_balance()
        balances = {
            asset: float(data['free']) 
            for asset, data in balance_data['free'].items() 
            if float(data) > 0
        }
        
        logging.info(f"Balances récupérées: {len(balances)} actifs trouvés")
        
        # Calculer et logger les soldes USD
        if 'ZUSD' in balances:
            logging.info(f"Solde USD: {balances['ZUSD']:.4f} USD")
        
        # Identifier les actifs significatifs (avec valeur > 1 USD)
        significant_assets = []
        for asset, balance in balances.items():
            if asset == 'ZUSD' or balance <= 0:
                continue
            
            symbol = f"{asset}/USD"
            try:
                ticker = exchange.fetch_ticker(symbol)
                if ticker and 'last' in ticker:
                    price = float(ticker['last'])
                    usd_value = balance * price
                    if usd_value > 1.0:
                        significant_assets.append((asset, balance, usd_value))
            except:
                pass
        
        # Afficher les actifs significatifs
        if significant_assets:
            assets_str = ", ".join([f"{asset}: {balance:.4f} (~{usd_value:.2f} USD)" 
                                   for asset, balance, usd_value in significant_assets])
            logging.info(f"Actifs significatifs: {assets_str}")
        else:
            logging.info("Aucun actif significatif trouvé")
        
        return balances
    except Exception as e:
        logging.error(f"Erreur lors de la récupération des balances: {e}")
        return {}

def find_volatile_assets(exchange, max_assets=10):
    """Trouve les actifs les plus volatils"""
    try:
        # Récupérer tous les marchés disponibles
        markets = exchange.load_markets()
        
        # Filtrer les marchés USD et exclure BTC, ETH, et Solana
        usd_markets = [
            m for m in markets 
            if '/USD' in m 
            and m.split('/')[0] not in ['BTC', 'ETH', 'SOL', 'XBT']
        ]
        
        # Évaluer la volatilité de quelques marchés aléatoires pour éviter trop de requêtes
        sample_markets = random.sample(usd_markets, min(20, len(usd_markets)))
        
        volatile_markets = []
        for market in sample_markets:
            try:
                asset = market.split('/')[0]
                
                # Récupérer les données OHLCV
                ohlcv = exchange.fetch_ohlcv(market, timeframe='5m', limit=12)
                
                if not ohlcv or len(ohlcv) < 6:
                    continue
                
                # Calculer la volatilité (écart-type des rendements en %)
                prices = [candle[4] for candle in ohlcv]
                returns = [
                    ((prices[i] - prices[i-1]) / prices[i-1]) * 100
                    for i in range(1, len(prices))
                ]
                
                if not returns:
                    continue
                
                # Calculer la volatilité
                volatility = sum([(r - sum(returns)/len(returns))**2 for r in returns])
                volatility = (volatility / len(returns)) ** 0.5
                
                # Calculer le momentum
                momentum = sum(returns[-3:]) / 3 if len(returns) >= 3 else 0
                
                # Score combiné (volatilité + momentum positif)
                combined_score = volatility + max(0, momentum * 2)
                
                # Ajouter à la liste
                volatile_markets.append({
                    'asset': asset,
                    'volatility': volatility,
                    'momentum': momentum,
                    'score': combined_score
                })
            except Exception as e:
                logging.error(f"Erreur d'analyse pour {market}: {e}")
        
        # Trier par score combiné et prendre les meilleurs
        volatile_markets.sort(key=lambda x: x['score'], reverse=True)
        top_volatile = volatile_markets[:max_assets]
        
        # Extraire les symboles des actifs
        results = [m['asset'] for m in top_volatile]
        
        if results:
            logging.info(f"Actifs les plus volatils: {', '.join(results[:3])}")
        
        return results
    except Exception as e:
        logging.error(f"Erreur lors de la recherche d'actifs volatils: {e}")
        return []

def calculate_momentum(exchange, asset):
    """Calcule le momentum pour un actif"""
    try:
        symbol = f"{asset}/USD"
        
        # Récupérer les données OHLCV
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe='15m', limit=12)
        
        if not ohlcv or len(ohlcv) < 6:
            return 0
        
        # Extraire les prix de clôture
        prices = [candle[4] for candle in ohlcv]
        
        # Calculer les rendements
        returns = [((prices[i] - prices[i-1]) / prices[i-1]) for i in range(1, len(prices))]
        
        # Calculer le momentum (moyenne des rendements récents)
        momentum = sum(returns[-3:]) / min(3, len(returns))
        
        return momentum
    except Exception as e:
        logging.error(f"Erreur de calcul du momentum pour {asset}: {e}")
        return 0

def sell_all_to_usd(exchange, asset, percentage=100):
    """Vend un actif contre USD"""
    try:
        if asset == 'ZUSD':
            return None
        
        symbol = f"{asset}/USD"
        
        # Récupérer la balance
        balances = get_balances(exchange)
        if asset not in balances or balances[asset] <= 0:
            logging.warning(f"Pas de balance {asset} à vendre")
            return None
        
        # Calculer le montant à vendre
        amount = balances[asset] * (percentage / 100)
        if amount <= 0:
            return None
        
        # Arrondir à 8 décimales pour éviter les erreurs
        amount = float(f"{amount:.8f}")
        
        # Vendre au marché
        logging.info(f"Vente de {amount} {asset} vers USD")
        order = exchange.create_market_sell_order(symbol, amount)
        
        logging.info(f"Vente réussie de {asset}: {order}")
        return order
    except Exception as e:
        logging.error(f"Erreur lors de la vente de {asset}: {e}")
        return None

def buy_with_usd(exchange, asset, percentage=90):
    """Achète un actif avec USD"""
    try:
        symbol = f"{asset}/USD"
        
        # Récupérer la balance USD
        balances = get_balances(exchange)
        if 'ZUSD' not in balances or balances['ZUSD'] <= 5:
            logging.warning(f"Pas assez d'USD pour acheter {asset}")
            return None
        
        # Calculer le montant USD à utiliser
        usd_amount = balances['ZUSD'] * (percentage / 100)
        
        # Récupérer le prix actuel
        ticker = exchange.fetch_ticker(symbol)
        if not ticker or 'last' not in ticker:
            return None
        
        price = float(ticker['last'])
        
        # Calculer le montant d'actifs à acheter
        amount = usd_amount / price
        
        # Arrondir à 8 décimales pour éviter les erreurs
        amount = float(f"{amount:.8f}")
        
        # Acheter au marché
        logging.info(f"Achat de {amount} {asset} avec USD")
        order = exchange.create_market_buy_order(symbol, amount)
        
        logging.info(f"Achat réussi de {asset}: {order}")
        return order
    except Exception as e:
        logging.error(f"Erreur lors de l'achat de {asset}: {e}")
        return None

def check_crypto_to_crypto_opportunities(exchange, all_balances, volatile_assets):
    """Vérifie les opportunités de conversion entre cryptos"""
    try:
        # Identifier les cryptos significatives dans notre portefeuille
        crypto_assets = {}
        for asset, balance in all_balances.items():
            if asset == 'ZUSD' or balance <= 0:
                continue
            
            symbol = f"{asset}/USD"
            try:
                ticker = exchange.fetch_ticker(symbol)
                if ticker and 'last' in ticker:
                    price = float(ticker['last'])
                    usd_value = balance * price
                    if usd_value > 5.0:  # Considérer seulement les actifs > 5 USD
                        crypto_assets[asset] = {
                            'balance': balance,
                            'usd_value': usd_value,
                            'price': price,
                            'momentum': calculate_momentum(exchange, asset)
                        }
            except Exception as e:
                logging.error(f"Erreur d'évaluation pour {asset}: {e}")
        
        if not crypto_assets:
            logging.info("Aucun actif crypto significatif trouvé")
            return
        
        # Évaluer les opportunités disponibles
        for volatile_asset in volatile_assets:
            if volatile_asset in crypto_assets:
                continue  # On possède déjà cet actif
            
            # Calculer le momentum de cette opportunité
            momentum = calculate_momentum(exchange, volatile_asset)
            
            # Trouver notre pire actif à remplacer
            worst_asset = None
            worst_momentum = 0
            
            for asset, data in crypto_assets.items():
                # Si notre actif a un momentum négatif et l'opportunité est positive
                if data['momentum'] < 0 and momentum > 0.01:
                    if worst_asset is None or data['momentum'] < worst_momentum:
                        worst_asset = asset
                        worst_momentum = data['momentum']
            
            # Si on a trouvé un actif à remplacer
            if worst_asset:
                logging.info(f"Opportunité détectée: {worst_asset} (momentum: {worst_momentum:.4f}) → "
                           f"{volatile_asset} (momentum: {momentum:.4f})")
                
                # Convertir
                sell_result = sell_all_to_usd(exchange, worst_asset)
                if sell_result:
                    # Attendre pour que la vente soit traitée
                    time.sleep(3)
                    # Acheter le nouvel actif
                    buy_result = buy_with_usd(exchange, volatile_asset)
                    if buy_result:
                        logging.info(f"✅ Conversion réussie: {worst_asset} → {volatile_asset}")
                        return  # Une seule conversion à la fois
    except Exception as e:
        logging.error(f"Erreur lors de la vérification des opportunités: {e}")

def handle_exit(signum, frame):
    """Gère la fermeture propre du bot"""
    global running
    logging.info("Signal d'arrêt reçu. Arrêt propre...")
    running = False

def run_trading_bot():
    """Boucle principale du bot de trading"""
    global running
    
    # Vérifier que les clés API sont disponibles
    if not api_key or not api_secret:
        logging.error("Clés API Kraken manquantes dans les variables d'environnement")
        return
    
    logging.info("""
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
BOT DE TRADING ULTRA-STABLE 24/7 DÉMARRÉ - MODE RÉEL KRAKEN
Utilisation de TOUTES les positions - Conversion crypto-to-crypto
Analyse ultra-simplifiée et ultra-stable - Détection de momentum
Stratégie: sortir des actifs en baisse, entrer dans ceux en hausse
Clés API intégrées - Fonctionnement continu sur Replit
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
""")
    
    # Initialiser l'exchange
    exchange = init_exchange()
    if not exchange:
        logging.error("Échec d'initialisation de l'exchange. Réessai dans 10 secondes...")
        time.sleep(10)
        return
    
    # Récupérer les balances initiales
    balances = get_balances(exchange)
    if not balances:
        logging.error("Échec de récupération des balances. Réessai dans 10 secondes...")
        time.sleep(10)
        return
    
    # Rechercher les actifs volatils
    volatile_assets = find_volatile_assets(exchange)
    
    # Boucle principale
    iteration = 0
    while running:
        try:
            update_heartbeat()
            
            # Nettoyer les logs périodiquement
            if iteration % 10 == 0:
                clean_logs()
            
            # Récupérer les balances actuelles
            balances = get_balances(exchange)
            if not balances:
                raise Exception("Échec de récupération des balances")
            
            # Rechercher périodiquement de nouveaux actifs volatils
            if iteration % 5 == 0:
                volatile_assets = find_volatile_assets(exchange)
            
            # Vérifier les opportunités de conversion entre cryptos
            check_crypto_to_crypto_opportunities(exchange, balances, volatile_assets)
            
            # Attendre avant la prochaine itération (1 minute)
            iteration += 1
            for i in range(60):
                if not running:
                    break
                time.sleep(1)
        except Exception as e:
            logging.error(f"Erreur dans la boucle principale: {e}")
            time.sleep(30)  # Attendre avant de réessayer

def keep_alive_thread():
    """Thread pour garder le bot actif"""
    while running:
        try:
            update_heartbeat()
            time.sleep(30)
        except Exception as e:
            logging.error(f"Erreur dans le thread de maintien en vie: {e}")
            time.sleep(30)

def main():
    """Point d'entrée principal"""
    global running
    
    # Configurer les gestionnaires de signaux
    signal.signal(signal.SIGINT, handle_exit)
    signal.signal(signal.SIGTERM, handle_exit)
    
    # Démarrer le thread de maintien en vie
    alive_thread = threading.Thread(target=keep_alive_thread, daemon=True)
    alive_thread.start()
    
    # Exécuter la boucle de trading avec relance automatique
    while running:
        try:
            run_trading_bot()
        except Exception as e:
            logging.error(f"ERREUR CRITIQUE - BOT CRASHÉ: {e}")
            logging.info("Redémarrage automatique dans 10 secondes...")
            time.sleep(10)

if __name__ == "__main__":
    main()