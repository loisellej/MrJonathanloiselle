#!/usr/bin/env python3
"""
Contrôleur du Trader Automatique - Interface interactive
Ce script permet de contrôler le trader automatique et de visualiser son activité
"""
import os
import sys
import time
import json
import datetime
import subprocess
from pathlib import Path

def clear_screen():
    """Efface l'écran du terminal"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """Affiche l'en-tête du contrôleur"""
    print("\n" + "=" * 80)
    print("🤖 CONTRÔLEUR DU TRADER AUTOMATIQUE - MODE LIVE TRADING".center(80))
    print("=" * 80 + "\n")

def check_trader_status():
    """Vérifie si le trader est en cours d'exécution"""
    # Vérifier le fichier PID
    if os.path.exists("trader.pid"):
        try:
            with open("trader.pid", "r") as f:
                pid = int(f.read().strip())
            
            # Vérifier si le processus existe
            try:
                os.kill(pid, 0)
                return True, pid
            except OSError:
                return False, None
        except:
            return False, None
    
    # Vérifier le heartbeat
    if os.path.exists("trader_heartbeat.txt"):
        try:
            mtime = os.path.getmtime("trader_heartbeat.txt")
            # Si le heartbeat date de moins de 60 secondes
            if time.time() - mtime < 60:
                return True, None
        except:
            pass
    
    return False, None

def get_recent_logs(file_path="auto_trader_verified.log", n=20):
    """Récupère les N dernières lignes du fichier de log"""
    if not os.path.exists(file_path):
        return []
    
    try:
        with open(file_path, "r") as f:
            lines = f.readlines()
        return lines[-n:]
    except Exception as e:
        print(f"Erreur lors de la lecture des logs: {e}")
        return []

def get_trade_proofs(file_path="trading_proofs.txt"):
    """Récupère les preuves de transactions"""
    if not os.path.exists(file_path):
        return []
    
    try:
        with open(file_path, "r") as f:
            content = f.read()
        
        # Diviser par les séparateurs
        sections = content.split("-" * 50)
        
        proofs = []
        for section in sections:
            if not section.strip():
                continue
            
            # Convertir la section en dictionnaire
            proof = {}
            for line in section.strip().split("\n"):
                if ":" in line:
                    key, value = line.split(":", 1)
                    proof[key.strip()] = value.strip()
            
            if proof:
                proofs.append(proof)
        
        return proofs
    except Exception as e:
        print(f"Erreur lors de la lecture des preuves: {e}")
        return []

def get_current_balances():
    """Récupère les balances actuelles via API"""
    try:
        # Exécuter le script de vérification des balances
        output = subprocess.check_output([
            sys.executable, "-c", 
            "import os; import krakenex; from dotenv import load_dotenv; load_dotenv(); "
            "k = krakenex.API(os.environ.get('KRAKEN_API_KEY'), os.environ.get('KRAKEN_API_SECRET')); "
            "print(k.query_private('Balance'))"
        ]).decode()
        
        # Convertir la sortie en dictionnaire
        result = eval(output.strip())
        
        # Vérifier s'il y a des erreurs
        if 'error' in result and result['error']:
            return [], f"Erreur API: {result['error']}"
        
        # Formater les balances pour l'affichage
        balances = []
        for asset, amount in result['result'].items():
            amount_float = float(amount)
            if amount_float > 0.001:  # Ignorer les très petits soldes
                balances.append({
                    'asset': asset,
                    'amount': amount_float
                })
        
        return balances, None
    except Exception as e:
        return [], f"Erreur: {e}"

def start_trader():
    """Démarre le trader automatique"""
    try:
        # Arrêter toute instance existante
        stop_trader()
        
        # Démarrer le trader en arrière-plan
        subprocess.Popen([
            sys.executable, "auto_trader_verified.py"
        ], stdout=open("auto_trader_output.log", "w"), stderr=subprocess.STDOUT)
        
        print("✅ Trader démarré en mode LIVE")
        return True
    except Exception as e:
        print(f"❌ Erreur lors du démarrage du trader: {e}")
        return False

def stop_trader():
    """Arrête le trader automatique"""
    try:
        # Tuer le processus par PID si possible
        if os.path.exists("trader.pid"):
            with open("trader.pid", "r") as f:
                pid = f.read().strip()
            
            try:
                os.system(f"kill {pid}")
            except:
                pass
        
        # Tuer tous les processus correspondants
        os.system("pkill -f auto_trader_verified.py")
        
        print("✅ Trader arrêté")
        return True
    except Exception as e:
        print(f"❌ Erreur lors de l'arrêt du trader: {e}")
        return False

def execute_real_trade():
    """Exécute un trade réel immédiatement"""
    try:
        print("🚀 Exécution d'un trade réel pour démonstration...")
        
        # Exécuter le script de trade réel
        result = subprocess.run([
            sys.executable, "execute_real_trade.py"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Afficher la sortie
        print(result.stdout.decode())
        
        if result.returncode != 0:
            print(f"❌ Erreur lors de l'exécution du trade: {result.stderr.decode()}")
            return False
        
        print("✅ Trade exécuté avec succès")
        return True
    except Exception as e:
        print(f"❌ Erreur lors de l'exécution du trade: {e}")
        return False

def show_dashboard():
    """Affiche le tableau de bord du trader"""
    clear_screen()
    print_header()
    
    # Vérifier si le trader est en cours d'exécution
    running, pid = check_trader_status()
    
    # Afficher le statut
    print(f"📊 STATUT: {'🟢 En cours d'exécution' if running else '🔴 Arrêté'}")
    if pid:
        print(f"PID: {pid}")
    
    # Récupérer les balances
    balances, error = get_current_balances()
    
    print("\n📈 BALANCES ACTUELLES:")
    if error:
        print(f"  ❌ {error}")
    elif not balances:
        print("  Aucune balance significative trouvée")
    else:
        for balance in balances:
            print(f"  {balance['asset']}: {balance['amount']:.6f}")
    
    # Récupérer les preuves de transactions
    proofs = get_trade_proofs()
    real_trades = [p for p in proofs if p.get('ACTION') in ['BUY', 'SELL']]
    
    print("\n🧾 TRANSACTIONS RÉELLES:")
    if not real_trades:
        print("  Aucune transaction réelle enregistrée")
    else:
        for trade in real_trades[-5:]:  # Afficher les 5 dernières transactions
            action = trade.get('ACTION', '')
            asset = trade.get('ASSET', '')
            amount = trade.get('AMOUNT', '0')
            price = trade.get('PRICE', '0')
            txid = trade.get('TXID', 'N/A')
            date = trade.get('DATE', '')
            
            action_symbol = "🔴" if action == "SELL" else "🟢"
            print(f"  {action_symbol} {date} - {action} {amount} {asset} @ {price} - ID: {txid}")
    
    # Récupérer les logs récents
    logs = get_recent_logs()
    
    print("\n📋 LOGS RÉCENTS:")
    if not logs:
        print("  Aucun log disponible")
    else:
        for log in logs[-10:]:  # Afficher les 10 derniers logs
            print(f"  {log.strip()}")
    
    print("\n" + "=" * 80)
    print("OPTIONS:")
    print("1. Démarrer le trader")
    print("2. Arrêter le trader")
    print("3. Exécuter un trade réel immédiatement")
    print("4. Rafraîchir l'écran")
    print("5. Quitter")
    print("=" * 80)

def main():
    """Fonction principale"""
    while True:
        show_dashboard()
        
        choice = input("\nChoisissez une option (1-5): ")
        
        if choice == "1":
            start_trader()
            input("\nAppuyez sur Entrée pour continuer...")
        
        elif choice == "2":
            stop_trader()
            input("\nAppuyez sur Entrée pour continuer...")
        
        elif choice == "3":
            execute_real_trade()
            input("\nAppuyez sur Entrée pour continuer...")
        
        elif choice == "4":
            # Rafraîchir l'écran seulement
            pass
        
        elif choice == "5":
            print("Au revoir!")
            break
        
        else:
            print("Option invalide. Veuillez réessayer.")
            time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nProgramme arrêté par l'utilisateur")
    except Exception as e:
        print(f"\nErreur fatale: {e}")
        sys.exit(1)