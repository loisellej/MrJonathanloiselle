#!/bin/bash
# Script de déploiement du trading bot vers Hetzner
# Utilisation: ./deploy_to_hetzner.sh <adresse_ip> <utilisateur> <chemin_clé_ssh>

set -e  # Arrête le script en cas d'erreur

# Vérification des arguments
if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <adresse_ip_serveur> <utilisateur_ssh> <chemin_cle_ssh>"
    echo "Exemple: $0 65.21.123.456 root ~/.ssh/id_rsa"
    exit 1
fi

SERVER_IP=$1
SSH_USER=$2
SSH_KEY_PATH=$3

echo "=== DÉPLOIEMENT DU TRADING BOT VERS HETZNER ==="
echo "Serveur: $SSH_USER@$SERVER_IP"
echo "Clé SSH: $SSH_KEY_PATH"

# Création du répertoire temporaire pour l'empaquetage
TMP_DIR=$(mktemp -d)
PACKAGE_NAME="trading_bot.tar.gz"

echo "Préparation des fichiers..."
# Copier les fichiers nécessaires
cp ultra_volatility_trader.py $TMP_DIR/
cp day_trader.py $TMP_DIR/
cp direct_kraken_api.py $TMP_DIR/
cp check_status.py $TMP_DIR/
cp -r models* $TMP_DIR/ 2>/dev/null || true
# Ajout des requirements
echo "krakenex" > $TMP_DIR/requirements.txt
echo "numpy" >> $TMP_DIR/requirements.txt
echo "requests" >> $TMP_DIR/requirements.txt
echo "python-dotenv" >> $TMP_DIR/requirements.txt

# Création du fichier de démarrage
cat > $TMP_DIR/start_bot.sh <<EOF
#!/bin/bash
# Script de démarrage du bot sur Hetzner
cd \$(dirname \$0)
source venv/bin/activate
python ultra_volatility_trader.py > trading.log 2>&1 &
echo \$! > bot.pid
echo "Bot démarré avec PID: \$(cat bot.pid)"
EOF

# Création du script d'installation
cat > $TMP_DIR/setup.sh <<EOF
#!/bin/bash
# Installation des dépendances
apt-get update
apt-get install -y python3 python3-pip python3-venv

# Création de l'environnement virtuel
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Configuration des permissions
chmod +x start_bot.sh
chmod +x stop_bot.sh
chmod +x check_status.sh

echo "Installation terminée!"
EOF

# Script d'arrêt du bot
cat > $TMP_DIR/stop_bot.sh <<EOF
#!/bin/bash
if [ -f bot.pid ]; then
    PID=\$(cat bot.pid)
    if ps -p \$PID > /dev/null; then
        echo "Arrêt du bot (PID: \$PID)..."
        kill \$PID
        rm bot.pid
        echo "Bot arrêté avec succès."
    else
        echo "Le bot n'est pas en cours d'exécution (PID: \$PID)."
        rm bot.pid
    fi
else
    echo "Aucun fichier PID trouvé."
fi
EOF

# Script de vérification
cat > $TMP_DIR/check_status.sh <<EOF
#!/bin/bash
if [ -f bot.pid ]; then
    PID=\$(cat bot.pid)
    if ps -p \$PID > /dev/null; then
        echo "Bot en cours d'exécution avec PID: \$PID"
        echo "Dernières lignes du journal:"
        tail -n 20 trading.log
    else
        echo "ERREUR: Le bot s'est arrêté de manière inattendue (PID: \$PID)."
        rm bot.pid
    fi
else
    echo "Le bot n'est pas en cours d'exécution."
fi
EOF

# Script pour créer le fichier .env avec les clés API de Kraken
cat > $TMP_DIR/create_env.sh <<EOF
#!/bin/bash
cat > .env <<INNEREOF
KRAKEN_API_KEY=\${1:-"votre_api_key_ici"}
KRAKEN_API_SECRET=\${2:-"votre_api_secret_ici"}
INNEREOF
echo "Fichier .env créé avec succès."
EOF

# Création du README
cat > $TMP_DIR/README.md <<EOF
# Bot de Trading Crypto Ultra-Volatil

## Installation
1. Exécutez \`./setup.sh\` pour installer les dépendances

## Configuration
1. Exécutez \`./create_env.sh "votre_api_key" "votre_api_secret"\` pour configurer les clés API

## Utilisation
- \`./start_bot.sh\` - Démarrer le bot
- \`./stop_bot.sh\` - Arrêter le bot
- \`./check_status.sh\` - Vérifier l'état du bot

## Logs
Les logs sont disponibles dans le fichier \`trading.log\`
EOF

# Compression des fichiers
echo "Création de l'archive..."
cd $TMP_DIR
chmod +x *.sh
tar -czf ../$PACKAGE_NAME .
cd ..

echo "Transfert vers Hetzner..."
# Transfert des fichiers via SCP
scp -i $SSH_KEY_PATH $PACKAGE_NAME $SSH_USER@$SERVER_IP:~/$PACKAGE_NAME

echo "Installation sur le serveur Hetzner..."
# Connexion SSH et extraction
ssh -i $SSH_KEY_PATH $SSH_USER@$SERVER_IP << EOF
mkdir -p ~/trading_bot
tar -xzf ~/$PACKAGE_NAME -C ~/trading_bot
cd ~/trading_bot
chmod +x *.sh
./setup.sh
echo "=== INSTALLATION TERMINÉE ==="
echo "Pour démarrer le bot:"
echo "1. Connectez-vous au serveur: ssh -i $SSH_KEY_PATH $SSH_USER@$SERVER_IP"
echo "2. Naviguez vers le dossier: cd ~/trading_bot"
echo "3. Configurez vos clés API: ./create_env.sh \"VOTRE_API_KEY\" \"VOTRE_API_SECRET\""
echo "4. Démarrez le bot: ./start_bot.sh"
rm ~/$PACKAGE_NAME
EOF

# Nettoyage des fichiers temporaires
rm -rf $TMP_DIR
rm $PACKAGE_NAME

echo "=== DÉPLOIEMENT TERMINÉ AVEC SUCCÈS ==="
echo "Utilisez SSH pour vous connecter au serveur et configurer/démarrer le bot."
echo "ssh -i $SSH_KEY_PATH $SSH_USER@$SERVER_IP"
echo "cd ~/trading_bot"
echo "Suivez les instructions dans le fichier README.md"