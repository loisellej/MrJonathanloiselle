#!/usr/bin/env python3
"""
Script principal pour démarrer le trader multi-positions avec supervision 24/7
Ce script garantit que le bot de trading reste actif en permanence
"""

import os
import time
import logging
import subprocess
import sys

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("launch.log"),
        logging.StreamHandler()
    ]
)

def launch_system():
    """Lance le système complet (superviseur + trader)"""
    try:
        print("=== LANCEMENT DU SYSTÈME DE TRADING 24/7 COMPLET ===")
        print(time.strftime("%a %d %b %Y %I:%M:%S %p %Z", time.localtime()))
        
        # Vérifier que les clés API sont disponibles
        api_key = os.environ.get("KRAKEN_API_KEY")
        api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        if not api_key or not api_secret:
            print("❌ ERREUR: Clés API Kraken non trouvées dans les variables d'environnement")
            print("Veuillez définir KRAKEN_API_KEY et KRAKEN_API_SECRET")
            sys.exit(1)
        
        # Arrêter tous les processus existants
        print("Arrêt des processus existants...")
        subprocess.run(["pkill", "-f", "multi_position_trader.py"], stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-f", "supervisor.py"], stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-f", "start_multi_position_trader.py"], stderr=subprocess.DEVNULL)
        
        # Attendre que tout soit arrêté
        time.sleep(2)
        
        # Démarrer le superviseur
        print("Démarrage du superviseur...")
        supervisor = subprocess.Popen(
            ["python3", "supervisor.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT
        )
        
        print(f"Superviseur démarré avec PID: {supervisor.pid}")
        
        # Attendre un moment pour que le superviseur démarre
        time.sleep(5)
        
        print("""
        
*************************************************************************
SYSTÈME DE TRADING MULTI-POSITIONS 24/7 ACTIVÉ!

Caractéristiques:
- Utilise TOUTES vos positions pour trader entre cryptos volatiles
- Analyse minute par minute des opportunités
- Stop-loss ultra-serré de 0.5-0.8%
- Target profit de 2-3% par trade
- Triple protection anti-crash et redémarrage automatique
- Serveur web intégré pour maintenir Replit actif
- Surveillance continue avec alertes
*************************************************************************

Pour accéder à l'interface de contrôle: http://127.0.0.1:8080
Pour voir les logs: tail -f trader_24_7.log
Pour arrêter complètement: pkill -f "supervisor.py"
        
        """)
        
        return True
    except Exception as e:
        logging.error(f"Erreur lors du lancement du système: {e}")
        return False

if __name__ == "__main__":
    success = launch_system()
    if not success:
        sys.exit(1)