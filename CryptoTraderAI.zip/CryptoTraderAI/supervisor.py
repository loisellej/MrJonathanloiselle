#!/usr/bin/env python3
"""
SUPERVISEUR DE BOT TRADING 24/7
- Maintient le bot actif en permanence
- Redémarre automatiquement en cas de crash
- Expose un petit serveur web pour garder Replit actif
- Utilise keep_alive de Replit (optionnel)
"""

import os
import time
import logging
import subprocess
import threading
import signal
import sys
from flask import Flask, jsonify

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("watchdog.log"),
        logging.StreamHandler()
    ]
)

# Variables globales
app = Flask(__name__)
bot_process = None
heartbeat_time = None
RESTART_DELAY = 5  # Délai de redémarrage en secondes
MAX_LOGS_SIZE = 1024 * 1024 * 10  # 10 MB max pour les logs

def manage_log_size(log_file, max_size=MAX_LOGS_SIZE):
    """Vérifie et gère la taille des fichiers de log pour éviter de saturer Replit"""
    try:
        if os.path.exists(log_file) and os.path.getsize(log_file) > max_size:
            # Renommer le fichier actuel
            backup_file = f"{log_file}.bak"
            if os.path.exists(backup_file):
                os.remove(backup_file)
            os.rename(log_file, backup_file)
            
            # Créer un nouveau fichier de log vide
            with open(log_file, 'w') as f:
                f.write(f"Log rotaté le {time.ctime()} - Ancienne version dans {backup_file}\n")
            
            logging.info(f"Rotation du fichier de log {log_file} (taille > {max_size/1024/1024:.2f} MB)")
    except Exception as e:
        logging.error(f"Erreur lors de la gestion des logs: {e}")

def update_heartbeat():
    """Met à jour le fichier heartbeat"""
    global heartbeat_time
    heartbeat_time = time.time()
    try:
        with open("bot_heartbeat.txt", "w") as f:
            f.write(time.ctime(heartbeat_time))
    except Exception as e:
        logging.error(f"Erreur lors de la mise à jour du heartbeat: {e}")

def is_bot_running():
    """Vérifie si le bot est en cours d'exécution"""
    try:
        # Vérifier le fichier PID
        if os.path.exists("trader.pid"):
            with open("trader.pid", "r") as f:
                pid = int(f.read().strip())
            
            # Vérifier si le processus existe
            try:
                os.kill(pid, 0)
                return True
            except OSError:
                return False
        return False
    except Exception as e:
        logging.error(f"Erreur lors de la vérification de l'état du bot: {e}")
        return False

def get_heartbeat_age():
    """Récupère l'âge du dernier heartbeat en secondes"""
    try:
        if os.path.exists("bot_heartbeat.txt"):
            mtime = os.path.getmtime("bot_heartbeat.txt")
            return time.time() - mtime
        return float('inf')  # Très vieux si le fichier n'existe pas
    except Exception as e:
        logging.error(f"Erreur lors de la récupération de l'âge du heartbeat: {e}")
        return float('inf')

def start_bot():
    """Démarre le bot de trading"""
    global bot_process
    try:
        # Tuer tout processus existant
        stop_bot()
        
        logging.info("Démarrage du trader automatique vérifié avec gestion des frais...")
        
        # Exécuter le script de démarrage du trader en arrière-plan
        process = subprocess.Popen(
            ["python3", "auto_trader_verified.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT
        )
        
        bot_process = process
        logging.info(f"Bot démarré avec PID: {process.pid}")
        update_heartbeat()
        
        return True
    except Exception as e:
        logging.error(f"Erreur lors du démarrage du bot: {e}")
        return False

def stop_bot():
    """Arrête le bot de trading"""
    global bot_process
    try:
        # Tuer le processus actuel si existant
        if bot_process:
            try:
                bot_process.terminate()
                bot_process.wait(timeout=5)
            except:
                pass
            bot_process = None
        
        # Tuer tout processus lié au bot via pkill
        subprocess.run(["pkill", "-f", "auto_trader_verified.py"], stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-f", "trading_guardian.py"], stderr=subprocess.DEVNULL)
        
        # Supprimer le fichier PID s'il existe
        if os.path.exists("trader.pid"):
            os.remove("trader.pid")
        
        logging.info("Bot arrêté")
        return True
    except Exception as e:
        logging.error(f"Erreur lors de l'arrêt du bot: {e}")
        return False

def monitor_bot_thread():
    """Thread de surveillance du bot"""
    logging.info("Démarrage du thread de surveillance du bot")
    
    while True:
        try:
            # Gérer la taille des fichiers de log
            manage_log_size("trader_24_7.log")
            manage_log_size("watchdog.log")
            
            # Mettre à jour le heartbeat
            update_heartbeat()
            
            # Vérifier si le bot est en cours d'exécution
            bot_running = is_bot_running()
            heartbeat_age = get_heartbeat_age()
            
            # Si le bot n'est pas en cours d'exécution ou le heartbeat est trop vieux
            if not bot_running or heartbeat_age > 300:  # 5 minutes
                logging.warning(f"Bot non détecté ou inactif (heartbeat: {heartbeat_age:.1f}s). Redémarrage...")
                start_bot()
            else:
                logging.info(f"Bot en cours d'exécution. Heartbeat: {heartbeat_age:.1f}s")
            
            # Attendre avant la prochaine vérification
            time.sleep(60)  # Vérifier toutes les minutes
        except Exception as e:
            logging.error(f"Erreur dans le thread de surveillance: {e}")
            time.sleep(60)  # Attendre avant de réessayer

# Routes du serveur web
@app.route('/')
def home():
    """Page d'accueil du serveur web"""
    bot_running = is_bot_running()
    heartbeat_age = get_heartbeat_age()
    
    status = "actif" if bot_running and heartbeat_age < 300 else "inactif"
    
    return f"""
    <html>
        <head>
            <title>Superviseur de Bot Trading</title>
            <meta http-equiv="refresh" content="60">
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .status {{ padding: 10px; border-radius: 5px; margin: 20px 0; }}
                .active {{ background-color: #d4edda; color: #155724; }}
                .inactive {{ background-color: #f8d7da; color: #721c24; }}
                button {{ padding: 10px 15px; margin: 5px; }}
                .info {{ background-color: #f8f9fa; padding: 15px; border-radius: 5px; }}
            </style>
        </head>
        <body>
            <h1>Superviseur de Bot Trading 24/7</h1>
            
            <div class="status {'active' if status == 'actif' else 'inactive'}">
                Le bot est actuellement <strong>{status}</strong>
                {f"(dernier signe de vie il y a {heartbeat_age:.1f}s)" if heartbeat_age < float('inf') else ""}
            </div>
            
            <div>
                <button onclick="fetch('/start_bot', {{method: 'POST'}}).then(() => location.reload())">
                    Démarrer le Bot
                </button>
                <button onclick="fetch('/stop_bot', {{method: 'POST'}}).then(() => location.reload())">
                    Arrêter le Bot
                </button>
                <button onclick="location.reload()">
                    Actualiser
                </button>
            </div>
            
            <div class="info">
                <h3>Informations</h3>
                <p>PID: {open("trader.pid").read().strip() if os.path.exists("trader.pid") else "N/A"}</p>
                <p>Dernier heartbeat: {time.ctime(time.time() - heartbeat_age) if heartbeat_age < float('inf') else "Jamais"}</p>
                <p>Surveillance active: Vérification toutes les minutes</p>
                <p>Redémarrage automatique: Activé</p>
            </div>
        </body>
    </html>
    """

@app.route('/start_bot', methods=['POST'])
def api_start_bot():
    """API pour démarrer le bot"""
    success = start_bot()
    return jsonify({"success": success, "message": "Bot démarré" if success else "Échec du démarrage"})

@app.route('/stop_bot', methods=['POST'])
def api_stop_bot():
    """API pour arrêter le bot"""
    success = stop_bot()
    return jsonify({"success": success, "message": "Bot arrêté" if success else "Échec de l'arrêt"})

@app.route('/status')
def api_status():
    """API pour récupérer le statut du bot"""
    bot_running = is_bot_running()
    heartbeat_age = get_heartbeat_age()
    
    return jsonify({
        "running": bot_running,
        "heartbeat_age": heartbeat_age,
        "status": "active" if bot_running and heartbeat_age < 300 else "inactive",
        "pid": open("trader.pid").read().strip() if os.path.exists("trader.pid") else None,
        "last_heartbeat": time.ctime(time.time() - heartbeat_age) if heartbeat_age < float('inf') else None
    })

def handle_exit(signum, frame):
    """Gère la fermeture propre du superviseur"""
    logging.info("Signal reçu. Arrêt propre...")
    stop_bot()
    sys.exit(0)

def run_web_server():
    """Démarre le serveur web Flask"""
    try:
        # Utiliser un thread pour le serveur web
        logging.info("Démarrage du serveur web...")
        app.run(host='0.0.0.0', port=8080, debug=False)
    except Exception as e:
        logging.error(f"Erreur lors du démarrage du serveur web: {e}")

def import_replit_keep_alive():
    """Importe et utilise replit.keep_alive si disponible"""
    try:
        from replit import keep_alive
        logging.info("Utilisation de replit.keep_alive()...")
        keep_alive()
        return True
    except ImportError:
        logging.warning("Module replit non disponible, keep_alive() non utilisé")
        return False

def main():
    """Fonction principale"""
    print("=== DÉMARRAGE DU SUPERVISEUR DE BOT TRADING 24/7 ===")
    print("Date:", time.ctime())
    
    # Configurer les gestionnaires de signaux
    signal.signal(signal.SIGINT, handle_exit)
    signal.signal(signal.SIGTERM, handle_exit)
    
    # Tenter d'utiliser replit.keep_alive
    import_replit_keep_alive()
    
    # Démarrer le thread de surveillance
    monitor_thread = threading.Thread(target=monitor_bot_thread, daemon=True)
    monitor_thread.start()
    
    # Démarrer initialement le bot
    if not is_bot_running():
        logging.info("Bot non détecté au démarrage, lancement initial...")
        start_bot()
    
    # Démarrer le serveur web pour maintenir Replit actif
    run_web_server()

if __name__ == "__main__":
    main()