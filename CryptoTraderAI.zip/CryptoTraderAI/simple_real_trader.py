import os
import time
import logging
import threading
import random
import ccxt

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class RealTrader:
    def __init__(self, api_key=None, api_secret=None):
        """Initialisation du trader en mode réel uniquement"""
        self.api_key = api_key or os.environ.get('KRAKEN_API_KEY')
        self.api_secret = api_secret or os.environ.get('KRAKEN_API_SECRET')
        self.exchange = None
        self.balances = {}
        self.thread = None
        self.running = False
        self.excluded_assets = ['BTC', 'ETH', 'SOL']
        self.audio_stop_loss = 0.08  # Stop-loss fixe pour AUDIO
        self.initialize_exchange()
        
    def initialize_exchange(self):
        """Initialise la connexion à l'exchange"""
        try:
            logger.info("Initialisation de la connexion à Kraken...")
            
            if not self.api_key or len(self.api_key) < 10 or not self.api_secret or len(self.api_secret) < 10:
                raise ValueError("Clés API Kraken invalides ou manquantes")
            
            # Configuration de l'exchange avec options pour trading haute fréquence
            self.exchange = ccxt.kraken({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'options': {
                    'adjustForTimeDifference': True,
                    'recvWindow': 5000
                },
                'timeout': 10000
            })
            
            # Test de connexion
            logger.info("Test de la connexion API...")
            self.exchange.load_markets()
            self.exchange.fetch_balance()
            logger.info("Connexion à Kraken réussie!")
            
            # Obtenir les soldes initiaux
            self.refresh_balances()
            
            return True
        except Exception as e:
            logger.error(f"Erreur d'initialisation de l'exchange: {e}")
            raise
    
    def refresh_balances(self):
        """Récupère les soldes actuels"""
        try:
            logger.info("Récupération des balances...")
            balance = self.exchange.fetch_balance()
            total = balance.get('total', {})
            
            # Filtrer uniquement les balances positives
            self.balances = {k: v for k, v in total.items() if v and v > 0}
            
            logger.info(f"Balances actuelles: {self.balances}")
            return self.balances
        except Exception as e:
            logger.error(f"Erreur de récupération des balances: {e}")
            return {}
    
    def get_volatile_assets(self, max_assets=5):
        """Récupère les actifs les plus volatils"""
        try:
            logger.info("Recherche des actifs volatils...")
            
            # Récupérer tous les marchés disponibles
            markets = self.exchange.load_markets()
            
            # Filtrer les paires USDT et USD
            tradable_markets = [m for m in markets.keys() if '/USDT' in m or '/USD' in m]
            
            # Traiter un sous-ensemble pour performance
            market_volatility = {}
            for market in tradable_markets[:30]:
                try:
                    # Extraire le symbole de base
                    base_symbol = market.split('/')[0]
                    
                    # Ignorer les actifs exclus
                    if base_symbol in self.excluded_assets:
                        continue
                    
                    # Récupérer les données historiques
                    ohlcv = self.exchange.fetch_ohlcv(market, timeframe='1h', limit=24)
                    
                    # Calculer la volatilité simple (max-min)/avg
                    if len(ohlcv) > 5:
                        closes = [candle[4] for candle in ohlcv]
                        price_min = min(closes)
                        price_max = max(closes)
                        price_avg = sum(closes) / len(closes)
                        volatility = (price_max - price_min) / price_avg * 100
                        
                        market_volatility[base_symbol] = {
                            'volatility': volatility,
                            'market': market
                        }
                    
                    time.sleep(0.1)  # Éviter de surcharger l'API
                except Exception as e:
                    logger.error(f"Erreur d'analyse du marché {market}: {e}")
            
            # Trier par volatilité
            sorted_assets = sorted(market_volatility.items(), key=lambda x: x[1]['volatility'], reverse=True)
            
            # Retourner les X plus volatils
            volatile_assets = [asset for asset, _ in sorted_assets[:max_assets]]
            
            logger.info(f"Actifs volatils trouvés: {volatile_assets}")
            return volatile_assets
        except Exception as e:
            logger.error(f"Erreur de recherche d'actifs volatils: {e}")
            return ['AUDIO', 'GARI', 'API3', 'APE', 'APU']  # Valeurs par défaut en cas d'erreur
    
    def buy(self, asset, amount=None, percentage=None):
        """Achète un actif avec un montant ou pourcentage du solde USDT"""
        try:
            symbol = f"{asset}/USDT"
            usdt_balance = self.balances.get('USDT', 0)
            
            # Si aucun montant spécifié, utiliser le pourcentage
            if amount is None and percentage is not None:
                amount_usdt = usdt_balance * percentage
                
                # Récupérer le prix actuel
                ticker = self.exchange.fetch_ticker(symbol)
                price = ticker['last']
                
                amount = amount_usdt / price
            
            if amount <= 0:
                logger.warning(f"Montant d'achat invalide pour {asset}: {amount}")
                return None
            
            logger.info(f"Achat de {amount} {asset}")
            order = self.exchange.create_market_buy_order(symbol, amount)
            
            # Rafraîchir les balances après l'ordre
            self.refresh_balances()
            
            logger.info(f"Achat réussi: {order}")
            return order
        except Exception as e:
            logger.error(f"Erreur d'achat de {asset}: {e}")
            return None
    
    def sell(self, asset, amount=None, percentage=None):
        """Vend un actif avec un montant ou pourcentage du solde de l'actif"""
        try:
            asset_balance = self.balances.get(asset, 0)
            
            # Si aucun montant spécifié, utiliser le pourcentage
            if amount is None and percentage is not None:
                amount = asset_balance * percentage
            
            if amount <= 0:
                logger.warning(f"Montant de vente invalide pour {asset}: {amount}")
                return None
            
            symbol = f"{asset}/USDT"
            logger.info(f"Vente de {amount} {asset}")
            order = self.exchange.create_market_sell_order(symbol, amount)
            
            # Rafraîchir les balances après l'ordre
            self.refresh_balances()
            
            logger.info(f"Vente réussie: {order}")
            return order
        except Exception as e:
            logger.error(f"Erreur de vente de {asset}: {e}")
            return None
    
    def convert_to_volatile(self, exclude_assets=None):
        """Convertit les actifs disponibles en cryptos volatiles"""
        if exclude_assets is None:
            exclude_assets = ['USDT']
        
        try:
            logger.info("Conversion des actifs en cryptos volatiles...")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Trouver les actifs volatils
            volatile_assets = self.get_volatile_assets(max_assets=3)
            if not volatile_assets:
                logger.warning("Aucun actif volatil trouvé")
                return False
            
            # Convertir d'abord les actifs en USDT
            for asset, balance in self.balances.items():
                if asset in exclude_assets or balance <= 0:
                    continue
                
                # Convertir uniquement les actifs avec un solde significatif
                if balance > 0:
                    try:
                        symbol = f"{asset}/USDT"
                        ticker = self.exchange.fetch_ticker(symbol)
                        price = ticker['last']
                        usdt_value = balance * price
                        
                        if usdt_value >= 1.0:
                            logger.info(f"Conversion de {balance} {asset} en USDT")
                            self.sell(asset, percentage=1.0)
                    except Exception as e:
                        logger.error(f"Erreur de conversion de {asset} en USDT: {e}")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Utiliser le solde USDT pour acheter des actifs volatils
            usdt_balance = self.balances.get('USDT', 0)
            if usdt_balance <= 1.0:
                logger.warning("Solde USDT insuffisant pour l'achat d'actifs volatils")
                return False
            
            # Répartir le solde USDT entre les actifs volatils
            num_assets = min(len(volatile_assets), 3)
            usdt_per_asset = usdt_balance / num_assets
            
            for asset in volatile_assets[:num_assets]:
                logger.info(f"Achat de l'actif volatil {asset} avec {usdt_per_asset} USDT")
                self.buy(asset, percentage=1.0/num_assets)
            
            return True
        except Exception as e:
            logger.error(f"Erreur de conversion en actifs volatils: {e}")
            return False
    
    def convert_to_audio(self):
        """Convertit les actifs disponibles en AUDIO"""
        try:
            logger.info("Conversion des actifs en AUDIO...")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Convertir d'abord les actifs en USDT
            for asset, balance in self.balances.items():
                if asset in ['USDT', 'AUDIO'] or balance <= 0:
                    continue
                
                # Convertir uniquement les actifs avec un solde significatif
                if balance > 0:
                    try:
                        symbol = f"{asset}/USDT"
                        ticker = self.exchange.fetch_ticker(symbol)
                        price = ticker['last']
                        usdt_value = balance * price
                        
                        if usdt_value >= 1.0:
                            logger.info(f"Conversion de {balance} {asset} en USDT")
                            self.sell(asset, percentage=1.0)
                    except Exception as e:
                        logger.error(f"Erreur de conversion de {asset} en USDT: {e}")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Utiliser le solde USDT pour acheter AUDIO
            usdt_balance = self.balances.get('USDT', 0)
            if usdt_balance <= 1.0:
                logger.warning("Solde USDT insuffisant pour l'achat d'AUDIO")
                return False
            
            logger.info(f"Achat d'AUDIO avec {usdt_balance} USDT")
            self.buy('AUDIO', percentage=1.0)
            
            return True
        except Exception as e:
            logger.error(f"Erreur de conversion en AUDIO: {e}")
            return False
    
    def convert_to_btc(self):
        """Convertit les actifs disponibles en BTC"""
        try:
            logger.info("Conversion des actifs en BTC...")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Convertir d'abord les actifs en USDT
            for asset, balance in self.balances.items():
                if asset in ['USDT', 'BTC'] or balance <= 0:
                    continue
                
                # Convertir uniquement les actifs avec un solde significatif
                if balance > 0:
                    try:
                        symbol = f"{asset}/USDT"
                        ticker = self.exchange.fetch_ticker(symbol)
                        price = ticker['last']
                        usdt_value = balance * price
                        
                        if usdt_value >= 1.0:
                            logger.info(f"Conversion de {balance} {asset} en USDT")
                            self.sell(asset, percentage=1.0)
                    except Exception as e:
                        logger.error(f"Erreur de conversion de {asset} en USDT: {e}")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Utiliser le solde USDT pour acheter BTC
            usdt_balance = self.balances.get('USDT', 0)
            if usdt_balance <= 1.0:
                logger.warning("Solde USDT insuffisant pour l'achat de BTC")
                return False
            
            logger.info(f"Achat de BTC avec {usdt_balance} USDT")
            self.buy('BTC', percentage=1.0)
            
            return True
        except Exception as e:
            logger.error(f"Erreur de conversion en BTC: {e}")
            return False
    
    def trading_loop(self):
        """Boucle principale de trading"""
        logger.info("Démarrage de la boucle de trading...")
        
        try:
            while self.running:
                # Rafraîchir les balances
                self.refresh_balances()
                
                # Obtenir les actifs volatils
                volatile_assets = self.get_volatile_assets(max_assets=5)
                
                # Si nous avons des USDT, les répartir sur les actifs volatils
                usdt_balance = self.balances.get('USDT', 0)
                if usdt_balance > 10.0:  # Au moins 10 USDT
                    logger.info(f"Répartition de {usdt_balance} USDT sur les actifs volatils")
                    
                    # Répartir sur 3 actifs maximum
                    num_assets = min(len(volatile_assets), 3)
                    usdt_per_asset = usdt_balance / num_assets
                    
                    for asset in volatile_assets[:num_assets]:
                        try:
                            logger.info(f"Achat de {asset} avec {usdt_per_asset} USDT")
                            self.buy(asset, percentage=1.0/num_assets)
                            time.sleep(1)  # Court délai entre les ordres
                        except Exception as e:
                            logger.error(f"Erreur d'achat de {asset}: {e}")
                
                # Attendre avant le prochain cycle
                logger.info("Attente avant le prochain cycle de trading...")
                for _ in range(60):  # Checking every second if we need to stop
                    if not self.running:
                        break
                    time.sleep(1)
        except Exception as e:
            logger.error(f"Erreur dans la boucle de trading: {e}")
        finally:
            logger.info("Boucle de trading arrêtée")
    
    def start(self):
        """Démarre le trading"""
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        try:
            self.running = True
            self.thread = threading.Thread(target=self.trading_loop)
            self.thread.daemon = True
            self.thread.start()
            logger.info("Trader démarré avec succès")
            return True
        except Exception as e:
            logger.error(f"Erreur de démarrage du trader: {e}")
            self.running = False
            return False
    
    def stop(self):
        """Arrête le trading"""
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        try:
            self.running = False
            if self.thread:
                self.thread.join(timeout=5.0)
            logger.info("Trader arrêté avec succès")
            return True
        except Exception as e:
            logger.error(f"Erreur d'arrêt du trader: {e}")
            return False
    
    def get_status(self):
        """Récupère le statut actuel du trader"""
        try:
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Calculer la valeur totale en USDT
            total_value_usdt = 0.0
            balances_with_value = {}
            
            for asset, balance in self.balances.items():
                if balance <= 0:
                    continue
                
                if asset == 'USDT':
                    value_usdt = balance
                else:
                    try:
                        symbol = f"{asset}/USDT"
                        ticker = self.exchange.fetch_ticker(symbol)
                        price = ticker['last']
                        value_usdt = balance * price
                    except:
                        value_usdt = 0.0
                
                balances_with_value[asset] = {
                    'balance': balance,
                    'value_usdt': value_usdt
                }
                total_value_usdt += value_usdt
            
            # Obtenir les actifs volatils
            volatile_assets = self.get_volatile_assets(max_assets=5)
            
            return {
                'running': self.running,
                'balances': balances_with_value,
                'total_value_usdt': total_value_usdt,
                'volatile_assets': volatile_assets
            }
        except Exception as e:
            logger.error(f"Erreur de récupération du statut: {e}")
            return {
                'running': self.running,
                'error': str(e)
            }

# Fonction d'initialisation
def create_trader(api_key=None, api_secret=None):
    """Crée et retourne une instance du trader"""
    api_key = api_key or os.environ.get('KRAKEN_API_KEY')
    api_secret = api_secret or os.environ.get('KRAKEN_API_SECRET')
    
    if not api_key or not api_secret:
        raise ValueError("Clés API Kraken manquantes")
    
    return RealTrader(api_key, api_secret)

# Test du trader
if __name__ == "__main__":
    try:
        # Créer le trader
        trader = create_trader()
        
        # Afficher les balances
        balances = trader.refresh_balances()
        print(f"Balances: {balances}")
        
        # Obtenir les actifs volatils
        volatile_assets = trader.get_volatile_assets()
        print(f"Actifs volatils: {volatile_assets}")
        
        # Démarrer le trader
        trader.start()
        
        # Attendre un certain temps
        time.sleep(60)
        
        # Arrêter le trader
        trader.stop()
    except Exception as e:
        print(f"Erreur: {e}")