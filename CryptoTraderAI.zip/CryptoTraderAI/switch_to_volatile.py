import krakenex
import time
import logging
import json
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

# Liste des cryptos potentiellement volatiles à considérer
VOLATILE_CRYPTO_LIST = [
    "DOGE",  # Dogecoin
    "SHIB",  # Shiba Inu
    "MATIC", # Polygon
    "AVAX",  # Avalanche
    "DOT",   # Polkadot
    "LINK",  # Chainlink
    "ADA",   # Cardano
    "SOL",   # Solana
    "FTM",   # Fantom
    "ATOM",  # Cosmos
    "XRP",   # Ripple
    "MANA",  # Decentraland
    "SAND",  # The Sandbox
    "ALGO",  # Algorand
    "ENJ",   # Enjin
    "1INCH", # 1inch
    "AAVE",  # Aave
    "KAVA",  # Kava
    "DYDX"   # dYdX
]

def cancel_all_orders():
    """Annule tous les ordres ouverts"""
    logger.info("=== ANNULATION DE TOUS LES ORDRES ===")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Récupérer les ordres ouverts
        open_orders = k.query_private('OpenOrders')
        
        if 'error' in open_orders and open_orders['error']:
            logger.error(f"Erreur lors de la récupération des ordres ouverts: {open_orders['error']}")
            return False
        
        # Compter le nombre d'ordres ouverts
        num_orders = len(open_orders['result']['open'])
        
        if num_orders == 0:
            logger.info("Aucun ordre ouvert à annuler.")
            return True
        
        logger.info(f"Annulation de {num_orders} ordres...")
        
        # Annuler chaque ordre
        for order_id in open_orders['result']['open'].keys():
            logger.info(f"Annulation de l'ordre {order_id}...")
            cancel_result = k.query_private('CancelOrder', {'txid': order_id})
            
            if 'error' in cancel_result and cancel_result['error']:
                logger.error(f"Erreur lors de l'annulation de l'ordre {order_id}: {cancel_result['error']}")
            else:
                logger.info(f"✅ Ordre {order_id} annulé avec succès")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors de l'annulation des ordres: {e}")
        return False

def sell_all_audio():
    """Vend tout l'AUDIO disponible sur le compte"""
    logger.info("=== VENTE DE TOUT L'AUDIO ===")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Récupérer les balances
        balances = k.query_private('Balance')
        
        if 'error' in balances and balances['error']:
            logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
            return 0
        
        # Vérifier le solde AUDIO
        audio_balance = float(balances['result'].get('AUDIO', 0))
        
        if audio_balance < 10:
            logger.error(f"Solde AUDIO insuffisant pour la vente: {audio_balance}")
            return 0
        
        logger.info(f"Solde AUDIO disponible: {audio_balance}")
        
        # Obtenir le prix actuel d'AUDIO
        ticker = k.query_public('Ticker', {'pair': 'AUDIOUSD'})
        current_price = float(ticker['result']['AUDIOUSD']['c'][0])
        logger.info(f"Prix actuel d'AUDIO: {current_price} USD")
        
        # Vendre tout l'AUDIO disponible
        logger.info(f"Vente de {audio_balance} AUDIO à environ {current_price} USD")
        
        # Placer l'ordre de vente (market)
        sell_order = k.query_private('AddOrder', {
            'pair': 'AUDIOUSD',
            'type': 'sell',
            'ordertype': 'market',
            'volume': str(audio_balance)
        })
        
        if 'error' in sell_order and sell_order['error']:
            logger.error(f"Erreur lors de la vente d'AUDIO: {sell_order['error']}")
            return 0
        
        # Récupérer l'ID de l'ordre
        order_txid = sell_order['result']['txid'][0]
        logger.info(f"✅ Ordre de vente placé avec succès: ID {order_txid}")
        
        # Attendre la confirmation de l'exécution
        logger.info("Attente de la confirmation de l'exécution...")
        time.sleep(5)
        
        # Vérifier l'état de l'ordre
        order_status = k.query_private('QueryOrders', {'txid': order_txid})
        
        if 'error' in order_status and order_status['error']:
            logger.error(f"Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
        else:
            logger.info(f"État de l'ordre: {order_status['result'][order_txid]['status']}")
        
        # Récupérer le nouveau solde USD
        new_balances = k.query_private('Balance')
        usd_balance = float(new_balances['result'].get('ZUSD', 0))
        logger.info(f"Nouveau solde USD: {usd_balance}")
        
        return usd_balance
    
    except Exception as e:
        logger.error(f"Erreur lors de la vente d'AUDIO: {e}")
        return 0

def analyze_volatility_and_trend():
    """Analyse la volatilité et la tendance des cryptos pour trouver la meilleure opportunité"""
    logger.info("=== ANALYSE DES CRYPTOS VOLATILES EN UPTREND ===")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Résultats de l'analyse
        results = []
        
        for crypto in VOLATILE_CRYPTO_LIST:
            pair = f"{crypto}/USD"
            
            try:
                # Vérifier si la paire est disponible
                ticker = k.query_public('Ticker', {'pair': pair})
                
                if 'error' in ticker and ticker['error']:
                    # Si la paire n'existe pas, essayer avec USDT
                    pair = f"{crypto}/USDT"
                    ticker = k.query_public('Ticker', {'pair': pair})
                
                if 'error' in ticker and ticker['error']:
                    # Si la paire n'existe toujours pas, passer à la crypto suivante
                    logger.info(f"La paire {crypto}/USD et {crypto}/USDT n'est pas disponible sur Kraken")
                    continue
                
                # Récupérer l'historique des prix récents pour analyser la tendance
                ohlc = k.query_public('OHLC', {'pair': pair, 'interval': 240})  # 4 heures
                
                # Si une erreur se produit, passer à la crypto suivante
                if 'error' in ohlc and ohlc['error']:
                    logger.warning(f"Erreur lors de la récupération des données OHLC pour {pair}: {ohlc['error']}")
                    continue
                
                # Récupérer les données OHLC (Open, High, Low, Close)
                ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
                
                # Extraire les prix de clôture
                close_prices = [float(item[4]) for item in ohlc_data[-10:]]  # 10 dernières périodes
                
                # Calculer la volatilité (écart-type des variations en %)
                price_changes = [abs(close_prices[i] - close_prices[i-1]) / close_prices[i-1] * 100 for i in range(1, len(close_prices))]
                volatility = sum(price_changes) / len(price_changes)
                
                # Calculer la tendance (% d'augmentation sur la période)
                trend = (close_prices[-1] - close_prices[0]) / close_prices[0] * 100
                
                # Calculer le volume récent
                current_volume = float(ticker['result'][list(ticker['result'].keys())[0]]['v'][0])
                
                # Calculer un score combiné (volatilité + tendance)
                # Plus le score est élevé, plus la crypto est volatile et en uptrend
                score = volatility * (1 + trend/100)
                
                # Si la tendance est négative, diviser le score par 2
                if trend < 0:
                    score = score / 2
                
                # Stocker les résultats
                results.append({
                    'crypto': crypto,
                    'pair': pair,
                    'volatility': volatility,
                    'trend': trend,
                    'volume': current_volume,
                    'score': score,
                    'current_price': float(ticker['result'][list(ticker['result'].keys())[0]]['c'][0])
                })
                
                logger.info(f"Analyse de {pair}: Volatilité = {volatility:.2f}%, Tendance = {trend:.2f}%, Score = {score:.2f}")
                
            except Exception as e:
                logger.error(f"Erreur lors de l'analyse de {crypto}: {e}")
                continue
        
        # Trier les résultats par score (du plus élevé au plus bas)
        results = sorted(results, key=lambda x: x['score'], reverse=True)
        
        # Afficher les meilleurs résultats
        logger.info("=== RÉSULTATS DE L'ANALYSE ===")
        for i, result in enumerate(results[:5]):
            logger.info(f"{i+1}. {result['crypto']}: Score = {result['score']:.2f}, Volatilité = {result['volatility']:.2f}%, Tendance = {result['trend']:.2f}%")
        
        # Retourner le meilleur résultat
        return results[0] if results else None
    
    except Exception as e:
        logger.error(f"Erreur lors de l'analyse des cryptos: {e}")
        return None

def buy_volatile_crypto(usd_balance, crypto_data):
    """Achète la crypto volatile sélectionnée avec le solde USD disponible"""
    if not crypto_data or usd_balance < 10:
        logger.error("Données insuffisantes pour l'achat ou solde USD trop faible")
        return False
    
    logger.info(f"=== ACHAT DE {crypto_data['crypto']} ===")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Calculer le montant à acheter (95% du solde USD pour tenir compte des frais)
        usd_to_spend = usd_balance * 0.95
        amount_to_buy = usd_to_spend / crypto_data['current_price']
        
        # Arrondir à un nombre raisonnable de décimales
        amount_to_buy = round(amount_to_buy, 6)
        
        logger.info(f"Achat de {amount_to_buy} {crypto_data['crypto']} à environ {crypto_data['current_price']} USD")
        logger.info(f"Montant USD à dépenser: {usd_to_spend} USD")
        
        # Placer l'ordre d'achat (market)
        buy_order = k.query_private('AddOrder', {
            'pair': crypto_data['pair'],
            'type': 'buy',
            'ordertype': 'market',
            'volume': str(amount_to_buy)
        })
        
        if 'error' in buy_order and buy_order['error']:
            logger.error(f"Erreur lors de l'achat de {crypto_data['crypto']}: {buy_order['error']}")
            
            # Si l'erreur concerne le volume minimum, essayer d'acheter avec un montant fixe en USD
            if 'EOrder:Invalid order' in str(buy_order['error']):
                logger.info(f"Tentative d'achat avec un montant USD fixe plutôt qu'un volume spécifique...")
                
                # Utiliser le paramètre 'cost' au lieu de 'volume'
                buy_order = k.query_private('AddOrder', {
                    'pair': crypto_data['pair'],
                    'type': 'buy',
                    'ordertype': 'market',
                    'cost': str(usd_to_spend)
                })
                
                if 'error' in buy_order and buy_order['error']:
                    logger.error(f"Seconde tentative échouée: {buy_order['error']}")
                    return False
            else:
                return False
        
        # Récupérer l'ID de l'ordre
        order_txid = buy_order['result']['txid'][0]
        logger.info(f"✅ Ordre d'achat placé avec succès: ID {order_txid}")
        
        # Attendre la confirmation de l'exécution
        logger.info("Attente de la confirmation de l'exécution...")
        time.sleep(5)
        
        # Vérifier l'état de l'ordre
        order_status = k.query_private('QueryOrders', {'txid': order_txid})
        
        if 'error' in order_status and order_status['error']:
            logger.error(f"Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
        else:
            logger.info(f"État de l'ordre: {order_status['result'][order_txid]['status']}")
        
        # Enregistrer les détails de la transaction dans un fichier
        with open('crypto_trades.log', 'a') as f:
            f.write(f"[{datetime.now().isoformat()}] ACHAT: {amount_to_buy} {crypto_data['crypto']} à {crypto_data['current_price']} USD\n")
            f.write(f"[{datetime.now().isoformat()}] RAISONS: Volatilité = {crypto_data['volatility']:.2f}%, Tendance = {crypto_data['trend']:.2f}%, Score = {crypto_data['score']:.2f}\n")
            f.write("-" * 50 + "\n")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors de l'achat de {crypto_data['crypto']}: {e}")
        return False

def check_final_balances():
    """Vérifie et affiche les balances finales après les transactions"""
    logger.info("=== VÉRIFICATION DES BALANCES FINALES ===")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Récupérer les balances
        balances = k.query_private('Balance')
        
        if 'error' in balances and balances['error']:
            logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
            return False
        
        # Afficher les balances
        logger.info("Balances finales:")
        for asset, balance in balances['result'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors de la vérification des balances: {e}")
        return False

def switch_from_audio_to_volatile():
    """Exécute tout le processus de conversion d'AUDIO vers une crypto volatile"""
    print("\n🚀 DÉMARRAGE DE LA CONVERSION AUDIO -> CRYPTO VOLATILE\n")
    
    # 1. Annuler tous les ordres existants
    if not cancel_all_orders():
        print("⚠️ Problème lors de l'annulation des ordres. Poursuite quand même...")
    
    # 2. Vendre tout l'AUDIO
    usd_balance = sell_all_audio()
    
    if usd_balance <= 0:
        print("\n❌ ÉCHEC: Impossible de vendre l'AUDIO ou de récupérer le solde USD")
        return False
    
    # 3. Analyser les cryptos volatiles en uptrend
    best_crypto = analyze_volatility_and_trend()
    
    if not best_crypto:
        print("\n❌ ÉCHEC: Impossible de trouver une crypto volatile en uptrend")
        return False
    
    # 4. Acheter la crypto volatile sélectionnée
    if not buy_volatile_crypto(usd_balance, best_crypto):
        print(f"\n❌ ÉCHEC: Impossible d'acheter {best_crypto['crypto']}")
        return False
    
    # 5. Vérifier les balances finales
    check_final_balances()
    
    print(f"\n✅ CONVERSION RÉUSSIE: AUDIO -> {best_crypto['crypto']}")
    print(f"   Nouvelle crypto: {best_crypto['crypto']}")
    print(f"   Raisons: Volatilité = {best_crypto['volatility']:.2f}%, Tendance = {best_crypto['trend']:.2f}%")
    print(f"   Plus de détails dans le fichier 'crypto_trades.log'")
    
    return True

if __name__ == "__main__":
    switch_from_audio_to_volatile()