import os
import ccxt
import logging
import sys

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def convert_now():
    """Convertit immédiatement tous les actifs disponibles en cryptos volatiles"""
    logger.info("=== CONVERSION DIRECTE VERS DES CRYPTOS VOLATILES ===")
    
    try:
        # Récupérer les clés API
        api_key = os.environ.get('KRAKEN_API_KEY')
        api_secret = os.environ.get('KRAKEN_API_SECRET')
        
        if not api_key or not api_secret:
            logger.error("Clés API manquantes")
            return False
        
        logger.info("Connexion à Kraken établie")
        exchange = ccxt.kraken({
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True
        })
        
        # Récupérer les balances
        balances = exchange.fetch_balance()
        
        # Afficher tous les soldes significatifs
        for asset, balance in balances['total'].items():
            if float(balance) > 0.001:  # Ignorer les très petites balances
                logger.info(f"Solde {asset}: {balance}")
        
        # Récupérer tous les marchés disponibles
        markets = exchange.load_markets()
        
        # Actifs volatils cibles (par ordre de préférence)
        volatile_assets = ['AUDIO', 'GARI', 'DOGE', 'SHIB', 'MATIC', 'MANA']
        
        # Vendre tous les actifs non-stablecoins pour USD ou USDT
        for asset, balance in balances['free'].items():
            # Ignorer les stablecoins et les petits montants
            if asset in ['USD', 'USDT', 'USDC'] or float(balance) < 0.001:
                continue
            
            balance_value = float(balance)
            
            # Chercher un marché pour vendre cet actif
            for quote in ['USD', 'USDT']:
                symbol = f"{asset}/{quote}"
                if symbol in markets:
                    logger.info(f"Vente de {balance_value} {asset} contre {quote}")
                    try:
                        # Placer un ordre de vente
                        order = exchange.create_market_sell_order(symbol, balance_value)
                        logger.info(f"Vente effectuée: {order}")
                        break
                    except Exception as e:
                        logger.error(f"Erreur lors de la vente de {asset}: {e}")
            
        # Attendre que les ventes soient complétées
        logger.info("Attente de la finalisation des ventes...")
        import time
        time.sleep(5)
        
        # Récupérer les nouveaux soldes
        new_balances = exchange.fetch_balance()
        usd_balance = float(new_balances['free'].get('USD', 0))
        usdt_balance = float(new_balances['free'].get('USDT', 0))
        
        logger.info(f"Solde USD disponible: {usd_balance}")
        logger.info(f"Solde USDT disponible: {usdt_balance}")
        
        # Acheter des actifs volatils avec USD/USDT
        success = False
        
        # D'abord essayer avec USD
        if usd_balance > 5:
            for asset in volatile_assets:
                symbol = f"{asset}/USD"
                if symbol in markets:
                    try:
                        logger.info(f"Achat de {asset} avec {usd_balance * 0.95} USD")
                        # Pour les ordres market en USD, on utilise le paramètre cost
                        order = exchange.create_market_buy_order(symbol, None, {'cost': usd_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        success = True
                        break
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat de {asset} avec USD: {e}")
        
        # Ensuite essayer avec USDT si disponible
        if not success and usdt_balance > 5:
            for asset in volatile_assets:
                symbol = f"{asset}/USDT"
                if symbol in markets:
                    try:
                        logger.info(f"Achat de {asset} avec {usdt_balance * 0.95} USDT")
                        order = exchange.create_market_buy_order(symbol, None, {'cost': usdt_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        success = True
                        break
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat de {asset} avec USDT: {e}")
        
        if success:
            logger.info("Conversion réussie!")
        else:
            logger.warning("Aucune conversion n'a pu être effectuée")
        
        return success
    
    except Exception as e:
        logger.error(f"Erreur générale lors de la conversion: {e}")
        return False

if __name__ == "__main__":
    result = convert_now()
    if result:
        sys.exit(0)
    else:
        sys.exit(1)