#!/usr/bin/env python
"""
Script d'intégration des optimisations dans le système de trading existant
Ce script automatise l'intégration des optimisations sans interrompre le trading en cours
"""
import os
import sys
import time
import logging
import subprocess
import shutil
import signal
import importlib.util
import psutil
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("integration.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("IntegrateOptimizations")

# Fichiers du système optimisé
OPTIMIZED_FILES = [
    "optimized_resource_manager.py",
    "optimized_queue_manager.py",
    "optimized_api_client.py",
    "performance_monitor.py"
]

# Fichier de configuration pour l'intégration
CONFIG_FILE = "integration_config.py"

def check_files():
    """
    Vérifie que tous les fichiers nécessaires sont présents
    
    Returns:
        bool: True si tous les fichiers sont présents
    """
    missing_files = []
    
    for filename in OPTIMIZED_FILES:
        if not os.path.exists(filename):
            missing_files.append(filename)
    
    if missing_files:
        logger.error(f"Fichiers manquants: {', '.join(missing_files)}")
        return False
    
    return True

def create_config_file():
    """
    Crée le fichier de configuration pour l'intégration
    
    Returns:
        bool: True si la création est réussie
    """
    try:
        # Configuration par défaut
        config = f"""# Configuration pour l'intégration des optimisations
# Généré automatiquement le {datetime.now()}

# Activation des optimisations
USE_OPTIMIZED_RESOURCES = True
USE_OPTIMIZED_QUEUE = True
USE_OPTIMIZED_API = True
USE_PERFORMANCE_MONITORING = True

# Paramètres des optimisations
CACHE_TTL = 60  # Durée de vie du cache en secondes
MAX_WORKERS = 2  # Nombre maximum de workers pour les files d'attente
HIGH_LOAD_THRESHOLD = 80  # Seuil d'alerte pour la charge système (%)
"""

        # Écrire la configuration
        with open(CONFIG_FILE, "w") as f:
            f.write(config)
        
        logger.info(f"Fichier de configuration créé: {CONFIG_FILE}")
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors de la création du fichier de configuration: {e}")
        return False

def find_original_trader():
    """
    Trouve le processus du trader original
    
    Returns:
        tuple: (pid, cmdline) ou (None, None) si non trouvé
    """
    try:
        # Rechercher tous les processus Python
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if proc.info['name'] == 'python3' or proc.info['name'] == 'python':
                    cmdline = proc.info['cmdline'] if proc.info['cmdline'] else []
                    cmd_str = ' '.join(cmdline)
                    
                    # Vérifier si c'est le trader original
                    if 'auto_trader_verified.py' in cmd_str:
                        return (proc.pid, cmdline)
                        
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
                
        return (None, None)
        
    except Exception as e:
        logger.error(f"Erreur lors de la recherche du trader original: {e}")
        return (None, None)

def create_integration_layer():
    """
    Crée une couche d'intégration pour connecter les optimisations au système existant
    
    Returns:
        bool: True si la création est réussie
    """
    try:
        # Contenu du fichier d'intégration
        integration_code = """#!/usr/bin/env python
\"\"\"
Couche d'intégration pour les optimisations du système de trading
Ce module connecte le système existant aux nouvelles optimisations
\"\"\"
import os
import sys
import time
import logging
import threading

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("integration_layer.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("IntegrationLayer")

# Variables globales pour les instances
_resource_manager = None
_queue_manager = None
_optimized_api = None
_performance_monitor = None

# Charger la configuration
try:
    from integration_config import *
    logger.info("Configuration chargée avec succès")
except ImportError:
    logger.warning("Fichier de configuration non trouvé, utilisation des valeurs par défaut")
    USE_OPTIMIZED_RESOURCES = True
    USE_OPTIMIZED_QUEUE = True
    USE_OPTIMIZED_API = True
    USE_PERFORMANCE_MONITORING = True
    CACHE_TTL = 60
    MAX_WORKERS = 2
    HIGH_LOAD_THRESHOLD = 80

def initialize_optimizations():
    \"\"\"
    Initialise toutes les optimisations
    
    Returns:
        dict: Instances des optimisations
    \"\"\"
    global _resource_manager, _queue_manager, _optimized_api, _performance_monitor
    
    try:
        logger.info("Initialisation des optimisations")
        
        # Gestionnaire de ressources
        if USE_OPTIMIZED_RESOURCES:
            try:
                from optimized_resource_manager import OptimizedResourceManager
                _resource_manager = OptimizedResourceManager()
                logger.info("Gestionnaire de ressources initialisé")
            except ImportError:
                logger.error("Module optimized_resource_manager non trouvé")
        
        # Gestionnaire de files d'attente
        if USE_OPTIMIZED_QUEUE:
            try:
                from optimized_queue_manager import get_queue_manager
                _queue_manager = get_queue_manager()
                logger.info("Gestionnaire de files d'attente initialisé")
            except ImportError:
                logger.error("Module optimized_queue_manager non trouvé")
        
        # Client API optimisé
        if USE_OPTIMIZED_API:
            try:
                from optimized_api_client import setup_optimized_kraken_client
                _optimized_api = setup_optimized_kraken_client(
                    api_key=os.environ.get("KRAKEN_API_KEY"),
                    api_secret=os.environ.get("KRAKEN_API_SECRET")
                )
                logger.info("Client API optimisé initialisé")
            except ImportError:
                logger.error("Module optimized_api_client non trouvé")
        
        # Moniteur de performances
        if USE_PERFORMANCE_MONITORING:
            try:
                from performance_monitor import get_performance_monitor
                _performance_monitor = get_performance_monitor(_resource_manager, _queue_manager)
                logger.info("Moniteur de performances initialisé")
            except ImportError:
                logger.error("Module performance_monitor non trouvé")
        
        return {
            'resource_manager': _resource_manager,
            'queue_manager': _queue_manager,
            'api_client': _optimized_api,
            'performance_monitor': _performance_monitor
        }
    
    except Exception as e:
        logger.error(f"Erreur lors de l'initialisation des optimisations: {e}")
        return {}

def get_cached_price(symbol, exchange_connector=None):
    \"\"\"
    Récupère le prix avec mise en cache intelligente
    
    Args:
        symbol (str): Symbole de la paire (ex: "BTC/USD")
        exchange_connector: Connecteur d'échange existant (fallback)
        
    Returns:
        float: Prix ou None si erreur
    \"\"\"
    global _resource_manager, _optimized_api
    
    # Utiliser le gestionnaire de ressources si disponible
    if _resource_manager is not None:
        return _resource_manager.get_cached_price(symbol)
    
    # Utiliser l'API optimisée si disponible
    if _optimized_api is not None:
        return _optimized_api.get_ticker_price(symbol)
    
    # Fallback sur le connecteur d'échange existant
    if exchange_connector is not None:
        return exchange_connector.get_ticker_price(symbol)
    
    return None

def add_task(task, *args, **kwargs):
    \"\"\"
    Ajoute une tâche à la file d'attente
    
    Args:
        task (callable): Fonction à exécuter
        *args, **kwargs: Arguments à passer à la fonction
    \"\"\"
    global _queue_manager
    
    # Utiliser le gestionnaire de files d'attente si disponible
    if _queue_manager is not None:
        _queue_manager.add_task(task, *args, **kwargs)
        return True
    
    # Exécuter directement si pas de gestionnaire
    try:
        task(*args, **kwargs)
        return True
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution de la tâche: {e}")
        return False

def add_priority_task(priority, task_id, task, *args, **kwargs):
    \"\"\"
    Ajoute une tâche prioritaire à la file d'attente
    
    Args:
        priority (int): Priorité (0-10, 0 étant la plus haute)
        task_id (str): Identifiant unique de la tâche
        task (callable): Fonction à exécuter
        *args, **kwargs: Arguments à passer à la fonction
    \"\"\"
    global _queue_manager
    
    # Utiliser le gestionnaire de files d'attente si disponible
    if _queue_manager is not None:
        _queue_manager.add_priority_task(priority, task_id, task, *args, **kwargs)
        return True
    
    # Exécuter directement si pas de gestionnaire
    try:
        task(*args, **kwargs)
        return True
    except Exception as e:
        logger.error(f"Erreur lors de l'exécution de la tâche prioritaire: {e}")
        return False

def execute_api_call(method, *args, **kwargs):
    \"\"\"
    Exécute un appel API avec rate limiting et retry
    
    Args:
        method (callable): Méthode API à appeler
        *args, **kwargs: Arguments à passer à la méthode
        
    Returns:
        any: Résultat de l'appel ou None si erreur
    \"\"\"
    global _optimized_api
    
    # Utiliser l'API optimisée si possible et si la méthode existe
    if _optimized_api is not None and hasattr(_optimized_api, method.__name__):
        api_method = getattr(_optimized_api, method.__name__)
        return api_method(*args, **kwargs)
    
    # Fallback sur la méthode originale
    try:
        return method(*args, **kwargs)
    except Exception as e:
        logger.error(f"Erreur lors de l'appel API {method.__name__}: {e}")
        return None

def record_performance_metric(metric_name, value):
    \"\"\"
    Enregistre une métrique de performance
    
    Args:
        metric_name (str): Nom de la métrique
        value: Valeur à enregistrer
    \"\"\"
    global _performance_monitor
    
    # Utiliser le moniteur de performances si disponible
    if _performance_monitor is not None:
        # Adapter selon les méthodes disponibles
        if hasattr(_performance_monitor, 'record_metric'):
            _performance_monitor.record_metric(metric_name, value)
        
        # Enregistrer les erreurs
        if metric_name == 'error' and hasattr(_performance_monitor, 'record_error'):
            _performance_monitor.record_error('integration', str(value))

def get_status():
    \"\"\"
    Récupère le statut des optimisations
    
    Returns:
        dict: Statut des optimisations
    \"\"\"
    status = {
        'resource_manager_active': _resource_manager is not None,
        'queue_manager_active': _queue_manager is not None,
        'optimized_api_active': _optimized_api is not None,
        'performance_monitor_active': _performance_monitor is not None
    }
    
    # Ajouter les statistiques si disponibles
    if _performance_monitor is not None and hasattr(_performance_monitor, 'get_metrics_summary'):
        status['system_metrics'] = _performance_monitor.get_metrics_summary()
    
    return status

# Initialiser les optimisations au chargement du module
optimizations = initialize_optimizations()
"""

        # Écrire le fichier d'intégration
        with open("optimization_layer.py", "w") as f:
            f.write(integration_code)
        
        logger.info("Couche d'intégration créée avec succès")
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors de la création de la couche d'intégration: {e}")
        return False

def patch_original_trader():
    """
    Patch le trader original pour utiliser les optimisations
    
    Returns:
        bool: True si le patch est réussi
    """
    try:
        # Vérifier si le fichier existe
        if not os.path.exists("auto_trader_verified.py"):
            logger.error("Fichier auto_trader_verified.py non trouvé")
            return False
        
        # Sauvegarder une copie du fichier original
        backup_file = f"auto_trader_verified.py.bak.{int(time.time())}"
        shutil.copy2("auto_trader_verified.py", backup_file)
        logger.info(f"Sauvegarde du fichier original créée: {backup_file}")
        
        # Lire le contenu du fichier
        with open("auto_trader_verified.py", "r") as f:
            content = f.read()
        
        # Vérifier si le fichier est déjà patché
        if "from optimization_layer import" in content:
            logger.info("Le fichier est déjà patché, aucune modification nécessaire")
            return True
        
        # Ajouter l'import des optimisations au début du fichier
        optimization_import = """# DÉBUT INTÉGRATION DES OPTIMISATIONS
try:
    # Importer la couche d'intégration des optimisations
    from optimization_layer import get_cached_price, add_task, add_priority_task, execute_api_call, record_performance_metric
    OPTIMIZATIONS_ENABLED = True
    print("✅ Optimisations activées avec succès")
except ImportError:
    # Fallback si les optimisations ne sont pas disponibles
    OPTIMIZATIONS_ENABLED = False
    print("⚠️ Optimisations non disponibles, utilisation du trader standard")
# FIN INTÉGRATION DES OPTIMISATIONS

"""
        # Trouver le bon endroit pour insérer les imports
        import_marker = "import os"
        if import_marker in content:
            content = content.replace(import_marker, import_marker + "\n" + optimization_import)
        else:
            # Si le marqueur n'est pas trouvé, ajouter en haut du fichier
            content = optimization_import + content
        
        # Chercher les fonctions qui peuvent être optimisées
        # Pattern 1: get_ticker_price ou similaire
        if "def get_ticker_price" in content:
            # Remplacer la fonction par une version optimisée
            original_func = """    def get_ticker_price(self, symbol):
        """
            if original_func in content:
                optimized_func = """    def get_ticker_price(self, symbol):
        # OPTIMISÉ: Utiliser le cache de prix si disponible
        if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
            cached_price = get_cached_price(symbol, self)
            if cached_price is not None:
                return cached_price
        
        # Version originale si optimisations non disponibles
        """
                content = content.replace(original_func, optimized_func)
                logger.info("Fonction get_ticker_price optimisée")
        
        # Pattern 2: Améliorer les appels API sensibles
        if "def execute_trade" in content or "def buy" in content or "def sell" in content:
            # Ajouter des mesures de performance autour des trades
            trade_patterns = [
                ("def execute_trade", "def execute_trade"),
                ("def buy", "def buy"),
                ("def sell", "def sell")
            ]
            
            for pattern, name in trade_patterns:
                if pattern in content:
                    start_pattern = f"{pattern}("
                    end_pattern = "return"
                    
                    if start_pattern in content and end_pattern in content:
                        # Trouver l'indentation
                        lines = content.split("\n")
                        indent = ""
                        for line in lines:
                            if pattern in line:
                                indent = line[:line.find(pattern)]
                                break
                        
                        # Ajouter le monitoring de performance
                        perf_start = f"""
{indent}    # OPTIMISÉ: Mesurer les performances
{indent}    if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
{indent}        start_time = time.time()
"""
                        
                        perf_end = f"""
{indent}    # OPTIMISÉ: Enregistrer les performances
{indent}    if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
{indent}        duration = time.time() - start_time
{indent}        record_performance_metric('trade_execution_time', duration)
{indent}        if result:  # Si le trade a réussi
{indent}            record_performance_metric('successful_trades', 1)
{indent}        else:
{indent}            record_performance_metric('failed_trades', 1)
"""
                        
                        # Insérer au début de la fonction
                        func_start_idx = content.find(start_pattern)
                        if func_start_idx > 0:
                            # Trouver la fin de la ligne
                            line_end_idx = content.find("\n", func_start_idx)
                            if line_end_idx > 0:
                                content = content[:line_end_idx+1] + perf_start + content[line_end_idx+1:]
                        
                        # Insérer avant le return
                        return_idx = content.find(end_pattern, func_start_idx)
                        if return_idx > 0:
                            content = content[:return_idx] + perf_end + content[return_idx:]
                        
                        logger.info(f"Fonction {name} optimisée")
        
        # Écrire le contenu modifié
        with open("auto_trader_verified.py", "w") as f:
            f.write(content)
        
        logger.info("Trader original patché avec succès")
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors du patch du trader original: {e}")
        # Restaurer la sauvegarde si elle existe
        if 'backup_file' in locals() and os.path.exists(backup_file):
            shutil.copy2(backup_file, "auto_trader_verified.py")
            logger.info("Restauration de la sauvegarde effectuée")
        return False

def restart_original_trader():
    """
    Redémarre le trader original
    
    Returns:
        bool: True si le redémarrage est réussi
    """
    try:
        # Trouver le processus du trader original
        pid, cmdline = find_original_trader()
        
        if pid is None:
            logger.warning("Trader original non trouvé, démarrage d'une nouvelle instance")
            
            # Démarrer une nouvelle instance
            subprocess.Popen(["python3", "auto_trader_verified.py"])
            logger.info("Nouvelle instance du trader démarrée")
            return True
        
        # Arrêter le processus existant
        logger.info(f"Arrêt du trader original (PID: {pid})")
        os.kill(pid, signal.SIGTERM)
        
        # Attendre l'arrêt
        max_wait = 10  # secondes
        for _ in range(max_wait):
            if not psutil.pid_exists(pid):
                break
            time.sleep(1)
        
        # Forcer l'arrêt si nécessaire
        if psutil.pid_exists(pid):
            logger.warning(f"Le trader ne s'est pas arrêté, envoi de SIGKILL")
            os.kill(pid, signal.SIGKILL)
            time.sleep(1)
        
        # Démarrer une nouvelle instance avec les mêmes arguments
        if cmdline and len(cmdline) > 1:
            subprocess.Popen(cmdline)
            logger.info(f"Trader redémarré avec la commande: {' '.join(cmdline)}")
        else:
            subprocess.Popen(["python3", "auto_trader_verified.py"])
            logger.info("Trader redémarré avec la commande par défaut")
        
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors du redémarrage du trader: {e}")
        return False

def main():
    """Fonction principale"""
    try:
        print("\n" + "=" * 70)
        print(" INTÉGRATION DES OPTIMISATIONS DANS LE SYSTÈME EXISTANT ".center(70, "="))
        print("=" * 70 + "\n")
        
        print("1. Vérification des fichiers d'optimisation...")
        if not check_files():
            print("❌ Des fichiers d'optimisation sont manquants")
            return 1
        print("✅ Tous les fichiers d'optimisation sont présents\n")
        
        print("2. Création du fichier de configuration...")
        if create_config_file():
            print("✅ Fichier de configuration créé\n")
        else:
            print("❌ Échec de la création du fichier de configuration\n")
            return 1
        
        print("3. Création de la couche d'intégration...")
        if create_integration_layer():
            print("✅ Couche d'intégration créée\n")
        else:
            print("❌ Échec de la création de la couche d'intégration\n")
            return 1
        
        print("4. Identification du trader original...")
        pid, cmdline = find_original_trader()
        if pid:
            print(f"✅ Trader original trouvé (PID: {pid})\n")
        else:
            print("⚠️ Trader original non trouvé, l'intégration continuera mais le redémarrage sera impossible\n")
        
        print("5. Modification du trader original...")
        if patch_original_trader():
            print("✅ Trader original modifié avec succès\n")
        else:
            print("❌ Échec de la modification du trader original\n")
            return 1
        
        print("6. Redémarrage du trader avec les optimisations...")
        if restart_original_trader():
            print("✅ Trader redémarré avec les optimisations\n")
        else:
            print("❌ Échec du redémarrage du trader\n")
            print("⚠️ Veuillez redémarrer manuellement le trader: python3 auto_trader_verified.py\n")
        
        print("\n" + "=" * 70)
        print(" INTÉGRATION TERMINÉE AVEC SUCCÈS ".center(70, "="))
        print("=" * 70)
        print("\nLes optimisations ont été intégrées à votre système de trading existant.")
        print("Votre trader continue de fonctionner avec les nouvelles optimisations.")
        print("Les performances et la stabilité sont maintenant améliorées.")
        
        return 0
        
    except Exception as e:
        print(f"❌ Erreur critique lors de l'intégration: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())