import krakenex
import json
import time
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API (nouvelles clés)
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

def test_krakenex_api():
    """Teste la connexion à l'API Kraken en utilisant la bibliothèque officielle krakenex"""
    logger.info("=== TEST KRAKENEX API ===")
    logger.info(f"Date et heure: {datetime.now().isoformat()}")
    
    try:
        # Initialiser l'API Kraken avec krakenex
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Tester une requête publique (pas d'authentification)
        logger.info("Test de l'API publique...")
        public_response = k.query_public('Ticker', {'pair': 'AUDIOUSD'})
        
        if 'error' in public_response and public_response['error']:
            logger.error(f"Erreur API publique: {public_response['error']}")
            return False
        else:
            logger.info("✅ API publique testée avec succès")
            audio_price = public_response['result']['AUDIOUSD']['c'][0]
            logger.info(f"Prix actuel d'AUDIO: {audio_price} USD")
        
        # Tester une requête privée (nécessite une authentification)
        logger.info("Test de l'API privée...")
        private_response = k.query_private('Balance')
        
        if 'error' in private_response and private_response['error']:
            logger.error(f"Erreur API privée: {private_response['error']}")
            return False
        else:
            logger.info("✅ API privée testée avec succès")
            logger.info("Balances récupérées:")
            for asset, balance in private_response['result'].items():
                if float(balance) > 0.001:
                    logger.info(f"  {asset}: {balance}")
            return True
    
    except Exception as e:
        logger.error(f"Erreur lors du test de l'API: {e}")
        return False

def trade_audio_with_krakenex():
    """Exécute un trade AUDIO en utilisant krakenex"""
    logger.info("=== TRADE AUDIO AVEC KRAKENEX ===")
    logger.info(f"Date et heure: {datetime.now().isoformat()}")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Récupérer les balances
        balances = k.query_private('Balance')
        
        if 'error' in balances and balances['error']:
            logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
            return False
        
        # Afficher les balances
        logger.info("Balances actuelles:")
        for asset, balance in balances['result'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Vérifier le solde AUDIO
        audio_balance = float(balances['result'].get('AUDIO', 0))
        
        if audio_balance < 10:
            logger.error(f"Solde AUDIO insuffisant: {audio_balance}")
            return False
        
        # Obtenir le prix actuel d'AUDIO
        ticker = k.query_public('Ticker', {'pair': 'AUDIOUSD'})
        current_price = float(ticker['result']['AUDIOUSD']['c'][0])
        logger.info(f"Prix actuel d'AUDIO: {current_price} USD")
        
        # Calculer le montant à vendre (5% de l'AUDIO disponible)
        amount_to_sell = audio_balance * 0.05
        amount_to_sell = round(amount_to_sell, 1)  # Arrondir à 1 décimale
        
        if amount_to_sell < 10:
            amount_to_sell = 10  # Minimum 10 AUDIO
            
        logger.info(f"Vente de {amount_to_sell} AUDIO à environ {current_price} USD")
        
        # Exécuter la vente
        sell_order = k.query_private('AddOrder', {
            'pair': 'AUDIOUSD',
            'type': 'sell',
            'ordertype': 'market',
            'volume': str(amount_to_sell)
        })
        
        if 'error' in sell_order and sell_order['error']:
            logger.error(f"Erreur lors de la vente: {sell_order['error']}")
            return False
        
        logger.info(f"✅ Ordre de vente placé avec succès: {sell_order['result']}")
        
        # Attendre la confirmation
        time.sleep(5)
        
        # Récupérer les nouvelles balances
        new_balances = k.query_private('Balance')
        
        logger.info("Nouvelles balances après la vente:")
        for asset, balance in new_balances['result'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Placer un ordre d'achat à un prix 2% inférieur
        buy_price = current_price * 0.98
        buy_price = round(buy_price, 5)  # Arrondir à 5 décimales
        
        # Récupérer le solde USD
        usd_balance = float(new_balances['result'].get('ZUSD', 0))
        
        if usd_balance < 5:
            logger.warning(f"Solde USD insuffisant pour l'achat: {usd_balance}")
            return True  # On considère que la vente a réussi
        
        # Calculer le montant à acheter
        amount_to_buy = (usd_balance * 0.95) / buy_price
        amount_to_buy = round(amount_to_buy, 1)  # Arrondir à 1 décimale
        
        logger.info(f"Placement d'un ordre d'achat de {amount_to_buy} AUDIO à {buy_price} USD")
        
        # Exécuter l'achat
        buy_order = k.query_private('AddOrder', {
            'pair': 'AUDIOUSD',
            'type': 'buy',
            'ordertype': 'limit',
            'price': str(buy_price),
            'volume': str(amount_to_buy)
        })
        
        if 'error' in buy_order and buy_order['error']:
            logger.error(f"Erreur lors de l'achat: {buy_order['error']}")
            return True  # On considère que la vente a réussi
        
        logger.info(f"✅ Ordre d'achat placé avec succès: {buy_order['result']}")
        
        # Enregistrer le trade dans un journal
        with open('audio_trades.log', 'a') as f:
            f.write(f"[{datetime.now().isoformat()}] VENTE: {amount_to_sell} AUDIO à {current_price} USD\n")
            f.write(f"[{datetime.now().isoformat()}] ACHAT: {amount_to_buy} AUDIO à {buy_price} USD\n")
            f.write("-" * 50 + "\n")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors du trade: {e}")
        return False

if __name__ == "__main__":
    print("\n=== DÉMARRAGE DU TEST KRAKENEX ===\n")
    
    # Tester la connexion à l'API
    if test_krakenex_api():
        print("\n✅ TEST KRAKENEX RÉUSSI")
        
        # Proposer d'exécuter un trade
        choice = input("\nVoulez-vous exécuter un trade AUDIO ? (o/n): ")
        
        if choice.lower() == 'o':
            if trade_audio_with_krakenex():
                print("\n✅ TRADE AUDIO RÉUSSI!")
            else:
                print("\n⚠️ LE TRADE AUDIO A ÉCHOUÉ")
    else:
        print("\n⚠️ TEST KRAKENEX ÉCHOUÉ")