#!/usr/bin/env python3
"""
Initialisation du système optimisé de trading
Ce script prépare et démarre le trader avec toutes les optimisations activées
Fonctionnalités:
- Vérification de l'environnement et des dépendances
- Mise en place des systèmes de surveillance
- Démarrage du trader avec optimisations
- Initialisation du watchdog système
"""
import os
import sys
import time
import json
import psutil
import logging
import subprocess
import threading
import datetime
from pathlib import Path

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("init_system.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("SystemInit")

# Constantes
MAX_RETRY = 3
TRADER_SCRIPT = "auto_trader_verified.py"
WATCHDOG_INTERVAL = 30  # secondes

def check_environment():
    """
    Vérifie l'environnement d'exécution et les variables nécessaires
    
    Returns:
        bool: True si l'environnement est correct
    """
    logger.info("🔍 Vérification de l'environnement...")
    
    # Vérifier les variables d'environnement
    required_vars = ['KRAKEN_API_KEY', 'KRAKEN_API_SECRET']
    missing_vars = [var for var in required_vars if not os.environ.get(var)]
    
    if missing_vars:
        logger.error(f"❌ Variables d'environnement manquantes: {', '.join(missing_vars)}")
        logger.info("⚠️ Tentative de chargement depuis .env...")
        
        try:
            # Charger depuis .env si le fichier existe
            if os.path.exists('.env'):
                with open('.env', 'r') as f:
                    for line in f:
                        if line.strip() and not line.startswith('#'):
                            key, value = line.strip().split('=', 1)
                            os.environ[key.strip()] = value.strip().strip('"').strip("'")
                
                # Vérifier à nouveau
                missing_vars = [var for var in required_vars if not os.environ.get(var)]
                if not missing_vars:
                    logger.info("✅ Variables chargées depuis .env")
                else:
                    logger.error(f"❌ Variables toujours manquantes après chargement .env: {', '.join(missing_vars)}")
                    return False
            else:
                logger.error("❌ Fichier .env introuvable")
                return False
        except Exception as e:
            logger.error(f"❌ Erreur lors du chargement de .env: {e}")
            return False
    
    # Vérifier les fichiers requis
    required_files = [TRADER_SCRIPT, 'optimizations.py']
    for file in required_files:
        if not os.path.exists(file):
            logger.error(f"❌ Fichier requis manquant: {file}")
            return False
    
    # Vérifier les dépendances Python
    try:
        import optimizations
        logger.info("✅ Module optimizations importé avec succès")
    except ImportError:
        logger.error("❌ Module optimizations introuvable")
        return False
    
    logger.info("✅ Environnement validé")
    return True

def initialize_monitoring():
    """
    Initialise le système de surveillance et métriques
    
    Returns:
        bool: True si l'initialisation est réussie
    """
    logger.info("🔧 Initialisation du système de surveillance...")
    
    try:
        # Créer le dossier de logs si nécessaire
        os.makedirs('logs', exist_ok=True)
        
        # Initialiser le fichier de métriques
        metrics = {
            'start_time': time.time(),
            'cpu_percent': psutil.cpu_percent(),
            'memory_percent': psutil.virtual_memory().percent,
            'system_status': 'initializing'
        }
        
        with open('system_metrics.json', 'w') as f:
            json.dump(metrics, f, indent=2)
        
        logger.info("✅ Système de surveillance initialisé")
        return True
    
    except Exception as e:
        logger.error(f"❌ Erreur lors de l'initialisation du système de surveillance: {e}")
        return False

def check_existing_processes():
    """
    Vérifie si des instances du trader sont déjà en cours d'exécution
    
    Returns:
        list: Liste des PID des processus existants
    """
    logger.info("🔍 Recherche d'instances existantes du trader...")
    existing_pids = []
    
    # Vérifier via les fichiers PID
    pid_files = ['auto_trader_pid.txt', 'trader.pid', 'bot_pid.txt']
    for pid_file in pid_files:
        if os.path.exists(pid_file):
            try:
                with open(pid_file, 'r') as f:
                    pid = int(f.read().strip())
                    try:
                        # Vérifier si le processus existe
                        process = psutil.Process(pid)
                        if TRADER_SCRIPT in ' '.join(process.cmdline()):
                            existing_pids.append(pid)
                            logger.info(f"✅ Instance existante trouvée: PID {pid}")
                    except psutil.NoSuchProcess:
                        logger.info(f"⚠️ PID {pid} dans {pid_file} n'existe plus, fichier obsolète")
            except Exception as e:
                logger.error(f"❌ Erreur lors de la lecture de {pid_file}: {e}")
    
    # Rechercher via psutil
    for process in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmdline = ' '.join(process.cmdline()) if process.cmdline() else ''
            if TRADER_SCRIPT in cmdline and process.pid not in existing_pids:
                existing_pids.append(process.pid)
                logger.info(f"✅ Instance existante trouvée via psutil: PID {process.pid}")
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    
    if not existing_pids:
        logger.info("✅ Aucune instance existante trouvée")
    
    return existing_pids

def stop_existing_processes(pids):
    """
    Arrête les instances existantes du trader
    
    Args:
        pids (list): Liste des PID à arrêter
        
    Returns:
        bool: True si tous les processus ont été arrêtés
    """
    if not pids:
        return True
    
    logger.info(f"🛑 Arrêt des instances existantes: {pids}")
    all_stopped = True
    
    for pid in pids:
        try:
            process = psutil.Process(pid)
            process.terminate()
            
            # Attendre que le processus se termine (max 5 secondes)
            process.wait(5)
            logger.info(f"✅ Processus {pid} arrêté")
        except psutil.NoSuchProcess:
            logger.info(f"⚠️ Processus {pid} déjà terminé")
        except psutil.TimeoutExpired:
            logger.warning(f"⚠️ Processus {pid} ne répond pas, tentative de kill")
            try:
                process.kill()
                logger.info(f"✅ Processus {pid} forcé")
            except Exception as e:
                logger.error(f"❌ Impossible de tuer le processus {pid}: {e}")
                all_stopped = False
        except Exception as e:
            logger.error(f"❌ Erreur lors de l'arrêt du processus {pid}: {e}")
            all_stopped = False
    
    # Nettoyer les fichiers PID
    pid_files = ['auto_trader_pid.txt', 'trader.pid', 'bot_pid.txt']
    for pid_file in pid_files:
        if os.path.exists(pid_file):
            try:
                os.remove(pid_file)
                logger.debug(f"Fichier PID supprimé: {pid_file}")
            except Exception as e:
                logger.error(f"❌ Erreur lors de la suppression de {pid_file}: {e}")
    
    return all_stopped

def start_trader():
    """
    Démarre le trader avec les optimisations
    
    Returns:
        int: PID du trader ou None en cas d'échec
    """
    logger.info("🚀 Démarrage du trader optimisé...")
    
    try:
        # Lancer le processus en arrière-plan
        process = subprocess.Popen(
            [sys.executable, TRADER_SCRIPT],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        # Attendre un peu pour s'assurer que le processus démarre
        time.sleep(2)
        
        # Vérifier que le processus est toujours en cours d'exécution
        if process.poll() is not None:
            logger.error(f"❌ Le trader a quitté prématurément avec le code: {process.poll()}")
            stdout, _ = process.communicate()
            logger.error(f"Sortie du processus: {stdout}")
            return None
        
        logger.info(f"✅ Trader démarré avec le PID: {process.pid}")
        
        # Enregistrer les métriques
        with open('system_metrics.json', 'r+') as f:
            metrics = json.load(f)
            metrics['trader_pid'] = process.pid
            metrics['trader_start_time'] = time.time()
            metrics['system_status'] = 'running'
            f.seek(0)
            json.dump(metrics, f, indent=2)
            f.truncate()
        
        return process.pid
    
    except Exception as e:
        logger.error(f"❌ Erreur lors du démarrage du trader: {e}")
        return None

def watchdog_process(pid):
    """
    Surveille un processus et le redémarre si nécessaire
    
    Args:
        pid (int): PID du processus à surveiller
    """
    logger.info(f"🔍 Démarrage du watchdog pour le PID {pid}")
    
    while True:
        try:
            # Vérifier si le processus existe
            process = psutil.Process(pid)
            
            # Vérifier le statut du processus
            process_status = process.status()
            
            # Vérifier le heartbeat
            heartbeat_file = "bot_heartbeat.txt"
            if os.path.exists(heartbeat_file):
                try:
                    # Vérifier l'âge du fichier
                    last_heartbeat = os.path.getmtime(heartbeat_file)
                    heartbeat_age = time.time() - last_heartbeat
                    
                    if heartbeat_age > 60:  # Pas de heartbeat depuis plus d'une minute
                        logger.warning(f"⚠️ Aucun heartbeat depuis {heartbeat_age:.1f}s - redémarrage du trader")
                        
                        # Redémarrer le processus
                        process.terminate()
                        time.sleep(5)
                        new_pid = start_trader()
                        if new_pid:
                            logger.info(f"✅ Trader redémarré avec le PID {new_pid}")
                            pid = new_pid
                        else:
                            logger.error("❌ Échec du redémarrage du trader")
                except Exception as e:
                    logger.error(f"❌ Erreur lors de la vérification du heartbeat: {e}")
            
            # Mise à jour des métriques
            try:
                cpu_percent = process.cpu_percent(interval=1)
                memory_info = process.memory_info()
                memory_mb = memory_info.rss / (1024 * 1024)
                
                with open('system_metrics.json', 'r+') as f:
                    metrics = json.load(f)
                    metrics['cpu_percent'] = cpu_percent
                    metrics['memory_mb'] = memory_mb
                    metrics['last_check'] = time.time()
                    metrics['process_status'] = process_status
                    metrics['uptime'] = time.time() - metrics.get('trader_start_time', time.time())
                    f.seek(0)
                    json.dump(metrics, f, indent=2)
                    f.truncate()
            except Exception as e:
                logger.error(f"❌ Erreur lors de la mise à jour des métriques: {e}")
            
            # Attendre pour la prochaine vérification
            time.sleep(WATCHDOG_INTERVAL)
        
        except psutil.NoSuchProcess:
            logger.error(f"❌ Processus {pid} introuvable - redémarrage du trader")
            
            # Redémarrer le processus
            new_pid = start_trader()
            if new_pid:
                logger.info(f"✅ Trader redémarré avec le PID {new_pid}")
                pid = new_pid
            else:
                logger.error("❌ Échec du redémarrage du trader")
                
                # Attendre avant la prochaine tentative
                time.sleep(60)
        
        except Exception as e:
            logger.error(f"❌ Erreur dans le watchdog: {e}")
            time.sleep(60)  # Attendre avant de réessayer

def main():
    """Fonction principale"""
    logger.info("=" * 80)
    logger.info("🚀 INITIALISATION DU SYSTÈME DE TRADING OPTIMISÉ")
    logger.info("=" * 80)
    
    # Vérifier l'environnement
    if not check_environment():
        logger.error("❌ L'environnement n'est pas correctement configuré")
        return False
    
    # Initialiser le système de surveillance
    if not initialize_monitoring():
        logger.error("❌ Échec de l'initialisation du système de surveillance")
        return False
    
    # Vérifier et arrêter les instances existantes
    existing_pids = check_existing_processes()
    if existing_pids and not stop_existing_processes(existing_pids):
        logger.error("❌ Impossible d'arrêter toutes les instances existantes")
        return False
    
    # Démarrer le trader
    trader_pid = start_trader()
    if not trader_pid:
        logger.error("❌ Échec du démarrage du trader")
        return False
    
    # Démarrer le watchdog dans un thread
    watchdog_thread = threading.Thread(target=watchdog_process, args=(trader_pid,))
    watchdog_thread.daemon = True
    watchdog_thread.start()
    
    logger.info("✅ Système de trading optimisé initialisé avec succès")
    logger.info(f"✅ Watchdog démarré pour le PID {trader_pid}")
    logger.info("=" * 80)
    
    # Maintenir le processus en vie
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("⚠️ Interruption utilisateur reçue")
        
        # Mettre à jour les métriques
        with open('system_metrics.json', 'r+') as f:
            metrics = json.load(f)
            metrics['system_status'] = 'stopping'
            f.seek(0)
            json.dump(metrics, f, indent=2)
            f.truncate()
        
        # Arrêter le trader
        try:
            process = psutil.Process(trader_pid)
            process.terminate()
            process.wait(5)
            logger.info(f"✅ Trader arrêté (PID {trader_pid})")
        except Exception as e:
            logger.error(f"❌ Erreur lors de l'arrêt du trader: {e}")
        
        # Mettre à jour les métriques finales
        with open('system_metrics.json', 'r+') as f:
            metrics = json.load(f)
            metrics['system_status'] = 'stopped'
            metrics['stop_time'] = time.time()
            f.seek(0)
            json.dump(metrics, f, indent=2)
            f.truncate()
    
    return True

if __name__ == "__main__":
    main()