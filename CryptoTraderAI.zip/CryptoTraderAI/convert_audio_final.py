import ccxt
import time
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API corrigées
API_KEY = "9/KUxib19lkk7FukHnbupTEBYHIFcKsKtGAEW3/krj89u0jC/fYhrwfD"
API_SECRET = "RKJ9m8mLgfDN07bMEvxubD6bY/avyqsQGe6Ev1APMBvBFCvBjXpKGyI5rmR1iJT8U5aVbuHJoY0OI9cprH9qSg=="

def convert_audio_to_other_volatile():
    """Convertit une partie de l'AUDIO en d'autres cryptos volatiles"""
    logger.info("=== CONVERSION AUDIO -> AUTRES CRYPTOS VOLATILES ===")
    logger.info(f"Date et heure: {datetime.now().isoformat()}")
    
    try:
        # Initialiser l'exchange
        exchange = ccxt.kraken({
            'apiKey': API_KEY,
            'secret': API_SECRET,
            'enableRateLimit': True
        })
        
        # Charger les marchés
        markets = exchange.load_markets()
        logger.info(f"Marchés chargés: {len(markets)} paires disponibles")
        
        # Récupérer les balances
        balances = exchange.fetch_balance()
        
        # Afficher les balances non nulles
        logger.info("Balances actuelles:")
        for asset, balance in balances['total'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Vérifier le solde AUDIO
        audio_balance = float(balances['total'].get('AUDIO', 0))
        
        if audio_balance < 10:
            logger.error(f"Solde AUDIO insuffisant: {audio_balance}")
            return False
        
        # Calculer le montant à vendre (40% de l'AUDIO disponible)
        amount_to_sell = audio_balance * 0.40
        logger.info(f"Vente de {amount_to_sell} AUDIO (40% du solde total)")
        
        # Vendre AUDIO pour USD
        symbol = "AUDIO/USD"
        
        if symbol in markets:
            try:
                logger.info(f"Récupération du minimum order pour {symbol}")
                market_info = markets[symbol]
                min_amount = market_info.get('limits', {}).get('amount', {}).get('min', 1)
                logger.info(f"Montant minimum pour {symbol}: {min_amount}")
                
                # S'assurer que le montant à vendre est supérieur au minimum
                if amount_to_sell < min_amount:
                    amount_to_sell = min_amount * 1.1  # 10% au-dessus du minimum pour être sûr
                    logger.info(f"Montant ajusté à {amount_to_sell} pour respecter le minimum")
                
                logger.info(f"Vente de {amount_to_sell} AUDIO via {symbol}")
                order = exchange.create_market_sell_order(symbol, amount_to_sell)
                logger.info(f"Vente effectuée: {order}")
            except Exception as e:
                logger.error(f"Erreur lors de la vente de AUDIO: {e}")
                return False
        else:
            logger.error(f"Paire {symbol} non disponible")
            return False
        
        # Attendre que la vente soit finalisée
        logger.info("Attente de la finalisation de la vente...")
        time.sleep(5)
        
        # Récupérer les nouvelles balances
        new_balances = exchange.fetch_balance()
        
        # Récupérer le solde USD
        usd_balance = float(new_balances['free'].get('USD', 0))
        
        logger.info(f"Solde USD disponible: {usd_balance}")
        
        if usd_balance < 5:
            logger.error(f"Solde USD insuffisant pour acheter d'autres cryptos: {usd_balance}")
            return False
        
        # Liste des actifs volatils cibles (sans AUDIO)
        volatile_targets = ['DOGE', 'SHIB', 'MATIC', 'MANA', 'DOT', 'ATOM', 'ALGO']
        
        # Acheter un actif volatil avec USD
        purchased = False
        
        for asset in volatile_targets:
            symbol = f"{asset}/USD"
            if symbol in markets:
                logger.info(f"Vérification des informations pour {symbol}")
                try:
                    # Vérifier les limites de la paire
                    market_info = markets[symbol]
                    min_cost = market_info.get('limits', {}).get('cost', {}).get('min', 5)
                    
                    # S'assurer que le solde USD est suffisant
                    if usd_balance * 0.95 < min_cost:
                        logger.warning(f"Solde USD ({usd_balance * 0.95}) inférieur au minimum requis ({min_cost}) pour {symbol}")
                        continue
                    
                    logger.info(f"Achat de {asset} avec {usd_balance * 0.95} USD via {symbol}")
                    
                    # Utiliser 95% du solde USD pour tenir compte des frais
                    order = exchange.create_market_buy_order(symbol, None, {'cost': usd_balance * 0.95})
                    logger.info(f"Achat effectué: {order}")
                    purchased = True
                    break
                except Exception as e:
                    logger.error(f"Erreur lors de l'achat de {asset}: {e}")
        
        # Afficher les balances finales
        final_balances = exchange.fetch_balance()
        
        logger.info("Balances finales après conversion:")
        for asset, balance in final_balances['total'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        if purchased:
            logger.info("✅ CONVERSION RÉUSSIE!")
            return True
        else:
            logger.warning("⚠️ Aucun achat d'actif volatil n'a pu être effectué")
            return False
        
    except Exception as e:
        logger.error(f"❌ Erreur critique lors de la conversion: {e}")
        return False

if __name__ == "__main__":
    if convert_audio_to_other_volatile():
        print("\n✅ CONVERSION TERMINÉE AVEC SUCCÈS!")
    else:
        print("\n⚠️ La conversion n'a pas pu être complétée")