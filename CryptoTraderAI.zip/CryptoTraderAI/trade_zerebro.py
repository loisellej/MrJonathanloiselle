#!/usr/bin/env python3
"""
TRADER ZEREBRO ULTRA-OPTIMISÉ
- Trader spécialisé sur ZEREBRO ultra-volatil
- Acheter quand baisse, vendre quand hausse
- Stop-loss serré à 0.5-0.8%
- Objectif 2-3% par trade
"""

import krakenex
import time
import logging
import threading
import os
from datetime import datetime, timedelta

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API directement intégrées
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

class ZerebroTrader:
    def __init__(self):
        """Initialise le trader ZEREBRO"""
        self.k = krakenex.API(API_KEY, API_SECRET)
        self.running = False
        self.thread = None
        self.price_history = []
        self.entry_price = None
        self.target_profit_rate = 0.03  # 3%
        self.stop_loss_rate = 0.006  # 0.6%
        self.target_price = None
        self.stop_loss_price = None
        self.position_size = 0
        self.last_price = 0
        
        logger.info("🟢 Trader ZEREBRO initialisé")
    
    def get_balance(self, asset="ZEREBRO"):
        """Récupère le solde de l'actif"""
        try:
            balances = self.k.query_private('Balance')
            
            if 'error' in balances and balances['error']:
                logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
                return 0
            
            return float(balances['result'].get(asset, 0))
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du solde {asset}: {e}")
            return 0
    
    def get_usd_balance(self):
        """Récupère le solde USD"""
        try:
            balances = self.k.query_private('Balance')
            
            if 'error' in balances and balances['error']:
                logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
                return 0
            
            return float(balances['result'].get('ZUSD', 0))
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du solde USD: {e}")
            return 0
    
    def get_current_price(self, asset="ZEREBRO"):
        """Récupère le prix actuel de l'actif"""
        try:
            ticker = self.k.query_public('Ticker', {'pair': f"{asset}USD"})
            
            if 'error' in ticker and ticker['error']:
                logger.error(f"Erreur lors de la récupération du prix: {ticker['error']}")
                return None
            
            return float(ticker['result'][f"{asset}USD"]['c'][0])
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix: {e}")
            return None
    
    def buy(self, amount_percentage=1.0):
        """Acheter ZEREBRO"""
        try:
            usd_balance = self.get_usd_balance()
            
            if usd_balance < 5:
                logger.warning(f"Solde USD insuffisant: {usd_balance} USD")
                return False
            
            amount_usd = usd_balance * amount_percentage
            
            price = self.get_current_price()
            if not price:
                return False
            
            volume = amount_usd / price * 0.995  # Réduction légère pour compenser les fluctuations
            
            logger.info(f"🔄 Achat de ZEREBRO pour {amount_usd:.2f} USD à {price:.6f} USD/ZEREBRO")
            
            order = self.k.query_private('AddOrder', {
                'pair': 'ZEREBROUSD',
                'type': 'buy',
                'ordertype': 'market',
                'volume': str(volume)
            })
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur lors de l'achat: {order['error']}")
                return False
            
            logger.info(f"✅ Ordre d'achat placé avec succès: {order['result']['txid'][0]}")
            
            # Définir les paramètres de sortie
            self.entry_price = price
            self.position_size = volume
            self.target_price = price * (1 + self.target_profit_rate)
            self.stop_loss_price = price * (1 - self.stop_loss_rate)
            
            logger.info(f"🎯 Prix d'entrée: {self.entry_price:.6f} USD")
            logger.info(f"🔼 Objectif de sortie: {self.target_price:.6f} USD (+{self.target_profit_rate*100:.1f}%)")
            logger.info(f"🔽 Stop loss: {self.stop_loss_price:.6f} USD (-{self.stop_loss_rate*100:.1f}%)")
            
            return True
        except Exception as e:
            logger.error(f"Erreur lors de l'achat: {e}")
            return False
    
    def sell(self, amount_percentage=1.0):
        """Vendre ZEREBRO"""
        try:
            zerebro_balance = self.get_balance()
            
            if zerebro_balance < 1:
                logger.warning(f"Solde ZEREBRO insuffisant: {zerebro_balance}")
                return False
            
            volume = zerebro_balance * amount_percentage
            
            price = self.get_current_price()
            if not price:
                return False
            
            logger.info(f"🔄 Vente de {volume:.2f} ZEREBRO à {price:.6f} USD/ZEREBRO")
            
            order = self.k.query_private('AddOrder', {
                'pair': 'ZEREBROUSD',
                'type': 'sell',
                'ordertype': 'market',
                'volume': str(volume)
            })
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur lors de la vente: {order['error']}")
                return False
            
            logger.info(f"✅ Ordre de vente placé avec succès: {order['result']['txid'][0]}")
            
            # Réinitialiser les paramètres
            profit = None
            if self.entry_price:
                profit_pct = (price / self.entry_price - 1) * 100
                profit = profit_pct
                logger.info(f"💰 Profit réalisé: {profit_pct:.2f}%")
            
            self.entry_price = None
            self.position_size = 0
            self.target_price = None
            self.stop_loss_price = None
            
            return True
        except Exception as e:
            logger.error(f"Erreur lors de la vente: {e}")
            return False
    
    def monitor_position(self):
        """Surveille la position actuelle pour le profit target ou stop loss"""
        if not self.entry_price or not self.target_price or not self.stop_loss_price:
            return
        
        price = self.get_current_price()
        if not price:
            return
        
        # Calculer le profit actuel
        profit_pct = (price / self.entry_price - 1) * 100
        
        logger.info(f"Prix actuel: {price:.6f} USD, Profit actuel: {profit_pct:.2f}%")
        
        # Vérifier si on atteint le target profit
        if price >= self.target_price:
            logger.info(f"🎯 OBJECTIF DE PROFIT ATTEINT! Vente à +{profit_pct:.2f}%")
            self.sell()
        
        # Vérifier si on atteint le stop loss
        elif price <= self.stop_loss_price:
            logger.info(f"⚠️ STOP LOSS DÉCLENCHÉ! Vente à {profit_pct:.2f}%")
            self.sell()
    
    def trading_loop(self):
        """Boucle principale de trading"""
        logger.info("🔄 Démarrage de la boucle de trading ZEREBRO")
        
        check_interval = 15  # Vérification toutes les 15 secondes
        decision_interval = 60  # Prise de décision toutes les minutes
        last_decision_time = time.time()
        
        zerebro_balance = self.get_balance()
        usd_balance = self.get_usd_balance()
        
        logger.info(f"Balance initiale: {zerebro_balance:.2f} ZEREBRO, {usd_balance:.2f} USD")
        
        # Si on a des ZEREBRO mais pas d'entrée définie, on définit l'entrée
        if zerebro_balance > 1 and not self.entry_price:
            price = self.get_current_price()
            if price:
                self.entry_price = price
                self.position_size = zerebro_balance
                self.target_price = price * (1 + self.target_profit_rate)
                self.stop_loss_price = price * (1 - self.stop_loss_rate)
                
                logger.info(f"Position existante détectée: {zerebro_balance:.2f} ZEREBRO")
                logger.info(f"🎯 Prix d'entrée estimé: {self.entry_price:.6f} USD")
                logger.info(f"🔼 Objectif de sortie: {self.target_price:.6f} USD (+{self.target_profit_rate*100:.1f}%)")
                logger.info(f"🔽 Stop loss: {self.stop_loss_price:.6f} USD (-{self.stop_loss_rate*100:.1f}%)")
        
        try:
            while self.running:
                current_time = time.time()
                
                # Obtenir le prix actuel
                price = self.get_current_price()
                if price:
                    self.last_price = price
                    self.price_history.append((datetime.now(), price))
                    
                    # Garder l'historique récent seulement (24 heures)
                    cutoff_time = datetime.now() - timedelta(hours=24)
                    self.price_history = [(t, p) for t, p in self.price_history if t >= cutoff_time]
                
                # Si nous avons une position, surveiller pour le profit target ou stop loss
                zerebro_balance = self.get_balance()
                if zerebro_balance > 1 and self.entry_price:
                    self.monitor_position()
                
                # Prise de décision périodique
                if current_time - last_decision_time >= decision_interval:
                    last_decision_time = current_time
                    
                    # Analyse des conditions de marché
                    zerebro_balance = self.get_balance()
                    usd_balance = self.get_usd_balance()
                    
                    logger.info(f"Balance actuelle: {zerebro_balance:.2f} ZEREBRO, {usd_balance:.2f} USD")
                    
                    # Si nous n'avons pas de position et avons de l'USD, analyser pour un achat
                    if zerebro_balance < 1 and usd_balance > 5:
                        # Ici on pourrait ajouter une logique d'analyse plus complexe
                        logger.info("Analyse des conditions d'achat...")
                        
                        # Pour l'instant, on achète directement avec tout l'USD disponible
                        self.buy()
                
                time.sleep(check_interval)
        except Exception as e:
            logger.error(f"Erreur dans la boucle de trading: {e}")
        finally:
            logger.info("Boucle de trading arrêtée")
    
    def start(self):
        """Démarrer le trader"""
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        self.running = True
        self.thread = threading.Thread(target=self.trading_loop)
        self.thread.daemon = True
        self.thread.start()
        
        logger.info("🚀 Trader ZEREBRO démarré")
        return True
    
    def stop(self):
        """Arrêter le trader"""
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        self.running = False
        if self.thread:
            self.thread.join(timeout=2)
        
        logger.info("🛑 Trader ZEREBRO arrêté")
        return True


def main():
    """Fonction principale"""
    print("=" * 80)
    print("DÉMARRAGE DU TRADER ZEREBRO ULTRA-OPTIMISÉ")
    print("=" * 80)
    
    # Initialiser le trader
    trader = ZerebroTrader()
    
    # Vérifier les balances
    zerebro_balance = trader.get_balance()
    usd_balance = trader.get_usd_balance()
    price = trader.get_current_price()
    
    print(f"\nBalances initiales:")
    print(f"  ZEREBRO: {zerebro_balance:.2f} tokens")
    print(f"  USD: {usd_balance:.2f} USD")
    
    if price:
        zerebro_value = zerebro_balance * price
        print(f"  Prix actuel: {price:.6f} USD/ZEREBRO")
        print(f"  Valeur ZEREBRO: {zerebro_value:.2f} USD")
        print(f"  Valeur totale: {zerebro_value + usd_balance:.2f} USD")
    
    # Démarrer le trader
    print("\nDémarrage du trader...")
    trader.start()
    
    print("\n" + "!" * 80)
    print("TRADER DÉMARRÉ AVEC SUCCÈS!")
    print("Le système surveille maintenant ZEREBRO en continu")
    print("!" * 80)
    
    # Surveiller le trader pour voir les profits
    try:
        while True:
            time.sleep(60)  # Mise à jour toutes les minutes
            
            zerebro_balance = trader.get_balance()
            usd_balance = trader.get_usd_balance()
            price = trader.get_current_price()
            
            if not price:
                continue
            
            zerebro_value = zerebro_balance * price
            total_value = zerebro_value + usd_balance
            
            print(f"\n[{datetime.now().strftime('%H:%M:%S')}] STATUT:")
            print(f"  ZEREBRO: {zerebro_balance:.2f} tokens (≈ {zerebro_value:.2f} USD)")
            print(f"  USD: {usd_balance:.2f} USD")
            print(f"  Total: {total_value:.2f} USD")
            
            if trader.entry_price:
                profit_pct = (price / trader.entry_price - 1) * 100
                print(f"  Position: +{profit_pct:.2f}% depuis l'entrée à {trader.entry_price:.6f} USD")
                print(f"  Objectif: {trader.target_price:.6f} USD (+{trader.target_profit_rate*100:.1f}%)")
                print(f"  Stop Loss: {trader.stop_loss_price:.6f} USD (-{trader.stop_loss_rate*100:.1f}%)")
    
    except KeyboardInterrupt:
        print("\nArrêt demandé par l'utilisateur...")
        trader.stop()
        print("Trader arrêté avec succès.")


if __name__ == "__main__":
    main()