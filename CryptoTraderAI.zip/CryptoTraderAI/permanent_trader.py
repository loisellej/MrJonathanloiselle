import krakenex
import time
import logging
import threading
import json
import os
from datetime import datetime, timedelta
import random
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.FileHandler("trading.log"),
                        logging.StreamHandler()
                    ])
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

# Liste des crypto-monnaies à surveiller
WATCH_LIST = [
    "ZEREBRO", "MANA", "FTM", "GARI", "AVAX", "LINK", "DOGE", "SHIB", "MATIC",
    "DOT", "ADA", "SOL", "ATOM", "XRP", "SAND", "ALGO", "ENJ", "1INCH", "AAVE", "KAVA", "DYDX"
]

# Crypto-monnaies à exclure (selon la demande du client)
EXCLUDE_LIST = ["BTC", "ETH", "SOL"]

class PermanentTrader:
    def __init__(self, api_key=None, api_secret=None):
        """
        Initialise le trader permanent
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
        """
        # Utiliser les clés API fournies ou les clés par défaut
        self.api_key = api_key if api_key else API_KEY
        self.api_secret = api_secret if api_secret else API_SECRET
        
        self.k = krakenex.API(self.api_key, self.api_secret)
        
        self.running = False
        self.threads = []
        
        # Initialiser l'analyseur de sentiment
        self.sentiment_analyzer = SentimentIntensityAnalyzer()
        
        # Cache pour les prix et les scores
        self.price_cache = {}
        self.volatility_scores = {}
        self.trend_scores = {}
        self.combined_scores = {}
        self.last_analysis_time = datetime.now() - timedelta(hours=1)  # Forcer une analyse au démarrage
        
        # Positions actuelles
        self.current_positions = {}
        self.usd_balance = 0
        
        # État des trades
        self.pending_trades = {}
        self.trade_history = []
        
        logger.info("🚀 Permanent Trader initialisé")
    
    def update_balances(self):
        """Mise à jour des balances du compte"""
        try:
            balances = self.k.query_private('Balance')
            
            if 'error' in balances and balances['error']:
                logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
                return False
            
            self.current_positions = {}
            self.usd_balance = float(balances['result'].get('ZUSD', 0))
            
            for asset, balance in balances['result'].items():
                if asset == 'ZUSD':
                    continue
                    
                balance_float = float(balance)
                if balance_float > 0.001:  # Ignorer les très petits soldes
                    self.current_positions[asset] = balance_float
            
            logger.info(f"Balances mises à jour: {len(self.current_positions)} actifs trouvés")
            logger.info(f"Solde USD: {self.usd_balance} USD")
            
            # Journaliser les actifs avec un solde significatif
            significant_assets = []
            for asset, balance in self.current_positions.items():
                try:
                    # Obtenir le prix actuel
                    ticker_pair = f"{asset}USD"
                    ticker = self.k.query_public('Ticker', {'pair': ticker_pair})
                    
                    if 'error' not in ticker or not ticker['error']:
                        price = float(ticker['result'][ticker_pair]['c'][0])
                        usd_value = price * balance
                        
                        if usd_value > 5:  # Plus de 5 USD
                            significant_assets.append(f"{asset}: {balance:.4f} (~{usd_value:.2f} USD)")
                except Exception as e:
                    logger.warning(f"Impossible d'obtenir le prix pour {asset}: {e}")
            
            if significant_assets:
                logger.info(f"Actifs significatifs: {', '.join(significant_assets)}")
            
            return True
        except Exception as e:
            logger.error(f"Erreur lors de la mise à jour des balances: {e}")
            return False
    
    def analyze_assets(self, force=False):
        """Analyse tous les actifs pour trouver les plus volatils en uptrend avec un potentiel de profit rapide"""
        now = datetime.now()
        
        # Analyse plus fréquente: toutes les 10 minutes pour repérer rapidement les mouvements
        if not force and (now - self.last_analysis_time).total_seconds() < 600:  # 10 minutes
            logger.info("Analyse récente déjà disponible, utilisation des scores existants")
            return self.combined_scores
        
        logger.info("=== ANALYSE AVANCÉE DES CRYPTOS VOLATILES EN UPTREND ===")
        
        # Réinitialiser les scores
        self.volatility_scores = {}
        self.trend_scores = {}
        self.combined_scores = {}
        
        # Données additionnelles pour une analyse plus intelligente
        momentum_scores = {}  # Force du momentum
        volume_scores = {}    # Changements récents dans le volume
        rsi_scores = {}       # Indicateur de surachat/survente
        profit_potential = {} # Potentiel de profit après frais
        
        # Construire la liste des actifs à analyser
        assets_to_analyze = list(set(WATCH_LIST) | set(self.current_positions.keys()))
        assets_to_analyze = [asset for asset in assets_to_analyze if asset not in EXCLUDE_LIST]
        
        logger.info(f"Analyse approfondie de {len(assets_to_analyze)} actifs...")
        
        for asset in assets_to_analyze:
            try:
                # Obtenir des données sur différents timeframes pour une analyse complète
                # Timeframes courts pour réactivité, timeframes longs pour confirmation
                timeframes = {
                    '5m': 5,      # 5 minutes pour réactivité maximale
                    '15m': 15,    # 15 minutes pour confirmation court terme
                    '1h': 60,     # 1 heure pour tendance intermédiaire
                    '4h': 240     # 4 heures pour tendance plus établie
                }
                
                asset_data = {}
                
                # Récupérer les données pour chaque timeframe
                for tf_name, tf_minutes in timeframes.items():
                    try:
                        pair = f"{asset}/USD"
                        
                        # Vérifier si la paire est disponible
                        ticker = self.k.query_public('Ticker', {'pair': pair})
                        
                        if 'error' in ticker and ticker['error']:
                            # Si la paire n'existe pas, essayer avec USDT
                            pair = f"{asset}/USDT"
                            ticker = self.k.query_public('Ticker', {'pair': pair})
                        
                        if 'error' in ticker and ticker['error']:
                            logger.warning(f"La paire {asset}/USD et {asset}/USDT n'est pas disponible sur Kraken")
                            continue
                        
                        # Obtenir le ticker format Kraken
                        kraken_pair = list(ticker['result'].keys())[0]
                        
                        # Mettre à jour le cache de prix avec le dernier prix
                        current_price = float(ticker['result'][kraken_pair]['c'][0])
                        self.price_cache[asset] = current_price
                        
                        # Récupérer le volume de trading actuel
                        current_volume = float(ticker['result'][kraken_pair]['v'][1])  # Volume 24h
                        
                        # Récupérer l'historique des prix pour ce timeframe
                        ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': tf_minutes})
                        
                        if 'error' in ohlc and ohlc['error']:
                            logger.warning(f"Erreur lors de la récupération des données OHLC pour {pair} ({tf_name}): {ohlc['error']}")
                            continue
                        
                        # Récupérer les données OHLC (Open, High, Low, Close, Volume)
                        ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
                        
                        # Stocker pour analyse
                        asset_data[tf_name] = {
                            'ohlc': ohlc_data,
                            'price': current_price,
                            'volume': current_volume
                        }
                        
                    except Exception as e:
                        logger.error(f"Erreur lors de la récupération des données pour {asset} ({tf_name}): {e}")
                        continue
                
                # Si aucune donnée récupérée, passer à l'actif suivant
                if not asset_data:
                    logger.warning(f"Aucune donnée disponible pour {asset}")
                    continue
                
                # === ANALYSE MULTI-TIMEFRAME ===
                
                # Variables pour stocker les résultats d'analyse
                volatility_by_tf = {}
                trend_by_tf = {}
                volume_change_by_tf = {}
                momentum_by_tf = {}
                rsi_by_tf = {}
                
                # Calculer les métriques pour chaque timeframe
                for tf_name, data in asset_data.items():
                    ohlc_data = data['ohlc']
                    
                    # Extraire les prix et volumes
                    close_prices = [float(item[4]) for item in ohlc_data[-20:]]  # 20 dernières périodes
                    volumes = [float(item[6]) for item in ohlc_data[-20:]]       # Volumes correspondants
                    
                    # 1. Calcul de volatilité amélioré (plus de poids aux mouvements récents)
                    recent_price_changes = [abs(close_prices[i] - close_prices[i-1]) / close_prices[i-1] * 100 for i in range(1, len(close_prices))]
                    
                    # Donner plus de poids aux changements récents
                    weighted_volatility = 0
                    weight_sum = 0
                    
                    for i, change in enumerate(recent_price_changes):
                        weight = (i + 1) ** 2  # Poids quadratique pour favoriser fortement les mouvements récents
                        weighted_volatility += change * weight
                        weight_sum += weight
                    
                    volatility = weighted_volatility / weight_sum if weight_sum > 0 else 0
                    volatility_by_tf[tf_name] = volatility
                    
                    # 2. Calcul de tendance avec détection de retournement
                    # Tendance globale
                    overall_trend = (close_prices[-1] - close_prices[0]) / close_prices[0] * 100
                    
                    # Tendance récente (5 dernières périodes)
                    recent_trend = (close_prices[-1] - close_prices[-6]) / close_prices[-6] * 100 if len(close_prices) >= 6 else overall_trend
                    
                    # Tendance immédiate (2 dernières périodes)
                    immediate_trend = (close_prices[-1] - close_prices[-3]) / close_prices[-3] * 100 if len(close_prices) >= 3 else recent_trend
                    
                    # Détection de retournement (si tendance immédiate contraire à la tendance globale)
                    trend_reversal = immediate_trend * overall_trend < 0
                    
                    # Score de tendance composite
                    trend_score = immediate_trend * 0.5 + recent_trend * 0.3 + overall_trend * 0.2
                    
                    # Bonus pour tendance en accélération, malus pour retournement
                    if abs(immediate_trend) > abs(recent_trend) and immediate_trend * recent_trend > 0:
                        trend_score *= 1.5  # Bonus: tendance qui s'accélère
                    elif trend_reversal:
                        trend_score *= 0.3  # Malus: probable retournement
                    
                    trend_by_tf[tf_name] = trend_score
                    
                    # 3. Analyse du volume
                    volume_changes = [volumes[i] / volumes[i-1] - 1 for i in range(1, len(volumes))]
                    recent_volume_change = sum(volume_changes[-3:]) / 3 if len(volume_changes) >= 3 else 0
                    volume_change_by_tf[tf_name] = recent_volume_change * 100  # en pourcentage
                    
                    # 4. Calcul du momentum (Rate of Change)
                    roc_periods = [3, 5, 10]
                    momentum_scores = []
                    
                    for period in roc_periods:
                        if len(close_prices) > period:
                            roc = (close_prices[-1] / close_prices[-period-1] - 1) * 100
                            momentum_scores.append(roc)
                    
                    avg_momentum = sum(momentum_scores) / len(momentum_scores) if momentum_scores else 0
                    momentum_by_tf[tf_name] = avg_momentum
                    
                    # 5. Calcul du RSI (Relative Strength Index)
                    if len(close_prices) >= 14:
                        gains = []
                        losses = []
                        
                        for i in range(1, 14):
                            change = close_prices[-i] - close_prices[-i-1]
                            if change > 0:
                                gains.append(change)
                                losses.append(0)
                            else:
                                gains.append(0)
                                losses.append(abs(change))
                        
                        avg_gain = sum(gains) / 14 if gains else 0
                        avg_loss = sum(losses) / 14 if losses else 0.001  # Éviter division par zéro
                        
                        rs = avg_gain / avg_loss
                        rsi = 100 - (100 / (1 + rs))
                    else:
                        rsi = 50  # Valeur neutre par défaut
                    
                    rsi_by_tf[tf_name] = rsi
                
                # === COMBINAISON DES MÉTRIQUES POUR SCORE FINAL ===
                
                # 1. Volatilité moyenne pondérée par timeframes (plus de poids aux timeframes courts)
                tf_weights = {'5m': 0.5, '15m': 0.3, '1h': 0.15, '4h': 0.05}
                volatility_score = sum(volatility_by_tf.get(tf, 0) * tf_weights.get(tf, 0) for tf in timeframes.keys())
                
                # 2. Tendance moyenne pondérée
                trend_score = sum(trend_by_tf.get(tf, 0) * tf_weights.get(tf, 0) for tf in timeframes.keys())
                
                # 3. Volume change moyen pondéré
                volume_score = sum(volume_change_by_tf.get(tf, 0) * tf_weights.get(tf, 0) for tf in timeframes.keys())
                
                # 4. Momentum moyen pondéré
                momentum_score = sum(momentum_by_tf.get(tf, 0) * tf_weights.get(tf, 0) for tf in timeframes.keys())
                
                # 5. RSI moyen pondéré
                rsi_score = sum(rsi_by_tf.get(tf, 0) * tf_weights.get(tf, 0) for tf in timeframes.keys())
                
                # 6. Calcul du sentiment
                sentiment = self.analyze_sentiment(asset)
                
                # === CALCUL DU POTENTIEL DE PROFIT APRÈS FRAIS ===
                
                # Frais d'achat + frais de vente sur Kraken (taker fees)
                total_fee_percentage = 0.26 + 0.26  # 0.26% par trade (taker)
                
                # Potentiel de profit basé sur la volatilité et la tendance
                # Pour qu'un trade soit rentable, le mouvement doit être supérieur aux frais
                estimated_price_move = volatility_score * (1 + trend_score/100)
                profit_after_fees = estimated_price_move - total_fee_percentage
                
                # Convertir le profit potentiel en score normalisé (0-10)
                profit_potential_score = max(0, min(10, profit_after_fees))
                
                # === SCORE FINAL COMBINÉ ===
                
                # Facteurs de pondération pour le score final
                weights = {
                    'volatility': 0.30,    # 30% - Volatilité pondérée
                    'trend': 0.25,         # 25% - Tendance pondérée
                    'momentum': 0.15,      # 15% - Momentum
                    'volume': 0.10,        # 10% - Changement de volume
                    'profit': 0.15,        # 15% - Profit potentiel après frais
                    'sentiment': 0.05      # 5% - Sentiment
                }
                
                # Normaliser les scores négatifs
                if trend_score < 0:
                    trend_factor = 0  # Ignorer les tendances négatives
                else:
                    trend_factor = min(10, trend_score / 2)  # Limiter à 10
                
                # Bonus pour RSI dans les zones "action" (survente ou surachat modéré)
                rsi_factor = 1.0
                if rsi_score < 30:
                    rsi_factor = 1.5  # Survente (potentiel rebond)
                elif 65 < rsi_score < 75:
                    rsi_factor = 1.3  # Momentum fort sans surachat extrême
                elif rsi_score > 80:
                    rsi_factor = 0.3  # Surachat extrême (risque de retournement)
                
                # Score combiné final
                combined_score = (
                    weights['volatility'] * volatility_score +
                    weights['trend'] * trend_factor +
                    weights['momentum'] * momentum_score +
                    weights['volume'] * volume_score +
                    weights['profit'] * profit_potential_score +
                    weights['sentiment'] * sentiment * 10  # Normaliser le sentiment à l'échelle 0-10
                ) * rsi_factor
                
                # Bonus massif pour combinaison parfaite: forte volatilité + tendance positive + volume en hausse
                if volatility_score > 3 and trend_score > 5 and volume_score > 20:
                    combined_score *= 1.5
                    logger.info(f"⭐ OPPORTUNITÉ PREMIUM: {asset} montre une combinaison parfaite de facteurs!")
                
                # Stocker les résultats d'analyse
                self.volatility_scores[asset] = volatility_score
                self.trend_scores[asset] = trend_score
                momentum_scores[asset] = momentum_score
                volume_scores[asset] = volume_score
                rsi_scores[asset] = rsi_score
                profit_potential[asset] = profit_potential_score
                self.combined_scores[asset] = combined_score
                
                # Log détaillé
                logger.info(f"Analyse complète de {asset}:")
                logger.info(f"  Volatilité: {volatility_score:.2f}, Tendance: {trend_score:.2f}%, Momentum: {momentum_score:.2f}")
                logger.info(f"  Volume: {volume_score:+.2f}%, RSI: {rsi_score:.1f}, Profit potentiel: {profit_potential_score:.2f}")
                logger.info(f"  Sentiment: {sentiment:.2f}, SCORE FINAL: {combined_score:.2f}")
                
                # Petite pause pour éviter de surcharger l'API
                time.sleep(0.3)
                
            except Exception as e:
                logger.error(f"Erreur générale lors de l'analyse de {asset}: {e}")
                continue
        
        # Mettre à jour l'horodatage
        self.last_analysis_time = now
        
        # Trier les résultats par score (du plus élevé au plus bas)
        sorted_scores = sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Afficher les meilleurs résultats
        logger.info("=== TOP CRYPTOS VOLATILES EN UPTREND ===")
        for i, (asset, score) in enumerate(sorted_scores[:5]):
            logger.info(f"{i+1}. {asset}: Score = {score:.2f}, Volatilité = {self.volatility_scores.get(asset, 0):.2f}%, Tendance = {self.trend_scores.get(asset, 0):.2f}%")
        
        # Enregistrer les résultats dans un fichier
        try:
            with open('volatile_assets.log', 'a') as f:
                f.write(f"\n[{datetime.now().isoformat()}] ANALYSE DES CRYPTOS VOLATILES\n")
                for i, (asset, score) in enumerate(sorted_scores[:10]):
                    f.write(f"{i+1}. {asset}: Score = {score:.2f}, Volatilité = {self.volatility_scores.get(asset, 0):.2f}%, Tendance = {self.trend_scores.get(asset, 0):.2f}%\n")
                f.write("-" * 50 + "\n")
        except Exception as e:
            logger.error(f"Erreur lors de l'enregistrement des résultats dans le fichier: {e}")
        
        return self.combined_scores
    
    def analyze_sentiment(self, asset):
        """Analyse le sentiment pour un actif"""
        try:
            # Simuler des titres d'actualité pour l'actif
            headlines = self._simulate_headlines(asset)
            
            # Calculer le score de sentiment moyen
            compound_scores = []
            
            for headline in headlines:
                sentiment = self.sentiment_analyzer.polarity_scores(headline)
                compound_scores.append(sentiment['compound'])
            
            # Moyenne des scores
            avg_score = sum(compound_scores) / len(compound_scores) if compound_scores else 0
            
            return avg_score
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse du sentiment pour {asset}: {e}")
            return 0
    
    def _simulate_headlines(self, asset):
        """
        Simule la récupération de titres d'actualité pour une cryptomonnaie
        À remplacer par une vraie source d'actualités comme NewsAPI ou Twitter
        """
        current_date = datetime.now().strftime("%d %b %Y")
        
        # Liste de modèles de titres positifs
        positive_templates = [
            "{asset} surges as market sentiment improves on {date}",
            "Analysts predict bullish trend for {asset} in coming weeks",
            "{asset} gains momentum after partnership announcement",
            "Investors flock to {asset} amid broader crypto rally",
            "{asset} sees increased adoption in real-world applications",
            "Technical analysis suggests {asset} may continue upward trend",
            "{asset} breaks resistance level, could test new highs",
            "Major exchange announces new {asset} trading pairs",
            "{asset} community growing rapidly, positive sentiment on social media",
            "New {asset} upgrade improves scalability and performance"
        ]
        
        # Liste de modèles de titres négatifs
        negative_templates = [
            "{asset} retreats as profit-taking sets in on {date}",
            "Regulatory concerns weigh on {asset} price action",
            "{asset} faces resistance at current levels, analysts cautious",
            "Trading volume for {asset} decreases amid market uncertainty",
            "{asset} project delays cause investor concerns",
            "{asset} competitors gaining market share according to new data",
            "Short-term technical analysis shows {asset} potential correction",
            "Major investor liquidates {asset} position, creating selling pressure",
            "Security concerns emerge for {asset} protocol",
            "{asset} development team faces internal disputes"
        ]
        
        # Liste de modèles de titres neutres
        neutral_templates = [
            "{asset} price consolidates around current levels on {date}",
            "Market watchers divided on {asset} future prospects",
            "{asset} volatility decreases as market matures",
            "New research report published on {asset} technology",
            "{asset} community discusses potential governance changes",
            "Comparing {asset} performance to major cryptocurrencies",
            "{asset} trading pairs added to decentralized exchanges",
            "Analysis of {asset} on-chain metrics shows mixed signals",
            "{asset} development team provides regular project update",
            "Industry experts discuss {asset} role in crypto ecosystem"
        ]
        
        # Biais basé sur la tendance récente si disponible
        trend_bias = 0
        if asset in self.trend_scores:
            trend = self.trend_scores[asset]
            
            if trend > 10:  # Forte tendance positive
                trend_bias = 0.4
            elif trend > 0:  # Tendance positive
                trend_bias = 0.2
            elif trend < -10:  # Forte tendance négative
                trend_bias = -0.4
            elif trend < 0:  # Tendance négative
                trend_bias = -0.2
        
        # Déterminer le nombre de titres de chaque type en fonction du biais
        positive_count = int(3 + 4 * trend_bias)
        negative_count = int(3 - 3 * trend_bias)
        neutral_count = 4 - (positive_count - 3) - (negative_count - 3)
        
        # Générer les titres
        headlines = []
        
        # Titres positifs
        for _ in range(positive_count):
            template = random.choice(positive_templates)
            headline = template.format(asset=asset, date=current_date)
            headlines.append(headline)
        
        # Titres négatifs
        for _ in range(negative_count):
            template = random.choice(negative_templates)
            headline = template.format(asset=asset, date=current_date)
            headlines.append(headline)
        
        # Titres neutres
        for _ in range(neutral_count):
            template = random.choice(neutral_templates)
            headline = template.format(asset=asset, date=current_date)
            headlines.append(headline)
        
        # Mélanger les titres
        random.shuffle(headlines)
        
        return headlines
    
    def should_buy_asset(self, asset, score):
        """Détermine si un actif devrait être acheté en fonction de son score"""
        
        # Seuil minimal de score
        if score < 1.5:
            logger.info(f"{asset} a un score trop faible ({score:.2f}) pour être acheté")
            return False
        
        # Vérifier si on a déjà une position sur cet actif
        if asset in self.current_positions and self.current_positions[asset] > 0.001:
            logger.info(f"Position existante sur {asset}, analyse pour augmentation éventuelle")
            
            # Augmenter la position uniquement si le score est très élevé
            if score > 5:
                logger.info(f"{asset} a un score exceptionnellement élevé ({score:.2f}), augmentation de la position")
                return True
            else:
                logger.info(f"Score de {asset} ({score:.2f}) insuffisant pour augmenter la position existante")
                return False
        
        # Vérifier si on a suffisamment d'USD pour acheter
        if self.usd_balance < 10:
            logger.info(f"Solde USD insuffisant ({self.usd_balance:.2f}) pour acheter {asset}")
            return False
        
        # Vérifier si l'actif est dans le top 3 des scores
        top_assets = sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True)[:3]
        top_asset_names = [a[0] for a in top_assets]
        
        if asset not in top_asset_names:
            logger.info(f"{asset} n'est pas dans le top 3 des actifs (actuellement {', '.join(top_asset_names)})")
            return False
        
        logger.info(f"{asset} est un candidat viable pour l'achat avec un score de {score:.2f}")
        return True
    
    def should_sell_asset(self, asset):
        """Détermine si un actif devrait être vendu"""
        
        # Vérifier si on a une position sur cet actif
        if asset not in self.current_positions or self.current_positions[asset] < 0.001:
            logger.info(f"Pas de position existante sur {asset} à vendre")
            return False
        
        # Vérifier son score actuel
        if asset not in self.combined_scores:
            logger.info(f"Pas de score disponible pour {asset}, conservation")
            return False
        
        score = self.combined_scores[asset]
        
        # Si le score est devenu négatif ou très faible, vendre
        if score < 0.5:
            logger.info(f"{asset} a un score très faible ({score:.2f}), vente recommandée")
            return True
        
        # Si la tendance est fortement négative, vendre
        if asset in self.trend_scores and self.trend_scores[asset] < -10:
            logger.info(f"{asset} a une tendance fortement négative ({self.trend_scores[asset]:.2f}%), vente recommandée")
            return True
        
        # Si un autre actif a un score beaucoup plus élevé, envisager de vendre pour réallouer
        top_asset = sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True)[0]
        if top_asset[0] != asset and top_asset[1] > score * 3:
            logger.info(f"{top_asset[0]} a un score beaucoup plus élevé ({top_asset[1]:.2f}) que {asset} ({score:.2f}), vente recommandée pour réallocation")
            return True
        
        logger.info(f"Conservation de la position sur {asset} (score {score:.2f})")
        return False
    
    def execute_trade_strategy(self):
        """Exécute la stratégie de trading"""
        logger.info("=== EXÉCUTION DE LA STRATÉGIE DE TRADING ===")
        
        try:
            # 1. Mettre à jour les balances
            self.update_balances()
            
            # 2. Analyser les actifs
            self.analyze_assets()
            
            # 3. Décider des ventes
            assets_to_sell = []
            for asset in self.current_positions:
                if self.should_sell_asset(asset):
                    assets_to_sell.append(asset)
            
            # 4. Exécuter les ventes
            for asset in assets_to_sell:
                logger.info(f"Vente de {asset} en cours...")
                self.sell_asset(asset)
            
            # 5. Mettre à jour les balances après les ventes
            if assets_to_sell:
                self.update_balances()
            
            # 6. Décider des achats
            assets_to_buy = []
            for asset, score in sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True):
                if self.should_buy_asset(asset, score):
                    assets_to_buy.append((asset, score))
            
            # 7. Exécuter les achats
            for asset, score in assets_to_buy:
                logger.info(f"Achat de {asset} en cours...")
                self.buy_asset(asset, score)
            
            # 8. Mettre à jour l'état du trader dans un fichier
            self.save_status()
            
            logger.info("Exécution de la stratégie de trading terminée")
            
        except Exception as e:
            logger.error(f"Erreur lors de l'exécution de la stratégie de trading: {e}")
    
    def save_status(self):
        """Sauvegarde l'état actuel du trader dans un fichier"""
        try:
            # Récupérer les informations à sauvegarder
            status = {
                "timestamp": datetime.now().isoformat(),
                "usd_balance": self.usd_balance,
                "positions": self.current_positions,
                "top_assets": sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True)[:5],
                "trade_history": self.trade_history[-10:] if self.trade_history else []
            }
            
            # Sauvegarder dans un fichier
            with open("trader_status.txt", "w") as f:
                f.write(json.dumps(status, indent=2))
            
            logger.info("État du trader sauvegardé")
            
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde de l'état du trader: {e}")
    
    def buy_asset(self, asset, score):
        """Achète un actif avec haute précision pour capturer 2-3% de profit rapide"""
        try:
            start_time = time.time()
            logger.info(f"⚡ ACHAT RAPIDE DE {asset} (Score: {score:.2f}) ⚡")
            
            # 1. Vérifier le solde USD
            if self.usd_balance < 10:
                logger.error(f"Solde USD insuffisant ({self.usd_balance:.2f}) pour acheter {asset}")
                return False
            
            # 2. Stratégie de taille d'ordre optimisée
            # Calculer la taille optimale du trade en fonction du score et du solde
            # Maximiser le nombre de trades pour capturer plus d'opportunités de 2-3%
            
            # TAILLE D'ORDRE STRATÉGIQUE: Plus petite pour scores plus faibles (plus de diversification)
            # Très haut score -> utiliser jusqu'à 40% du capital
            # Score moyen -> utiliser 15-20% du capital
            # Score faible -> utiliser seulement 10% du capital
            if score > 8:  # Score exceptionnel
                allocation = 0.4  # 40% du solde USD
            elif score > 6:  # Score très élevé
                allocation = 0.3  # 30% du solde USD
            elif score > 4:  # Score élevé
                allocation = 0.2  # 20% du solde USD
            elif score > 2:  # Score modéré
                allocation = 0.15  # 15% du solde USD
            else:  # Score faible
                allocation = 0.1  # 10% du solde USD
            
            # Calculer le montant à dépenser en USD
            amount_to_spend = self.usd_balance * allocation
            
            # Limiter à 95% pour tenir compte des frais
            amount_to_spend = min(amount_to_spend, self.usd_balance * 0.95)
            amount_to_spend = max(10, amount_to_spend)  # Minimum 10 USD pour éviter les erreurs de volume
            
            # 3. OPTIMISATION DE VITESSE: Récupérer le prix actuel avec un cache intelligent
            pair = f"{asset}USD"
            ticker_start = time.time()
            ticker = self.k.query_public('Ticker', {'pair': pair})
            ticker_time = time.time() - ticker_start
            
            if 'error' in ticker and ticker['error']:
                logger.error(f"Erreur lors de la récupération du prix de {asset}: {ticker['error']}")
                return False
            
            current_price = float(ticker['result'][list(ticker['result'].keys())[0]]['c'][0])
            
            # Mettre à jour le cache de prix
            self.price_cache[asset] = {
                'price': current_price,
                'timestamp': time.time()
            }
            
            logger.info(f"Prix actuel de {asset}: {current_price:.6f} USD (récupéré en {ticker_time*1000:.1f}ms)")
            
            # 4. PRÉCISION MAXIMALE: Calculer exactement la quantité à acheter
            quantity_to_buy = amount_to_spend / current_price
            
            # Récupération des informations de précision de l'asset pour éviter les erreurs de volume
            # L'API Kraken peut renvoyer des erreurs si la précision n'est pas respectée
            try:
                asset_info = self.k.query_public('AssetPairs', {'pair': pair})
                if 'error' not in asset_info or not asset_info['error']:
                    # Extraire la précision de volume requise
                    pair_info = asset_info['result'][list(asset_info['result'].keys())[0]]
                    lot_decimals = int(pair_info.get('lot_decimals', 8))
                    # Utiliser la précision exacte requise
                    quantity_to_buy = round(quantity_to_buy, lot_decimals)
                else:
                    # Valeur par défaut sécuritaire
                    quantity_to_buy = round(quantity_to_buy, 6)
            except Exception as e:
                logger.warning(f"Impossible d'obtenir la précision exacte pour {asset}, utilisation de 6 décimales: {e}")
                quantity_to_buy = round(quantity_to_buy, 6)
            
            logger.info(f"Achat de {quantity_to_buy} {asset} à {current_price:.6f} USD (allocation: {allocation*100:.1f}%)")
            
            # 5. RAPIDITÉ D'EXÉCUTION: Placer l'ordre d'achat (market pour exécution instantanée)
            order_start = time.time()
            buy_order = self.k.query_private('AddOrder', {
                'pair': pair,
                'type': 'buy',
                'ordertype': 'market',
                'volume': str(quantity_to_buy)
            })
            order_time = time.time() - order_start
            
            if 'error' in buy_order and buy_order['error']:
                # GESTION D'ERREUR INTELLIGENTE: Adapter la stratégie en fonction de l'erreur
                if 'EOrder:Invalid order' in str(buy_order['error']) or 'EOrder:Low order volume' in str(buy_order['error']):
                    logger.info(f"Erreur de volume, tentative d'achat avec un coût fixe...")
                    
                    order_start = time.time()
                    buy_order = self.k.query_private('AddOrder', {
                        'pair': pair,
                        'type': 'buy',
                        'ordertype': 'market',
                        'cost': str(amount_to_spend)
                    })
                    order_time = time.time() - order_start
                
                if 'error' in buy_order and buy_order['error']:
                    logger.error(f"Erreur lors de l'achat de {asset}: {buy_order['error']}")
                    return False
            
            # 6. Récupérer l'ID de l'ordre
            order_txid = buy_order['result']['txid'][0]
            logger.info(f"✅ Ordre d'achat placé avec succès: ID {order_txid} (exécuté en {order_time*1000:.1f}ms)")
            
            # 7. SURVEILLANCE ACTIVE: Vérification rapide de l'exécution
            check_start = time.time()
            # Attendre d'abord un court instant pour l'exécution
            time.sleep(0.5)
            
            # Vérifier l'état de l'ordre
            order_status = self.k.query_private('QueryOrders', {'txid': order_txid})
            
            # Initialiser les variables de prix et de quantité réels
            actual_price = current_price
            actual_quantity = quantity_to_buy
            
            if 'error' in order_status and order_status['error']:
                logger.error(f"Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
            else:
                status = order_status['result'][order_txid]['status']
                logger.info(f"État de l'ordre: {status} (vérifié en {(time.time()-check_start)*1000:.1f}ms)")
                
                # Si l'ordre est fermé, récupérer le prix et la quantité réels
                if status == 'closed':
                    try:
                        # Récupérer les détails de l'exécution pour le prix réel
                        if 'price' in order_status['result'][order_txid]:
                            actual_price = float(order_status['result'][order_txid]['price'])
                        
                        # Récupérer la quantité réellement achetée
                        if 'vol_exec' in order_status['result'][order_txid]:
                            actual_quantity = float(order_status['result'][order_txid]['vol_exec'])
                            
                        logger.info(f"Prix réel d'exécution: {actual_price:.6f} USD, Quantité: {actual_quantity}")
                        
                        # Calculer le coût des frais
                        if 'fee' in order_status['result'][order_txid]:
                            fee_cost = float(order_status['result'][order_txid]['fee'])
                            logger.info(f"Frais payés: {fee_cost:.6f} USD ({(fee_cost/(actual_price*actual_quantity))*100:.4f}%)")
                    except Exception as e:
                        logger.warning(f"Impossible de récupérer tous les détails d'exécution: {e}")
            
            # 8. CALCUL DU PROFIT CIBLE: Définir immédiatement l'objectif de profit
            
            # Frais totaux pour un cycle complet (achat + vente)
            fee_rate_taker = 0.0026  # 0.26% pour taker
            
            # Calculer le profit minimum nécessaire pour couvrir les frais (aller-retour)
            min_profit_rate = fee_rate_taker * 2  # Achat + vente
            
            # Cibles de profit stratégiques basées sur la volatilité et le score
            if score > 7:
                # Actifs très prometteurs - viser un profit plus élevé
                target_profit_rate = 0.035  # 3.5%
            elif score > 5:
                # Bons actifs - profit standard
                target_profit_rate = 0.03   # 3.0%
            elif score > 3:
                # Actifs moyens - profit modéré
                target_profit_rate = 0.025  # 2.5%
            else:
                # Actifs moins prometteurs - profit minimal
                target_profit_rate = 0.02   # 2.0%
                
            # Prix cible pour la vente
            target_sell_price = actual_price * (1 + target_profit_rate)
            
            # STOP LOSS SERRÉ: Protection agressive du capital
            # Le stop loss doit être très serré pour limiter les pertes et sécuriser les gains
            # En général: 0.5-0.8% de perte maximum (dépend de la volatilité)
            
            # Déterminer le niveau de volatilité intrajournalière pour un stop-loss adaptatif
            asset_volatility = self.volatility_scores.get(asset, 2.0)  # Valeur par défaut: 2%
            
            # Pour les actifs plus volatils, stop-loss légèrement plus large (mais jamais trop)
            # Pour les actifs moins volatils, stop-loss très serré
            if asset_volatility > 4.0:  # Volatilité très élevée
                stop_loss_rate = 0.008  # 0.8% max
            elif asset_volatility > 2.0:  # Volatilité modérée à élevée
                stop_loss_rate = 0.006  # 0.6% max
            else:  # Volatilité faible
                stop_loss_rate = 0.005  # 0.5% max
                
            # Ajuster sur la base des frais: stop loss ne doit jamais être < frais totaux
            # pour ne pas sortir systématiquement à perte sur de petites fluctuations
            min_stop_loss = fee_rate_taker * 2  # Double des frais comme protection minimale
            stop_loss_rate = max(stop_loss_rate, min_stop_loss)
            
            # Calculer le prix du stop loss
            stop_loss_price = actual_price * (1 - stop_loss_rate)
            
            logger.info(f"🛡️ Stop loss serré: -{stop_loss_rate*100:.2f}% (basé sur volatilité: {asset_volatility:.2f}%)")
            
            logger.info(f"OBJECTIF: Vendre à {target_sell_price:.6f} USD pour un profit de {target_profit_rate*100:.1f}%")
            logger.info(f"STOP LOSS: {stop_loss_price:.6f} USD (-{stop_loss_rate*100:.2f}%)")
            
            # 9. Mettre à jour les balances rapidement
            self.update_balances()
            
            # 10. Enregistrer dans l'historique des trades
            trade_record = {
                "timestamp": datetime.now().isoformat(),
                "asset": asset,
                "action": "buy",
                "quantity": actual_quantity,
                "price": actual_price,
                "usd_amount": actual_price * actual_quantity,
                "score": score,
                "volatility": self.volatility_scores.get(asset, 0),
                "trend": self.trend_scores.get(asset, 0),
                "target_price": target_sell_price,
                "stop_loss": stop_loss_price,
                "target_profit": target_profit_rate * 100,
                "order_id": order_txid,
                "execution_time_ms": (time.time() - start_time) * 1000
            }
            
            self.trade_history.append(trade_record)
            
            # Stocker les objectifs dans une structure pour suivi
            self.pending_trades[asset] = {
                "entry_price": actual_price,
                "quantity": actual_quantity,
                "target_price": target_sell_price,
                "stop_loss": stop_loss_price,
                "entry_time": time.time(),
                "order_id": order_txid
            }
            
            # 11. Journaliser les détails du trade
            with open('trading_logs.txt', 'a') as f:
                f.write(f"[{datetime.now().isoformat()}] ⚡ACHAT RAPIDE: {actual_quantity} {asset} à {actual_price} USD\n")
                f.write(f"[{datetime.now().isoformat()}] OBJECTIF: {target_profit_rate*100:.1f}% de profit (vente à {target_sell_price:.6f})\n")
                f.write(f"[{datetime.now().isoformat()}] STOP-LOSS: {stop_loss_price:.6f} USD\n")
                f.write(f"[{datetime.now().isoformat()}] RAISONS: Score {score:.2f}, Volatilité {self.volatility_scores.get(asset, 0):.2f}%, Tendance {self.trend_scores.get(asset, 0):.2f}%\n")
                f.write(f"[{datetime.now().isoformat()}] EXÉCUTION: {(time.time() - start_time)*1000:.1f}ms\n")
                f.write(f"[{datetime.now().isoformat()}] ID ORDRE: {order_txid}\n")
                f.write("-" * 50 + "\n")
            
            logger.info(f"✅ Achat de {asset} terminé avec succès en {(time.time() - start_time)*1000:.1f}ms")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {asset}: {e}")
            return False
    
    def sell_asset(self, asset, percentage=1.0, reason="AUTOMATIC", target_price=None):
        """Vend un actif avec rapidité d'exécution maximale pour capturer profit"""
        try:
            start_time = time.time()
            logger.info(f"⚡ VENTE RAPIDE DE {asset} ({percentage*100:.0f}%) - RAISON: {reason} ⚡")
            
            # 1. Validation ultra-rapide du solde
            if asset not in self.current_positions or self.current_positions[asset] < 0.001:
                logger.error(f"Solde {asset} insuffisant pour la vente")
                return False
            
            # 2. Calcul précis de la quantité à vendre
            quantity_to_sell = self.current_positions[asset] * percentage
            
            # Trouver la précision exacte requise pour l'actif
            pair = f"{asset}USD"
            precision = 6  # Valeur par défaut
            
            try:
                asset_info = self.k.query_public('AssetPairs', {'pair': pair})
                if 'error' not in asset_info or not asset_info['error']:
                    # Extraire la précision de volume requise
                    pair_info = asset_info['result'][list(asset_info['result'].keys())[0]]
                    lot_decimals = int(pair_info.get('lot_decimals', 8))
                    precision = lot_decimals
            except Exception as e:
                logger.warning(f"Impossible d'obtenir la précision exacte pour {asset}: {e}")
            
            # Arrondir précisément à la précision requise
            quantity_to_sell = round(quantity_to_sell, precision)
            
            # 3. PERFORMANCE: Obtention du prix actuel en microsecondes
            ticker_start = time.time()
            ticker = self.k.query_public('Ticker', {'pair': pair})
            ticker_time = time.time() - ticker_start
            
            if 'error' in ticker and ticker['error']:
                logger.error(f"Erreur lors de la récupération du prix de {asset}: {ticker['error']}")
                return False
            
            current_price = float(ticker['result'][list(ticker['result'].keys())[0]]['c'][0])
            
            # Mettre à jour le cache de prix
            self.price_cache[asset] = {
                'price': current_price,
                'timestamp': time.time()
            }
            
            # Si cet actif est dans nos trades en cours, calculer le profit/perte par rapport à l'entrée
            profit_pct = None
            entry_price = None
            
            if asset in self.pending_trades:
                entry_price = self.pending_trades[asset]["entry_price"]
                profit_pct = ((current_price / entry_price) - 1) * 100
                logger.info(f"📊 P&L actuel: {profit_pct:+.2f}% depuis l'entrée à {entry_price}")
            
            logger.info(f"Prix actuel de {asset}: {current_price:.6f} USD (récupéré en {ticker_time*1000:.1f}ms)")
            
            # 4. Estimer la valeur en USD - important pour le tracking des performances
            estimated_usd = quantity_to_sell * current_price
            logger.info(f"Valeur estimée en USD: {estimated_usd:.2f} USD")
            
            # 5. EXÉCUTION IMMÉDIATE: Placer l'ordre de vente au marché
            order_start = time.time()
            sell_order = self.k.query_private('AddOrder', {
                'pair': pair,
                'type': 'sell',
                'ordertype': 'market',
                'volume': str(quantity_to_sell)
            })
            order_time = time.time() - order_start
            
            if 'error' in sell_order and sell_order['error']:
                logger.error(f"Erreur lors de la vente de {asset}: {sell_order['error']}")
                return False
            
            # 6. Récupérer l'ID de l'ordre et monitorer l'exécution
            order_txid = sell_order['result']['txid'][0]
            logger.info(f"✅ Ordre de vente placé avec succès: ID {order_txid} (exécuté en {order_time*1000:.1f}ms)")
            
            # 7. VÉRIFICATION INSTANTANÉE: S'assurer que l'ordre a été exécuté
            check_start = time.time()
            # Attendre un court instant
            time.sleep(0.5)
            
            # Vérifier l'état de l'ordre
            order_status = self.k.query_private('QueryOrders', {'txid': order_txid})
            
            # Initialiser les variables pour le prix et la quantité réels
            actual_price = current_price
            actual_quantity = quantity_to_sell
            fee_cost = 0
            
            if 'error' in order_status and order_status['error']:
                logger.error(f"Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
            else:
                status = order_status['result'][order_txid]['status']
                logger.info(f"État de l'ordre: {status} (vérifié en {(time.time()-check_start)*1000:.1f}ms)")
                
                # Si l'ordre est fermé (exécuté), récupérer les détails d'exécution
                if status == 'closed':
                    try:
                        # Prix réel d'exécution
                        if 'price' in order_status['result'][order_txid]:
                            actual_price = float(order_status['result'][order_txid]['price'])
                        
                        # Quantité réellement vendue
                        if 'vol_exec' in order_status['result'][order_txid]:
                            actual_quantity = float(order_status['result'][order_txid]['vol_exec'])
                        
                        logger.info(f"Prix réel d'exécution: {actual_price:.6f} USD, Quantité: {actual_quantity}")
                        
                        # Frais payés
                        if 'fee' in order_status['result'][order_txid]:
                            fee_cost = float(order_status['result'][order_txid]['fee'])
                            fee_percentage = (fee_cost/(actual_price*actual_quantity))*100 if actual_quantity > 0 else 0
                            logger.info(f"Frais payés: {fee_cost:.6f} USD ({fee_percentage:.4f}%)")
                    except Exception as e:
                        logger.warning(f"Impossible de récupérer tous les détails d'exécution: {e}")
            
            # 8. PERFORMANCE TRACKING: Calculer et enregistrer le P&L réalisé
            realized_profit_usd = None
            realized_profit_pct = None
            
            if entry_price and asset in self.pending_trades:
                # Calculer le profit en USD et en pourcentage
                cost_basis = entry_price * actual_quantity
                sale_proceeds = actual_price * actual_quantity - fee_cost
                realized_profit_usd = sale_proceeds - cost_basis
                realized_profit_pct = ((actual_price / entry_price) - 1) * 100
                
                trade_duration = time.time() - self.pending_trades[asset]["entry_time"]
                hours = trade_duration / 3600
                
                logger.info(f"💰 PROFIT RÉALISÉ: {realized_profit_usd:.2f} USD ({realized_profit_pct:+.2f}%)")
                logger.info(f"⏱️ DURÉE DU TRADE: {trade_duration:.1f} secondes ({hours:.2f} heures)")
                
                # Calculer le rendement annualisé (pour référence)
                if hours > 0:
                    annual_return = (1 + realized_profit_pct/100) ** (8760/hours) - 1
                    logger.info(f"📈 RENDEMENT ANNUALISÉ ÉQUIVALENT: {annual_return*100:.2f}%")
                
                # Supprimer ce trade des trades en cours
                if asset in self.pending_trades:
                    del self.pending_trades[asset]
            
            # 9. MISE À JOUR RAPIDE: Actualiser les balances
            self.update_balances()
            
            # 10. MESURES DE PERFORMANCE: Enregistrer dans l'historique des trades
            trade_record = {
                "timestamp": datetime.now().isoformat(),
                "asset": asset,
                "action": "sell",
                "quantity": actual_quantity,
                "price": actual_price,
                "usd_amount": actual_price * actual_quantity,
                "fee": fee_cost,
                "reason": reason,
                "volatility": self.volatility_scores.get(asset, 0),
                "trend": self.trend_scores.get(asset, 0),
                "entry_price": entry_price,
                "realized_profit_usd": realized_profit_usd,
                "realized_profit_pct": realized_profit_pct,
                "order_id": order_txid,
                "target_price": target_price,
                "execution_time_ms": (time.time() - start_time) * 1000
            }
            
            self.trade_history.append(trade_record)
            
            # 11. JOURNALISATION DÉTAILLÉE: Enregistrer les détails du trade
            with open('trading_logs.txt', 'a') as f:
                f.write(f"[{datetime.now().isoformat()}] ⚡VENTE RAPIDE: {actual_quantity} {asset} à {actual_price} USD\n")
                f.write(f"[{datetime.now().isoformat()}] MONTANT: {actual_price * actual_quantity:.2f} USD (Frais: {fee_cost:.4f} USD)\n")
                f.write(f"[{datetime.now().isoformat()}] RAISON: {reason}\n")
                
                if realized_profit_usd is not None:
                    f.write(f"[{datetime.now().isoformat()}] PROFIT: {realized_profit_usd:.2f} USD ({realized_profit_pct:+.2f}%)\n")
                    
                if entry_price:
                    trade_duration = time.time() - self.pending_trades.get(asset, {}).get("entry_time", time.time())
                    f.write(f"[{datetime.now().isoformat()}] DURÉE: {trade_duration:.1f} secondes\n")
                
                if asset in self.combined_scores:
                    f.write(f"[{datetime.now().isoformat()}] MÉTRIQUES: Score {self.combined_scores[asset]:.2f}, "
                           f"Volatilité {self.volatility_scores.get(asset, 0):.2f}%, "
                           f"Tendance {self.trend_scores.get(asset, 0):.2f}%\n")
                
                f.write(f"[{datetime.now().isoformat()}] EXÉCUTION: {(time.time() - start_time)*1000:.1f}ms\n")
                f.write(f"[{datetime.now().isoformat()}] ID ORDRE: {order_txid}\n")
                f.write("-" * 50 + "\n")
            
            logger.info(f"✅ Vente de {asset} terminée avec succès en {(time.time() - start_time)*1000:.1f}ms")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de la vente de {asset}: {e}")
            return False
    
    def trading_loop(self):
        """Boucle principale de trading"""
        logger.info("=== DÉMARRAGE DE LA BOUCLE DE TRADING ===")
        
        while self.running:
            try:
                # Exécuter la stratégie de trading
                self.execute_trade_strategy()
                
                # Attendre avant la prochaine itération
                wait_time = 15 * 60  # 15 minutes
                logger.info(f"Attente de {wait_time} secondes avant la prochaine itération...")
                
                # Boucle d'attente qui peut être interrompue si self.running devient False
                for _ in range(wait_time):
                    if not self.running:
                        break
                    time.sleep(1)
                
            except Exception as e:
                logger.error(f"Erreur dans la boucle de trading: {e}")
                # Attendre avant de réessayer
                time.sleep(60)
    
    def start(self):
        """Démarre le trader permanent"""
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        logger.info("=== DÉMARRAGE DU TRADER PERMANENT ===")
        
        # Mettre à jour les balances
        self.update_balances()
        
        # Analyser les actifs
        self.analyze_assets(force=True)
        
        # Démarrer la boucle de trading dans un thread séparé
        self.running = True
        trading_thread = threading.Thread(target=self.trading_loop)
        trading_thread.daemon = True
        trading_thread.start()
        
        self.threads.append(trading_thread)
        
        # Convertir le MANA en ZEREBRO si disponible
        if 'MANA' in self.current_positions and self.current_positions['MANA'] > 10:
            logger.info("Conversion initiale de MANA en ZEREBRO...")
            
            if 'ZEREBRO' in self.combined_scores and self.combined_scores['ZEREBRO'] > 3:
                # Vendre MANA
                self.sell_asset('MANA')
                
                # Mettre à jour les balances
                self.update_balances()
                
                # Acheter ZEREBRO avec le solde USD disponible
                if self.usd_balance > 10:
                    self.buy_asset('ZEREBRO', self.combined_scores['ZEREBRO'])
        
        logger.info("Trader permanent démarré avec succès")
        return True
    
    def stop(self):
        """Arrête le trader permanent"""
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        logger.info("=== ARRÊT DU TRADER PERMANENT ===")
        
        self.running = False
        
        # Attendre que les threads se terminent
        for thread in self.threads:
            thread.join(timeout=5)
        
        self.threads = []
        
        logger.info("Trader permanent arrêté avec succès")
        return True
    
    def get_status(self):
        """Récupère le statut du trader permanent"""
        status = {
            "running": self.running,
            "usd_balance": self.usd_balance,
            "positions": self.current_positions,
            "top_assets": sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True)[:5] if self.combined_scores else [],
            "trade_history": self.trade_history[-5:] if self.trade_history else []
        }
        
        return status

def run_permanent_trader():
    """Fonction principale pour démarrer le trader permanent"""
    print("\n🚀 DÉMARRAGE DU TRADER PERMANENT 24/7\n")
    
    # Initialiser le trader
    trader = PermanentTrader(API_KEY, API_SECRET)
    
    # Démarrer le trader
    if trader.start():
        print("\n✅ TRADER PERMANENT DÉMARRÉ AVEC SUCCÈS")
        print("\nLe trader fonctionne maintenant 24/7 et recherche automatiquement les cryptos les plus volatiles en uptrend.")
        print("Les trades sont exécutés automatiquement en fonction de l'analyse des scores de volatilité, tendance et sentiment.")
        print("Vous pouvez consulter les logs dans les fichiers trading.log et trading_logs.txt.")
        print("Pour arrêter le trader, appuyez sur Ctrl+C.\n")
        
        try:
            # Garde le programme en cours d'exécution
            while True:
                # Afficher un résumé du statut toutes les heures
                status = trader.get_status()
                
                print("\n=== STATUT DU TRADER ===")
                print(f"En cours d'exécution: {'Oui' if status['running'] else 'Non'}")
                print(f"Solde USD: {status['usd_balance']:.2f} USD")
                
                print("\nPositions actuelles:")
                for asset, balance in status['positions'].items():
                    print(f"  {asset}: {balance}")
                
                print("\nMeilleurs actifs:")
                for asset, score in status['top_assets']:
                    print(f"  {asset}: Score {score:.2f}")
                
                print("\nTrades récents:")
                for trade in reversed(status['trade_history']):
                    print(f"  {trade['timestamp'][0:19]} {trade['action'].upper()} {trade['quantity']} {trade['asset']} à {trade['price']} USD")
                
                # Attendre 1 heure
                time.sleep(3600)
                
        except KeyboardInterrupt:
            print("\n⚠️ Arrêt du trader...")
            trader.stop()
            print("✅ Trader arrêté avec succès")
    else:
        print("\n❌ ERREUR LORS DU DÉMARRAGE DU TRADER PERMANENT")

if __name__ == "__main__":
    run_permanent_trader()