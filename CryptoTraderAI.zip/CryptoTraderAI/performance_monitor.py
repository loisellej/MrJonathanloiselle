#!/usr/bin/env python3
"""
Module de monitoring des performances pour le trader "Béton Armé"
Surveille les performances système et optimise l'utilisation des ressources
"""
import os
import time
import json
import psutil
import logging
import threading
from datetime import datetime, timedelta
import gc

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("performance_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("PerformanceMonitor")

class PerformanceMonitor:
    """
    Moniteur de performances pour l'optimisation des ressources
    """
    
    def __init__(self, resource_manager=None, queue_manager=None):
        """
        Initialise le moniteur de performances
        
        Args:
            resource_manager: Gestionnaire de ressources optionnel
            queue_manager: Gestionnaire de files d'attente optionnel
        """
        self.resource_manager = resource_manager
        self.queue_manager = queue_manager
        
        # Seuils d'alerte
        self.warning_threshold = 70  # %
        self.critical_threshold = 85  # %
        self.extreme_threshold = 95  # %
        
        # Métriques de performance
        self.metrics = {
            'cpu': [],  # Liste des mesures CPU
            'memory': [],  # Liste des mesures mémoire
            'disk': [],  # Liste des mesures disque
            'network': [],  # Liste des mesures réseau
            'api_calls': 0,  # Nombre d'appels API
            'errors': 0,  # Nombre d'erreurs
            'threads': 0  # Nombre de threads actifs
        }
        
        # Historique des métriques
        self.history = {
            'cpu': {},  # {timestamp: valeur}
            'memory': {},
            'disk': {},
            'errors': {}
        }
        
        # Fichier de sauvegarde des métriques
        self.metrics_file = "performance_metrics.json"
        
        # Chargement des métriques précédentes
        self.load_metrics()
        
        # Démarrage du thread de monitoring
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        logger.info("Moniteur de performances initialisé")
    
    def load_metrics(self):
        """Charge les métriques de performance précédentes"""
        try:
            if os.path.exists(self.metrics_file):
                with open(self.metrics_file, 'r') as f:
                    saved_metrics = json.load(f)
                    
                    # Fusionner avec les métriques actuelles
                    for key in saved_metrics:
                        if key in self.history and isinstance(saved_metrics[key], dict):
                            self.history[key].update(saved_metrics[key])
                
                logger.info("Métriques de performance chargées")
        except Exception as e:
            logger.error(f"Erreur lors du chargement des métriques: {e}")
    
    def save_metrics(self):
        """Sauvegarde les métriques de performance actuelles"""
        try:
            # Limiter l'historique aux 24 dernières heures
            cutoff = time.time() - 86400  # 24h
            
            # Filtrer les métriques trop anciennes
            filtered_history = {}
            for key, data in self.history.items():
                filtered_history[key] = {
                    ts: value for ts, value in data.items()
                    if float(ts) > cutoff
                }
            
            with open(self.metrics_file, 'w') as f:
                json.dump(filtered_history, f)
            
            logger.debug("Métriques de performance sauvegardées")
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde des métriques: {e}")
    
    def _monitoring_loop(self):
        """Boucle principale de monitoring des performances"""
        logger.info("Démarrage de la boucle de monitoring des performances")
        
        last_save_time = time.time()
        
        while self.running:
            try:
                # Collecte des métriques
                self._collect_metrics()
                
                # Vérification des seuils d'alerte
                self._check_thresholds()
                
                # Sauvegarde périodique des métriques (toutes les 15 minutes)
                now = time.time()
                if now - last_save_time > 900:  # 15 minutes
                    self.save_metrics()
                    last_save_time = now
                
                # Nettoyage du cache si nécessaire
                self._check_memory_cleanup()
                
                # Pause entre les mesures
                time.sleep(30)  # 30 secondes entre les mesures
                
            except Exception as e:
                logger.error(f"Erreur dans la boucle de monitoring: {e}")
                time.sleep(60)  # Pause plus longue en cas d'erreur
    
    def _collect_metrics(self):
        """Collecte les métriques de performance du système"""
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=1)
            self.metrics['cpu'].append(cpu_percent)
            
            # Mémoire
            memory = psutil.virtual_memory()
            self.metrics['memory'].append(memory.percent)
            
            # Disque
            disk = psutil.disk_usage('/')
            self.metrics['disk'].append(disk.percent)
            
            # Réseau (bytes totaux)
            net = psutil.net_io_counters()
            self.metrics['network'].append(net.bytes_sent + net.bytes_recv)
            
            # Threads actifs
            self.metrics['threads'] = threading.active_count()
            
            # Limiter les listes à 60 valeurs (30 minutes avec mesure toutes les 30s)
            for key in ['cpu', 'memory', 'disk', 'network']:
                if len(self.metrics[key]) > 60:
                    self.metrics[key] = self.metrics[key][-60:]
            
            # Ajouter à l'historique (une mesure toutes les 5 minutes)
            now_ts = str(int(time.time()))
            if int(now_ts) % 300 < 30:  # ~toutes les 5 minutes
                self.history['cpu'][now_ts] = cpu_percent
                self.history['memory'][now_ts] = memory.percent
                self.history['disk'][now_ts] = disk.percent
            
        except Exception as e:
            logger.error(f"Erreur lors de la collecte des métriques: {e}")
            self.metrics['errors'] += 1
            
            # Enregistrer l'erreur dans l'historique
            now_ts = str(int(time.time()))
            self.history['errors'][now_ts] = str(e)
    
    def _check_thresholds(self):
        """Vérifie si les métriques dépassent les seuils d'alerte"""
        if not self.metrics['cpu'] or not self.metrics['memory']:
            return
        
        # Calculer les moyennes sur les dernières minutes
        avg_cpu = sum(self.metrics['cpu'][-6:]) / min(6, len(self.metrics['cpu']))
        avg_memory = sum(self.metrics['memory'][-6:]) / min(6, len(self.metrics['memory']))
        avg_disk = sum(self.metrics['disk'][-6:]) / min(6, len(self.metrics['disk']))
        
        # Vérifier les seuils
        if avg_cpu > self.extreme_threshold or avg_memory > self.extreme_threshold:
            # Alerte extrême - Mesures d'urgence
            logger.critical(f"ALERTE CRITIQUE: CPU {avg_cpu:.1f}%, Mémoire {avg_memory:.1f}%")
            self._emergency_cleanup()
            
        elif avg_cpu > self.critical_threshold or avg_memory > self.critical_threshold:
            # Alerte critique - Réduction d'activité
            logger.error(f"ALERTE: CPU {avg_cpu:.1f}%, Mémoire {avg_memory:.1f}%")
            self._reduce_activity()
            
        elif avg_cpu > self.warning_threshold or avg_memory > self.warning_threshold:
            # Alerte - Optimisation des ressources
            logger.warning(f"AVERTISSEMENT: CPU {avg_cpu:.1f}%, Mémoire {avg_memory:.1f}%")
            self._optimize_resources()
        
        # Vérifier l'espace disque
        if avg_disk > 90:
            logger.warning(f"AVERTISSEMENT: Espace disque limité ({avg_disk:.1f}%)")
            self._cleanup_disk()
    
    def _emergency_cleanup(self):
        """Mesures d'urgence pour libérer des ressources"""
        logger.critical("Mesures d'urgence pour libérer des ressources")
        
        # Forcer le garbage collector
        gc.collect()
        
        # Vider les caches
        if self.resource_manager:
            self.resource_manager.clear_caches()
        
        # Supprimer les fichiers de log anciens
        self._cleanup_old_logs()
        
        # Limiter le nombre de processus
        self._limit_processes()
    
    def _reduce_activity(self):
        """Réduire l'activité pour économiser les ressources"""
        logger.error("Réduction de l'activité pour économiser les ressources")
        
        # Forcer le garbage collector
        gc.collect()
        
        # Optimisation du gestionnaire de files d'attente
        if self.queue_manager:
            # Suspendre les tâches non critiques
            logger.warning("Suspension des tâches non critiques")
    
    def _optimize_resources(self):
        """Optimise l'utilisation des ressources"""
        logger.warning("Optimisation des ressources")
        
        # Exécuter le garbage collector
        gc.collect()
    
    def _check_memory_cleanup(self):
        """Vérifie si un nettoyage de mémoire est nécessaire"""
        if not self.metrics['memory']:
            return
        
        # Vérifier si la mémoire dépasse 75%
        if self.metrics['memory'][-1] > 75:
            logger.warning(f"Utilisation mémoire élevée ({self.metrics['memory'][-1]:.1f}%), nettoyage")
            
            # Forcer le garbage collector
            collected = gc.collect()
            logger.info(f"Garbage collector: {collected} objets libérés")
    
    def _cleanup_old_logs(self):
        """Supprime les anciens fichiers de log"""
        try:
            log_files = [
                'performance_monitor.log', 
                'resource_manager.log',
                'api_client.log',
                'queue_manager.log',
                'auto_trader_verified.log',
                'bot_output.log'
            ]
            
            for log_file in log_files:
                if os.path.exists(log_file) and os.path.getsize(log_file) > 10 * 1024 * 1024:  # 10 Mo
                    # Renommer le fichier log actuel
                    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                    os.rename(log_file, f"{log_file}.{timestamp}")
                    
                    # Ouvrir un nouveau fichier log
                    with open(log_file, 'w') as f:
                        f.write(f"Log file rotated at {datetime.now()}\n")
                    
                    logger.info(f"Rotation du fichier log {log_file}")
        
        except Exception as e:
            logger.error(f"Erreur lors du nettoyage des logs: {e}")
    
    def _cleanup_disk(self):
        """Nettoie l'espace disque"""
        try:
            # Supprimer les fichiers temporaires
            temp_paths = ['/tmp', os.path.join(os.getcwd(), 'tmp')]
            
            for path in temp_paths:
                if os.path.exists(path) and os.path.isdir(path):
                    for filename in os.listdir(path):
                        file_path = os.path.join(path, filename)
                        try:
                            if os.path.isfile(file_path) and time.time() - os.path.getmtime(file_path) > 86400:
                                os.remove(file_path)
                        except Exception as e:
                            logger.error(f"Erreur lors de la suppression de {file_path}: {e}")
            
            # Nettoyer les anciens logs
            self._cleanup_old_logs()
            
            logger.info("Nettoyage disque effectué")
            
        except Exception as e:
            logger.error(f"Erreur lors du nettoyage disque: {e}")
    
    def _limit_processes(self):
        """Limite le nombre de processus"""
        try:
            # Arrêter les processus non essentiels
            pass  # Implémentation dépend des processus spécifiques
        
        except Exception as e:
            logger.error(f"Erreur lors de la limitation des processus: {e}")
    
    def stop(self):
        """Arrête le moniteur de performances"""
        logger.info("Arrêt du moniteur de performances")
        self.running = False
        
        # Attendre que le thread de monitoring s'arrête
        if self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=2)
        
        # Sauvegarde finale des métriques
        self.save_metrics()
    
    def get_metrics_summary(self):
        """
        Retourne un résumé des métriques de performance
        
        Returns:
            dict: Résumé des métriques
        """
        if not self.metrics['cpu'] or not self.metrics['memory']:
            return {
                'cpu': 0,
                'memory': 0,
                'disk': 0,
                'threads': 0,
                'errors': self.metrics['errors']
            }
        
        # Calculer les moyennes
        avg_cpu = sum(self.metrics['cpu'][-10:]) / min(10, len(self.metrics['cpu']))
        avg_memory = sum(self.metrics['memory'][-10:]) / min(10, len(self.metrics['memory']))
        avg_disk = sum(self.metrics['disk'][-10:]) / min(10, len(self.metrics['disk']))
        
        return {
            'cpu': avg_cpu,
            'memory': avg_memory,
            'disk': avg_disk,
            'threads': self.metrics['threads'],
            'errors': self.metrics['errors'],
            'status': self._get_system_status(avg_cpu, avg_memory)
        }
    
    def _get_system_status(self, cpu, memory):
        """
        Détermine le statut du système en fonction des métriques
        
        Args:
            cpu (float): Utilisation CPU en %
            memory (float): Utilisation mémoire en %
            
        Returns:
            str: Statut du système
        """
        if cpu > self.critical_threshold or memory > self.critical_threshold:
            return "critical"
        elif cpu > self.warning_threshold or memory > self.warning_threshold:
            return "warning"
        else:
            return "normal"
    
    def get_performance_trends(self, hours=24):
        """
        Récupère les tendances de performance sur une période
        
        Args:
            hours (int): Nombre d'heures
            
        Returns:
            dict: Tendances de performance
        """
        cutoff = time.time() - (hours * 3600)
        
        # Filtrer l'historique
        filtered_cpu = {ts: val for ts, val in self.history['cpu'].items() if float(ts) > cutoff}
        filtered_memory = {ts: val for ts, val in self.history['memory'].items() if float(ts) > cutoff}
        
        # Calculer les tendances (valeurs moyennes par heure)
        cpu_trend = self._calculate_hourly_average(filtered_cpu)
        memory_trend = self._calculate_hourly_average(filtered_memory)
        
        return {
            'cpu': cpu_trend,
            'memory': memory_trend
        }
    
    def _calculate_hourly_average(self, data):
        """
        Calcule la moyenne horaire des données
        
        Args:
            data (dict): Données {timestamp: valeur}
            
        Returns:
            list: Moyennes horaires [(hour, value), ...]
        """
        if not data:
            return []
        
        # Regrouper par heure
        hourly_data = {}
        
        for ts, value in data.items():
            hour = int(float(ts) / 3600) * 3600
            if hour not in hourly_data:
                hourly_data[hour] = []
            hourly_data[hour].append(value)
        
        # Calculer les moyennes
        hourly_avg = [
            (hour, sum(values) / len(values))
            for hour, values in hourly_data.items()
        ]
        
        # Trier par heure
        hourly_avg.sort(key=lambda x: x[0])
        
        return hourly_avg
    
    def record_error(self, error_type, details):
        """
        Enregistre une erreur système
        
        Args:
            error_type (str): Type d'erreur
            details (str): Détails de l'erreur
        """
        self.metrics['errors'] += 1
        
        # Enregistrer dans l'historique
        now_ts = str(int(time.time()))
        self.history['errors'][now_ts] = f"{error_type}: {details}"
        
        # Log
        logger.error(f"{error_type}: {details}")


# Fonction utilitaire pour obtenir une instance unique
_performance_monitor_instance = None

def get_performance_monitor(resource_manager=None, queue_manager=None):
    """
    Récupère l'instance unique du moniteur de performances
    
    Args:
        resource_manager: Gestionnaire de ressources optionnel
        queue_manager: Gestionnaire de files d'attente optionnel
        
    Returns:
        PerformanceMonitor: Instance du moniteur
    """
    global _performance_monitor_instance
    if _performance_monitor_instance is None:
        _performance_monitor_instance = PerformanceMonitor(
            resource_manager, queue_manager
        )
    return _performance_monitor_instance