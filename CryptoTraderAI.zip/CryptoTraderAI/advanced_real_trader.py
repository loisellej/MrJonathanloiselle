import os
import time
import logging
import threading
import random
import numpy as np
import ccxt
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AdvancedRealTrader:
    def __init__(self, api_key=None, api_secret=None, risk_per_trade=0.9):
        """
        Initialisation du trader avancé en mode RÉEL UNIQUEMENT
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
            risk_per_trade (float): Pourcentage du solde à utiliser par trade (0-1)
        """
        self.api_key = api_key or os.environ.get('KRAKEN_API_KEY')
        self.api_secret = api_secret or os.environ.get('KRAKEN_API_SECRET')
        self.risk_per_trade = risk_per_trade
        self.exchange = None
        
        # Initialisation des variables de trading
        self.balances = {}
        self.price_cache = {}
        self.price_cache_lock = threading.Lock()
        self.cached_prices_ttl = 50  # 50ms de TTL pour réponse en microsecondes
        self.price_history = {}
        self.volatile_assets = []
        self.asset_volatility = {}
        self.asset_sentiment = {}
        self.asset_bubble_score = {}
        self.trade_history = []
        self.entry_prices = {}
        self.stop_losses = {}
        self.running = False
        self.threads = []
        
        # Crypto exclues du trading
        self.excluded_assets = ['BTC', 'ETH', 'SOL']
        
        # Configuration spéciale pour AUDIO
        self.audio_stop_loss = 0.08  # Stop-loss fixe pour AUDIO
        
        # Initialiser l'analyseur de sentiment
        self.sentiment_analyzer = SentimentIntensityAnalyzer()
        
        # Initialiser l'exchange
        self.initialize_exchange()
    
    def initialize_exchange(self):
        """Initialise la connexion à l'exchange Kraken"""
        try:
            logger.info("Initialisation de Kraken en MODE RÉEL UNIQUEMENT...")
            
            # Vérification des clés API
            if not self.api_key or not self.api_secret or len(self.api_key) < 10 or len(self.api_secret) < 10:
                raise ValueError("Clés API Kraken invalides ou manquantes - MODE RÉEL UNIQUEMENT")
            
            # Configuration de l'exchange avec options HFT
            self.exchange = ccxt.kraken({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'options': {
                    'adjustForTimeDifference': True,
                    'recvWindow': 5000
                },
                'timeout': 10000
            })
            
            # Test de la connexion
            logger.info("Test de la connexion API Kraken...")
            self.exchange.load_markets()
            
            # Test avec des endpoints privés
            self.exchange.fetch_balance()
            logger.info("Connexion à Kraken réussie!")
            
            # Initialiser les balances
            self.refresh_balances()
            
            return True
        except Exception as e:
            logger.error(f"ERREUR d'initialisation de l'exchange: {e}")
            raise
    
    def refresh_balances(self):
        """Récupère les balances depuis l'exchange"""
        try:
            logger.info("Récupération des balances Kraken...")
            balance = self.exchange.fetch_balance()
            total = balance.get('total', {})
            
            # Filtrer uniquement les balances positives
            self.balances = {k: v for k, v in total.items() if v and v > 0}
            
            # S'assurer que USDT est toujours présent
            if 'USDT' not in self.balances:
                self.balances['USDT'] = 0.0
            
            logger.info(f"Balances actuelles: {self.balances}")
            return self.balances
        except Exception as e:
            logger.error(f"Erreur de récupération des balances: {e}")
            return self.balances
    
    def _run_price_cache_updater(self):
        """Thread qui met à jour le cache de prix pour un accès en microsecondes"""
        logger.info("Démarrage du thread de mise à jour du cache de prix...")
        
        while self.running:
            try:
                # Obtenir les marchés les plus actifs
                markets = self.exchange.markets
                tradable_markets = [m for m in markets.keys() if '/USDT' in m or '/USD' in m][:50]
                
                # Exclure BTC, ETH, SOL
                filtered_markets = []
                for market in tradable_markets:
                    base = market.split('/')[0]
                    if base not in self.excluded_assets:
                        filtered_markets.append(market)
                
                # Mise à jour des prix en parallèle
                with ThreadPoolExecutor(max_workers=10) as executor:
                    futures = {executor.submit(self._update_single_price, market): market for market in filtered_markets}
                    for future in as_completed(futures):
                        pass  # Laisser terminer
                
                # Court délai entre les mises à jour du cache
                time.sleep(0.05)  # 50ms entre les updates (20 updates par seconde)
            except Exception as e:
                logger.error(f"Erreur dans le thread de mise à jour du cache: {e}")
                time.sleep(1.0)
    
    def _update_single_price(self, market):
        """Met à jour un seul prix dans le cache"""
        try:
            ticker = self.exchange.fetch_ticker(market)
            
            with self.price_cache_lock:
                self.price_cache[market] = {
                    'price': ticker['last'],
                    'bid': ticker['bid'],
                    'ask': ticker['ask'],
                    'timestamp': int(time.time() * 1000)
                }
            
            # Mettre à jour l'historique des prix
            base_symbol = market.split('/')[0]
            self.update_price_history(base_symbol, ticker['last'])
        except Exception:
            # Échec silencieux - nouvelle tentative au prochain cycle
            pass
    
    def update_price_history(self, asset, price):
        """Met à jour l'historique des prix pour un actif"""
        if asset not in self.price_history:
            self.price_history[asset] = []
        
        self.price_history[asset].append({
            'price': price,
            'timestamp': datetime.now()
        })
        
        # Garder seulement les 100 derniers points
        if len(self.price_history[asset]) > 100:
            self.price_history[asset] = self.price_history[asset][-100:]
    
    def _find_volatile_assets_thread(self):
        """Thread qui recherche en continu les actifs les plus volatils"""
        logger.info("Démarrage du thread de recherche d'actifs volatils...")
        
        while self.running:
            try:
                # Rechercher les actifs volatils
                volatile_assets = self.find_volatile_assets()
                logger.info(f"Actifs volatils mis à jour: {volatile_assets}")
                
                # Attendre avant la prochaine mise à jour (15 minutes)
                time.sleep(900)
            except Exception as e:
                logger.error(f"Erreur dans le thread de recherche d'actifs volatils: {e}")
                time.sleep(60)
    
    def find_volatile_assets(self, max_assets=10):
        """
        Trouve les actifs les plus volatils sur Kraken - Analyse TOUS les actifs disponibles
        Vise des gains de 20-50% mensuels grâce à une analyse approfondie
        
        Returns:
            list: Liste des actifs les plus volatils
        """
        try:
            logger.info("Recherche des actifs les plus volatils...")
            
            # Obtenir tous les marchés disponibles
            markets = self.exchange.load_markets()
            
            # Filtrer les paires USDT et USD
            tradable_markets = [m for m in markets.keys() if '/USDT' in m or '/USD' in m]
            
            # SCANNER TOUS LES ACTIFS DISPONIBLES pour trouver les meilleures opportunités
            market_data = {}
            for market in tradable_markets:  # Analyse de TOUS les marchés sans limitation
                try:
                    # Extraire le symbole de base
                    base_symbol = market.split('/')[0]
                    
                    # Ignorer les actifs exclus
                    if base_symbol in self.excluded_assets:
                        continue
                    
                    # Récupérer les données historiques
                    ohlcv = self.exchange.fetch_ohlcv(market, timeframe='1h', limit=24)
                    
                    # Calculer la volatilité
                    if len(ohlcv) > 5:
                        closes = [candle[4] for candle in ohlcv]
                        pct_changes = [((closes[i] - closes[i-1]) / closes[i-1]) * 100 for i in range(1, len(closes))]
                        volatility = np.std(pct_changes)
                        
                        # Récupérer le volume
                        volume = sum([candle[5] for candle in ohlcv[-6:]])  # Volume des 6 dernières heures
                        
                        # Calculer le sentiment
                        sentiment = self.analyze_sentiment(base_symbol)
                        
                        # Calculer le score de bulle
                        bubble_score = self.calculate_bubble_score(base_symbol)
                        
                        # Stocker les données
                        market_data[base_symbol] = {
                            'volatility': volatility,
                            'volume': volume,
                            'sentiment': sentiment,
                            'bubble_score': bubble_score,
                            'market': market
                        }
                        
                        # Mettre à jour la volatilité et le sentiment
                        self.asset_volatility[base_symbol] = volatility
                        self.asset_sentiment[base_symbol] = sentiment
                        self.asset_bubble_score[base_symbol] = bubble_score
                    
                    # Court délai pour éviter de surcharger l'API
                    time.sleep(0.2)
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse du marché {market}: {e}")
            
            # GAINS DE 20-50% PAR MOIS: Algorithme avancé de scoring des actifs
            for symbol, data in market_data.items():
                # Donner plus de poids à la volatilité (facteur clé pour gains 20-50% mensuels)
                log_volume = np.log(max(data['volume'], 1.0))
                data['score'] = data['volatility'] * 8.0 + log_volume  # Poids augmenté pour volatilité
                
                # Exploitation maximale des sentiments positifs
                if data['sentiment'] > 0.1:
                    data['score'] *= 1.5  # Bonus plus important pour sentiment positif
                
                # Détection et trading des bulles en formation (potentiel max de gain)
                if 0.3 < data['bubble_score'] < 0.7:
                    data['score'] *= 1.8  # Bonus très important pour bulles en formation
            
            # Trier par score
            sorted_assets = sorted(market_data.items(), key=lambda x: x[1]['score'], reverse=True)
            
            # Mettre à jour la liste des actifs volatils
            volatile_assets = [asset for asset, _ in sorted_assets[:max_assets]]
            self.volatile_assets = volatile_assets
            
            return volatile_assets
        except Exception as e:
            logger.error(f"Erreur lors de la recherche d'actifs volatils: {e}")
            return []
    
    def _trading_thread(self):
        """Thread principal de trading"""
        logger.info("Démarrage du thread principal de trading...")
        
        while self.running:
            try:
                # Rafraîchir les balances
                self.refresh_balances()
                
                # Vérifier les stop-loss en premier (priorité à la protection du capital)
                self.check_stop_losses()
                
                # Obtenir les actifs volatils
                if not self.volatile_assets:
                    self.volatile_assets = self.find_volatile_assets()
                
                # Exécuter la logique de trading sur chaque actif volatil
                for asset in self.volatile_assets:
                    if asset not in self.excluded_assets:
                        self.execute_trade_logic(asset)
                
                # Attendre avant le prochain cycle
                time.sleep(1.0)
            except Exception as e:
                logger.error(f"Erreur dans le thread de trading: {e}")
                time.sleep(5.0)
    
    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel avec temps de réponse en microsecondes
        
        Args:
            symbol (str): Symbole de la paire de trading (ex: 'BTC/USDT')
        
        Returns:
            float: Prix actuel ou None si non disponible
        """
        # Normaliser le format du symbole
        if not '/' in symbol:
            symbol = f"{symbol}/USDT"
        
        try:
            # D'abord, vérifier dans le cache pour une réponse ultra-rapide
            with self.price_cache_lock:
                if symbol in self.price_cache:
                    cache_entry = self.price_cache[symbol]
                    cache_age = int(time.time() * 1000) - cache_entry['timestamp']
                    
                    if cache_age < self.cached_prices_ttl:
                        return cache_entry['price']
            
            # Si pas dans le cache ou cache expiré, récupérer en temps réel
            ticker = self.exchange.fetch_ticker(symbol)
            price = ticker['last']
            
            # Mettre à jour le cache
            with self.price_cache_lock:
                self.price_cache[symbol] = {
                    'price': price,
                    'bid': ticker['bid'],
                    'ask': ticker['ask'],
                    'timestamp': int(time.time() * 1000)
                }
            
            return price
        except Exception as e:
            logger.error(f"Erreur de récupération du prix pour {symbol}: {e}")
            return None
    
    def analyze_sentiment(self, asset):
        """
        Analyse le sentiment pour un actif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            float: Score de sentiment entre -1 et 1
        """
        try:
            # Pour l'instant, on simule l'analyse de sentiment (pour être remplacé par une vraie analyse)
            headlines = self._simulate_headlines(asset)
            
            # Analyser le sentiment des titres
            compound_scores = []
            for headline in headlines:
                score = self.sentiment_analyzer.polarity_scores(headline)
                compound_scores.append(score['compound'])
            
            # Calculer le sentiment moyen
            avg_sentiment = sum(compound_scores) / len(compound_scores) if compound_scores else 0
            
            return avg_sentiment
        except Exception as e:
            logger.error(f"Erreur d'analyse de sentiment pour {asset}: {e}")
            return 0.0  # Sentiment neutre en cas d'erreur
    
    def _simulate_headlines(self, asset):
        """
        Simule la récupération de titres d'actualité pour une cryptomonnaie
        À remplacer par une vraie source d'actualités comme NewsAPI ou Twitter
        """
        # Templates de titres par sentiment
        positive_templates = [
            "{asset} surges as adoption increases",
            "New partnership boosts {asset} by 10%",
            "Analysts predict bullish trend for {asset}",
            "{asset} becomes most traded token on major exchanges",
            "Institutional investors buying {asset} in record numbers"
        ]
        
        negative_templates = [
            "{asset} drops amid market uncertainty",
            "Regulatory concerns affect {asset} price",
            "Major holder dumps {asset} causing price drop",
            "Technical analysis suggests {asset} correction incoming",
            "Market sentiment turns bearish for {asset}"
        ]
        
        neutral_templates = [
            "{asset} price stabilizes after volatility",
            "Trading volume steady for {asset}",
            "Market analysts divided on {asset} future",
            "{asset} maintaining support levels",
            "New {asset} update receives mixed reactions"
        ]
        
        # Générer quelques titres aléatoires
        headlines = []
        
        # Plus l'actif est volatile, plus les titres sont extrêmes
        volatility = self.asset_volatility.get(asset, 5.0)
        
        # Générer entre 3 et 10 titres
        num_headlines = max(3, min(10, int(volatility/2)))
        
        # Pour les actifs volatils, favoriser les titres positifs
        for _ in range(num_headlines):
            if asset in self.volatile_assets and random.random() < 0.7:
                template = random.choice(positive_templates)
            elif random.random() < 0.5:
                # 50% chance d'être positif
                template = random.choice(positive_templates)
            elif random.random() < 0.7:
                # 35% chance d'être négatif
                template = random.choice(negative_templates)
            else:
                # 15% chance d'être neutre
                template = random.choice(neutral_templates)
            
            headlines.append(template.format(asset=asset))
        
        return headlines
    
    def calculate_bubble_score(self, asset):
        """
        Calcule un score de bulle pour un actif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            float: Score de bulle entre 0 et 1
        """
        # Vérifier si nous avons assez de données d'historique
        if asset not in self.price_history or len(self.price_history[asset]) < 10:
            return 0.0
        
        try:
            # Récupérer l'historique des prix
            history = self.price_history[asset]
            prices = [entry['price'] for entry in history]
            
            # Calculer la moyenne mobile exponentielle (EMA)
            ema_period = min(20, len(prices))
            ema = prices[-ema_period:]
            for i in range(1, ema_period):
                alpha = 2 / (ema_period + 1)
                ema[i] = alpha * prices[-ema_period+i] + (1 - alpha) * ema[i-1]
            
            current_ema = ema[-1]
            
            # Calculer le ratio prix/EMA
            price_ema_ratio = prices[-1] / current_ema if current_ema > 0 else 1.0
            
            # Calculer la pente
            recent_window = min(5, len(prices))
            recent_prices = prices[-recent_window:]
            
            if len(recent_prices) >= 2:
                slope = (recent_prices[-1] - recent_prices[0]) / recent_prices[0]
            else:
                slope = 0
            
            # Mouvement journalier
            daily_movement = 0
            if len(history) >= 2:
                newest = history[-1]
                oldest = history[0]
                time_diff = (newest['timestamp'] - oldest['timestamp']).total_seconds() / 3600
                
                if time_diff > 0:
                    price_change = (newest['price'] - oldest['price']) / oldest['price'] * 100
                    daily_movement = price_change / (time_diff / 24)
            
            # Calculer le score de bulle
            bubble_score = 0.0
            
            if price_ema_ratio > 1.1:
                bubble_score += min(0.5, (price_ema_ratio - 1.0) * 2)
            
            if slope > 0.05:
                bubble_score += min(0.3, slope * 3)
            
            if daily_movement > 5.0:
                bubble_score += min(0.2, daily_movement / 25.0)
            
            return min(1.0, bubble_score)
        except Exception as e:
            logger.error(f"Erreur de calcul du score de bulle pour {asset}: {e}")
            return 0.0
    
    def calculate_momentum(self, asset):
        """
        Calcule le momentum pour un actif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            float: Score de momentum entre -1 et 1
        """
        if asset not in self.price_history or len(self.price_history[asset]) < 5:
            return 0.0
        
        try:
            # Récupérer les prix récents
            recent_prices = self.price_history[asset][-10:]
            prices = [entry['price'] for entry in recent_prices]
            
            # Calculer les variations en pourcentage
            pct_changes = [((prices[i] - prices[i-1]) / prices[i-1]) * 100 for i in range(1, len(prices))]
            
            # Utiliser une moyenne pondérée (plus de poids aux variations récentes)
            weights = [0.1, 0.15, 0.2, 0.25, 0.3]
            weights = weights[-len(pct_changes):]
            
            # Normaliser les poids
            weights = [w / sum(weights) for w in weights]
            
            # Calculer le momentum pondéré
            weighted_momentum = sum(pct * w for pct, w in zip(pct_changes[-len(weights):], weights))
            
            # Normaliser entre -1 et 1
            normalized_momentum = max(-1.0, min(1.0, weighted_momentum / 5.0))
            
            return normalized_momentum
        except Exception as e:
            logger.error(f"Erreur de calcul du momentum pour {asset}: {e}")
            return 0.0
    
    def has_strong_momentum(self, asset):
        """
        Vérifie si un actif a un fort momentum positif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            bool: True si l'actif a un fort momentum positif
        """
        momentum = self.calculate_momentum(asset)
        volatility = self.asset_volatility.get(asset, 5.0)
        
        # Ajuster le seuil en fonction de la volatilité
        threshold = 0.2
        if volatility > 10.0:
            threshold = 0.15  # Seuil plus bas pour les actifs très volatils
        
        return momentum > threshold
    
    def dynamic_stop_loss(self, current_price, entry_price, asset=None):
        """
        Calcule un stop-loss dynamique adapté au momentum et à la volatilité
        
        Args:
            current_price (float): Prix actuel
            entry_price (float): Prix d'entrée
            asset (str): Symbole de l'actif
        
        Returns:
            float: Prix du stop-loss
        """
        # Cas spécial pour AUDIO avec stop-loss fixe
        if asset == 'AUDIO':
            return self.audio_stop_loss
        
        # Récupérer la volatilité et le momentum
        volatility = self.asset_volatility.get(asset, 5.0)
        momentum = self.calculate_momentum(asset) if asset else 0.0
        
        # Déterminer si c'est une position longue
        is_long = current_price >= entry_price
        
        # Ajuster le pourcentage du stop-loss en fonction de la volatilité et du momentum
        if is_long:
            # Pour les positions longues
            if asset and self.has_strong_momentum(asset):
                # Stop-loss plus éloigné pour les actifs à fort momentum
                stop_pct = max(0.05, min(0.15, volatility / 100.0 * 1.5))
            else:
                # Stop-loss normal
                stop_pct = max(0.03, min(0.10, volatility / 100.0))
            
            # Calculer le stop-loss
            stop_loss = current_price * (1.0 - stop_pct)
            
            # Ne jamais mettre le stop-loss en dessous de 95% du prix d'entrée
            min_stop = entry_price * 0.95
            return max(stop_loss, min_stop)
        else:
            # Pour les positions courtes (pas utilisé en spot trading mais gardé pour complétude)
            if asset and self.has_strong_momentum(asset):
                stop_pct = max(0.05, min(0.15, volatility / 100.0 * 1.5))
            else:
                stop_pct = max(0.03, min(0.10, volatility / 100.0))
            
            # Calculer le stop-loss
            stop_loss = current_price * (1.0 + stop_pct)
            
            # Ne jamais mettre le stop-loss au-dessus de 105% du prix d'entrée
            max_stop = entry_price * 1.05
            return min(stop_loss, max_stop)
    
    def check_stop_losses(self):
        """Vérifie tous les stop-losses et exécute les ventes si nécessaire"""
        for asset, stop_loss in self.stop_losses.items():
            try:
                # Vérifier si nous avons une position sur cet actif
                balance = self.balances.get(asset, 0)
                if balance <= 0:
                    continue  # Pas de position
                
                # Récupérer le prix actuel
                current_price = self.get_ticker_price(f"{asset}/USDT")
                if not current_price:
                    continue  # Pas de prix disponible
                
                # Cas spécial pour AUDIO
                if asset == 'AUDIO' and current_price <= self.audio_stop_loss:
                    logger.info(f"⚠️ Stop-loss atteint pour AUDIO à {current_price} (fixe à {self.audio_stop_loss})")
                    self.sell(asset, balance)  # Vendre 100%
                    continue
                
                # Pour les autres actifs
                entry_price = self.entry_prices.get(asset, current_price)
                is_long = entry_price <= current_price
                
                if is_long and current_price <= stop_loss:
                    # Stop-loss déclenché pour position longue
                    logger.info(f"⚠️ Stop-loss atteint pour {asset} à {current_price} (stop à {stop_loss})")
                    self.sell(asset, balance)  # Vendre 100%
            except Exception as e:
                logger.error(f"Erreur lors de la vérification du stop-loss pour {asset}: {e}")
    
    def calculate_trade_size(self, balance, price, asset=None):
        """
        Calcule la taille optimale du trade
        
        Args:
            balance (float): Solde disponible
            price (float): Prix actuel
            asset (str): Symbole de l'actif
        
        Returns:
            float: Taille du trade
        """
        try:
            # Récupérer la volatilité
            volatility = self.asset_volatility.get(asset, 5.0)
            
            # Multiplicateur pour les actifs à fort momentum
            momentum_multiplier = 1.0
            if asset and self.has_strong_momentum(asset):
                momentum_multiplier = 1.3  # 30% plus grand pour les actifs à fort momentum
            
            # Multiplicateur pour les bulles
            bubble_multiplier = 1.0
            if asset:
                bubble_score = self.asset_bubble_score.get(asset, 0.0)
                if bubble_score > 0.7:
                    # Réduire les trades pour les bulles probables
                    bubble_multiplier = 0.7
                elif bubble_score > 0.4:
                    # Augmenter les trades pour les bulles potentielles (opportunité)
                    bubble_multiplier = 1.2
            
            # Ajuster le risque en fonction de la volatilité
            volatility_factor = min(1.1, max(0.8, volatility / 10.0))
            
            # Calculer la taille du trade
            usdt_amount = balance * self.risk_per_trade * momentum_multiplier * bubble_multiplier * volatility_factor
            
            # Convertir en unités de l'actif
            amount = usdt_amount / price if price > 0 else 0
            
            # Minimum de 1 USDT
            min_amount = 1.0 / price if price > 0 else 0
            amount = max(amount, min_amount)
            
            # Arrondir à 8 décimales
            amount = round(amount, 8)
            
            return amount
        except Exception as e:
            logger.error(f"Erreur de calcul de taille de trade: {e}")
            return balance * 0.5  # Valeur sûre par défaut
    
    def buy(self, asset, amount=None, percentage=None):
        """
        Exécute un ordre d'achat
        
        Args:
            asset (str): Symbole de l'actif
            amount (float): Montant à acheter (en actif)
            percentage (float): Pourcentage du solde USDT à utiliser
        
        Returns:
            dict: Détails de l'ordre ou None en cas d'erreur
        """
        try:
            symbol = f"{asset}/USDT"
            
            # Si montant non spécifié mais pourcentage oui
            if amount is None and percentage is not None:
                usdt_balance = self.balances.get('USDT', 0)
                usdt_to_use = usdt_balance * percentage
                
                # Récupérer le prix actuel
                price = self.get_ticker_price(symbol)
                if not price:
                    logger.error(f"Impossible d'obtenir le prix pour {symbol}")
                    return None
                
                amount = usdt_to_use / price
            
            # Vérifier si le montant est valide
            if amount <= 0:
                logger.warning(f"Montant d'achat invalide pour {asset}: {amount}")
                return None
            
            # Récupérer le prix actuel pour le logging
            price = self.get_ticker_price(symbol)
            logger.info(f"🔵 Achat de {amount} {asset} à environ {price} USDT")
            
            # Exécuter l'ordre
            order = self.exchange.create_market_buy_order(symbol, amount)
            
            # Enregistrer le prix d'entrée
            self.entry_prices[asset] = price
            
            # Calculer et enregistrer le stop-loss
            stop_loss = self.dynamic_stop_loss(price, price, asset)
            self.stop_losses[asset] = stop_loss
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Enregistrer dans l'historique
            trade_record = {
                'timestamp': datetime.now(),
                'asset': asset,
                'action': 'buy',
                'amount': amount,
                'price': price,
                'total_usdt': amount * price,
                'sentiment': self.asset_sentiment.get(asset, 0),
                'volatility': self.asset_volatility.get(asset, 0),
                'bubble_score': self.asset_bubble_score.get(asset, 0),
                'stop_loss': stop_loss
            }
            self.trade_history.append(trade_record)
            
            logger.info(f"✅ Achat réussi de {amount} {asset} à {price} USDT (stop-loss: {stop_loss})")
            return order
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {asset}: {e}")
            return None
    
    def sell(self, asset, amount=None, percentage=None):
        """
        Exécute un ordre de vente
        
        Args:
            asset (str): Symbole de l'actif
            amount (float): Montant à vendre (en actif)
            percentage (float): Pourcentage du solde de l'actif à vendre
        
        Returns:
            dict: Détails de l'ordre ou None en cas d'erreur
        """
        try:
            # Si montant non spécifié mais pourcentage oui
            if amount is None and percentage is not None:
                asset_balance = self.balances.get(asset, 0)
                amount = asset_balance * percentage
            
            # Vérifier si le montant est valide
            if amount <= 0:
                logger.warning(f"Montant de vente invalide pour {asset}: {amount}")
                return None
            
            symbol = f"{asset}/USDT"
            
            # Récupérer le prix actuel pour le logging
            price = self.get_ticker_price(symbol)
            logger.info(f"🔴 Vente de {amount} {asset} à environ {price} USDT")
            
            # Exécuter l'ordre
            order = self.exchange.create_market_sell_order(symbol, amount)
            
            # Si on vend tout, supprimer les références
            asset_balance = self.balances.get(asset, 0)
            if amount >= asset_balance * 0.9:  # Si on vend plus de 90%
                if asset in self.entry_prices:
                    del self.entry_prices[asset]
                if asset in self.stop_losses:
                    del self.stop_losses[asset]
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Enregistrer dans l'historique
            trade_record = {
                'timestamp': datetime.now(),
                'asset': asset,
                'action': 'sell',
                'amount': amount,
                'price': price,
                'total_usdt': amount * price,
                'sentiment': self.asset_sentiment.get(asset, 0),
                'volatility': self.asset_volatility.get(asset, 0),
                'bubble_score': self.asset_bubble_score.get(asset, 0)
            }
            self.trade_history.append(trade_record)
            
            logger.info(f"✅ Vente réussie de {amount} {asset} à {price} USDT")
            return order
        except Exception as e:
            logger.error(f"Erreur lors de la vente de {asset}: {e}")
            return None
    
    def execute_trade_logic(self, asset):
        """
        Exécute la logique de trading pour un actif avec scaling out 25/25/50
        
        Args:
            asset (str): Symbole de l'actif
        """
        try:
            # Ignorer les actifs exclus
            if asset in self.excluded_assets:
                return
            
            # Récupérer les balances
            asset_balance = self.balances.get(asset, 0)
            usdt_balance = self.balances.get('USDT', 0)
            
            # Récupérer le prix actuel
            symbol = f"{asset}/USDT"
            current_price = self.get_ticker_price(symbol)
            if not current_price:
                return
            
            # Mettre à jour l'historique des prix
            self.update_price_history(asset, current_price)
            
            # Récupérer les métriques
            sentiment = self.asset_sentiment.get(asset, self.analyze_sentiment(asset))
            volatility = self.asset_volatility.get(asset, 5.0)
            bubble_score = self.asset_bubble_score.get(asset, self.calculate_bubble_score(asset))
            
            # Cas spécial pour AUDIO
            if asset == 'AUDIO':
                # Mise à jour du stop-loss spécial pour AUDIO
                if asset_balance > 0:
                    self.stop_losses[asset] = self.audio_stop_loss
                
                # Si possédons AUDIO et prix > 0.095
                if asset_balance > 0:
                    # Niveau 1 - Vendre 25% à 0.095
                    if 0.095 <= current_price < 0.105:
                        self.sell(asset, percentage=0.25)
                        logger.info(f"📈 Prise de bénéfices AUDIO niveau 1 (25%) à {current_price}")
                        return
                    
                    # Niveau 2 - Vendre 25% à 0.105
                    elif 0.105 <= current_price < 0.12:
                        self.sell(asset, percentage=0.25)
                        logger.info(f"📈 Prise de bénéfices AUDIO niveau 2 (25%) à {current_price}")
                        return
                    
                    # Niveau 3 - Vendre 25% à 0.12
                    elif current_price >= 0.12:
                        self.sell(asset, percentage=0.25)
                        logger.info(f"📈 Prise de bénéfices AUDIO niveau 3 (25%) à {current_price}")
                        return
            
            # Stratégie de scaling out pour tous les actifs (si nous avons une position)
            if asset_balance > 0 and asset in self.entry_prices:
                entry_price = self.entry_prices[asset]
                profit_pct = (current_price - entry_price) / entry_price * 100
                
                # Niveau 1 - Vendre 25% à +10%
                if 10 <= profit_pct < 15:
                    self.sell(asset, percentage=0.25)
                    logger.info(f"📈 Prise de bénéfices {asset} niveau 1 (25%) à +{profit_pct:.2f}%")
                    return
                
                # Niveau 2 - Vendre 25% à +15%
                elif 15 <= profit_pct < 25:
                    self.sell(asset, percentage=0.25)
                    logger.info(f"📈 Prise de bénéfices {asset} niveau 2 (25%) à +{profit_pct:.2f}%")
                    return
                
                # Niveau 3 - Conserver 50% pour profit potentiel plus important
                elif profit_pct >= 25:
                    # Ne vendre que si nous n'avons pas encore réduit la position
                    if asset_balance >= self.entry_prices.get(f"{asset}_initial_balance", asset_balance) * 0.5:
                        self.sell(asset, percentage=0.5)
                        logger.info(f"📈 Prise de bénéfices {asset} niveau 3 (50%) à +{profit_pct:.2f}%")
                        return
            
            # Day trading actif - décisions d'achat/vente
            
            # Seuils de sentiment
            sentiment_buy_threshold = 0.1
            sentiment_sell_threshold = -0.1
            
            # Ajuster les seuils pour les actifs très volatils
            if volatility > 10.0:
                sentiment_buy_threshold = 0.08
                sentiment_sell_threshold = -0.08
            
            # Condition d'achat: sentiment positif et volatilité suffisante
            if sentiment > sentiment_buy_threshold and volatility > 3.0:
                # Pour les bulles très avancées, être prudent
                if bubble_score > 0.8:
                    logger.info(f"⚠️ Bulle très avancée détectée pour {asset} ({bubble_score:.2f}) - pas d'achat")
                    return
                
                # Calculer la taille du trade
                trade_size = self.calculate_trade_size(usdt_balance, current_price, asset)
                
                # Exécuter l'achat si suffisant
                if trade_size * current_price >= 1.0:  # Minimum 1 USDT
                    # Enregistrer la taille initiale de la position pour le scaling out
                    if asset not in self.entry_prices:
                        self.entry_prices[f"{asset}_initial_balance"] = trade_size
                    
                    self.buy(asset, amount=trade_size)
                    return
            
            # Condition de vente: sentiment négatif ou bulle sur le point d'éclater
            elif (sentiment < sentiment_sell_threshold or bubble_score > 0.85) and asset_balance > 0:
                # Si bulle très avancée, vente d'urgence
                if bubble_score > 0.85:
                    sell_pct = min(1.0, 0.5 + bubble_score * 0.5)  # Plus le score est élevé, plus on vend
                    self.sell(asset, percentage=sell_pct)
                    logger.info(f"⚠️ Vente d'urgence de {asset} - bulle imminente ({bubble_score:.2f})")
                else:
                    # Vente normale basée sur sentiment négatif
                    self.sell(asset, percentage=self.risk_per_trade)
                    logger.info(f"📉 Vente de {asset} - sentiment négatif ({sentiment:.2f})")
                return
            
            # Day trading sur momentum fort
            if self.has_strong_momentum(asset) and volatility > 4.0 and usdt_balance > 10.0:
                # Pour le day trading, utiliser une position plus petite
                usdt_to_use = usdt_balance * self.risk_per_trade * 0.3
                amount = usdt_to_use / current_price
                
                if amount * current_price >= 1.0:  # Minimum 1 USDT
                    self.buy(asset, amount=amount)
                    logger.info(f"🚀 Day trading sur {asset} - fort momentum et volatilité")
                    return
        except Exception as e:
            logger.error(f"Erreur dans la logique de trading pour {asset}: {e}")
    
    def convert_to_volatile(self):
        """
        ÉCHANGE RAPIDE: Convertit TOUS les actifs disponibles en cryptos ultra-volatiles
        Reconnaissance automatique des actifs de valeur et conversion ultra-rapide
        Vise des gains mensuels de 20-50% 
        
        Returns:
            bool: True si au moins une conversion a réussi
        """
        try:
            logger.info("Conversion des actifs en cryptos volatiles...")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Trouver les actifs volatils
            volatile_assets = self.find_volatile_assets(max_assets=3)
            if not volatile_assets:
                logger.warning("Aucun actif volatil trouvé")
                return False
            
            # Convertir d'abord les actifs en USDT (sauf exclus)
            for asset, balance in self.balances.items():
                if asset == 'USDT' or balance <= 0 or asset in volatile_assets[:2]:
                    continue
                
                try:
                    # Vérifier si l'actif a une valeur significative
                    symbol = f"{asset}/USDT"
                    price = self.get_ticker_price(symbol)
                    if not price:
                        continue
                    
                    usdt_value = balance * price
                    
                    # Convertir seulement si valeur > 1 USDT
                    if usdt_value >= 1.0:
                        logger.info(f"Conversion de {balance} {asset} en USDT")
                        self.sell(asset, percentage=1.0)
                except Exception as e:
                    logger.error(f"Erreur lors de la conversion de {asset} en USDT: {e}")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Utiliser USDT pour acheter les actifs volatils
            usdt_balance = self.balances.get('USDT', 0)
            if usdt_balance <= 1.0:
                logger.warning("Solde USDT insuffisant pour acheter des actifs volatils")
                return False
            
            # Répartir sur 3 actifs maximum
            num_assets = min(len(volatile_assets), 3)
            usdt_per_asset = usdt_balance / num_assets
            
            success_count = 0
            for asset in volatile_assets[:num_assets]:
                if asset in self.excluded_assets:
                    continue
                
                logger.info(f"Achat de l'actif volatil {asset}")
                result = self.buy(asset, percentage=1.0/num_assets)
                if result:
                    success_count += 1
            
            return success_count > 0
        except Exception as e:
            logger.error(f"Erreur lors de la conversion en cryptos volatiles: {e}")
            return False
    
    def convert_to_audio(self):
        """
        Convertit tous les actifs significatifs en AUDIO
        
        Returns:
            bool: True si la conversion a réussi
        """
        try:
            logger.info("Conversion des actifs en AUDIO...")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Convertir d'abord les actifs en USDT (sauf AUDIO)
            for asset, balance in self.balances.items():
                if asset in ['USDT', 'AUDIO'] or balance <= 0:
                    continue
                
                try:
                    # Vérifier si l'actif a une valeur significative
                    symbol = f"{asset}/USDT"
                    price = self.get_ticker_price(symbol)
                    if not price:
                        continue
                    
                    usdt_value = balance * price
                    
                    # Convertir seulement si valeur > 1 USDT
                    if usdt_value >= 1.0:
                        logger.info(f"Conversion de {balance} {asset} en USDT")
                        self.sell(asset, percentage=1.0)
                except Exception as e:
                    logger.error(f"Erreur lors de la conversion de {asset} en USDT: {e}")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Utiliser USDT pour acheter AUDIO
            usdt_balance = self.balances.get('USDT', 0)
            if usdt_balance <= 1.0:
                logger.warning("Solde USDT insuffisant pour acheter AUDIO")
                return False
            
            logger.info(f"Achat d'AUDIO avec {usdt_balance} USDT")
            result = self.buy('AUDIO', percentage=1.0)
            
            return result is not None
        except Exception as e:
            logger.error(f"Erreur lors de la conversion en AUDIO: {e}")
            return False
    
    def convert_to_btc(self):
        """
        Convertit tous les actifs significatifs en BTC
        
        Returns:
            bool: True si la conversion a réussi
        """
        try:
            logger.info("Conversion des actifs en BTC...")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Convertir d'abord les actifs en USDT (sauf BTC)
            for asset, balance in self.balances.items():
                if asset in ['USDT', 'BTC'] or balance <= 0:
                    continue
                
                try:
                    # Vérifier si l'actif a une valeur significative
                    symbol = f"{asset}/USDT"
                    price = self.get_ticker_price(symbol)
                    if not price:
                        continue
                    
                    usdt_value = balance * price
                    
                    # Convertir seulement si valeur > 1 USDT
                    if usdt_value >= 1.0:
                        logger.info(f"Conversion de {balance} {asset} en USDT")
                        self.sell(asset, percentage=1.0)
                except Exception as e:
                    logger.error(f"Erreur lors de la conversion de {asset} en USDT: {e}")
            
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Utiliser USDT pour acheter BTC
            usdt_balance = self.balances.get('USDT', 0)
            if usdt_balance <= 1.0:
                logger.warning("Solde USDT insuffisant pour acheter BTC")
                return False
            
            logger.info(f"Achat de BTC avec {usdt_balance} USDT")
            result = self.buy('BTC', percentage=1.0)
            
            return result is not None
        except Exception as e:
            logger.error(f"Erreur lors de la conversion en BTC: {e}")
            return False
    
    def start(self):
        """
        Démarre le trader
        
        Returns:
            bool: True si démarré avec succès
        """
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        try:
            logger.info("🚀 Démarrage du trader avancé en MODE RÉEL...")
            self.running = True
            
            # Démarrer les threads
            thread_price_cache = threading.Thread(target=self._run_price_cache_updater)
            thread_price_cache.daemon = True
            thread_price_cache.start()
            self.threads.append(thread_price_cache)
            
            thread_volatile = threading.Thread(target=self._find_volatile_assets_thread)
            thread_volatile.daemon = True
            thread_volatile.start()
            self.threads.append(thread_volatile)
            
            thread_trading = threading.Thread(target=self._trading_thread)
            thread_trading.daemon = True
            thread_trading.start()
            self.threads.append(thread_trading)
            
            logger.info("Trader démarré avec succès!")
            return True
        except Exception as e:
            logger.error(f"Erreur de démarrage du trader: {e}")
            self.running = False
            return False
    
    def stop(self):
        """
        Arrête le trader
        
        Returns:
            bool: True si arrêté avec succès
        """
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        try:
            logger.info("🛑 Arrêt du trader...")
            self.running = False
            
            # Attendre que les threads se terminent
            for thread in self.threads:
                try:
                    thread.join(timeout=2.0)
                except:
                    pass
            
            self.threads = []
            logger.info("Trader arrêté avec succès!")
            return True
        except Exception as e:
            logger.error(f"Erreur d'arrêt du trader: {e}")
            return False
    
    def get_status(self):
        """
        Récupère le statut complet du trader
        
        Returns:
            dict: Statut du trader
        """
        try:
            # Rafraîchir les balances
            self.refresh_balances()
            
            # Calculer la valeur totale en USDT
            total_value_usdt = 0.0
            balances_with_value = {}
            
            for asset, balance in self.balances.items():
                if balance <= 0:
                    continue
                
                if asset == 'USDT':
                    value_usdt = balance
                else:
                    try:
                        price = self.get_ticker_price(f"{asset}/USDT")
                        value_usdt = balance * price if price else 0
                    except:
                        value_usdt = 0
                
                balances_with_value[asset] = {
                    'balance': balance,
                    'value_usdt': value_usdt
                }
                total_value_usdt += value_usdt
            
            # Préparer les données sur les actifs volatils
            volatile_assets_data = []
            for asset in self.volatile_assets:
                price = self.get_ticker_price(f"{asset}/USDT")
                
                volatile_assets_data.append({
                    'asset': asset,
                    'price': price,
                    'volatility': self.asset_volatility.get(asset, 0),
                    'sentiment': self.asset_sentiment.get(asset, 0),
                    'bubble_score': self.asset_bubble_score.get(asset, 0),
                    'momentum': self.calculate_momentum(asset)
                })
            
            # Récupérer les trades récents
            recent_trades = self.trade_history[-20:] if self.trade_history else []
            
            return {
                'success': True,
                'running': self.running,
                'mode': 'REAL',
                'balances': balances_with_value,
                'total_value_usdt': total_value_usdt,
                'volatile_assets': volatile_assets_data,
                'recent_trades': recent_trades,
                'excluded_assets': self.excluded_assets
            }
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du statut: {e}")
            return {
                'success': False,
                'running': self.running,
                'error': str(e)
            }