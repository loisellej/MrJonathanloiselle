import ccxt
import base64
import logging
import time
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Définir les clés API
RAW_API_KEY = """9/KUxib19lkk7FukHnbupTEBYHIFcKsKtGAEW3/krj89u0jC/fYhrwfD"""
RAW_API_SECRET = """RKJ9m8mLgfDN07bMEvxubD6bY/avyqsQGe6Ev1APMBvBFCvBjXpKGyI5rmR1iJT8U5aVbuHJoY0OI9cprH9qSg=="""

# Nettoyer les clés (supprimer espaces, retours à la ligne, etc.)
def clean_key(key):
    return key.strip().replace('\n', '').replace('\r', '').replace(' ', '')

API_KEY = clean_key(RAW_API_KEY)
API_SECRET = clean_key(RAW_API_SECRET)

def trade_audio_now():
    """Exécuter un trade AUDIO immédiatement avec un prix fixe"""
    logger.info("=== TRADE AUDIO IMMÉDIAT ===")
    now = datetime.now()
    logger.info(f"Date et heure: {now.isoformat()}")
    logger.info(f"Utilisation des clés: {API_KEY[:5]}...{API_KEY[-5:]}")
    
    try:
        # Initialiser l'exchange avec un délai plus long et des options étendues
        exchange = ccxt.kraken({
            'apiKey': API_KEY,
            'secret': API_SECRET,
            'enableRateLimit': True,
            'timeout': 30000,  # 30 secondes de timeout
            'verbose': True  # Pour voir les requêtes en détail
        })
        
        # Charger les marchés
        logger.info("Chargement des marchés...")
        markets = exchange.load_markets()
        logger.info(f"Marchés chargés: {len(markets)} paires disponibles")
        
        # Récupérer les balances
        logger.info("Récupération des balances...")
        balances = exchange.fetch_balance()
        
        # Afficher les balances non nulles
        logger.info("Balances actuelles:")
        for asset, balance in balances['total'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Définir un ordre d'achat simple pour AUDIO/USD
        symbol = "AUDIO/USD"
        
        # Vérifier que la paire existe
        if symbol not in markets:
            logger.error(f"La paire {symbol} n'existe pas sur Kraken")
            return False
        
        # Obtenir le prix actuel
        ticker = exchange.fetch_ticker(symbol)
        current_price = ticker['last']
        logger.info(f"Prix actuel d'AUDIO: {current_price} USD")
        
        # Vérifier le montant minimum
        market_info = markets[symbol]
        min_amount = market_info.get('limits', {}).get('amount', {}).get('min', 1)
        logger.info(f"Montant minimum pour {symbol}: {min_amount}")
        
        # Placer un ordre d'achat limit 1% sous le prix actuel
        buy_price = current_price * 0.99
        buy_amount = max(min_amount * 1.1, 10)  # Au moins 10 AUDIO ou 10% au-dessus du minimum
        
        logger.info(f"Placement d'un ordre limite d'achat de {buy_amount} AUDIO à {buy_price} USD")
        
        order = exchange.create_limit_buy_order(symbol, buy_amount, buy_price)
        logger.info(f"Ordre placé avec succès: {order}")
        
        # Enregistrer le trade dans un fichier journal
        with open('audio_trades.log', 'a') as f:
            f.write(f"[{now.isoformat()}] ORDRE D'ACHAT: {buy_amount} AUDIO à {buy_price} USD\n")
            f.write(f"[{now.isoformat()}] DÉTAILS: {order}\n")
            f.write("-" * 50 + "\n")
        
        return True
    
    except Exception as e:
        error_msg = str(e)
        logger.error(f"❌ Erreur lors du trade: {error_msg}")
        
        if "EAPI:Invalid key" in error_msg:
            logger.error("Problème avec les clés API")
            logger.error("1. Vérifiez que les clés sont correctes")
            logger.error("2. Vérifiez les permissions des clés (Query Funds, Trading)")
            logger.error("3. Vérifiez les restrictions d'IP (désactivez-les pour Replit)")
        elif "EOrder" in error_msg:
            logger.error("Problème avec l'ordre")
            logger.error("1. Le montant pourrait être trop petit")
            logger.error("2. Le solde pourrait être insuffisant")
            logger.error("3. Le prix pourrait être invalide")
        
        return False

if __name__ == "__main__":
    if trade_audio_now():
        print("\n✅ ORDRE DE TRADING AUDIO PLACÉ AVEC SUCCÈS!")
    else:
        print("\n⚠️ LE PLACEMENT DE L'ORDRE A ÉCHOUÉ")