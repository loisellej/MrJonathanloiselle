#!/usr/bin/env python3
"""
Script de démarrage pour le trader multi-positions
Ce script est utilisé pour démarrer le trader multi-positions qui utilise toutes
les positions existantes pour trader entre cryptos volatiles
"""

import os
import sys
import time
import logging
import subprocess

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("trader_24_7.log"),
        logging.StreamHandler()
    ]
)

def test_api_keys():
    """Vérifie si les clés API sont valides"""
    try:
        logging.info("Vérification des clés API Kraken...")
        
        # Récupérer les clés depuis les variables d'environnement
        api_key = os.environ.get("KRAKEN_API_KEY")
        api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        if not api_key or not api_secret:
            logging.error("❌ Clés API Kraken non disponibles dans les variables d'environnement")
            return False
        
        print("Test des clés API Kraken...")
        print(f"API Key: {api_key[:5]}...{api_key[-5:]}")
        print(f"API Secret: {api_secret[:5]}...{api_secret[-5:]}")
        
        # Importer le module pour tester les clés
        from direct_kraken_api import KrakenAPI
        
        # Initialiser l'API
        api = KrakenAPI(api_key=api_key, api_secret=api_secret)
        
        # Tester les clés en récupérant les balances
        print("Test d'une requête privée (Balance)...")
        balances = api.get_balances()
        
        if not balances:
            logging.error("❌ Échec du test des clés API: Aucune balance reçue")
            return False
        
        print("✅ Connexion réussie!")
        print("Balances:")
        for asset, balance in balances.items():
            print(f"  {asset}: {balance}")
        
        print("✅ Test réussi: Les clés API Kraken sont valides!")
        return True
    except Exception as e:
        logging.error(f"❌ Erreur lors du test des clés API: {e}")
        return False

def launch_trader():
    """Lance le trader en arrière-plan"""
    try:
        # Tester d'abord les clés API
        if not test_api_keys():
            logging.error("❌ Les clés API ne sont pas valides. Le trader ne peut pas être démarré.")
            return False
        
        # Démarrer le trader
        print("Démarrage du trader multi-positions en arrière-plan...")
        
        # Exécuter le trader en arrière-plan et rediriger la sortie
        process = subprocess.Popen(
            ["python3", "multi_position_trader.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT
        )
        
        # Enregistrer le PID du processus
        with open("trader.pid", "w") as f:
            f.write(str(process.pid))
        
        logging.info(f"Trader démarré avec PID: {process.pid}")
        print("Bot démarré avec succès!")
        
        return True
    except Exception as e:
        logging.error(f"❌ Erreur lors du lancement du trader: {e}")
        return False

def main():
    """Fonction principale"""
    print("=== DÉMARRAGE DU BOT DE TRADING MULTI-POSITIONS ===")
    print(time.strftime("%a %d %b %Y %I:%M:%S %p %Z", time.localtime()))
    
    # Lancer le trader
    success = launch_trader()
    
    if success:
        print("=== BOT DE TRADING DÉMARRÉ AVEC SUCCÈS ===")
        print("Les logs sont disponibles dans trader_24_7.log")
        print("Vous pouvez vérifier l'état du bot à tout moment avec:")
        print("  python3 check_status.py")
        print("----- " + time.strftime("%c") + " -----")
    else:
        print("=== ÉCHEC DU DÉMARRAGE DU BOT DE TRADING ===")
        print("Veuillez vérifier les logs pour plus d'informations.")
        sys.exit(1)

if __name__ == "__main__":
    main()