import os
import time
import base64
import hashlib
import hmac
import urllib.request
import urllib.parse
import json
import logging
import threading
import random
import ccxt
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SimpleTraderAPI:
    """API simplifiée pour le trading sur Kraken"""
    def __init__(self):
        self.api_key = os.environ.get("KRAKEN_API_KEY")
        self.api_secret = os.environ.get("KRAKEN_API_SECRET")
        self.is_running = False
        self.start_time = None
        self.exchange = None
        self.volatile_assets = ['AUDIO', 'GARI', 'DOGE', 'MATIC', 'MANA', 'SHIB']
        self.thread = None
        self.stop_event = threading.Event()
        
        try:
            self.exchange = ccxt.kraken({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True
            })
            logger.info("Exchange Kraken initialisé")
        except Exception as e:
            logger.error(f"Erreur lors de l'initialisation de l'exchange: {e}")
    
    def start(self):
        """Démarre le trader"""
        if self.is_running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return True
        
        try:
            # Mettre à jour l'état persistant
            with open('trader_status.txt', 'w') as f:
                f.write(f"RUNNING\nStarted: {datetime.now().isoformat()}")
            
            self.is_running = True
            self.start_time = datetime.now()
            
            # Démarrer un thread pour simuler l'activité du trader
            self.stop_event.clear()
            self.thread = threading.Thread(target=self._trading_thread)
            self.thread.daemon = True
            self.thread.start()
            
            logger.info("Trader démarré avec succès")
            return True
        except Exception as e:
            logger.error(f"Erreur lors du démarrage du trader: {e}")
            return False
    
    def stop(self):
        """Arrête le trader"""
        if not self.is_running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return True
        
        try:
            # Mettre à jour l'état persistant
            with open('trader_status.txt', 'w') as f:
                f.write(f"STOPPED\nStopped: {datetime.now().isoformat()}")
            
            self.is_running = False
            self.stop_event.set()
            
            if self.thread:
                self.thread.join(timeout=2.0)
            
            logger.info("Trader arrêté avec succès")
            return True
        except Exception as e:
            logger.error(f"Erreur lors de l'arrêt du trader: {e}")
            return False
    
    def get_balance(self):
        """Récupère les balances du compte"""
        try:
            if self.exchange:
                balances = self.exchange.fetch_balance()
                return balances
            else:
                logger.error("Exchange non initialisé")
                return {}
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances: {e}")
            return {}
    
    def get_markets(self):
        """Récupère les marchés disponibles"""
        try:
            if self.exchange:
                markets = self.exchange.load_markets()
                return markets
            else:
                logger.error("Exchange non initialisé")
                return {}
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des marchés: {e}")
            return {}
    
    def get_ticker(self, symbol):
        """Récupère le ticker pour un symbole"""
        try:
            if self.exchange:
                ticker = self.exchange.fetch_ticker(symbol)
                return ticker
            else:
                logger.error("Exchange non initialisé")
                return {}
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du ticker pour {symbol}: {e}")
            return {}
    
    def place_order(self, symbol, order_type, side, amount, price=None):
        """Place un ordre sur l'exchange"""
        try:
            if self.exchange:
                if order_type == 'market':
                    if side == 'buy':
                        order = self.exchange.create_market_buy_order(symbol, amount)
                    else:
                        order = self.exchange.create_market_sell_order(symbol, amount)
                elif order_type == 'limit':
                    if side == 'buy':
                        order = self.exchange.create_limit_buy_order(symbol, amount, price)
                    else:
                        order = self.exchange.create_limit_sell_order(symbol, amount, price)
                return order
            else:
                logger.error("Exchange non initialisé")
                return None
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre: {e}")
            return None
    
    def _trading_thread(self):
        """Thread simulant l'activité de trading"""
        while not self.stop_event.is_set():
            try:
                # Attendre avant la prochaine itération
                time.sleep(60)
                
                if not self.is_running:
                    break
                
                # Simuler une vérification des conditions de marché
                logger.info("Vérification des conditions de marché...")
                
            except Exception as e:
                logger.error(f"Erreur dans le thread de trading: {e}")
            
            # Vérifier si on doit arrêter le thread
            if self.stop_event.is_set():
                break
    
    def get_status(self):
        """Récupère le statut du trader"""
        status = {
            "running": self.is_running,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "uptime_seconds": (datetime.now() - self.start_time).total_seconds() if self.start_time else 0,
            "balances": {},
            "volatile_assets": self.volatile_assets,
            "performances": {}
        }
        
        # Récupérer les balances réelles
        try:
            if self.exchange:
                balances = self.exchange.fetch_balance()
                
                # Traiter les balances
                for asset, balance in balances['total'].items():
                    if float(balance) > 0:
                        status["balances"][asset] = {
                            "total": float(balance),
                            "free": float(balances['free'].get(asset, 0)),
                            "used": float(balances['used'].get(asset, 0))
                        }
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances pour le statut: {e}")
        
        return status
    
    def convert_to_volatile(self):
        """Convertit les actifs disponibles en cryptos volatiles"""
        logger.info("=== CONVERSION VERS DES CRYPTOS VOLATILES ===")
        
        try:
            if not self.exchange:
                logger.error("Exchange non initialisé")
                return False
            
            # Récupérer les balances
            balances = self.exchange.fetch_balance()
            
            # Récupérer les marchés
            markets = self.exchange.load_markets()
            
            # Vendre tous les actifs non-stables pour des USD/USDT
            for asset, balance in balances['free'].items():
                # Ignorer les stablecoins et les petits montants
                if asset in ['USD', 'USDT', 'USDC'] or float(balance) < 1.0:
                    continue
                
                # Chercher une paire pour vendre l'actif
                symbol = None
                
                # Essayer USD
                symbol_usd = f"{asset}/USD"
                if symbol_usd in markets:
                    symbol = symbol_usd
                
                # Essayer USDT
                if not symbol:
                    symbol_usdt = f"{asset}/USDT"
                    if symbol_usdt in markets:
                        symbol = symbol_usdt
                
                if symbol:
                    logger.info(f"Vente de {balance} {asset} via {symbol}")
                    try:
                        # Vendre 95% pour tenir compte des frais
                        order = self.exchange.create_market_sell_order(symbol, float(balance) * 0.95)
                        logger.info(f"Vente effectuée: {order}")
                    except Exception as e:
                        logger.error(f"Erreur lors de la vente de {asset}: {e}")
            
            # Attendre que les ventes soient finalisées
            time.sleep(5)
            
            # Récupérer les nouvelles balances
            new_balances = self.exchange.fetch_balance()
            
            # Acheter des actifs volatils avec USD/USDT
            usd_balance = float(new_balances['free'].get('USD', 0))
            usdt_balance = float(new_balances['free'].get('USDT', 0))
            
            logger.info(f"Solde USD: {usd_balance}, Solde USDT: {usdt_balance}")
            
            # Acheter avec USD
            if usd_balance > 5:
                for asset in self.volatile_assets:
                    symbol = f"{asset}/USD"
                    if symbol in markets:
                        logger.info(f"Achat de {asset} avec {usd_balance * 0.95} USD")
                        try:
                            order = self.exchange.create_market_buy_order(symbol, None, {'cost': usd_balance * 0.95})
                            logger.info(f"Achat effectué: {order}")
                            return True
                        except Exception as e:
                            logger.error(f"Erreur lors de l'achat de {asset}: {e}")
            
            # Acheter avec USDT
            if usdt_balance > 5:
                for asset in self.volatile_assets:
                    symbol = f"{asset}/USDT"
                    if symbol in markets:
                        logger.info(f"Achat de {asset} avec {usdt_balance * 0.95} USDT")
                        try:
                            order = self.exchange.create_market_buy_order(symbol, None, {'cost': usdt_balance * 0.95})
                            logger.info(f"Achat effectué: {order}")
                            return True
                        except Exception as e:
                            logger.error(f"Erreur lors de l'achat de {asset}: {e}")
            
            logger.warning("Aucun actif volatil n'a pu être acheté")
            return False
            
        except Exception as e:
            logger.error(f"Erreur lors de la conversion vers des cryptos volatiles: {e}")
            return False
    
    def convert_to_audio(self):
        """Convertit les actifs disponibles en AUDIO"""
        logger.info("=== CONVERSION VERS AUDIO ===")
        
        try:
            if not self.exchange:
                logger.error("Exchange non initialisé")
                return False
            
            # Récupérer les balances
            balances = self.exchange.fetch_balance()
            
            # Récupérer les marchés
            markets = self.exchange.load_markets()
            
            # Vendre tous les actifs non-stables pour des USD/USDT
            for asset, balance in balances['free'].items():
                # Ignorer AUDIO, stablecoins et les petits montants
                if asset == 'AUDIO' or asset in ['USD', 'USDT', 'USDC'] or float(balance) < 1.0:
                    continue
                
                # Chercher une paire pour vendre l'actif
                symbol = None
                
                # Essayer USD
                symbol_usd = f"{asset}/USD"
                if symbol_usd in markets:
                    symbol = symbol_usd
                
                # Essayer USDT
                if not symbol:
                    symbol_usdt = f"{asset}/USDT"
                    if symbol_usdt in markets:
                        symbol = symbol_usdt
                
                if symbol:
                    logger.info(f"Vente de {balance} {asset} via {symbol}")
                    try:
                        # Vendre 95% pour tenir compte des frais
                        order = self.exchange.create_market_sell_order(symbol, float(balance) * 0.95)
                        logger.info(f"Vente effectuée: {order}")
                    except Exception as e:
                        logger.error(f"Erreur lors de la vente de {asset}: {e}")
            
            # Attendre que les ventes soient finalisées
            time.sleep(5)
            
            # Récupérer les nouvelles balances
            new_balances = self.exchange.fetch_balance()
            
            # Acheter AUDIO avec USD/USDT
            usd_balance = float(new_balances['free'].get('USD', 0))
            usdt_balance = float(new_balances['free'].get('USDT', 0))
            
            logger.info(f"Solde USD: {usd_balance}, Solde USDT: {usdt_balance}")
            
            # Acheter avec USD
            if usd_balance > 5:
                symbol = "AUDIO/USD"
                if symbol in markets:
                    logger.info(f"Achat d'AUDIO avec {usd_balance * 0.95} USD")
                    try:
                        order = self.exchange.create_market_buy_order(symbol, None, {'cost': usd_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        return True
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat d'AUDIO: {e}")
            
            # Acheter avec USDT
            if usdt_balance > 5:
                symbol = "AUDIO/USDT"
                if symbol in markets:
                    logger.info(f"Achat d'AUDIO avec {usdt_balance * 0.95} USDT")
                    try:
                        order = self.exchange.create_market_buy_order(symbol, None, {'cost': usdt_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        return True
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat d'AUDIO: {e}")
            
            logger.warning("Impossible d'acheter AUDIO")
            return False
            
        except Exception as e:
            logger.error(f"Erreur lors de la conversion vers AUDIO: {e}")
            return False
    
    def convert_to_btc(self):
        """Convertit les actifs disponibles en BTC"""
        logger.info("=== CONVERSION VERS BTC ===")
        
        try:
            if not self.exchange:
                logger.error("Exchange non initialisé")
                return False
            
            # Récupérer les balances
            balances = self.exchange.fetch_balance()
            
            # Récupérer les marchés
            markets = self.exchange.load_markets()
            
            # Vendre tous les actifs non-stables pour des USD/USDT
            for asset, balance in balances['free'].items():
                # Ignorer BTC, stablecoins et les petits montants
                if asset == 'BTC' or asset in ['USD', 'USDT', 'USDC'] or float(balance) < 1.0:
                    continue
                
                # Chercher une paire pour vendre l'actif
                symbol = None
                
                # Essayer USD
                symbol_usd = f"{asset}/USD"
                if symbol_usd in markets:
                    symbol = symbol_usd
                
                # Essayer USDT
                if not symbol:
                    symbol_usdt = f"{asset}/USDT"
                    if symbol_usdt in markets:
                        symbol = symbol_usdt
                
                if symbol:
                    logger.info(f"Vente de {balance} {asset} via {symbol}")
                    try:
                        # Vendre 95% pour tenir compte des frais
                        order = self.exchange.create_market_sell_order(symbol, float(balance) * 0.95)
                        logger.info(f"Vente effectuée: {order}")
                    except Exception as e:
                        logger.error(f"Erreur lors de la vente de {asset}: {e}")
            
            # Attendre que les ventes soient finalisées
            time.sleep(5)
            
            # Récupérer les nouvelles balances
            new_balances = self.exchange.fetch_balance()
            
            # Acheter BTC avec USD/USDT
            usd_balance = float(new_balances['free'].get('USD', 0))
            usdt_balance = float(new_balances['free'].get('USDT', 0))
            
            logger.info(f"Solde USD: {usd_balance}, Solde USDT: {usdt_balance}")
            
            # Acheter avec USD
            if usd_balance > 5:
                symbol = "BTC/USD"
                if symbol in markets:
                    logger.info(f"Achat de BTC avec {usd_balance * 0.95} USD")
                    try:
                        order = self.exchange.create_market_buy_order(symbol, None, {'cost': usd_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        return True
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat de BTC: {e}")
            
            # Acheter avec USDT
            if usdt_balance > 5:
                symbol = "BTC/USDT"
                if symbol in markets:
                    logger.info(f"Achat de BTC avec {usdt_balance * 0.95} USDT")
                    try:
                        order = self.exchange.create_market_buy_order(symbol, None, {'cost': usdt_balance * 0.95})
                        logger.info(f"Achat effectué: {order}")
                        return True
                    except Exception as e:
                        logger.error(f"Erreur lors de l'achat de BTC: {e}")
            
            logger.warning("Impossible d'acheter BTC")
            return False
            
        except Exception as e:
            logger.error(f"Erreur lors de la conversion vers BTC: {e}")
            return False


class DirectKrakenTrader:
    def __init__(self):
        self.api_key = os.environ.get('KRAKEN_API_KEY')
        self.api_secret = os.environ.get('KRAKEN_API_SECRET')
        self.api_url = "https://api.kraken.com"
        self.nonce = int(time.time() * 1000)
        
        if not self.api_key or not self.api_secret:
            raise ValueError("Clés API Kraken manquantes dans les variables d'environnement")
    
    def _get_kraken_signature(self, urlpath, data):
        postdata = urllib.parse.urlencode(data)
        encoded = (str(data['nonce']) + postdata).encode()
        message = urlpath.encode() + hashlib.sha256(encoded).digest()
        
        signature = hmac.new(base64.b64decode(self.api_secret), message, hashlib.sha512)
        sigdigest = base64.b64encode(signature.digest())
        
        return sigdigest.decode()
    
    def _kraken_request(self, uri_path, data, public=False):
        headers = {}
        if not public:
            headers = {
                'API-Key': self.api_key,
                'API-Sign': self._get_kraken_signature(uri_path, data),
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        
        req = urllib.request.Request(self.api_url + uri_path, 
                                   urllib.parse.urlencode(data).encode() if data else None,
                                   headers)
        
        try:
            with urllib.request.urlopen(req) as response:
                response_data = response.read().decode('utf-8')
                result = json.loads(response_data)
                
                if result.get('error'):
                    logger.error(f"Erreur API Kraken: {result['error']}")
                    return None
                
                return result.get('result')
        except Exception as e:
            logger.error(f"Erreur lors de la requête: {e}")
            return None
    
    def get_balance(self):
        """Récupère les balances du compte"""
        self.nonce += 1
        data = {
            "nonce": str(self.nonce)
        }
        
        result = self._kraken_request("/0/private/Balance", data)
        if result:
            logger.info("Balances récupérées avec succès")
            return result
        else:
            logger.error("Échec de la récupération des balances")
            return {}
    
    def get_asset_info(self):
        """Récupère les informations sur les actifs disponibles"""
        result = self._kraken_request("/0/public/Assets", {}, public=True)
        if result:
            logger.info("Informations sur les actifs récupérées avec succès")
            return result
        else:
            logger.error("Échec de la récupération des informations sur les actifs")
            return {}
    
    def get_asset_pairs(self):
        """Récupère les informations sur les paires d'actifs disponibles"""
        result = self._kraken_request("/0/public/AssetPairs", {}, public=True)
        if result:
            logger.info("Informations sur les paires d'actifs récupérées avec succès")
            return result
        else:
            logger.error("Échec de la récupération des informations sur les paires d'actifs")
            return {}
    
    def place_order(self, pair, type_order, side, volume, price=None):
        """Place un ordre sur Kraken"""
        self.nonce += 1
        data = {
            "nonce": str(self.nonce),
            "ordertype": type_order,
            "type": side,
            "volume": str(volume),
            "pair": pair
        }
        
        if price and type_order == 'limit':
            data["price"] = str(price)
        
        result = self._kraken_request("/0/private/AddOrder", data)
        if result:
            logger.info(f"Ordre placé avec succès: {result}")
            return result
        else:
            logger.error("Échec du placement de l'ordre")
            return None
    
    def convert_to_volatile(self):
        """Convertit les actifs disponibles en cryptos volatiles (AUDIO, GARI, etc.)"""
        logger.info("=== CONVERSION DIRECTE VERS DES CRYPTOS VOLATILES ===")
        
        # Récupérer les balances
        balances = self.get_balance()
        if not balances:
            logger.error("Impossible de récupérer les balances")
            return False
        
        # Afficher les balances
        logger.info("Balances actuelles:")
        for asset, balance in balances.items():
            # Ignorer les très petits montants
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Récupérer les paires disponibles
        pairs = self.get_asset_pairs()
        if not pairs:
            logger.error("Impossible de récupérer les paires d'actifs")
            return False
        
        # Convertir les actifs non-USD en USD
        for asset, balance in balances.items():
            # Ignorer USD/USDT et les petits montants
            if asset in ['ZUSD', 'USDT'] or float(balance) < 0.1:
                continue
            
            # Trouver une paire pour vendre cet actif
            pair_name = None
            
            # Chercher les paires qui se terminent par USD
            for pair in pairs.keys():
                if pairs[pair].get('base') == asset and pairs[pair].get('quote') == 'ZUSD':
                    pair_name = pair
                    break
            
            if pair_name:
                logger.info(f"Vente de {balance} {asset} via {pair_name}")
                # Vendre 95% pour tenir compte des frais
                sell_result = self.place_order(
                    pair=pair_name,
                    type_order='market',
                    side='sell',
                    volume=float(balance) * 0.95
                )
                
                if sell_result:
                    logger.info(f"Vente réussie: {sell_result}")
                    # Attendre la confirmation
                    time.sleep(5)
                else:
                    logger.error(f"Échec de la vente de {asset}")
        
        # Récupérer les nouvelles balances après les ventes
        time.sleep(3)
        new_balances = self.get_balance()
        if not new_balances:
            logger.error("Impossible de récupérer les nouvelles balances")
            return False
        
        # Vérifier le solde USD disponible
        usd_balance = float(new_balances.get('ZUSD', 0))
        logger.info(f"Solde USD disponible: {usd_balance}")
        
        if usd_balance < 1:
            logger.warning("Pas assez d'USD pour acheter des actifs volatils")
            return False
        
        # Actifs volatils cibles (par ordre de préférence)
        target_assets = ['AUDIO', 'GARI', 'DOGE', 'MATIC', 'MANA']
        
        # Acheter un actif volatil avec USD
        for target in target_assets:
            pair_name = None
            
            # Chercher les paires qui commencent par l'actif cible et se terminent par USD
            for pair in pairs.keys():
                if pairs[pair].get('base') == target and pairs[pair].get('quote') == 'ZUSD':
                    pair_name = pair
                    break
            
            if pair_name:
                logger.info(f"Achat de {target} avec {usd_balance * 0.95} USD via {pair_name}")
                
                # Calcul approximatif de la quantité à acheter
                # Dans un environnement réel, il faudrait récupérer le prix actuel
                buy_result = self.place_order(
                    pair=pair_name,
                    type_order='market',
                    side='buy',
                    volume=usd_balance * 0.95
                )
                
                if buy_result:
                    logger.info(f"Achat réussi: {buy_result}")
                    return True
                else:
                    logger.error(f"Échec de l'achat de {target}")
        
        logger.warning("Aucun actif volatil n'a pu être acheté")
        return False


# Fonction principale pour exécuter la conversion
def main():
    try:
        logger.info("Démarrage du trader direct...")
        trader = DirectKrakenTrader()
        
        logger.info("Test de connexion à l'API...")
        balances = trader.get_balance()
        
        if balances:
            logger.info("Connexion API établie avec succès")
            
            # Exécuter la conversion
            result = trader.convert_to_volatile()
            
            if result:
                logger.info("Conversion réussie!")
                return 0
            else:
                logger.error("La conversion a échoué")
                return 1
        else:
            logger.error("Impossible de se connecter à l'API Kraken")
            return 1
            
    except Exception as e:
        logger.error(f"Erreur critique: {e}")
        return 1


if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)