#!/bin/bash
# Script pour générer une clé SSH et la transférer vers le serveur Hetzner

SERVER_IP="168.119.248.8"

# Générer une nouvelle paire de clés SSH
echo "Génération d'une paire de clés SSH..."
ssh-keygen -t rsa -b 4096 -f ~/.ssh/hetzner_key -N ""

# Demander le mot de passe SSH une seule fois
echo -n "Entrez le mot de passe SSH du serveur Hetzner (ne sera pas affiché): "
read -s SSH_PASSWORD
echo ""

# Installer sshpass si nécessaire
command -v sshpass >/dev/null 2>&1 || { 
  echo "Installation de sshpass..."
  apt-get update > /dev/null 2>&1
  apt-get install -y sshpass > /dev/null 2>&1
}

# Transférer la clé publique vers le serveur Hetzner
echo "Transfert de la clé SSH vers le serveur Hetzner..."
export SSHPASS=$SSH_PASSWORD
sshpass -e ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/hetzner_key root@$SERVER_IP

if [ $? -eq 0 ]; then
  echo "=== CONFIGURATION SSH TERMINÉE AVEC SUCCÈS ==="
  echo ""
  echo "Vous pouvez maintenant vous connecter au serveur sans mot de passe:"
  echo "ssh -i ~/.ssh/hetzner_key root@$SERVER_IP"
  echo ""
  echo "Pour déployer le bot, exécutez:"
  echo "./deploy_with_key.sh"
else
  echo "Erreur: Impossible de transférer la clé SSH. Vérifiez le mot de passe SSH."
  exit 1
fi