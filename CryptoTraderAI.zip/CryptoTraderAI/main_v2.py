import os
import time
import threading
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Configuration du logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Définition de la classe de base pour les modèles SQLAlchemy
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Création de l'application Flask
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "your_secret_key")

# Configuration de la base de données
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialisation de la base de données
db.init_app(app)

# Import des modèles après l'initialisation de db
from models_v2 import APIKey, Trade, AssetData, BotState
from advanced_real_trader import AdvancedRealTrader

# Variable globale pour stocker l'instance du trader
trader = None
bot_thread = None

def initialize_database():
    """Initialise la base de données si ce n'est pas déjà fait"""
    with app.app_context():
        db.create_all()
        # Vérifier s'il y a un état de bot existant
        bot_state = BotState.query.first()
        if not bot_state:
            # Créer un état initial
            bot_state = BotState(running=False, config={
                "risk_per_trade": 0.9,
                "excluded_assets": ["BTC", "ETH", "SOL"],
                "max_assets": 10
            })
            db.session.add(bot_state)
            db.session.commit()
            logger.info("État initial du bot créé")

def get_trader():
    """Récupère ou initialise le trader"""
    global trader
    if trader is None:
        # Récupérer les clés API
        api_key = os.environ.get('KRAKEN_API_KEY')
        api_secret = os.environ.get('KRAKEN_API_SECRET')
        
        # Récupérer la configuration du bot
        bot_state = BotState.query.first()
        if bot_state and bot_state.config:
            risk_per_trade = bot_state.config.get("risk_per_trade", 0.9)
            excluded_assets = bot_state.config.get("excluded_assets", ["BTC", "ETH", "SOL"])
        else:
            risk_per_trade = 0.9
            excluded_assets = ["BTC", "ETH", "SOL"]
        
        # Créer le trader
        trader = AdvancedRealTrader(
            api_key=api_key,
            api_secret=api_secret,
            risk_per_trade=risk_per_trade
        )
        
        # Configurer les actifs exclus
        trader.excluded_assets = excluded_assets
        
        logger.info("Trader initialisé avec succès")
    
    return trader

def bot_worker():
    """Thread du bot de trading"""
    global trader
    logger.info("Thread du bot démarré")
    
    # Marquer le bot comme démarré
    with app.app_context():
        bot_state = BotState.query.first()
        if bot_state:
            bot_state.running = True
            bot_state.started_at = datetime.utcnow()
            bot_state.stopped_at = None
            db.session.commit()
    
    # Démarrer le trader
    trader = get_trader()
    trader.start()
    
    # Boucle de synchronisation des données
    while trader and trader.running:
        try:
            with app.app_context():
                sync_trader_data()
            time.sleep(60)  # Synchroniser toutes les minutes
        except Exception as e:
            logger.error(f"Erreur dans la boucle de synchronisation: {e}")
    
    # Marquer le bot comme arrêté
    with app.app_context():
        bot_state = BotState.query.first()
        if bot_state:
            bot_state.running = False
            bot_state.stopped_at = datetime.utcnow()
            db.session.commit()
    
    logger.info("Thread du bot terminé")

def sync_trader_data():
    """Synchronise les données du trader avec la base de données"""
    if not trader:
        return
    
    try:
        # Récupérer le statut actuel
        status = trader.get_status()
        
        # Mettre à jour les données des actifs
        for asset_data in status.get('volatile_assets', []):
            asset_record = AssetData(
                asset=asset_data['asset'],
                price=asset_data['price'] or 0.0,
                volatility=asset_data['volatility'] or 0.0,
                sentiment=asset_data['sentiment'] or 0.0,
                bubble_score=asset_data['bubble_score'] or 0.0
            )
            db.session.add(asset_record)
        
        # Ajouter les nouveaux trades à l'historique
        for trade in trader.trade_history[-5:]:  # Derniers trades
            # Vérifier si le trade existe déjà (éviter les doublons)
            existing = Trade.query.filter_by(
                timestamp=trade['timestamp'],
                asset=trade['asset'],
                action=trade['action']
            ).first()
            
            if not existing:
                trade_record = Trade(
                    timestamp=trade['timestamp'],
                    asset=trade['asset'],
                    action=trade['action'],
                    amount=trade['amount'],
                    price=trade['price'],
                    sentiment=trade.get('sentiment', 0.0),
                    volatility=trade.get('volatility', 0.0),
                    bubble_score=trade.get('bubble_score', 0.0),
                    total_usdt=trade.get('total_usdt', 0.0),
                    stop_loss=trade.get('stop_loss', 0.0)
                )
                db.session.add(trade_record)
        
        db.session.commit()
        logger.debug("Données du trader synchronisées avec succès")
    
    except Exception as e:
        db.session.rollback()
        logger.error(f"Erreur lors de la synchronisation des données: {e}")

@app.route('/')
def index():
    """Page principale de l'application"""
    # Vérifier l'état du bot
    bot_state = BotState.query.first()
    running = bot_state.running if bot_state else False
    
    # Récupérer les derniers trades
    trades = Trade.query.order_by(Trade.timestamp.desc()).limit(20).all()
    
    # Récupérer les données des actifs
    assets = AssetData.query.order_by(AssetData.timestamp.desc()).limit(30).all()
    
    # Obtenir des données temps réel si le bot est en cours d'exécution
    realtime_data = None
    if trader:
        try:
            realtime_data = trader.get_status()
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des données temps réel: {e}")
    
    # Récupérer la configuration
    config = bot_state.config if bot_state else {}
    
    return render_template('index.html', 
                          running=running, 
                          trades=trades, 
                          assets=assets, 
                          realtime_data=realtime_data,
                          config=config)

@app.route('/configure_api', methods=['GET', 'POST'])
def configure_api():
    """Configure les clés API Kraken"""
    if request.method == 'POST':
        api_key = request.form.get('api_key')
        api_secret = request.form.get('api_secret')
        
        if not api_key or not api_secret:
            flash("Les deux clés API sont requises", "danger")
            return redirect(url_for('configure_api'))
        
        try:
            # Enregistrer les clés dans la base de données
            existing_key = APIKey.query.first()
            if existing_key:
                existing_key.api_key = api_key
                existing_key.api_secret = api_secret
                existing_key.last_used = datetime.utcnow()
            else:
                new_key = APIKey(api_key=api_key, api_secret=api_secret)
                db.session.add(new_key)
            
            db.session.commit()
            
            # Mettre à jour les variables d'environnement pour la session en cours
            os.environ['KRAKEN_API_KEY'] = api_key
            os.environ['KRAKEN_API_SECRET'] = api_secret
            
            # Réinitialiser le trader pour qu'il utilise les nouvelles clés
            global trader
            trader = None
            
            flash("Clés API configurées avec succès", "success")
            return redirect(url_for('index'))
        
        except Exception as e:
            db.session.rollback()
            flash(f"Erreur lors de la configuration des clés API: {e}", "danger")
    
    # Récupérer les clés existantes
    existing_key = APIKey.query.first()
    masked_key = "********" if existing_key else ""
    masked_secret = "********" if existing_key else ""
    
    return render_template('configure_api.html', 
                          masked_key=masked_key, 
                          masked_secret=masked_secret)

@app.route('/start_bot')
def start_bot():
    """Démarre le bot de trading"""
    global bot_thread
    try:
        bot_state = BotState.query.first()
        if bot_state and bot_state.running:
            flash("Le bot est déjà en cours d'exécution", "warning")
            return redirect(url_for('index'))
        
        # Vérifier que les clés API sont configurées
        if not os.environ.get('KRAKEN_API_KEY') or not os.environ.get('KRAKEN_API_SECRET'):
            api_key = APIKey.query.first()
            if not api_key:
                flash("Veuillez configurer les clés API avant de démarrer le bot", "warning")
                return redirect(url_for('configure_api'))
            else:
                # Charger les clés dans les variables d'environnement
                os.environ['KRAKEN_API_KEY'] = api_key.api_key
                os.environ['KRAKEN_API_SECRET'] = api_key.api_secret
        
        # Démarrer le thread du bot
        if bot_thread is None or not bot_thread.is_alive():
            bot_thread = threading.Thread(target=bot_worker, daemon=True)
            bot_thread.start()
            flash("Bot de trading démarré avec succès", "success")
        else:
            flash("Un thread du bot est déjà en cours d'exécution", "warning")
        
        return redirect(url_for('index'))
    
    except Exception as e:
        flash(f"Erreur lors du démarrage du bot: {e}", "danger")
        return redirect(url_for('index'))

@app.route('/stop_bot')
def stop_bot():
    """Arrête le bot de trading"""
    try:
        bot_state = BotState.query.first()
        if not bot_state or not bot_state.running:
            flash("Le bot n'est pas en cours d'exécution", "warning")
            return redirect(url_for('index'))
        
        # Arrêter le trader
        if trader:
            trader.stop()
            flash("Bot de trading arrêté avec succès", "success")
        else:
            flash("Trader non initialisé", "warning")
        
        # Mettre à jour l'état
        bot_state.running = False
        bot_state.stopped_at = datetime.utcnow()
        db.session.commit()
        
        return redirect(url_for('index'))
    
    except Exception as e:
        flash(f"Erreur lors de l'arrêt du bot: {e}", "danger")
        return redirect(url_for('index'))

@app.route('/force_trade_btc')
def force_trade_btc():
    """Convertit des actifs en BTC"""
    try:
        t = get_trader()
        result = t.convert_to_btc()
        
        if result:
            flash("Conversion en BTC effectuée avec succès", "success")
        else:
            flash("Aucune conversion en BTC effectuée", "warning")
        
        return redirect(url_for('index'))
    
    except Exception as e:
        flash(f"Erreur lors de la conversion en BTC: {e}", "danger")
        return redirect(url_for('index'))

@app.route('/force_trade_audio')
def force_trade_audio():
    """Convertit des actifs en AUDIO"""
    try:
        t = get_trader()
        result = t.convert_to_audio()
        
        if result:
            flash("Conversion en AUDIO effectuée avec succès", "success")
        else:
            flash("Aucune conversion en AUDIO effectuée", "warning")
        
        return redirect(url_for('index'))
    
    except Exception as e:
        flash(f"Erreur lors de la conversion en AUDIO: {e}", "danger")
        return redirect(url_for('index'))

@app.route('/force_trade_any')
def force_trade_any():
    """Convertit des actifs en cryptomonnaies volatiles"""
    try:
        t = get_trader()
        result = t.convert_to_volatile()
        
        if result:
            flash("Conversion en cryptomonnaies volatiles effectuée avec succès", "success")
        else:
            flash("Aucune conversion en cryptomonnaies volatiles effectuée", "warning")
        
        return redirect(url_for('index'))
    
    except Exception as e:
        flash(f"Erreur lors de la conversion en cryptomonnaies volatiles: {e}", "danger")
        return redirect(url_for('index'))

@app.route('/get_data')
def get_data():
    """Récupère les données en temps réel sur les soldes, trades et état des actifs"""
    try:
        t = get_trader()
        data = t.get_status()
        return jsonify(data)
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

# Initialiser la base de données au démarrage
initialize_database()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)