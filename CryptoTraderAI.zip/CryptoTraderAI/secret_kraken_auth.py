import os
import time
import json
import base64
import hashlib
import hmac
import urllib.request
import urllib.parse
import urllib.error
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_kraken_signature(urlpath, data, secret):
    """
    Calcule la signature Kraken selon leur documentation officielle
    """
    postdata = urllib.parse.urlencode(data)
    encoded = (data['nonce'] + postdata).encode()
    message = urlpath.encode() + hashlib.sha256(encoded).digest()
    
    # Utiliser base64.b64decode directement sur la chaîne
    mac = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    sigdigest = base64.b64encode(mac.digest())
    
    return sigdigest.decode()

def kraken_request(uri_path, data, api_key, api_sec):
    """
    Envoie une requête authentifiée à l'API Kraken
    """
    headers = {
        'API-Key': api_key,
        'API-Sign': get_kraken_signature(uri_path, data, api_sec),
        'User-Agent': 'Kraken Direct Trader'
    }
    
    req = urllib.request.Request('https://api.kraken.com' + uri_path, 
                                urllib.parse.urlencode(data).encode(),
                                headers)
    
    try:
        with urllib.request.urlopen(req) as response:
            res = json.loads(response.read().decode())
            return res
    except urllib.error.HTTPError as e:
        logger.error(f"HTTPError: {e.code} {e.reason}")
        return None
    except Exception as e:
        logger.error(f"Erreur générale: {e}")
        return None

def test_kraken_auth():
    """
    Teste l'authentification à l'API Kraken
    """
    api_key = os.environ.get('KRAKEN_API_KEY')
    api_sec = os.environ.get('KRAKEN_API_SECRET')
    
    if not api_key or not api_sec:
        logger.error("Clés API manquantes")
        return False
    
    nonce = str(int(1000 * time.time()))
    
    data = {
        "nonce": nonce
    }
    
    logger.info("Test de l'authentification Kraken...")
    response = kraken_request('/0/private/Balance', data, api_key, api_sec)
    
    if response and 'result' in response:
        logger.info("Authentification réussie!")
        logger.info("Balances:")
        
        balances = response['result']
        
        for asset, amount in balances.items():
            if float(amount) > 0:
                logger.info(f"  {asset}: {amount}")
        
        return True
    else:
        if response and 'error' in response:
            logger.error(f"Erreur d'authentification: {response['error']}")
        else:
            logger.error("Réponse inattendue")
        
        return False

if __name__ == "__main__":
    success = test_kraken_auth()
    
    if success:
        print("Test réussi - L'authentification fonctionne correctement")
        exit(0)
    else:
        print("Test échoué - Problème d'authentification")
        exit(1)