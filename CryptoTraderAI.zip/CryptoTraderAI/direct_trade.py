import urllib.request
import urllib.parse
import json
import time
import base64
import hashlib
import hmac
import logging

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "9/KUxib19lkk7FukHnbupTEBYHIFcKsKtGAEW3/krj89u0jC/fYhrwfD"
API_SECRET = "RKJ9m8mLgfDN07bMEvxubD6bY/avyqsQGe6Ev1APMBvBFCvBjXpKGyI5rmR1iJT8U5aVbuHJoY0OI9cprH9qSg=="

# URL de l'API Kraken
API_URL = "https://api.kraken.com"

def get_kraken_signature(urlpath, data, secret):
    """Génère une signature pour l'API Kraken"""
    postdata = urllib.parse.urlencode(data)
    encoded = (str(data['nonce']) + postdata).encode()
    message = urlpath.encode() + hashlib.sha256(encoded).digest()
    
    signature = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    sigdigest = base64.b64encode(signature.digest())
    
    return sigdigest.decode()

def kraken_request(uri_path, data, api_key, api_secret):
    """Envoie une requête authentifiée à l'API Kraken"""
    headers = {
        'API-Key': api_key,
        'API-Sign': get_kraken_signature(uri_path, data, api_secret),
        'User-Agent': 'Direct Kraken API Trader'
    }
    
    req = urllib.request.Request(API_URL + uri_path, 
                               urllib.parse.urlencode(data).encode(),
                               headers)
    
    logger.info(f"Envoi de la requête à {uri_path}")
    logger.info(f"Données: {data}")
    
    try:
        with urllib.request.urlopen(req) as response:
            response_data = response.read().decode()
            result = json.loads(response_data)
            
            if result.get('error') and len(result['error']) > 0:
                logger.error(f"Erreur API Kraken: {result['error']}")
                return None
            
            return result.get('result')
    except Exception as e:
        logger.error(f"Erreur lors de la requête: {e}")
        return None

def get_balance():
    """Récupère les balances du compte"""
    nonce = str(int(time.time() * 1000))
    data = {
        "nonce": nonce
    }
    
    result = kraken_request("/0/private/Balance", data, API_KEY, API_SECRET)
    
    if result:
        logger.info("Balances récupérées avec succès")
        
        # Afficher les balances
        for asset, balance in result.items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        return result
    else:
        logger.error("Échec de la récupération des balances")
        return {}

def get_ticker(pair):
    """Récupère le ticker pour une paire"""
    data = {
        "pair": pair
    }
    
    result = kraken_request("/0/public/Ticker", data, API_KEY, API_SECRET)
    
    if result:
        logger.info(f"Ticker pour {pair} récupéré avec succès")
        return result
    else:
        logger.error(f"Échec de la récupération du ticker pour {pair}")
        return {}

def place_order(pair, type_order, side, volume, price=None):
    """Place un ordre sur Kraken"""
    nonce = str(int(time.time() * 1000))
    data = {
        "nonce": nonce,
        "ordertype": type_order,
        "type": side,
        "volume": str(volume),
        "pair": pair
    }
    
    if price and type_order == 'limit':
        data["price"] = str(price)
    
    result = kraken_request("/0/private/AddOrder", data, API_KEY, API_SECRET)
    
    if result:
        logger.info(f"Ordre placé avec succès: {result}")
        return result
    else:
        logger.error("Échec du placement de l'ordre")
        return None

def direct_audio_trade():
    """Exécute un trade AUDIO directement via l'API REST"""
    logger.info("=== TRADE AUDIO DIRECT VIA API REST ===")
    
    # Étape 1: Récupérer les balances
    balances = get_balance()
    
    if not balances:
        logger.error("Impossible de récupérer les balances, arrêt du trader")
        return False
    
    # Étape 2: Vérifier le prix actuel d'AUDIO
    ticker = get_ticker("AUDIOUSD")
    
    if not ticker or "AUDIOUSD" not in ticker:
        logger.error("Impossible de récupérer le prix d'AUDIO, arrêt du trader")
        return False
    
    price_info = ticker["AUDIOUSD"]
    current_price = float(price_info['c'][0])  # Prix de clôture actuel
    
    logger.info(f"Prix actuel d'AUDIO: {current_price} USD")
    
    # Étape 3: Récupérer le solde AUDIO
    audio_balance = float(balances.get('AUDIO', 0))
    
    if audio_balance < 10:
        logger.error(f"Solde AUDIO trop faible: {audio_balance}")
        return False
    
    # Étape 4: Calculer le montant à vendre (10% des AUDIO)
    amount_to_sell = audio_balance * 0.10
    
    if amount_to_sell < 10:
        amount_to_sell = 10  # Minimum 10 AUDIO
    
    logger.info(f"Vente de {amount_to_sell} AUDIO à {current_price} USD")
    
    # Étape 5: Placer l'ordre de vente
    sell_result = place_order("AUDIOUSD", "market", "sell", amount_to_sell)
    
    if not sell_result:
        logger.error("Échec de la vente d'AUDIO")
        return False
    
    logger.info("Vente d'AUDIO réussie!")
    
    # Étape 6: Attendre la confirmation de la vente
    time.sleep(5)
    
    # Étape 7: Récupérer les nouvelles balances
    new_balances = get_balance()
    
    if not new_balances:
        logger.error("Impossible de récupérer les nouvelles balances")
        return False
    
    # Étape 8: Placer un ordre d'achat limite 2% plus bas
    buy_price = current_price * 0.98
    usd_balance = float(new_balances.get('ZUSD', 0))
    
    if usd_balance < 5:
        logger.error(f"Solde USD insuffisant pour le rachat: {usd_balance}")
        return True  # On considère quand même que la vente a réussi
    
    # Calculer le montant à acheter
    amount_to_buy = (usd_balance * 0.95) / buy_price
    amount_to_buy = round(amount_to_buy, 1)  # Arrondir à 1 décimale
    
    logger.info(f"Achat de {amount_to_buy} AUDIO à {buy_price} USD")
    
    # Placer l'ordre d'achat
    buy_result = place_order("AUDIOUSD", "limit", "buy", amount_to_buy, buy_price)
    
    if not buy_result:
        logger.error("Échec de l'achat d'AUDIO")
        return True  # On considère quand même que la vente a réussi
    
    logger.info("Ordre d'achat d'AUDIO placé avec succès!")
    
    return True

if __name__ == "__main__":
    if direct_audio_trade():
        print("\n✅ TRADE AUDIO RÉUSSI!")
    else:
        print("\n⚠️ LE TRADE AUDIO A ÉCHOUÉ")