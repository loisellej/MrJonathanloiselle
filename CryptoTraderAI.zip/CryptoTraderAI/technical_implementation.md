# Documentation Technique du Bot de Trading Crypto

## Architecture technique

### Composants principaux

```
exchange_connector.py  -> Interface avec l'API de Kraken (exécution des ordres, données de prix)
trading_bot.py         -> Logique de trading et stratégies (stop-loss, analyse momentum)
sentiment_analyzer.py  -> Analyse du sentiment pour les décisions d'achat/vente
models.py              -> Modèles de base de données (transactions, API keys, état du bot)
app.py                 -> Interface web Flask et endpoints API
```

### Flux de données
1. L'ExchangeConnector maintient un cache de prix en temps réel (microseconde)
2. Le TradingBot analyse continuellement les opportunités de marché
3. L'analyse de sentiment influence les décisions d'achat/vente
4. Les transactions sont exécutées via l'ExchangeConnector
5. L'historique est enregistré dans la base de données

## Implémentation de la stratégie

### Analyse de momentum
```python
def calculate_momentum(self, asset):
    """
    Calcule un score de momentum entre -1 et 1
    - Positif fort: tendance fortement haussière
    - Négatif fort: tendance fortement baissière
    - Proche de zéro: pas de tendance claire
    """
    if asset not in self.price_history or len(self.price_history[asset]) < 10:
        return 0
    
    # Utilise les 10 derniers prix pour calculer la direction
    prices = self.price_history[asset][-10:]
    
    # Calcule la pente et normalise entre -1 et 1
    slope = (prices[-1] - prices[0]) / prices[0]
    momentum = min(max(slope * 5, -1), 1)  # Limité entre -1 et 1
    
    return momentum
```

### Stop-loss dynamique
```python
def dynamic_stop_loss(self, current_price, entry_price, momentum_factor=1.5, volatility=None, asset=None):
    """
    Calcule un stop-loss dynamique basé sur:
    - Le prix d'entrée
    - Le momentum actuel
    - La volatilité de l'actif
    
    Règles spéciales pour AUDIO:
    - Stop-loss fixe à 0.08 indépendamment des autres facteurs
    """
    if asset == 'AUDIO':
        return 0.08  # Stop-loss fixe pour AUDIO
    
    # Stop-loss par défaut: 5% sous le prix d'entrée
    default_stop = entry_price * 0.95
    
    # Si l'actif a un fort momentum, permet plus de marge (jusqu'à 15%)
    if self.has_strong_momentum(asset):
        momentum_stop = entry_price * 0.85
        return momentum_stop
    
    # Ajuste en fonction de la volatilité si disponible
    if volatility and volatility > 0:
        volatility_adjustment = min(volatility * 0.5, 0.1)  # Max 10%
        adjusted_stop = entry_price * (1 - volatility_adjustment)
        return max(adjusted_stop, default_stop)
    
    return default_stop
```

### Calcul de bulle
```python
def calculate_bubble_score(self, asset):
    """
    Calcule un score de bulle pour un actif basé sur:
    - Accélération récente des prix
    - Volume anormal
    - Écart par rapport à la moyenne mobile
    
    Retourne une valeur de 0 (pas de bulle) à 1 (bulle confirmée)
    """
    if asset not in self.price_history or len(self.price_history[asset]) < 30:
        return 0.0
    
    prices = self.price_history[asset]
    
    # Calcule l'accélération de prix (dérivée seconde)
    recent_change = (prices[-1] - prices[-5]) / prices[-5]
    older_change = (prices[-6] - prices[-10]) / prices[-10]
    acceleration = recent_change - older_change
    
    # Calcule l'écart avec la moyenne mobile
    ma20 = sum(prices[-20:]) / 20
    deviation = (prices[-1] - ma20) / ma20
    
    # Combine les facteurs pour un score final
    bubble_score = min((acceleration * 3) + (deviation * 2), 1.0)
    return max(bubble_score, 0.0)  # Entre 0 et 1
```

## Optimisations de performance

### Cache de prix
```python
def _run_price_cache_updater(self):
    """
    Met à jour le cache de prix en arrière-plan pour un accès microseconde
    Utilise un ThreadPoolExecutor pour les mises à jour parallèles
    """
    while self.running:
        try:
            with ThreadPoolExecutor(max_workers=8) as executor:
                futures = []
                for symbol in self.tracked_symbols:
                    futures.append(executor.submit(self._update_single_price, symbol))
                
                # Attend la fin de toutes les mises à jour
                wait(futures, timeout=4.5)
            
            # Intervalle de mise à jour: 5 secondes
            time.sleep(5)
        except Exception as e:
            logging.error(f"Erreur dans le cache de prix: {e}")
            time.sleep(5)  # Récupération d'erreur avec backoff
```

### Exécution d'ordres parallèles
```python
def buy(self, symbol, amount):
    """
    Exécute un ordre d'achat au marché avec timing microseconde
    """
    try:
        # Vérification du prix avant exécution
        current_price = self.get_ticker_price(symbol)
        
        # Timing critique: exécution immédiate
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(
                self.exchange.create_market_buy_order,
                symbol, amount
            )
            result = future.result(timeout=2.5)  # Timeout de 2.5s max
            
            # Enregistrement de la transaction
            logging.info(f"Achat exécuté: {symbol}, {amount} à {current_price}")
            return result
    except Exception as e:
        # Gestion des erreurs avec backoff exponentiel
        retry_delay = random.uniform(0.5, 1.5)
        logging.error(f"Erreur d'achat {symbol}: {e}, nouvel essai dans {retry_delay}s")
        time.sleep(retry_delay)
        return None
```

## Paramètres critiques

### Configuration

- **RISK_PER_TRADE**: 0.9 (90% du capital disponible par trade)
- **VOLATILITY_THRESHOLD**: 5.0 (cible les actifs avec >5% de volatilité)
- **SENTIMENT_BUY_THRESHOLD**: 0.1 (achète quand sentiment > 0.1)
- **SENTIMENT_SELL_THRESHOLD**: -0.1 (vend quand sentiment < -0.1)
- **STOP_LOSS_FACTOR_NORMAL**: 0.95 (5% sous le prix d'entrée)
- **STOP_LOSS_FACTOR_MOMENTUM**: 0.85 (15% sous le prix d'entrée pour high-momentum)
- **SCALING_OUT_FIRST**: 0.25 (25% au premier objectif)
- **SCALING_OUT_SECOND**: 0.25 (25% au deuxième objectif)
- **MIN_TRADE_SIZE_USD**: 1.0 (Taille minimale d'ordre: 1 USDT)

### Exclusions explicites
```python
EXCLUDED_ASSETS = ['BTC', 'ETH', 'SOL', 'XBT']  # Assets explicitement exclus
```

## Sécurité et gestion d'erreurs

### Stockage API Key
```python
# models.py
class APIKey(db.Model):
    """Modèle pour stocker les clés API de façon sécurisée"""
    id = db.Column(db.Integer, primary_key=True)
    api_key = db.Column(db.String(255), nullable=False)
    api_secret = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime)
```

### Backoff exponentiel
```python
def _safe_api_call(self, func, *args, **kwargs):
    """
    Fonction utilitaire pour les appels API avec backoff exponentiel
    Réessaie jusqu'à 3 fois avec des délais croissants
    """
    max_retries = 3
    retry_delay = 0.5
    
    for attempt in range(max_retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if attempt == max_retries - 1:
                raise e
            
            # Backoff exponentiel avec jitter
            jitter = random.uniform(0, 0.5)
            sleep_time = retry_delay * (2 ** attempt) + jitter
            logging.warning(f"Erreur API, réessai dans {sleep_time:.2f}s: {e}")
            time.sleep(sleep_time)
```

## Déploiement et exécution 24/7

Le bot est configuré pour fonctionner 24/7 sur Replit avec plusieurs mécanismes pour assurer la stabilité:

1. **Redémarrage automatique** : En cas de crash ou d'erreur non récupérable, le service se redémarre automatiquement
2. **Gestion de la mémoire** : Optimisation pour éviter les fuites de mémoire durant l'exécution de longue durée
3. **Persistance de données** : Toutes les transactions et configurations sont sauvegardées en base de données
4. **Tolérance aux pannes** : Système de recovery pour reprendre les opérations après une interruption

Cette architecture permet au bot de continuer à trader de manière autonome, même lorsque l'application est fermée et l'appareil de l'utilisateur est éteint.