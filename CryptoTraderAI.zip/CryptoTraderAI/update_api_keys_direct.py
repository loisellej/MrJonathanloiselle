#!/usr/bin/env python3
"""
Update API keys to environment variables and ensure they are correctly set
"""
import os
import subprocess
import sys

def update_environment_variables(api_key, api_secret):
    """Update environment variables for Kraken API"""
    try:
        # Configure pour le shell actuel
        os.environ["KRAKEN_API_KEY"] = api_key
        os.environ["KRAKEN_API_SECRET"] = api_secret
        
        # Configure de façon permanente pour Replit
        subprocess.run(["bash", "-c", f"echo 'export KRAKEN_API_KEY=\"{api_key}\"' >> ~/.bashrc"], check=True)
        subprocess.run(["bash", "-c", f"echo 'export KRAKEN_API_SECRET=\"{api_secret}\"' >> ~/.bashrc"], check=True)
        
        # Set directly in Replit secrets - not possible via code, only through UI
        print("API keys set successfully in environment variables and bashrc")
        return True
    except Exception as e:
        print(f"Error updating environment variables: {e}")
        return False

def main():
    """Main function"""
    # Hardcoded values - copy directly from the keys provided by user
    api_key = "ytisCoU+hbhrzopz6IDzhlFeynvRT1dcsMDpoWzjBjxPat9k/aU/Sdtx"
    api_secret = "VTikouzAPjh2HTscpZqbMI8wMlpVxM4N+dfWrDHtIjmAVzQcpxvCm9XdSsYerZf34iwZtTZrgyx5bB4uuWz+Ig=="
    
    if not api_key or not api_secret:
        print("API key and/or secret not provided!")
        sys.exit(1)
    
    success = update_environment_variables(api_key, api_secret)
    if success:
        # Now restart any running bots or services
        try:
            subprocess.run(["bash", "-c", "pkill -f ultra_stable_bot.py"], check=False)
            subprocess.run(["bash", "-c", "pkill -f multi_position_trader.py"], check=False)
            subprocess.run(["bash", "-c", "./start_everything.sh"], check=False)
            print("Trading bot restarted with new API keys!")
        except Exception as e:
            print(f"Warning: Failed to restart services: {e}")
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()