#!/usr/bin/env python3
"""
Exécuteur du bot de trading - MODE LIVE UNIQUEMENT
Ce script charge les variables d'environnement et démarre le trader
en mode LIVE (jamais en simulation)
"""
import os
import subprocess
import sys
import time

# Charger les variables d'environnement depuis .env
def load_env():
    """Charge les variables d'environnement depuis .env"""
    try:
        print("🔄 Chargement des variables d'environnement...")
        with open(".env", "r") as f:
            for line in f:
                if line.strip() and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key.strip()] = value.strip().strip('"').strip("'")
        
        # Vérifier les clés API
        api_key = os.environ.get("KRAKEN_API_KEY")
        api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        if api_key and api_secret:
            print(f"✅ Clés API chargées: {api_key[:5]}...{api_key[-5:]}")
            return True
        else:
            print("❌ Clés API non trouvées dans .env")
            return False
    except Exception as e:
        print(f"❌ Erreur lors du chargement des variables d'environnement: {e}")
        return False

# Tester la connexion à l'API
def test_api_connection():
    """Teste la connexion à l'API Kraken"""
    try:
        print("🔄 Test de la connexion à l'API Kraken...")
        import krakenex
        
        k = krakenex.API(
            os.environ.get("KRAKEN_API_KEY"),
            os.environ.get("KRAKEN_API_SECRET")
        )
        
        # Récupérer les balances pour tester l'API
        balance = k.query_private('Balance')
        
        if 'error' in balance and balance['error']:
            print(f"❌ Erreur API: {balance['error']}")
            return False
        
        # Obtenir le solde USD
        usd_balance = float(balance['result'].get('ZUSD', 0))
        
        # Afficher les positions significatives
        positions = []
        for asset, amount in balance['result'].items():
            if asset != 'ZUSD' and float(amount) > 0.001:
                positions.append(f"{asset}: {float(amount):.4f}")
        
        print(f"✅ Connexion API réussie! Solde USD: {usd_balance:.2f} USD")
        if positions:
            print(f"📊 Positions: {', '.join(positions)}")
        
        return True
    except Exception as e:
        print(f"❌ Erreur lors du test de la connexion API: {e}")
        return False

# Démarrer le trader
def start_trader():
    """Démarre le trader en mode LIVE"""
    try:
        print("🚀 Démarrage du trader en mode LIVE...")
        # Arrêter tout processus existant
        subprocess.run(["pkill", "-f", "live_trader.py"], stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-f", "start_24_7_trader.py"], stderr=subprocess.DEVNULL)
        time.sleep(1)
        
        # Démarrer le trader en arrière-plan
        subprocess.Popen([sys.executable, "live_trader.py"])
        print("✅ Trader démarré en mode LIVE")
        print("📝 Les logs sont disponibles dans live_trader.log")
        return True
    except Exception as e:
        print(f"❌ Erreur lors du démarrage du trader: {e}")
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("🤖 DÉMARRAGE DU BOT DE TRADING - MODE LIVE UNIQUEMENT")
    print("=" * 50)
    
    if not load_env():
        print("❌ Impossible de charger les variables d'environnement. Arrêt.")
        sys.exit(1)
    
    if not test_api_connection():
        print("❌ Échec de la connexion à l'API. Vérifiez les clés API. Arrêt.")
        sys.exit(1)
    
    if not start_trader():
        print("❌ Échec du démarrage du trader. Arrêt.")
        sys.exit(1)
    
    print("=" * 50)
    print("✅ Bot démarré avec succès en mode LIVE")
    print("📊 Surveillez les logs dans live_trader.log")
    print("=" * 50)