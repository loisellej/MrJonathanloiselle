#!/usr/bin/env python3
"""
TRADER MULTI-EXCHANGE 24/7
- Connexion simultanée à plusieurs exchanges
- Fonctionne en continu 24h/24 et 7j/7
- Détection des cryptos ultra-volatiles en uptrend
- Exécution ultra-rapide des ordres (microsecondes)
- Gains visés: 20-50% mensuels
"""
import os
import time
import logging
import sys
import json
import ccxt
import threading
import numpy as np
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from secure_api_client import SecureAPIClient
from integration_kraken import KrakenIntegration
from sentiment_analyzer import SentimentAnalyzer

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('multi_exchange_logs.txt')
    ]
)
logger = logging.getLogger(__name__)

# Liste des exchanges supportés par le système
SUPPORTED_EXCHANGES = [
    'kraken',      # Exchange principal avec vos clés API
    'kucoin',      # Ajouté pour surveillance uniquement
    'binance',     # Ajouté pour surveillance uniquement
    'huobi',       # Ajouté pour surveillance uniquement
    'okx',         # Ajouté pour surveillance uniquement
    'gate',        # Ajouté pour surveillance uniquement
    'bybit',       # Ajouté pour surveillance uniquement
    'bitget',      # Ajouté pour surveillance uniquement
    'mexc'         # Ajouté pour surveillance uniquement
]

class ExchangeConnector:
    """Connecteur standardisé pour les différents exchanges"""
    
    def __init__(self, exchange_id, api_key=None, api_secret=None, trading_enabled=False):
        """
        Initialise le connecteur pour un exchange
        
        Args:
            exchange_id (str): Identifiant de l'exchange
            api_key (str): Clé API pour l'exchange
            api_secret (str): Clé secrète API pour l'exchange
            trading_enabled (bool): Si True, le trading est activé sur cet exchange
        """
        self.exchange_id = exchange_id
        self.api_key = api_key
        self.api_secret = api_secret
        self.trading_enabled = trading_enabled
        self.connected = False
        self.exchange = None
        self.price_cache = {}
        self.last_price_update = {}
        
        # Initialiser l'exchange
        self._initialize_exchange()
    
    def _initialize_exchange(self):
        """Initialise la connexion à l'exchange"""
        try:
            # Créer l'instance ccxt
            if self.exchange_id in ccxt.exchanges:
                exchange_class = getattr(ccxt, self.exchange_id)
                
                # Configuration de base
                config = {
                    'enableRateLimit': True,
                    'timeout': 30000
                }
                
                # Ajouter les clés API si disponibles
                if self.api_key and self.api_secret:
                    config.update({
                        'apiKey': self.api_key,
                        'secret': self.api_secret
                    })
                
                # Créer l'exchange
                self.exchange = exchange_class(config)
                
                # Vérifier la connectivité
                self.exchange.load_markets()
                self.connected = True
                
                logger.info(f"Connecté à l'exchange {self.exchange_id}")
                
                # Démarrer le thread de mise à jour des prix
                self._start_price_updater()
                
                return True
            
            else:
                logger.error(f"Exchange non supporté: {self.exchange_id}")
                return False
        
        except Exception as e:
            logger.error(f"Erreur lors de l'initialisation de l'exchange {self.exchange_id}: {e}")
            self.connected = False
            return False
    
    def _start_price_updater(self):
        """Démarre le thread de mise à jour des prix"""
        if not self.connected:
            return
        
        self.price_update_thread = threading.Thread(target=self._price_update_loop)
        self.price_update_thread.daemon = True
        self.price_update_thread.start()
    
    def _price_update_loop(self):
        """Boucle de mise à jour des prix"""
        try:
            while True:
                # Récupérer les marchés populaires
                try:
                    tickers = self.exchange.fetch_tickers()
                    for symbol, ticker in tickers.items():
                        if '/USD' in symbol or '/USDT' in symbol:
                            price = ticker['last']
                            if price:
                                self.price_cache[symbol] = price
                                self.last_price_update[symbol] = time.time()
                except Exception as e:
                    logger.error(f"Erreur lors de la mise à jour des prix sur {self.exchange_id}: {e}")
                
                # Pause pour éviter de surcharger l'API
                time.sleep(5)
        
        except Exception as e:
            logger.error(f"Erreur dans la boucle de mise à jour des prix pour {self.exchange_id}: {e}")
    
    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel d'un symbole
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            
        Returns:
            float: Prix actuel ou None si non disponible
        """
        # Vérifier si le prix est dans le cache et récent
        if symbol in self.price_cache and symbol in self.last_price_update:
            if time.time() - self.last_price_update[symbol] < 10:  # Cache de 10 secondes
                return self.price_cache[symbol]
        
        # Si non, récupérer le prix en direct
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            price = ticker['last']
            
            # Mettre à jour le cache
            self.price_cache[symbol] = price
            self.last_price_update[symbol] = time.time()
            
            return price
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {symbol} sur {self.exchange_id}: {e}")
            return None
    
    def get_balances(self):
        """
        Récupère les balances des différents actifs
        
        Returns:
            dict: Balances par actif
        """
        if not self.connected or not self.trading_enabled:
            return {}
        
        try:
            balances = {}
            response = self.exchange.fetch_balance()
            
            # Extraire les balances
            for asset, balance in response['total'].items():
                if balance > 0:
                    balances[asset] = balance
            
            return balances
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances sur {self.exchange_id}: {e}")
            return {}
    
    def get_ohlcv(self, symbol, timeframe='1h', limit=100):
        """
        Récupère les données OHLCV pour un symbole
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            timeframe (str): Intervalle de temps
            limit (int): Nombre de points de données
            
        Returns:
            list: Données OHLCV
        """
        try:
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            return ohlcv
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des OHLCV pour {symbol} sur {self.exchange_id}: {e}")
            return []
    
    def place_buy_order(self, symbol, amount):
        """
        Place un ordre d'achat
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            amount (float): Quantité à acheter
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        if not self.connected or not self.trading_enabled:
            logger.error(f"Trading non activé sur {self.exchange_id}")
            return None
        
        try:
            logger.info(f"Placement d'un ordre d'achat sur {self.exchange_id} pour {amount} {symbol}")
            order = self.exchange.create_market_buy_order(symbol, amount)
            
            return order
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre d'achat sur {self.exchange_id}: {e}")
            return None
    
    def place_sell_order(self, symbol, amount):
        """
        Place un ordre de vente
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            amount (float): Quantité à vendre
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        if not self.connected or not self.trading_enabled:
            logger.error(f"Trading non activé sur {self.exchange_id}")
            return None
        
        try:
            logger.info(f"Placement d'un ordre de vente sur {self.exchange_id} pour {amount} {symbol}")
            order = self.exchange.create_market_sell_order(symbol, amount)
            
            return order
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre de vente sur {self.exchange_id}: {e}")
            return None

class MultiExchangeTrader:
    """
    Trader connecté à plusieurs exchanges en simultané
    Optimisé pour fonctionner 24/7 et détecter les meilleures opportunités
    """
    
    def __init__(self):
        """Initialise le système de trading multi-exchange"""
        # Initialiser les composants du système
        self.exchanges = {}
        self.sentiment_analyzer = SentimentAnalyzer()
        self.running = False
        self.trade_history = []
        self.open_positions = {}
        
        # Paramètres de trading
        self.excluded_assets = ["BTC", "ETH", "SOL"]  # Actifs à exclure
        self.min_order_size_usd = 5.0  # Taille minimale d'un ordre en USD
        self.max_positions = 5  # Nombre maximum de positions simultanées
        self.position_size_pct = 0.95  # 95% du capital disponible (fractionnement par max_positions)
        
        # Paramètres pour le trading ultra-volatile
        self.profit_target_pct = 0.10  # 10% de profit visé par trade
        self.stop_loss_pct = 0.05  # 5% de perte maximale par trade
        self.extended_stop_loss_pct = 0.12  # 12% pour les actifs à fort momentum
        self.max_holding_time = 8  # 8 heures maximum par position
        
        # Données de marché
        self.asset_sentiment = {}
        self.asset_volatility = {}
        self.asset_momentum = {}
        self.asset_uptrend_score = {}
        self.volatility_rankings = {}  # Classement de volatilité par exchange
        self.volatile_assets = []  # Liste des actifs les plus volatils
        
        # Cache des prix en temps réel (microsecondes)
        self.price_cache = {}
        self.last_price_update = {}
        
        # Système de surveillance multi-exchange
        self.monitoring_data = {
            'multi_exchange_opportunities': [],  # Opportunités détectées sur plusieurs exchanges
            'arbitrage_opportunities': [],       # Opportunités d'arbitrage entre exchanges
            'exchange_status': {}                # Statut de chaque exchange
        }
        
        # Connecter aux exchanges
        self._connect_exchanges()
        
        logger.info("Système de trading multi-exchange initialisé")
    
    def _connect_exchanges(self):
        """Connecte aux différents exchanges supportés"""
        # Kraken (trading activé si clés disponibles)
        kraken_api_key = os.environ.get("KRAKEN_API_KEY")
        kraken_api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        if kraken_api_key and kraken_api_secret:
            self.exchanges['kraken'] = ExchangeConnector(
                'kraken',
                api_key=kraken_api_key,
                api_secret=kraken_api_secret,
                trading_enabled=True
            )
            logger.info("Trading activé sur Kraken")
        else:
            logger.warning("Clés API Kraken non trouvées, trading désactivé")
            self.exchanges['kraken'] = ExchangeConnector('kraken', trading_enabled=False)
        
        # Connecter aux autres exchanges en mode surveillance uniquement
        for exchange_id in SUPPORTED_EXCHANGES:
            if exchange_id != 'kraken' and exchange_id not in self.exchanges:
                # Vérifier si des clés API sont disponibles pour cet exchange
                api_key = os.environ.get(f"{exchange_id.upper()}_API_KEY")
                api_secret = os.environ.get(f"{exchange_id.upper()}_API_SECRET")
                
                # Si les clés sont disponibles, activer le trading sur cet exchange
                trading_enabled = bool(api_key and api_secret)
                
                try:
                    self.exchanges[exchange_id] = ExchangeConnector(
                        exchange_id,
                        api_key=api_key,
                        api_secret=api_secret,
                        trading_enabled=trading_enabled
                    )
                    
                    status = "Trading activé" if trading_enabled else "Surveillance uniquement"
                    logger.info(f"Exchange {exchange_id} connecté: {status}")
                
                except Exception as e:
                    logger.error(f"Erreur lors de la connexion à {exchange_id}: {e}")
    
    def _start_price_cache_updater(self):
        """Démarre le thread de mise à jour du cache de prix"""
        self.price_updater_thread = threading.Thread(target=self._price_cache_update_loop)
        self.price_updater_thread.daemon = True
        self.price_updater_thread.start()
    
    def _price_cache_update_loop(self):
        """Boucle de mise à jour du cache de prix en temps réel"""
        while self.running:
            try:
                # Récupérer les symboles d'intérêt
                symbols = set()
                
                # Ajouter les symboles des positions ouvertes
                for asset in self.open_positions:
                    symbols.add(f"{asset}/USD")
                    symbols.add(f"{asset}/USDT")
                
                # Ajouter les symboles des actifs volatils
                for asset in self.volatile_assets:
                    symbols.add(f"{asset}/USD")
                    symbols.add(f"{asset}/USDT")
                
                # Mettre à jour les prix pour tous les symboles d'intérêt
                for symbol in symbols:
                    for exchange_id, exchange in self.exchanges.items():
                        if exchange.connected:
                            price = exchange.get_ticker_price(symbol)
                            if price:
                                key = f"{exchange_id}:{symbol}"
                                self.price_cache[key] = price
                                self.last_price_update[key] = time.time()
                
                # Courte pause
                time.sleep(0.5)
            
            except Exception as e:
                logger.error(f"Erreur dans la boucle de mise à jour du cache de prix: {e}")
                time.sleep(5)
    
    def get_best_price(self, symbol, order_type='buy'):
        """
        Récupère le meilleur prix disponible sur tous les exchanges
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            order_type (str): Type d'ordre ('buy' ou 'sell')
            
        Returns:
            tuple: (prix, exchange_id) ou (None, None) si non disponible
        """
        prices = []
        
        # Récupérer les prix sur tous les exchanges
        for exchange_id, exchange in self.exchanges.items():
            if exchange.connected:
                price = exchange.get_ticker_price(symbol)
                if price:
                    prices.append((price, exchange_id))
        
        if not prices:
            return None, None
        
        # Pour un achat, on veut le prix le plus bas
        if order_type == 'buy':
            return min(prices, key=lambda x: x[0])
        
        # Pour une vente, on veut le prix le plus élevé
        return max(prices, key=lambda x: x[0])
    
    def analyze_volatility(self, symbol, exchange_id='kraken'):
        """
        Analyse la volatilité d'un actif
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            exchange_id (str): Identifiant de l'exchange
            
        Returns:
            float: Score de volatilité
        """
        try:
            exchange = self.exchanges.get(exchange_id)
            if not exchange or not exchange.connected:
                return 0.0
            
            # Essayer différents timeframes pour une analyse complète
            timeframes = ['5m', '15m', '1h']
            volatility_scores = []
            
            for tf in timeframes:
                # Récupérer les données OHLCV
                ohlcv = exchange.get_ohlcv(symbol, tf, 20)
                
                if not ohlcv or len(ohlcv) < 10:
                    continue
                
                # Calculer les variations en pourcentage
                closes = [candle[4] for candle in ohlcv]
                pct_changes = [abs((closes[i] - closes[i-1]) / closes[i-1]) * 100 for i in range(1, len(closes))]
                
                # Calculer l'écart-type (volatilité)
                volatility = np.std(pct_changes)
                
                # Calculer les écarts high-low pour chaque bougie
                hl_ranges = [(candle[2] - candle[3]) / candle[3] * 100 for candle in ohlcv]
                avg_hl_range = sum(hl_ranges) / len(hl_ranges)
                
                # Combiner les deux mesures pour un score de volatilité
                volatility_score = (volatility * 0.7) + (avg_hl_range * 0.3)
                volatility_scores.append(volatility_score)
            
            # Calculer le score moyen
            if volatility_scores:
                avg_volatility = sum(volatility_scores) / len(volatility_scores)
                
                # Stocker dans le cache
                base_symbol = symbol.split('/')[0]
                self.asset_volatility[base_symbol] = avg_volatility
                
                return avg_volatility
            
            return 0.0
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de volatilité pour {symbol} sur {exchange_id}: {e}")
            return 0.0
    
    def analyze_uptrend(self, symbol, exchange_id='kraken'):
        """
        Analyse si un actif est en uptrend (tendance haussière)
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            exchange_id (str): Identifiant de l'exchange
            
        Returns:
            float: Score d'uptrend entre 0 et 1
        """
        try:
            exchange = self.exchanges.get(exchange_id)
            if not exchange or not exchange.connected:
                return 0.0
            
            # Analyser différents timeframes
            timeframes = ['5m', '15m', '1h']
            uptrend_scores = {}
            
            for tf in timeframes:
                # Récupérer les données OHLCV
                ohlcv = exchange.get_ohlcv(symbol, tf, 20)
                
                if not ohlcv or len(ohlcv) < 12:
                    uptrend_scores[tf] = 0.0
                    continue
                
                # Extraire les prix de clôture
                closes = [candle[4] for candle in ohlcv]
                
                # Calculer les moyennes mobiles
                ma_fast = sum(closes[-5:]) / 5
                ma_medium = sum(closes[-10:]) / 10
                ma_slow = sum(closes[-20:]) / min(20, len(closes))
                
                # Calculer les variations récentes
                last_changes = [((closes[i] - closes[i-1]) / closes[i-1]) * 100 
                               for i in range(max(1, len(closes)-5), len(closes))]
                recent_change_pct = sum(last_changes)
                
                # Vérifier si les moyennes mobiles sont alignées pour un uptrend
                ma_aligned = ma_fast > ma_medium > ma_slow
                
                # Vérifier si la majorité des dernières bougies sont haussières
                bullish_candles = sum(1 for i in range(1, min(10, len(ohlcv))) 
                                     if ohlcv[-i][4] > ohlcv[-i][1])
                mostly_bullish = bullish_candles > 5
                
                # Calculer le score d'uptrend pour ce timeframe
                score = 0.0
                
                if ma_aligned:
                    score += 0.5
                
                if mostly_bullish:
                    score += 0.3
                
                if recent_change_pct > 0:
                    score += min(0.2, recent_change_pct / 10)
                
                # Stocker le score pour ce timeframe
                uptrend_scores[tf] = score
            
            # Calculer le score global (pondéré selon les timeframes)
            if uptrend_scores:
                # Les timeframes courts ont plus de poids pour le day trading
                weights = {
                    '5m': 0.5,
                    '15m': 0.3,
                    '1h': 0.2
                }
                
                # Calculer la moyenne pondérée des scores
                weighted_sum = sum(uptrend_scores.get(tf, 0) * weights.get(tf, 0.1) 
                                  for tf in timeframes)
                total_weight = sum(weights.get(tf, 0.1) for tf in timeframes if tf in uptrend_scores)
                
                global_score = weighted_sum / total_weight if total_weight else 0.0
                
                # Stocker dans le cache
                base_symbol = symbol.split('/')[0]
                self.asset_uptrend_score[base_symbol] = global_score
                
                return global_score
            
            return 0.0
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse d'uptrend pour {symbol} sur {exchange_id}: {e}")
            return 0.0
    
    def analyze_momentum(self, symbol, exchange_id='kraken'):
        """
        Analyse le momentum d'un actif
        
        Args:
            symbol (str): Symbole de la paire (ex: 'BTC/USD')
            exchange_id (str): Identifiant de l'exchange
            
        Returns:
            float: Score de momentum entre -1 et 1
        """
        try:
            exchange = self.exchanges.get(exchange_id)
            if not exchange or not exchange.connected:
                return 0.0
            
            # Analyser différents timeframes
            timeframes = ['5m', '15m', '1h']
            momentum_scores = []
            
            for tf in timeframes:
                # Récupérer les données OHLCV
                ohlcv = exchange.get_ohlcv(symbol, tf, 20)
                
                if not ohlcv or len(ohlcv) < 10:
                    continue
                
                # Extraire les prix de clôture
                closes = [candle[4] for candle in ohlcv]
                
                # Calculer les variations en pourcentage
                pct_changes = [((closes[i] - closes[i-1]) / closes[i-1]) * 100 
                              for i in range(1, len(closes))]
                
                # Utiliser une moyenne pondérée (plus de poids aux variations récentes)
                weights = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
                weights = weights[-len(pct_changes):]
                
                # Normaliser les poids
                weights = [w / sum(weights) for w in weights]
                
                # Calculer le momentum pondéré
                weighted_momentum = sum(pct * w for pct, w in zip(pct_changes[-len(weights):], weights))
                
                # Normaliser entre -1 et 1
                normalized_momentum = max(-1.0, min(1.0, weighted_momentum / 5.0))
                
                # Ajouter à la liste des scores
                momentum_scores.append(normalized_momentum)
            
            # Calculer le momentum moyen sur tous les timeframes
            if momentum_scores:
                avg_momentum = sum(momentum_scores) / len(momentum_scores)
                
                # Stocker dans le cache
                base_symbol = symbol.split('/')[0]
                self.asset_momentum[base_symbol] = avg_momentum
                
                return avg_momentum
            
            return 0.0
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse du momentum pour {symbol} sur {exchange_id}: {e}")
            return 0.0
    
    def analyze_sentiment(self, asset):
        """
        Analyse le sentiment pour un actif
        
        Args:
            asset (str): Symbole de l'actif
            
        Returns:
            float: Score de sentiment entre -1 et 1
        """
        try:
            sentiment = self.sentiment_analyzer.analyze_sentiment(asset)
            
            # Stocker dans le cache
            self.asset_sentiment[asset] = sentiment
            
            return sentiment
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de sentiment pour {asset}: {e}")
            return 0.0
    
    def find_volatile_assets_on_all_exchanges(self, max_assets=20):
        """
        Recherche les actifs les plus volatils sur tous les exchanges
        
        Args:
            max_assets (int): Nombre maximum d'actifs à retourner
            
        Returns:
            list: Liste des actifs les plus volatils
        """
        try:
            logger.info("Recherche des actifs ultra-volatils sur tous les exchanges...")
            
            # Résultats par exchange
            results_by_exchange = {}
            
            # Utiliser ThreadPoolExecutor pour des analyses parallèles
            with ThreadPoolExecutor(max_workers=min(10, len(self.exchanges))) as executor:
                # Lancer l'analyse pour chaque exchange
                futures = {
                    executor.submit(self._find_volatile_assets_on_exchange, exchange_id): exchange_id
                    for exchange_id in self.exchanges
                }
                
                # Récupérer les résultats
                for future in futures:
                    exchange_id = futures[future]
                    try:
                        results = future.result()
                        results_by_exchange[exchange_id] = results
                    except Exception as e:
                        logger.error(f"Erreur lors de l'analyse sur {exchange_id}: {e}")
            
            # Consolider les résultats
            all_assets = {}
            
            for exchange_id, results in results_by_exchange.items():
                for asset, data in results.items():
                    if asset not in all_assets:
                        all_assets[asset] = {
                            'mentions': 1,
                            'total_score': data['score'],
                            'data': data
                        }
                    else:
                        all_assets[asset]['mentions'] += 1
                        all_assets[asset]['total_score'] += data['score']
            
            # Calculer les scores finaux
            for asset, data in all_assets.items():
                # Bonus pour les actifs détectés sur plusieurs exchanges
                mention_bonus = min(3.0, data['mentions'] / 2)
                final_score = data['total_score'] * mention_bonus
                data['final_score'] = final_score
            
            # Trier par score final
            sorted_assets = sorted(all_assets.items(), key=lambda x: x[1]['final_score'], reverse=True)
            
            # Extraire les meilleurs actifs
            top_assets = []
            for asset, data in sorted_assets[:max_assets]:
                top_assets.append(asset)
                logger.info(f"Actif ultra-volatile: {asset}, Score: {data['final_score']:.2f}, "
                           f"Détecté sur {data['mentions']} exchanges")
            
            # Mettre à jour la liste
            self.volatile_assets = top_assets
            
            return top_assets
        
        except Exception as e:
            logger.error(f"Erreur lors de la recherche d'actifs volatils: {e}")
            return []
    
    def _find_volatile_assets_on_exchange(self, exchange_id):
        """
        Trouve les actifs les plus volatils sur un exchange spécifique
        
        Args:
            exchange_id (str): Identifiant de l'exchange
            
        Returns:
            dict: Actifs volatils avec leurs données
        """
        try:
            exchange = self.exchanges.get(exchange_id)
            if not exchange or not exchange.connected:
                return {}
            
            # Récupérer la liste des marchés disponibles
            markets = {}
            try:
                # Utiliser ccxt directement pour cette opération
                markets = exchange.exchange.load_markets()
            except Exception as e:
                logger.error(f"Erreur lors du chargement des marchés sur {exchange_id}: {e}")
                return {}
            
            # Filtrer pour n'inclure que les paires USD ou USDT
            tradable_markets = [m for m in markets.keys() if '/USD' in m or '/USDT' in m]
            
            # Données pour le scoring
            market_data = {}
            
            # Analyser un échantillon de marchés (pour être plus rapide)
            sample_size = min(100, len(tradable_markets))
            sample_markets = tradable_markets[:sample_size]
            
            for symbol in sample_markets:
                try:
                    # Extraire le symbole de base
                    base_symbol = symbol.split('/')[0]
                    
                    # Ignorer les actifs exclus
                    if base_symbol in self.excluded_assets:
                        continue
                    
                    # Analyser l'uptrend
                    uptrend_score = self.analyze_uptrend(symbol, exchange_id)
                    
                    # Si pas en uptrend, on ignore directement
                    if uptrend_score < 0.4:
                        continue
                    
                    # Analyser la volatilité
                    volatility = self.analyze_volatility(symbol, exchange_id)
                    
                    # Si pas assez volatile, on ignore également
                    if volatility < 3.0:
                        continue
                    
                    # Analyser le momentum
                    momentum = self.analyze_momentum(symbol, exchange_id)
                    
                    # Analyser le sentiment
                    sentiment = self.analyze_sentiment(base_symbol)
                    
                    # Récupérer le prix actuel
                    price = exchange.get_ticker_price(symbol)
                    
                    # Stocker les données
                    market_data[base_symbol] = {
                        'symbol': symbol,
                        'uptrend_score': uptrend_score,
                        'volatility': volatility,
                        'momentum': momentum,
                        'sentiment': sentiment,
                        'price': price,
                        'exchange': exchange_id
                    }
                
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse du marché {symbol} sur {exchange_id}: {e}")
            
            # Calculer les scores combinés
            for asset, data in market_data.items():
                # Stratégie de scoring spécifique au trading multi-exchange
                score = (
                    data['uptrend_score'] * 10.0 +  # Uptrend est crucial
                    data['volatility'] * 3.0 +      # Volatilité très importante
                    max(0, data['momentum']) * 5.0 + # Momentum positif
                    max(0, data['sentiment']) * 2.0  # Sentiment positif
                )
                
                data['score'] = score
            
            # Stocker les résultats dans le monitoring
            self.volatility_rankings[exchange_id] = {
                asset: data['score'] for asset, data in market_data.items()
            }
            
            return market_data
        
        except Exception as e:
            logger.error(f"Erreur lors de la recherche d'actifs volatils sur {exchange_id}: {e}")
            return {}
    
    def calculate_position_size(self, asset, exchange_id='kraken'):
        """
        Calcule la taille optimale d'une position
        
        Args:
            asset (str): Symbole de l'actif
            exchange_id (str): Identifiant de l'exchange
            
        Returns:
            float: Taille de la position en unités de l'actif
        """
        try:
            exchange = self.exchanges.get(exchange_id)
            if not exchange or not exchange.connected or not exchange.trading_enabled:
                return 0.0
            
            # Récupérer les balances
            balances = exchange.get_balances()
            
            # Calculer le capital disponible en USD
            usd_balance = balances.get('USD', 0) + balances.get('USDT', 0)
            
            # Si pas assez de capital, ne pas trader
            if usd_balance < self.min_order_size_usd:
                logger.warning(f"Solde USD insuffisant sur {exchange_id}: ${usd_balance:.2f}")
                return 0.0
            
            # Récupérer le prix actuel
            symbol = f"{asset}/USD"
            price = exchange.get_ticker_price(symbol)
            
            if not price:
                symbol = f"{asset}/USDT"
                price = exchange.get_ticker_price(symbol)
            
            if not price:
                logger.error(f"Prix non disponible pour {asset} sur {exchange_id}")
                return 0.0
            
            # Calculer le montant à allouer par position
            allocation = usd_balance * self.position_size_pct / self.max_positions
            
            # Vérifier si on a déjà des positions ouvertes
            open_positions_count = len([p for p, pos in self.open_positions.items() if pos['exchange'] == exchange_id])
            if open_positions_count >= self.max_positions:
                logger.warning(f"Nombre maximum de positions atteint sur {exchange_id}")
                return 0.0
            
            # Ajuster en fonction des positions déjà ouvertes
            remaining_positions = self.max_positions - open_positions_count
            if remaining_positions < self.max_positions:
                allocation = usd_balance * self.position_size_pct / remaining_positions
            
            # Si l'actif a un momentum exceptionnel, augmenter l'allocation
            momentum = self.asset_momentum.get(asset, 0.0)
            if momentum > 0.7:  # Momentum très fort
                allocation *= 1.2  # +20%
            
            # Calculer la quantité
            quantity = allocation / price
            
            # Vérifier la taille minimale
            if quantity * price < self.min_order_size_usd:
                logger.warning(f"Taille de position trop petite pour {asset} sur {exchange_id}: ${quantity * price:.2f} < ${self.min_order_size_usd}")
                return 0.0
            
            return quantity
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul de la taille de position pour {asset} sur {exchange_id}: {e}")
            return 0.0
    
    def place_buy_order(self, asset, quantity, exchange_id='kraken'):
        """
        Place un ordre d'achat
        
        Args:
            asset (str): Symbole de l'actif
            quantity (float): Quantité à acheter
            exchange_id (str): Identifiant de l'exchange
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        try:
            exchange = self.exchanges.get(exchange_id)
            if not exchange or not exchange.connected or not exchange.trading_enabled:
                logger.error(f"Trading non disponible sur {exchange_id}")
                return None
            
            # Déterminer le symbole de la paire
            symbol = f"{asset}/USD"
            price = exchange.get_ticker_price(symbol)
            
            if not price:
                symbol = f"{asset}/USDT"
                price = exchange.get_ticker_price(symbol)
            
            if not price:
                logger.error(f"Prix non disponible pour {asset} sur {exchange_id}")
                return None
            
            # Placer l'ordre
            logger.info(f"Placement d'un ordre d'achat sur {exchange_id} pour {quantity} {asset}...")
            result = exchange.place_buy_order(symbol, quantity)
            
            if result:
                # Récupérer le prix réel de l'exécution
                executed_price = float(result.get('price', price))
                
                # Calculer les niveaux de profit target et stop loss
                profit_target = executed_price * (1 + self.profit_target_pct)
                
                # Déterminer le stop loss en fonction du momentum
                momentum = self.asset_momentum.get(asset, 0.0)
                if momentum > 0.7:  # Fort momentum => stop loss plus large
                    stop_loss = executed_price * (1 - self.extended_stop_loss_pct)
                else:
                    stop_loss = executed_price * (1 - self.stop_loss_pct)
                
                # Mettre à jour l'historique des trades
                trade = {
                    'timestamp': datetime.utcnow(),
                    'asset': asset,
                    'exchange': exchange_id,
                    'action': 'buy',
                    'amount': quantity,
                    'price': executed_price,
                    'total_usd': executed_price * quantity,
                    'uptrend_score': self.asset_uptrend_score.get(asset, 0.0),
                    'volatility': self.asset_volatility.get(asset, 0.0),
                    'momentum': self.asset_momentum.get(asset, 0.0),
                    'sentiment': self.asset_sentiment.get(asset, 0.0)
                }
                self.trade_history.append(trade)
                
                # Mettre à jour la liste des positions ouvertes
                self.open_positions[asset] = {
                    'exchange': exchange_id,
                    'entry_price': executed_price,
                    'amount': quantity,
                    'entry_time': datetime.utcnow(),
                    'profit_target': profit_target,
                    'stop_loss': stop_loss
                }
                
                logger.info(f"Achat réussi sur {exchange_id}: {quantity} {asset} à ${executed_price:.4f}")
                logger.info(f"Profit Target: ${profit_target:.4f} (gain: {self.profit_target_pct*100:.1f}%)")
                logger.info(f"Stop Loss: ${stop_loss:.4f} (perte max: {(executed_price-stop_loss)/executed_price*100:.1f}%)")
                
                return result
            
            logger.error(f"Échec de l'ordre d'achat pour {asset} sur {exchange_id}")
            return None
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre d'achat pour {asset} sur {exchange_id}: {e}")
            return None
    
    def place_sell_order(self, asset, quantity, exchange_id='kraken', reason="manuel"):
        """
        Place un ordre de vente
        
        Args:
            asset (str): Symbole de l'actif
            quantity (float): Quantité à vendre
            exchange_id (str): Identifiant de l'exchange
            reason (str): Raison de la vente
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        try:
            exchange = self.exchanges.get(exchange_id)
            if not exchange or not exchange.connected or not exchange.trading_enabled:
                logger.error(f"Trading non disponible sur {exchange_id}")
                return None
            
            # Déterminer le symbole de la paire
            symbol = f"{asset}/USD"
            price = exchange.get_ticker_price(symbol)
            
            if not price:
                symbol = f"{asset}/USDT"
                price = exchange.get_ticker_price(symbol)
            
            if not price:
                logger.error(f"Prix non disponible pour {asset} sur {exchange_id}")
                return None
            
            # Placer l'ordre
            logger.info(f"Placement d'un ordre de vente sur {exchange_id} pour {quantity} {asset} (raison: {reason})...")
            result = exchange.place_sell_order(symbol, quantity)
            
            if result:
                # Récupérer le prix réel de l'exécution
                executed_price = float(result.get('price', price))
                
                # Mettre à jour l'historique des trades
                trade = {
                    'timestamp': datetime.utcnow(),
                    'asset': asset,
                    'exchange': exchange_id,
                    'action': f"sell_{reason}",
                    'amount': quantity,
                    'price': executed_price,
                    'total_usd': executed_price * quantity
                }
                
                # Calculer le P&L si on avait une position ouverte
                if asset in self.open_positions and self.open_positions[asset]['exchange'] == exchange_id:
                    entry_price = self.open_positions[asset]['entry_price']
                    profit_pct = ((executed_price / entry_price) - 1) * 100
                    trade['profit_pct'] = profit_pct
                    
                    logger.info(f"Vente réussie sur {exchange_id}: {quantity} {asset} à ${executed_price:.4f} "
                               f"(P&L: {profit_pct:+.2f}%, Raison: {reason})")
                    
                    # Supprimer la position ouverte
                    del self.open_positions[asset]
                else:
                    logger.info(f"Vente réussie sur {exchange_id}: {quantity} {asset} à ${executed_price:.4f} (Raison: {reason})")
                
                self.trade_history.append(trade)
                return result
            
            logger.error(f"Échec de l'ordre de vente pour {asset} sur {exchange_id}")
            return None
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre de vente pour {asset} sur {exchange_id}: {e}")
            return None
    
    def update_intelligent_stop_loss(self, asset, position, current_price):
        """
        Met à jour de manière intelligente le niveau de stop-loss en fonction 
        des conditions de marché et de la performance de la position
        
        Args:
            asset (str): Symbole de l'actif
            position (dict): Données de la position
            current_price (float): Prix actuel
            
        Returns:
            float: Nouveau niveau de stop-loss
        """
        entry_price = position['entry_price']
        entry_time = position['entry_time']
        original_stop_loss = position['stop_loss']
        current_time = datetime.utcnow()
        
        # Calculer le profit actuel
        profit_pct = ((current_price / entry_price) - 1) * 100
        elapsed_hours = (current_time - entry_time).total_seconds() / 3600
        
        # Récupérer les données de marché actuelles
        exchange_id = position['exchange']
        symbol = f"{asset}/USD"
        exchange = self.exchanges.get(exchange_id)
        
        # Récupérer l'évaluation actuelle du marché
        volatility = self.asset_volatility.get(asset, 0)
        momentum = self.asset_momentum.get(asset, 0)
        uptrend_score = self.analyze_uptrend(symbol, exchange_id)
        
        # Stratégies de stop-loss intelligent:
        new_stop_loss = original_stop_loss
        
        # 1. Trailing stop-loss: déplacer le stop-loss à mesure que le prix augmente
        # Quand le profit atteint certains paliers, on remonte le stop-loss
        if profit_pct >= 12:  # +12% de profit
            # Garantir au moins +6% de profit même en cas de retournement
            trailing_level = entry_price * 1.06
            if trailing_level > original_stop_loss:
                new_stop_loss = max(new_stop_loss, trailing_level)
                logger.info(f"Stop-loss intelligent ajusté (+12% profit) pour {asset}: ${new_stop_loss:.4f}")
        
        elif profit_pct >= 8:  # +8% de profit
            # Garantir au moins +4% de profit
            trailing_level = entry_price * 1.04
            if trailing_level > original_stop_loss:
                new_stop_loss = max(new_stop_loss, trailing_level)
                logger.info(f"Stop-loss intelligent ajusté (+8% profit) pour {asset}: ${new_stop_loss:.4f}")
        
        elif profit_pct >= 4:  # +4% de profit
            # Garantir au moins +1% de profit (conservation de gains)
            trailing_level = entry_price * 1.01
            if trailing_level > original_stop_loss:
                new_stop_loss = max(new_stop_loss, trailing_level)
                logger.info(f"Stop-loss intelligent ajusté (+4% profit) pour {asset}: ${new_stop_loss:.4f}")
        
        # 2. Dynamique de marché: ajuster en fonction des conditions actuelles
        # Si les conditions se détériorent, resserrer le stop-loss
        if uptrend_score < 0.4 and elapsed_hours > 0.5:  # Uptrend faible
            dynamic_level = current_price * 0.98  # Stop-loss plus proche (-2%)
            if dynamic_level > original_stop_loss:
                new_stop_loss = max(new_stop_loss, dynamic_level)
                logger.info(f"Stop-loss intelligent ajusté (uptrend faible) pour {asset}: ${new_stop_loss:.4f}")
        
        # Si le momentum devient négatif, resserrer le stop-loss
        if momentum < -0.3 and elapsed_hours > 0.5:
            dynamic_level = current_price * 0.985  # Stop-loss très proche (-1.5%)
            if dynamic_level > original_stop_loss:
                new_stop_loss = max(new_stop_loss, dynamic_level)
                logger.info(f"Stop-loss intelligent ajusté (momentum négatif) pour {asset}: ${new_stop_loss:.4f}")
        
        # 3. Facteur temps: plus une position est ancienne, plus on protège les gains
        # Après 3 heures, on commence à protéger davantage les gains
        if elapsed_hours > 3 and profit_pct > 2:
            time_factor = min(0.8, elapsed_hours / 10)  # Max 80% de protection
            protected_gain = entry_price * (1 + (profit_pct * time_factor / 100))
            if protected_gain > original_stop_loss:
                new_stop_loss = max(new_stop_loss, protected_gain)
                logger.info(f"Stop-loss intelligent ajusté (facteur temps) pour {asset}: ${new_stop_loss:.4f}")
        
        # Si le nouveau stop-loss est plus élevé, mettre à jour la position
        if new_stop_loss > original_stop_loss:
            position['stop_loss'] = new_stop_loss
            position['stop_loss_updated_at'] = current_time
            position['stop_loss_reason'] = "intelligent_adjustment"
            
            if new_stop_loss > entry_price:
                logger.info(f"Position {asset} maintenant en mode sans perte avec stop-loss à ${new_stop_loss:.4f}")
        
        return new_stop_loss

    def check_exit_conditions(self):
        """Vérifie les conditions de sortie pour toutes les positions ouvertes"""
        current_time = datetime.utcnow()
        
        for asset, position in list(self.open_positions.items()):
            try:
                exchange_id = position['exchange']
                exchange = self.exchanges.get(exchange_id)
                
                if not exchange or not exchange.connected:
                    continue
                
                # Déterminer le symbole de la paire
                symbol = f"{asset}/USD"
                price = exchange.get_ticker_price(symbol)
                
                if not price:
                    symbol = f"{asset}/USDT"
                    price = exchange.get_ticker_price(symbol)
                
                if not price:
                    continue
                
                entry_price = position['entry_price']
                entry_time = position['entry_time']
                amount = position['amount']
                profit_target = position['profit_target']
                
                # Mettre à jour le stop-loss intelligent
                stop_loss = self.update_intelligent_stop_loss(asset, position, price)
                
                # Calculer le temps écoulé depuis l'entrée
                elapsed_time = current_time - entry_time
                elapsed_hours = elapsed_time.total_seconds() / 3600
                
                # Calculer le profit actuel
                profit_pct = ((price / entry_price) - 1) * 100
                
                # Vérifier si on a atteint le profit target
                if price >= profit_target:
                    logger.info(f"Profit target atteint pour {asset} sur {exchange_id}: ${price:.4f} >= ${profit_target:.4f}")
                    self.place_sell_order(asset, amount, exchange_id, reason="profit")
                    continue
                
                # Vérifier si on a déclenché le stop loss
                if price <= stop_loss:
                    # Déterminer le type de stop-loss déclenché
                    if stop_loss > entry_price:
                        reason = "stop-loss-profit"
                        logger.info(f"Stop loss en profit déclenché pour {asset} sur {exchange_id}: ${price:.4f} <= ${stop_loss:.4f} (profit protégé: {((stop_loss/entry_price)-1)*100:.2f}%)")
                    else:
                        reason = "stop-loss"
                        logger.warning(f"Stop loss déclenché pour {asset} sur {exchange_id}: ${price:.4f} <= ${stop_loss:.4f}")
                    
                    self.place_sell_order(asset, amount, exchange_id, reason=reason)
                    continue
                
                # Vérifier le timeout (max holding time)
                if elapsed_hours >= self.max_holding_time:
                    logger.info(f"Timeout atteint pour {asset} sur {exchange_id}: {elapsed_hours:.1f}h >= {self.max_holding_time}h")
                    
                    if profit_pct > 0:
                        reason = "timeout_profit"
                    else:
                        reason = "timeout"
                    
                    self.place_sell_order(asset, amount, exchange_id, reason=reason)
                    continue
                
                # Vérifier les conditions de marché (tendance inversée ?)
                uptrend_score = self.analyze_uptrend(symbol, exchange_id)
                
                # Vérification intelligente des conditions du marché
                market_exit_triggered = False
                exit_reason = ""
                
                # Si l'uptrend est clairement cassé et qu'on a tenu plus de 30 minutes
                if uptrend_score < 0.3 and elapsed_hours > 0.5:
                    market_exit_triggered = True
                    exit_reason = "trend_change"
                    logger.warning(f"Uptrend cassé pour {asset} sur {exchange_id}: score {uptrend_score:.2f} < 0.3")
                
                # Si le momentum devient très négatif et qu'on a des profits
                momentum = self.asset_momentum.get(asset, 0)
                if momentum < -0.5 and profit_pct > 3 and elapsed_hours > 0.5:
                    market_exit_triggered = True
                    exit_reason = "negative_momentum"
                    logger.warning(f"Momentum très négatif pour {asset} sur {exchange_id}: {momentum:.2f} < -0.5")
                
                # Si la volatilité augmente trop (risque accru)
                volatility = self.asset_volatility.get(asset, 0)
                if volatility > 15 and profit_pct > 5:  # Volatilité extrême + profits
                    market_exit_triggered = True
                    exit_reason = "extreme_volatility"
                    logger.warning(f"Volatilité extrême pour {asset} sur {exchange_id}: {volatility:.2f} > 15")
                
                # Si toutes les conditions sont remplies, exécuter la sortie
                if market_exit_triggered:
                    # Ajuster la raison selon qu'on est en profit ou en perte
                    if profit_pct > 0:
                        reason = f"{exit_reason}_profit"
                    else:
                        reason = exit_reason
                    
                    self.place_sell_order(asset, amount, exchange_id, reason=reason)
            
            except Exception as e:
                logger.error(f"Erreur lors de la vérification des conditions de sortie pour {asset}: {e}")
    
    def manage_entries(self):
        """Gère les entrées en position selon la stratégie multi-exchange"""
        try:
            # Vérifier quels exchanges sont configurés pour le trading
            trading_exchanges = {
                exchange_id: exchange for exchange_id, exchange in self.exchanges.items()
                if exchange.connected and exchange.trading_enabled
            }
            
            if not trading_exchanges:
                logger.warning("Aucun exchange configuré pour le trading")
                return
            
            # Pour chaque exchange configuré pour le trading
            for exchange_id, exchange in trading_exchanges.items():
                try:
                    # Récupérer les balances
                    balances = exchange.get_balances()
                    
                    # Calculer le capital disponible en USD
                    usd_balance = balances.get('USD', 0) + balances.get('USDT', 0)
                    
                    if usd_balance < self.min_order_size_usd:
                        logger.info(f"Solde USD insuffisant sur {exchange_id}: ${usd_balance:.2f}")
                        continue
                    
                    logger.info(f"Capital disponible sur {exchange_id}: ${usd_balance:.2f}")
                    
                    # Vérifier si on a déjà atteint le nombre max de positions pour cet exchange
                    open_positions_count = len([p for p, pos in self.open_positions.items() if pos['exchange'] == exchange_id])
                    if open_positions_count >= self.max_positions:
                        logger.info(f"Nombre maximum de positions atteint sur {exchange_id} ({self.max_positions})")
                        continue
                    
                    # Évaluer chaque actif ultra-volatil
                    for asset in self.volatile_assets:
                        # Éviter d'acheter si on a déjà une position sur cet actif
                        if asset in self.open_positions:
                            continue
                        
                        # Vérifier les critères pour l'achat
                        uptrend_score = self.asset_uptrend_score.get(asset, 0.0)
                        momentum = self.asset_momentum.get(asset, 0.0)
                        volatility = self.asset_volatility.get(asset, 0.0)
                        
                        # Critères stricts pour le trading ultra-volatil
                        buy_signal = (uptrend_score > 0.7 and  # Fort uptrend
                                    volatility > 3.0 and      # Volatilité significative
                                    momentum > 0.0)           # Momentum positif
                        
                        if buy_signal:
                            # Calculer la taille de la position
                            quantity = self.calculate_position_size(asset, exchange_id)
                            
                            if quantity > 0:
                                # Placer l'ordre d'achat
                                logger.info(f"OPPORTUNITÉ DE TRADING: {asset} sur {exchange_id}, "
                                          f"Uptrend: {uptrend_score:.2f}, Volatilité: {volatility:.2f}, "
                                          f"Momentum: {momentum:.2f}")
                                
                                result = self.place_buy_order(asset, quantity, exchange_id)
                                
                                if result:
                                    # Pause pour éviter de surcharger l'API
                                    time.sleep(1)
                
                except Exception as e:
                    logger.error(f"Erreur lors de la gestion des entrées sur {exchange_id}: {e}")
        
        except Exception as e:
            logger.error(f"Erreur lors de la gestion des entrées: {e}")
    
    def scan_for_opportunities(self):
        """Scanner tous les exchanges pour des opportunités de trading"""
        # Mettre à jour la liste des actifs ultra-volatils
        self.find_volatile_assets_on_all_exchanges()
        
        # Vérifier les conditions de sortie pour les positions existantes
        self.check_exit_conditions()
        
        # Chercher de nouvelles opportunités d'entrée
        self.manage_entries()
    
    def trading_loop(self):
        """Boucle principale de trading"""
        logger.info("Démarrage de la boucle de trading multi-exchange...")
        
        next_scan_time = time.time()
        next_status_update = time.time() + 60
        
        while self.running:
            try:
                current_time = time.time()
                
                # Scanner périodiquement pour de nouvelles opportunités
                if current_time >= next_scan_time:
                    self.scan_for_opportunities()
                    
                    # Programmer le prochain scan dans 10 minutes
                    next_scan_time = current_time + 600  # 10 minutes
                
                # Afficher périodiquement un statut
                if current_time >= next_status_update:
                    self._log_trading_status()
                    next_status_update = current_time + 300  # 5 minutes
                
                # Pause
                time.sleep(10)
            
            except Exception as e:
                logger.error(f"Erreur dans la boucle de trading multi-exchange: {e}")
                time.sleep(30)
    
    def _log_trading_status(self):
        """Enregistre le statut actuel du système de trading"""
        try:
            # Compter les exchanges actifs
            active_exchanges = sum(1 for e in self.exchanges.values() if e.connected)
            trading_exchanges = sum(1 for e in self.exchanges.values() if e.connected and e.trading_enabled)
            
            # Compter les positions ouvertes
            open_positions_count = len(self.open_positions)
            
            # Calculer les stats de performance
            profitable_trades = [t for t in self.trade_history if t.get('action', '').startswith('sell') and t.get('profit_pct', 0) > 0]
            losing_trades = [t for t in self.trade_history if t.get('action', '').startswith('sell') and t.get('profit_pct', 0) <= 0]
            
            win_rate = len(profitable_trades) / max(1, len(profitable_trades) + len(losing_trades)) * 100
            
            logger.info(f"STATUS DU SYSTÈME 24/7: {active_exchanges} exchanges actifs, "
                      f"{trading_exchanges} avec trading, {open_positions_count} positions ouvertes, "
                      f"{len(self.volatile_assets)} actifs ultra-volatils surveillés, "
                      f"Win rate: {win_rate:.1f}%")
            
            # Enregistrer les positions ouvertes
            if self.open_positions:
                for asset, position in self.open_positions.items():
                    exchange_id = position['exchange']
                    exchange = self.exchanges.get(exchange_id)
                    
                    if not exchange:
                        continue
                    
                    # Déterminer le symbole de la paire
                    symbol = f"{asset}/USD"
                    price = exchange.get_ticker_price(symbol)
                    
                    if not price:
                        symbol = f"{asset}/USDT"
                        price = exchange.get_ticker_price(symbol)
                    
                    if price:
                        entry_price = position['entry_price']
                        profit_pct = ((price / entry_price) - 1) * 100
                        entry_time = position['entry_time']
                        elapsed_hours = (datetime.utcnow() - entry_time).total_seconds() / 3600
                        
                        logger.info(f"Position: {asset} sur {exchange_id}, Entrée: ${entry_price:.4f}, "
                                  f"Actuel: ${price:.4f}, P&L: {profit_pct:+.2f}%, Durée: {elapsed_hours:.1f}h")
        
        except Exception as e:
            logger.error(f"Erreur lors de l'enregistrement du statut: {e}")
    
    def start(self):
        """Démarre le système de trading multi-exchange"""
        if self.running:
            logger.warning("Le système de trading est déjà en cours d'exécution")
            return False
        
        logger.info("🚀 DÉMARRAGE DU SYSTÈME DE TRADING MULTI-EXCHANGE 24/7")
        self.running = True
        
        # Démarrer le thread de mise à jour du cache de prix
        self._start_price_cache_updater()
        
        # Démarrer la boucle de trading dans un thread
        self.trading_thread = threading.Thread(target=self.trading_loop)
        self.trading_thread.daemon = True
        self.trading_thread.start()
        
        logger.info("Système de trading multi-exchange démarré avec succès!")
        return True
    
    def stop(self):
        """Arrête le système de trading"""
        if not self.running:
            logger.warning("Le système de trading n'est pas en cours d'exécution")
            return False
        
        logger.info("Arrêt du système de trading multi-exchange...")
        self.running = False
        
        # Attendre que les threads se terminent
        if hasattr(self, 'trading_thread') and self.trading_thread.is_alive():
            self.trading_thread.join(timeout=5.0)
        
        logger.info("Système de trading multi-exchange arrêté avec succès!")
        return True
    
    def get_status(self):
        """Récupère le statut complet du système de trading"""
        # Compter les exchanges actifs
        exchange_status = {}
        total_value_usd = 0.0
        balances_by_exchange = {}
        
        for exchange_id, exchange in self.exchanges.items():
            if exchange.connected:
                # Récupérer les balances
                if exchange.trading_enabled:
                    balances = exchange.get_balances()
                    
                    # Calculer la valeur totale en USD
                    exchange_value_usd = 0.0
                    balances_with_value = {}
                    
                    for asset, amount in balances.items():
                        if amount <= 0:
                            continue
                        
                        if asset in ["USD", "USDT"]:
                            value_usd = amount
                        else:
                            symbol = f"{asset}/USD"
                            price = exchange.get_ticker_price(symbol)
                            if not price:
                                symbol = f"{asset}/USDT"
                                price = exchange.get_ticker_price(symbol)
                            
                            value_usd = amount * price if price else 0
                        
                        balances_with_value[asset] = {
                            'balance': amount,
                            'value_usd': value_usd
                        }
                        exchange_value_usd += value_usd
                    
                    balances_by_exchange[exchange_id] = balances_with_value
                    total_value_usd += exchange_value_usd
                
                exchange_status[exchange_id] = {
                    'connected': True,
                    'trading_enabled': exchange.trading_enabled,
                    'value_usd': exchange_value_usd if exchange.trading_enabled else 0.0
                }
            else:
                exchange_status[exchange_id] = {
                    'connected': False,
                    'trading_enabled': False,
                    'value_usd': 0.0
                }
        
        # Informations sur les positions ouvertes
        positions_data = []
        for asset, position in self.open_positions.items():
            exchange_id = position['exchange']
            exchange = self.exchanges.get(exchange_id)
            
            if not exchange or not exchange.connected:
                continue
            
            # Déterminer le symbole de la paire
            symbol = f"{asset}/USD"
            price = exchange.get_ticker_price(symbol)
            
            if not price:
                symbol = f"{asset}/USDT"
                price = exchange.get_ticker_price(symbol)
            
            if price:
                entry_price = position['entry_price']
                profit_pct = ((price / entry_price) - 1) * 100
                entry_time = position['entry_time']
                elapsed_time = (datetime.utcnow() - entry_time).total_seconds() / 3600
                
                positions_data.append({
                    'asset': asset,
                    'exchange': exchange_id,
                    'amount': position['amount'],
                    'entry_price': entry_price,
                    'entry_time': entry_time.isoformat(),
                    'elapsed_hours': elapsed_time,
                    'current_price': price,
                    'profit_pct': profit_pct,
                    'profit_target': position['profit_target'],
                    'stop_loss': position['stop_loss']
                })
        
        # Préparer les données sur les actifs volatils
        volatile_assets_data = []
        for asset in self.volatile_assets:
            # Trouver le meilleur prix disponible pour cet actif
            best_price, best_exchange = None, None
            for exchange_id, exchange in self.exchanges.items():
                if exchange.connected:
                    symbol = f"{asset}/USD"
                    price = exchange.get_ticker_price(symbol)
                    
                    if not price:
                        symbol = f"{asset}/USDT"
                        price = exchange.get_ticker_price(symbol)
                    
                    if price and (not best_price or price > best_price):
                        best_price = price
                        best_exchange = exchange_id
            
            volatile_assets_data.append({
                'asset': asset,
                'best_price': best_price,
                'best_exchange': best_exchange,
                'uptrend_score': self.asset_uptrend_score.get(asset, 0),
                'volatility': self.asset_volatility.get(asset, 0),
                'momentum': self.asset_momentum.get(asset, 0),
                'sentiment': self.asset_sentiment.get(asset, 0)
            })
        
        # Analyse des P&L
        trades = self.trade_history
        profitable_trades = [t for t in trades if t.get('action', '').startswith('sell') and t.get('profit_pct', 0) > 0]
        losing_trades = [t for t in trades if t.get('action', '').startswith('sell') and t.get('profit_pct', 0) <= 0]
        
        win_rate = len(profitable_trades) / max(1, len(profitable_trades) + len(losing_trades)) * 100
        avg_profit = sum(t.get('profit_pct', 0) for t in profitable_trades) / len(profitable_trades) if profitable_trades else 0
        avg_loss = sum(t.get('profit_pct', 0) for t in losing_trades) / len(losing_trades) if losing_trades else 0
        
        return {
            'running': self.running,
            'total_value_usd': total_value_usd,
            'exchange_status': exchange_status,
            'balances_by_exchange': balances_by_exchange,
            'volatile_assets': volatile_assets_data,
            'open_positions': positions_data,
            'trade_history': self.trade_history[-20:] if self.trade_history else [],
            'statistics': {
                'total_trades': len(trades),
                'profitable_trades': len(profitable_trades),
                'losing_trades': len(losing_trades),
                'win_rate': win_rate,
                'avg_profit': avg_profit,
                'avg_loss': avg_loss
            }
        }

def run_multi_exchange_trader():
    """Fonction principale pour démarrer le système de trading multi-exchange"""
    try:
        # Afficher un avertissement
        print("=" * 80)
        print("ATTENTION: LANCEMENT DU SYSTÈME DE TRADING MULTI-EXCHANGE EN MODE RÉEL 24/7")
        print("Cryptos ciblées: ULTRA-VOLATILES en UPTREND sur plusieurs exchanges")
        print("Objectif: Trading sophistiqué avec gains de 20-50% par mois")
        print("=" * 80)
        
        # Initialiser le trader
        trader = MultiExchangeTrader()
        
        # Afficher les exchanges connectés
        status = trader.get_status()
        print(f"Solde total: ${status['total_value_usd']:.2f}")
        
        print("Exchanges connectés:")
        for exchange_id, exchange_status in status['exchange_status'].items():
            if exchange_status['connected']:
                trading_status = "TRADING ACTIVÉ" if exchange_status['trading_enabled'] else "Surveillance uniquement"
                print(f"  {exchange_id.upper()}: {trading_status}")
                
                # Afficher les balances si disponibles
                if exchange_id in status['balances_by_exchange']:
                    balances = status['balances_by_exchange'][exchange_id]
                    print(f"    Solde: ${exchange_status['value_usd']:.2f}")
                    for asset, data in balances.items():
                        if data['value_usd'] > 1.0:  # N'afficher que les soldes significatifs
                            print(f"    {asset}: {data['balance']} ≈ ${data['value_usd']:.2f}")
            else:
                print(f"  {exchange_id.upper()}: Non connecté")
        
        # Démarrer le trader
        trader.start()
        
        print("=" * 80)
        print("SYSTÈME DE TRADING MULTI-EXCHANGE 24/7 DÉMARRÉ AVEC SUCCÈS")
        print("Surveillance continue des opportunités sur tous les exchanges")
        print("Utilisez Ctrl+C pour arrêter")
        print("=" * 80)
        
        # Boucle pour afficher le statut périodiquement
        try:
            while True:
                time.sleep(300)  # Attendre 5 minutes
                status = trader.get_status()
                
                print(f"\nSTATUT DU SYSTÈME (Solde total: ${status['total_value_usd']:.2f}):")
                
                # Afficher les positions ouvertes
                if status['open_positions']:
                    print("Positions ouvertes:")
                    for pos in status['open_positions']:
                        print(f"  {pos['asset']} sur {pos['exchange']}: {pos['amount']} @ ${pos['entry_price']:.4f} "
                              f"(Actuel: ${pos['current_price']:.4f}, "
                              f"{pos['profit_pct']:+.2f}%, depuis {pos['elapsed_hours']:.1f}h)")
                else:
                    print("Aucune position ouverte, recherche d'opportunités...")
                
                # Afficher les actifs surveillés
                if status['volatile_assets']:
                    print("Top actifs ultra-volatils surveillés:")
                    for asset in status['volatile_assets'][:5]:  # Afficher les 5 premiers
                        if asset['best_price']:
                            print(f"  {asset['asset']}: ${asset['best_price']:.4f} sur {asset['best_exchange']}, "
                                 f"Uptrend: {asset['uptrend_score']:.2f}, Volatilité: {asset['volatility']:.2f}")
                
                # Afficher les statistiques
                stats = status['statistics']
                print(f"Performance: {stats['win_rate']:.1f}% win rate, "
                      f"Profit moyen: {stats['avg_profit']:+.2f}%, Perte moyenne: {stats['avg_loss']:+.2f}%")
        
        except KeyboardInterrupt:
            print("\nArrêt demandé par l'utilisateur...")
            trader.stop()
            print("Système de trading multi-exchange arrêté avec succès.")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors du lancement du système de trading multi-exchange: {e}")
        return False

if __name__ == "__main__":
    run_multi_exchange_trader()