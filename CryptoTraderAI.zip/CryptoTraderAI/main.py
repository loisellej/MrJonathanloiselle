import os
import time
import logging
import threading
import subprocess
from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Charger les variables d'environnement depuis .env
load_dotenv()

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
# Création de l'application Flask
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET") or "clé_secrète_ultra_volatile"

# Configuration de la base de données
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialisation de la base de données
db.init_app(app)

# Variables globales pour l'état du bot
bot_process = None
bot_status = "arrêté"
last_heartbeat = None

def initialize_database():
    """Initialise la base de données si nécessaire"""
    with app.app_context():
        db.create_all()

def is_bot_running():
    """Vérifie si le bot est en cours d'exécution"""
    try:
        # Vérifier le fichier PID
        if os.path.exists("trader.pid"):
            with open("trader.pid", "r") as f:
                pid = int(f.read().strip())
            # Vérifier si le processus existe
            os.kill(pid, 0)
            return True
        return False
    except:
        return False

def check_heartbeat():
    """Vérifie si le heartbeat du bot est récent"""
    global last_heartbeat
    if os.path.exists("bot_heartbeat.txt"):
        try:
            mtime = os.path.getmtime("bot_heartbeat.txt")
            last_heartbeat = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(mtime))
            # Si le heartbeat est de moins de 5 minutes
            if time.time() - mtime < 300:
                return True
        except:
            pass
    return False

def start_bot_process():
    """Démarre le processus du bot en arrière-plan"""
    global bot_process, bot_status
    try:
        # Arrêter tout processus existant
        stop_bot_process()
        
        # Démarrer le script de surveillance (keep_bot_alive.sh)
        subprocess.Popen(["bash", "-c", "nohup ./keep_bot_alive.sh > /dev/null 2>&1 &"])
        
        bot_status = "démarré"
        logging.info("Bot démarré avec succès via keep_bot_alive.sh")
        return True
    except Exception as e:
        logging.error(f"Erreur lors du démarrage du bot: {e}")
        bot_status = "erreur"
        return False

def stop_bot_process():
    """Arrête le processus du bot"""
    global bot_status
    try:
        # Tuer les processus liés au bot
        subprocess.run(["pkill", "-f", "start_24_7_trader.py"], stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-f", "keep_bot_alive.sh"], stderr=subprocess.DEVNULL)
        
        # Supprimer le fichier PID s'il existe
        if os.path.exists("trader.pid"):
            os.remove("trader.pid")
            
        bot_status = "arrêté"
        logging.info("Bot arrêté avec succès")
        return True
    except Exception as e:
        logging.error(f"Erreur lors de l'arrêt du bot: {e}")
        return False

def get_bot_status():
    """Récupère le statut actuel du bot"""
    status = {
        "status": "inconnu",
        "last_heartbeat": last_heartbeat,
        "pid": None
    }
    
    # Vérifier si le bot est en cours d'exécution
    if is_bot_running():
        status["status"] = "en cours d'exécution"
        with open("trader.pid", "r") as f:
            status["pid"] = f.read().strip()
    elif check_heartbeat():
        status["status"] = "actif (heartbeat récent)"
    else:
        status["status"] = "arrêté"
    
    return status

def get_account_balances():
    """Récupère les soldes du compte"""
    balances = []
    try:
        from direct_kraken_api import KrakenAPI
        
        # Récupération des clés API depuis les variables d'environnement
        api_key = os.environ.get("KRAKEN_API_KEY")
        api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        # Création de l'objet API
        api = KrakenAPI(api_key=api_key, api_secret=api_secret)
        
        # Récupération des balances
        account_balances = api.get_balances()
        
        # Formatage des balances
        for asset, balance in account_balances.items():
            if float(balance) > 0:
                # Récupérer le prix en USD si possible
                price_usd = None
                try:
                    if asset != "ZUSD":
                        ticker = api.get_ticker(f"{asset}/USD")
                        if ticker:
                            price_usd = float(ticker["c"][0]) * float(balance)
                except:
                    pass
                
                balances.append({
                    "asset": asset.replace("X", "").replace("Z", ""),
                    "balance": float(balance),
                    "usd_value": price_usd
                })
    except Exception as e:
        logging.error(f"Erreur lors de la récupération des balances: {e}")
    
    return balances

def get_recent_logs(n=20):
    """Récupère les N dernières lignes du journal de trading"""
    logs = []
    try:
        if os.path.exists("trader_24_7.log"):
            with open("trader_24_7.log", "r") as f:
                all_lines = f.readlines()
                logs = all_lines[-n:]
    except Exception as e:
        logging.error(f"Erreur lors de la récupération des logs: {e}")
    
    return logs

def monitor_bot():
    """Fonction pour surveiller l'état du bot en continu"""
    while True:
        try:
            # Vérifier si le bot est en cours d'exécution
            if bot_status == "démarré" and not (is_bot_running() or check_heartbeat()):
                logging.warning("Bot détecté comme arrêté, tentative de redémarrage...")
                start_bot_process()
            
            # Attendre avant la prochaine vérification
            time.sleep(60)
        except Exception as e:
            logging.error(f"Erreur dans la surveillance du bot: {e}")
            time.sleep(60)

# Démarrer le thread de surveillance du bot
monitor_thread = threading.Thread(target=monitor_bot, daemon=True)
monitor_thread.start()

# Démarrer automatiquement le bot au lancement de l'application Flask
# Cela garantit que le bot démarre automatiquement lors du déploiement
# ou du redémarrage de Replit
# Note: before_first_request est déprécié dans Flask 2.0+
# On utilise une autre approche
@app.route('/startup')
def startup():
    """Route pour démarrer automatiquement le bot"""
    global bot_status
    if bot_status == "arrêté":
        logging.info("Démarrage automatique du bot...")
        start_bot_process()
    return jsonify({"success": True, "message": "Initialisation du bot terminée"})

# Routes Flask
@app.route('/')
def index():
    """Page d'accueil"""
    bot_info = get_bot_status()
    return render_template('index.html', bot_info=bot_info)

@app.route('/live')
def live_trading():
    """Page de trading en mode LIVE uniquement"""
    bot_info = get_bot_status()
    return render_template('live_trading.html', bot_info=bot_info)

@app.route('/start_bot', methods=['POST'])
def start_bot():
    """Route pour démarrer le bot"""
    success = start_bot_process()
    return jsonify({"success": success, "status": bot_status})

@app.route('/stop_bot', methods=['POST'])
def stop_bot():
    """Route pour arrêter le bot"""
    success = stop_bot_process()
    return jsonify({"success": success, "status": bot_status})

@app.route('/status')
def status():
    """Page de statut du bot"""
    bot_info = get_bot_status()
    balances = get_account_balances()
    logs = get_recent_logs()
    return render_template('status.html', bot_info=bot_info, balances=balances, logs=logs)

@app.route('/api/status')
def api_status():
    """API pour récupérer le statut du bot"""
    bot_info = get_bot_status()
    balances = get_account_balances()
    logs = get_recent_logs(10)
    
    return jsonify({
        "bot": bot_info,
        "balances": balances,
        "logs": logs
    })

@app.route('/convert')
def convert_page():
    """Page pour convertir les actifs"""
    return render_template('convert.html')

@app.route('/convert/to_volatile', methods=['POST'])
def convert_to_volatile():
    """Convertit les actifs en cryptos volatiles"""
    try:
        # Import du module de trading direct
        from direct_kraken_api import KrakenAPI
        
        # Récupération des clés API
        api_key = os.environ.get("KRAKEN_API_KEY")
        api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        # Initialisation de l'API
        api = KrakenAPI(api_key=api_key, api_secret=api_secret)
        
        # Conversion des actifs
        result = api.convert_to_volatile()
        
        return jsonify({"success": True, "message": "Conversion en cours", "details": result})
    except Exception as e:
        logging.error(f"Erreur lors de la conversion: {e}")
        return jsonify({"success": False, "message": f"Erreur: {str(e)}"})

# Fonction pour maintenir Replit actif
def keep_alive_ping():
    """Fonction pour garder l'application Replit active"""
    while True:
        try:
            # Ping pour maintenir Replit actif
            logging.debug("Ping de maintien en vie")
            time.sleep(300)  # Toutes les 5 minutes
        except Exception as e:
            logging.error(f"Erreur dans le ping de maintien en vie: {e}")
            time.sleep(300)

# Démarrer le thread de ping
keep_alive_thread = threading.Thread(target=keep_alive_ping, daemon=True)
keep_alive_thread.start()

# Initialisation de la base de données au démarrage
initialize_database()

# Démarrer le bot au lancement de l'application
if not is_bot_running():
    logging.info("Le trader n'est pas en cours d'exécution, démarrage automatique...")
    start_bot_process()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)