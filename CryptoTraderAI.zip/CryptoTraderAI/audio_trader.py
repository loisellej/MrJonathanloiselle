import ccxt
import time
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "9/KUxib19lkk7FukHnbupTEBYHIFcKsKtGAEW3/krj89u0jC/fYhrwfD"
API_SECRET = "RKJ9m8mLgfDN07bMEvxubD6bY/avyqsQGe6Ev1APMBvBFCvBjXpKGyI5rmR1iJT8U5aVbuHJoY0OI9cprH9qSg=="

def trade_audio():
    """
    Trader AUDIO uniquement:
    - Vend 20% des AUDIO pour USD
    - Rachète des AUDIO quand le prix baisse
    """
    logger.info("=== TRADER AUDIO UNIQUEMENT ===")
    logger.info(f"Date et heure: {datetime.now().isoformat()}")
    
    try:
        # Initialiser l'exchange
        exchange = ccxt.kraken({
            'apiKey': API_KEY,
            'secret': API_SECRET,
            'enableRateLimit': True
        })
        
        # Charger les marchés
        markets = exchange.load_markets()
        logger.info(f"Marchés chargés: {len(markets)} paires disponibles")
        
        # Récupérer les balances
        balances = exchange.fetch_balance()
        
        # Afficher les balances non nulles
        logger.info("Balances actuelles:")
        for asset, balance in balances['total'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Vérifier le solde AUDIO
        audio_balance = float(balances['total'].get('AUDIO', 0))
        
        if audio_balance < 10:
            logger.error(f"Solde AUDIO insuffisant: {audio_balance}")
            return False
        
        # Obtenir le prix actuel d'AUDIO
        symbol = "AUDIO/USD"
        ticker = exchange.fetch_ticker(symbol)
        current_price = ticker['last']
        logger.info(f"Prix actuel d'AUDIO: {current_price} USD")
        
        # Calculer le montant à vendre (20% de l'AUDIO disponible)
        amount_to_sell = audio_balance * 0.20
        logger.info(f"Vente de {amount_to_sell} AUDIO (20% du solde total)")
        
        # Vérifier le minimum requis
        market_info = markets[symbol]
        min_amount = market_info.get('limits', {}).get('amount', {}).get('min', 1)
        logger.info(f"Montant minimum pour {symbol}: {min_amount}")
        
        # S'assurer que le montant à vendre est supérieur au minimum
        if amount_to_sell < min_amount:
            amount_to_sell = min_amount * 1.1  # 10% au-dessus du minimum
            logger.info(f"Montant ajusté à {amount_to_sell} pour respecter le minimum")
        
        # Vendre AUDIO pour USD
        try:
            logger.info(f"Vente de {amount_to_sell} AUDIO à {current_price} USD")
            sell_order = exchange.create_market_sell_order(symbol, amount_to_sell)
            logger.info(f"Vente effectuée: {sell_order}")
            
            # Calculer le prix de rachat cible (2% plus bas)
            buy_back_price = current_price * 0.98
            logger.info(f"Prix de rachat cible fixé à {buy_back_price} USD (-2%)")
            
            # Attendre que la vente soit finalisée
            logger.info("Attente de la finalisation de la vente...")
            time.sleep(5)
            
            # Récupérer les nouvelles balances
            new_balances = exchange.fetch_balance()
            usd_balance = float(new_balances['free'].get('USD', 0))
            logger.info(f"Solde USD disponible après vente: {usd_balance}")
            
            # Surveiller le prix pour racheter
            logger.info("Surveillance du prix AUDIO pour rachat...")
            
            # Placer un ordre limite de rachat 
            buy_amount = (usd_balance * 0.95) / buy_back_price
            
            # Arrondir à 2 décimales
            buy_amount = float('{:.2f}'.format(buy_amount))
            
            logger.info(f"Placement d'un ordre limite d'achat de {buy_amount} AUDIO à {buy_back_price} USD")
            buy_order = exchange.create_limit_buy_order(symbol, buy_amount, buy_back_price)
            logger.info(f"Ordre d'achat placé: {buy_order}")
            
            # Enregistrer les détails pour référence future
            with open('audio_trades.log', 'a') as f:
                f.write(f"[{datetime.now().isoformat()}] Vendu {amount_to_sell} AUDIO à {current_price} USD\n")
                f.write(f"[{datetime.now().isoformat()}] Ordre d'achat placé: {buy_amount} AUDIO à {buy_back_price} USD\n")
                f.write("-" * 50 + "\n")
            
            logger.info("✅ TRADING AUDIO RÉUSSI!")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors du trading AUDIO: {e}")
            return False
        
    except Exception as e:
        logger.error(f"❌ Erreur critique: {e}")
        return False

if __name__ == "__main__":
    if trade_audio():
        print("\n✅ TRADING AUDIO TERMINÉ AVEC SUCCÈS!")
    else:
        print("\n⚠️ Le trading AUDIO n'a pas pu être complété")