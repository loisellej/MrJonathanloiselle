#!/usr/bin/env python3
"""
LANCEUR DIRECT DU DAY TRADER ULTRA-PERFORMANT
- Connexion directe à Kraken
- Trading automatique sur cryptos ultra-volatiles
- Aucune confirmation nécessaire - LANCE LE TRADING IMMÉDIATEMENT
"""
import os
import sys
import time
import logging
import ccxt
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("trading.log")
    ]
)
logger = logging.getLogger(__name__)

# Configuration du trader
RISK_PER_TRADE = 0.95  # 95% du capital disponible
MAX_POSITIONS = 5
STOP_LOSS_PCT = 0.05  # 5%
PROFIT_TARGET_PCT = 0.10  # 10%

class SimpleTrader:
    """Trader simplifié avec connexion directe à Kraken"""
    
    def __init__(self):
        """Initialise le trader avec les clés API de l'environnement"""
        # Récupérer les clés API
        self.api_key = os.environ.get("KRAKEN_API_KEY")
        self.api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        if not self.api_key or not self.api_secret:
            logger.error("Clés API non trouvées dans les variables d'environnement")
            raise ValueError("Clés API manquantes")
        
        # Initialiser la connexion à Kraken
        self.exchange = ccxt.kraken({
            'apiKey': self.api_key,
            'secret': self.api_secret,
            'enableRateLimit': True
        })
        
        # Vérifier la connexion
        try:
            self.exchange.load_markets()
            self.markets = self.exchange.markets
            logger.info("Connexion à Kraken établie avec succès")
        except Exception as e:
            logger.error(f"Échec de la connexion à Kraken: {e}")
            raise
        
        # Statut du trader
        self.running = False
        self.positions = {}
        self.price_cache = {}
    
    def get_balance(self):
        """Récupère les soldes du compte"""
        try:
            balance = self.exchange.fetch_balance()
            result = {}
            
            # Extraire les balances significatives
            for currency, value in balance['total'].items():
                if value > 0:
                    result[currency] = value
            
            return result
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des soldes: {e}")
            return {}
    
    def get_ticker_price(self, symbol):
        """Récupère le prix actuel d'un symbole"""
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            return ticker['last']
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {symbol}: {e}")
            return None
    
    def calculate_asset_values(self):
        """Calcule la valeur en USD de chaque actif"""
        balances = self.get_balance()
        values = {}
        total_usd = 0
        
        for currency, amount in balances.items():
            if currency in ['USD', 'USDT']:
                value = amount
            else:
                symbol = f"{currency}/USD"
                try:
                    price = self.get_ticker_price(symbol)
                    if not price:
                        symbol = f"{currency}/USDT"
                        price = self.get_ticker_price(symbol)
                    
                    value = amount * (price or 0)
                except:
                    value = 0
            
            values[currency] = value
            total_usd += value
        
        return values, total_usd
    
    def find_volatile_assets(self, max_assets=5):
        """Trouve les actifs les plus volatils"""
        try:
            # Récupérer tous les symboles disponibles
            symbols = [s for s in self.markets.keys() if '/USD' in s or '/USDT' in s]
            
            # Filtrer les symboles exclus (BTC, ETH, SOL)
            excluded = ['BTC', 'ETH', 'SOL']
            symbols = [s for s in symbols if not any(e in s.split('/')[0] for e in excluded)]
            
            # Limiter le nombre de symboles à analyser pour des raisons de performance
            if len(symbols) > 100:
                symbols = symbols[:100]
            
            # Analyser la volatilité de chaque symbole
            volatility_data = []
            
            for symbol in symbols:
                try:
                    # Récupérer les données OHLCV
                    ohlcv = self.exchange.fetch_ohlcv(symbol, '1h', limit=24)
                    
                    if len(ohlcv) < 12:
                        continue
                    
                    # Calculer la volatilité (écart-type des variations de prix)
                    closes = [candle[4] for candle in ohlcv]
                    changes = [abs((closes[i] - closes[i-1]) / closes[i-1]) for i in range(1, len(closes))]
                    volatility = sum(changes) / len(changes)
                    
                    # Calculer le momentum (tendance récente)
                    recent_changes = [((closes[i] - closes[i-1]) / closes[i-1]) for i in range(-6, 0)]
                    momentum = sum(recent_changes)
                    
                    # Ne garder que les actifs avec un momentum positif
                    if momentum <= 0:
                        continue
                    
                    # Combiner la volatilité et le momentum pour un score global
                    score = volatility * (1 + momentum)
                    
                    asset = symbol.split('/')[0]
                    volatility_data.append((asset, score, symbol))
                    
                    logger.info(f"Actif {asset}: volatilité {volatility:.4f}, momentum {momentum:.4f}, score {score:.4f}")
                
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse de {symbol}: {e}")
                    continue
            
            # Trier par score et prendre les X actifs les plus volatils
            volatility_data.sort(key=lambda x: x[1], reverse=True)
            return volatility_data[:max_assets]
        
        except Exception as e:
            logger.error(f"Erreur lors de la recherche d'actifs volatils: {e}")
            return []
    
    def place_buy_order(self, symbol, amount):
        """Place un ordre d'achat"""
        try:
            logger.info(f"Placement d'un ordre d'achat pour {amount} {symbol}")
            order = self.exchange.create_market_buy_order(symbol, amount)
            
            # Extraire les informations de l'ordre
            price = float(order['price'] or self.get_ticker_price(symbol))
            amount = float(order['amount'])
            
            # Calculer le stop loss et le profit target
            stop_loss = price * (1 - STOP_LOSS_PCT)
            profit_target = price * (1 + PROFIT_TARGET_PCT)
            
            # Ajouter à la liste des positions
            asset = symbol.split('/')[0]
            self.positions[asset] = {
                'symbol': symbol,
                'entry_price': price,
                'amount': amount,
                'stop_loss': stop_loss,
                'profit_target': profit_target,
                'entry_time': datetime.now()
            }
            
            logger.info(f"Achat réussi: {amount} {asset} à ${price}")
            logger.info(f"Stop loss: ${stop_loss}, Profit target: ${profit_target}")
            
            return order
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre d'achat pour {symbol}: {e}")
            return None
    
    def place_sell_order(self, symbol, amount, reason="manuel"):
        """Place un ordre de vente"""
        try:
            logger.info(f"Placement d'un ordre de vente pour {amount} {symbol} (raison: {reason})")
            order = self.exchange.create_market_sell_order(symbol, amount)
            
            # Extraire les informations de l'ordre
            price = float(order['price'] or self.get_ticker_price(symbol))
            amount = float(order['amount'])
            
            # Calculer le profit/perte
            asset = symbol.split('/')[0]
            if asset in self.positions:
                entry_price = self.positions[asset]['entry_price']
                profit_pct = ((price / entry_price) - 1) * 100
                
                logger.info(f"Vente réussie: {amount} {asset} à ${price} (P&L: {profit_pct:+.2f}%)")
                
                # Supprimer de la liste des positions
                del self.positions[asset]
            else:
                logger.info(f"Vente réussie: {amount} {asset} à ${price}")
            
            return order
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre de vente pour {symbol}: {e}")
            return None
    
    def check_positions(self):
        """Vérifie les positions ouvertes et applique les stop loss / profit targets"""
        for asset, position in list(self.positions.items()):
            try:
                symbol = position['symbol']
                current_price = self.get_ticker_price(symbol)
                
                if not current_price:
                    logger.warning(f"Impossible de récupérer le prix actuel pour {symbol}")
                    continue
                
                entry_price = position['entry_price']
                stop_loss = position['stop_loss']
                profit_target = position['profit_target']
                amount = position['amount']
                
                # Calculer le profit actuel
                profit_pct = ((current_price / entry_price) - 1) * 100
                logger.info(f"Position {asset}: ${current_price:.4f} (P&L: {profit_pct:+.2f}%)")
                
                # Vérifier si le stop loss est atteint
                if current_price <= stop_loss:
                    logger.warning(f"Stop loss atteint pour {asset}: ${current_price:.4f} <= ${stop_loss:.4f}")
                    self.place_sell_order(symbol, amount, "stop-loss")
                    continue
                
                # Vérifier si le profit target est atteint
                if current_price >= profit_target:
                    logger.info(f"Profit target atteint pour {asset}: ${current_price:.4f} >= ${profit_target:.4f}")
                    self.place_sell_order(symbol, amount, "profit")
                    continue
                
                # Vérifier le timeout (24h maximum)
                entry_time = position['entry_time']
                elapsed_hours = (datetime.now() - entry_time).total_seconds() / 3600
                
                if elapsed_hours >= 24:
                    logger.info(f"Timeout atteint pour {asset}: {elapsed_hours:.1f}h")
                    self.place_sell_order(symbol, amount, "timeout")
            
            except Exception as e:
                logger.error(f"Erreur lors de la vérification de la position {asset}: {e}")
    
    def buy_volatile_assets(self):
        """Recherche et achète les actifs les plus volatils"""
        # Vérifier si on a atteint le nombre max de positions
        if len(self.positions) >= MAX_POSITIONS:
            logger.info(f"Nombre maximum de positions atteint ({MAX_POSITIONS})")
            return
        
        # Récupérer les soldes
        balances = self.get_balance()
        
        # Calculer le solde USD disponible
        usd_balance = balances.get('USD', 0) + balances.get('USDT', 0)
        
        if usd_balance < 10:  # Minimum 10 USD
            logger.info(f"Solde USD insuffisant: ${usd_balance:.2f}")
            return
        
        # Trouver les actifs les plus volatils
        volatile_assets = self.find_volatile_assets()
        
        if not volatile_assets:
            logger.warning("Aucun actif volatile trouvé")
            return
        
        logger.info(f"Actifs les plus volatils: {volatile_assets}")
        
        # Positions disponibles
        positions_available = MAX_POSITIONS - len(self.positions)
        
        # Limiter aux N premières
        volatile_assets = volatile_assets[:positions_available]
        
        # Répartir le capital disponible
        usd_per_asset = usd_balance * RISK_PER_TRADE / len(volatile_assets)
        
        # Acheter chaque actif
        for asset, score, symbol in volatile_assets:
            # Vérifier si on a déjà une position sur cet actif
            if asset in self.positions:
                continue
            
            # Récupérer le prix actuel
            price = self.get_ticker_price(symbol)
            
            if not price:
                logger.warning(f"Impossible de récupérer le prix pour {symbol}")
                continue
            
            # Calculer la quantité
            amount = usd_per_asset / price
            
            # Placer l'ordre
            logger.info(f"Achat de {asset} pour ${usd_per_asset:.2f} (score: {score:.4f})")
            self.place_buy_order(symbol, amount)
    
    def convert_all_to_volatile(self):
        """Convertit tous les actifs non-USD en actifs volatils"""
        # Récupérer les balances
        balances = self.get_balance()
        
        # Calculer la valeur de chaque actif
        values, total_usd = self.calculate_asset_values()
        
        # Vendre tous les actifs non-USD et non-USDT
        for asset, amount in list(balances.items()):
            if asset not in ['USD', 'USDT'] and amount > 0:
                try:
                    # Vérifier si la valeur est significative
                    if values.get(asset, 0) < 10:  # Minimum 10 USD
                        logger.info(f"Solde {asset} trop petit pour être vendu: {amount}")
                        continue
                    
                    symbol = f"{asset}/USD"
                    
                    # Placer l'ordre de vente
                    logger.info(f"Conversion de {amount} {asset} en USD")
                    self.place_sell_order(symbol, amount, "conversion")
                except Exception as e:
                    logger.error(f"Erreur lors de la conversion de {asset}: {e}")
        
        # Attendre que les ordres soient exécutés
        time.sleep(5)
        
        # Acheter les actifs volatils
        self.buy_volatile_assets()
        
        return True
    
    def run(self):
        """Lance le trader"""
        self.running = True
        logger.info("Trader démarré")
        
        try:
            # Récupérer les balances
            values, total_usd = self.calculate_asset_values()
            
            # Afficher les soldes initiaux
            logger.info(f"Solde total: ${total_usd:.2f}")
            for asset, value in values.items():
                logger.info(f"  {asset}: ${value:.2f}")
            
            # Boucle principale
            while self.running:
                # Vérifier les positions existantes
                self.check_positions()
                
                # Chercher de nouvelles opportunités
                if len(self.positions) < MAX_POSITIONS:
                    self.buy_volatile_assets()
                
                # Pause
                time.sleep(60)
        
        except KeyboardInterrupt:
            logger.info("Arrêt demandé par l'utilisateur")
            self.running = False
        
        except Exception as e:
            logger.error(f"Erreur dans la boucle principale: {e}")
            self.running = False
        
        return True

def main():
    """Fonction principale"""
    print("==== DÉMARRAGE DU TRADER CRYPTO ULTRA-PERFORMANT ====")
    print("ATTENTION: Ce script va effectuer des trades réels avec vos fonds!")
    print("Cibles: Cryptos ultra-volatiles en uptrend")
    print("Objectif: 20-50% de gains mensuels")
    print("==================================================")
    
    try:
        # Créer et démarrer le trader
        trader = SimpleTrader()
        
        # Afficher les soldes
        values, total_usd = trader.calculate_asset_values()
        print(f"\nSolde total: ${total_usd:.2f}")
        for asset, value in values.items():
            print(f"  {asset}: ${value:.2f}")
        
        print("\n==== DÉMARRAGE DU TRADING AUTOMATIQUE ====")
        trader.run()
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors du démarrage du trader: {e}")
        print(f"ERREUR: {e}")
        return False

if __name__ == "__main__":
    main()