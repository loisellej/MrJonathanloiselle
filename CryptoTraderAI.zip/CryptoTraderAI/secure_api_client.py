import os
import logging
import requests
import time
import hmac
import hashlib
import base64
import urllib.parse
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SecureAPIClient:
    """
    Client API sécurisé pour les échanges de cryptomonnaies
    Prend en charge l'authentification API et la gestion des erreurs
    """
    
    def __init__(self, api_key=None, api_secret=None, exchange="kraken"):
        """Initialise le client API sécurisé"""
        self.api_key = api_key or os.environ.get("KRAKEN_API_KEY")
        self.api_secret = api_secret or os.environ.get("KRAKEN_API_SECRET")
        self.exchange = exchange.lower()
        
        if self.exchange == "kraken":
            self.api_url = "https://api.kraken.com"
            self.api_version = "0"
        else:
            raise ValueError(f"Exchange {exchange} non pris en charge")
        
        # Vérification des clés API
        if not self.api_key or not self.api_secret:
            logger.warning("Clés API non configurées. Les requêtes privées échoueront.")
    
    def _get_kraken_signature(self, urlpath, data, nonce):
        """Générer une signature API Kraken"""
        if not self.api_secret:
            return None
            
        postdata = urllib.parse.urlencode(data)
        encoded = (str(nonce) + postdata).encode()
        message = urlpath.encode() + hashlib.sha256(encoded).digest()
        
        signature = hmac.new(base64.b64decode(self.api_secret), message, hashlib.sha512)
        sigdigest = base64.b64encode(signature.digest())
        
        return sigdigest.decode()
    
    def _make_request(self, method, endpoint, data=None, private=False, retry_count=3, retry_delay=2):
        """Effectue une requête API sécurisée avec gestion des erreurs et retry exponentiel"""
        url = f"{self.api_url}{endpoint}"
        headers = {}
        params = {}
        
        if private:
            if not self.api_key or not self.api_secret:
                logger.error("Clés API non configurées. Impossible d'effectuer une requête privée.")
                return None
            
            # Préparation des données pour requête privée
            if self.exchange == "kraken":
                nonce = str(int(time.time() * 1000))
                data = data or {}
                data["nonce"] = nonce
                
                headers = {
                    "API-Key": self.api_key,
                    "API-Sign": self._get_kraken_signature(endpoint, data, nonce)
                }
        
        # Exécution de la requête avec retry exponentiel
        for attempt in range(retry_count):
            try:
                if method.lower() == "get":
                    response = requests.get(url, headers=headers, params=params or data, timeout=10)
                else:  # POST par défaut
                    response = requests.post(url, headers=headers, data=data, timeout=10)
                
                response.raise_for_status()
                result = response.json()
                
                # Vérification des erreurs spécifiques à Kraken
                if self.exchange == "kraken" and result.get("error") and len(result["error"]) > 0:
                    error_msg = ", ".join(result["error"])
                    logger.error(f"Erreur API Kraken: {error_msg}")
                    
                    # Si c'est une erreur temporaire, on réessaie
                    if any(temp_err in error_msg.lower() for temp_err in ["temporary", "timeout", "busy", "rate limit"]):
                        retry_delay_current = retry_delay * (2 ** attempt)
                        logger.warning(f"Erreur temporaire, nouvelle tentative dans {retry_delay_current}s...")
                        time.sleep(retry_delay_current)
                        continue
                    
                    return {"success": False, "error": error_msg}
                    
                return result
                
            except requests.exceptions.RequestException as e:
                logger.error(f"Erreur de requête API ({attempt+1}/{retry_count}): {e}")
                
                # Backoff exponentiel
                if attempt < retry_count - 1:
                    retry_delay_current = retry_delay * (2 ** attempt)
                    logger.warning(f"Nouvelle tentative dans {retry_delay_current}s...")
                    time.sleep(retry_delay_current)
                else:
                    return {"success": False, "error": f"Erreur de requête après {retry_count} tentatives: {e}"}
        
        return {"success": False, "error": "Nombre maximum de tentatives atteint"}
    
    def get_balances(self):
        """Récupère les soldes de tous les actifs"""
        if self.exchange == "kraken":
            endpoint = f"/{self.api_version}/private/Balance"
            response = self._make_request("post", endpoint, data={}, private=True)
            
            if response and "result" in response:
                # Formater les soldes
                balances = {}
                for asset, amount in response["result"].items():
                    # Kraken utilise des préfixes comme X ou Z pour certains actifs
                    clean_asset = asset[1:] if asset.startswith("X") or asset.startswith("Z") else asset
                    # Convertir en float
                    balances[clean_asset] = float(amount)
                return balances
                
            return {}
        
        return {"success": False, "error": f"Exchange {self.exchange} non pris en charge"}
    
    def place_order(self, symbol, side, amount, price=None, order_type="market"):
        """
        Place un ordre sur l'exchange
        
        Args:
            symbol (str): Paire de trading (format: BTC/USD)
            side (str): 'buy' ou 'sell'
            amount (float): Quantité à acheter/vendre
            price (float, optional): Prix (requis pour les ordres limit)
            order_type (str): 'market' ou 'limit'
            
        Returns:
            dict: Résultat de l'ordre
        """
        if self.exchange == "kraken":
            endpoint = f"/{self.api_version}/private/AddOrder"
            
            # Formater le symbole pour Kraken (BTC/USD -> XBTUSD)
            kraken_symbol = symbol.replace("/", "")
            
            data = {
                "pair": kraken_symbol,
                "type": side,
                "ordertype": order_type,
                "volume": str(amount)
            }
            
            if order_type == "limit" and price:
                data["price"] = str(price)
            
            response = self._make_request("post", endpoint, data=data, private=True)
            
            if response and "result" in response:
                return {
                    "success": True,
                    "order_id": response["result"].get("txid", [])[0] if response["result"].get("txid") else None,
                    "info": response["result"]
                }
            
            return {"success": False, "error": response.get("error", "Erreur inconnue")}
        
        return {"success": False, "error": f"Exchange {self.exchange} non pris en charge"}
    
    def cancel_order(self, order_id):
        """Annule un ordre par son ID"""
        if self.exchange == "kraken":
            endpoint = f"/{self.api_version}/private/CancelOrder"
            data = {"txid": order_id}
            
            response = self._make_request("post", endpoint, data=data, private=True)
            
            if response and "result" in response:
                return {"success": True, "info": response["result"]}
            
            return {"success": False, "error": response.get("error", "Erreur inconnue")}
        
        return {"success": False, "error": f"Exchange {self.exchange} non pris en charge"}
    
    def get_ticker(self, symbol):
        """Récupère les informations de ticker pour un symbole"""
        if self.exchange == "kraken":
            endpoint = f"/{self.api_version}/public/Ticker"
            data = {"pair": symbol.replace("/", "")}
            
            response = self._make_request("get", endpoint, data=data, private=False)
            
            if response and "result" in response:
                # Récupérer le résultat pour la première (et normalement unique) paire
                pair_data = next(iter(response["result"].values())) if response["result"] else None
                
                if pair_data:
                    return {
                        "success": True,
                        "last": float(pair_data["c"][0]),  # Prix de la dernière transaction
                        "bid": float(pair_data["b"][0]),   # Meilleur prix d'achat
                        "ask": float(pair_data["a"][0]),   # Meilleur prix de vente
                        "volume": float(pair_data["v"][1])  # Volume sur 24h
                    }
            
            return {"success": False, "error": response.get("error", "Erreur inconnue")}
        
        return {"success": False, "error": f"Exchange {self.exchange} non pris en charge"}
    
    def get_ohlcv(self, symbol, timeframe="1h", limit=100):
        """Récupère les données OHLCV (Open, High, Low, Close, Volume)"""
        if self.exchange == "kraken":
            # Mapping des timeframes vers les valeurs Kraken
            timeframe_map = {
                "1m": 1, "5m": 5, "15m": 15, "30m": 30,
                "1h": 60, "4h": 240, "1d": 1440, "1w": 10080
            }
            
            interval = timeframe_map.get(timeframe, 60)  # Par défaut 1h
            endpoint = f"/{self.api_version}/public/OHLC"
            data = {
                "pair": symbol.replace("/", ""),
                "interval": interval
            }
            
            response = self._make_request("get", endpoint, data=data, private=False)
            
            if response and "result" in response:
                # Extraire les données OHLCV (ignorer la clé "last")
                pair_key = next((k for k in response["result"].keys() if k != "last"), None)
                if pair_key and pair_key in response["result"]:
                    ohlcv_data = response["result"][pair_key][-limit:]  # Prendre les dernières entrées
                    
                    # Formater les données selon le format standard
                    formatted_data = []
                    for candle in ohlcv_data:
                        formatted_data.append([
                            int(candle[0]) * 1000,  # Timestamp en millisecondes
                            float(candle[1]),       # Open
                            float(candle[2]),       # High
                            float(candle[3]),       # Low
                            float(candle[4]),       # Close
                            float(candle[6])        # Volume
                        ])
                    
                    return formatted_data
            
            return []
        
        return {"success": False, "error": f"Exchange {self.exchange} non pris en charge"}
    
    def test_connection(self):
        """Teste la connexion à l'API et les clés d'authentification"""
        if self.exchange == "kraken":
            # Test d'une requête publique
            endpoint_public = f"/{self.api_version}/public/Time"
            response_public = self._make_request("get", endpoint_public, private=False)
            
            if not response_public or "result" not in response_public:
                return {
                    "success": False,
                    "error": "Échec de la connexion API publique",
                    "public_api": False,
                    "private_api": False
                }
            
            # Test d'une requête privée (Balance)
            endpoint_private = f"/{self.api_version}/private/Balance"
            response_private = self._make_request("post", endpoint_private, data={}, private=True)
            
            return {
                "success": True,
                "public_api": True,
                "private_api": response_private and "result" in response_private,
                "time": datetime.utcnow().isoformat()
            }
        
        return {"success": False, "error": f"Exchange {self.exchange} non pris en charge"}

# Exemple d'utilisation:
if __name__ == "__main__":
    # Test du client API
    client = SecureAPIClient()
    
    # Tester la connexion
    connection_test = client.test_connection()
    print(f"Test de connexion: {connection_test}")
    
    # Si les clés API fonctionnent, récupérer les soldes
    if connection_test.get("private_api"):
        balances = client.get_balances()
        print(f"Soldes: {balances}")
    
    # Récupérer le ticker BTC/USD
    ticker = client.get_ticker("BTC/USD")
    print(f"Ticker BTC/USD: {ticker}")