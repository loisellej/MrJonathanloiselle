#!/bin/bash
# Configuration de crontab pour vérifier le bot toutes les 5 minutes

# Rendre les scripts exécutables
chmod +x keep_bot_alive.sh
chmod +x start_trader_permanent.sh
chmod +x auto_trader_verified.py

# Ajouter la tâche cron (vérification toutes les 5 minutes)
CRON_JOB="*/5 * * * * cd $(pwd) && bash keep_bot_alive.sh >> cron_log.txt 2>&1"
(crontab -l 2>/dev/null | grep -v "keep_bot_alive.sh"; echo "$CRON_JOB") | crontab -

echo "Crontab configuré avec succès pour maintenir le bot actif 24/7."
echo "Tâche planifiée: $CRON_JOB"