// Global variables
let priceCharts = {};
let sentimentChart = null;
let portfolioChart = null;
let priceData = {
    BTC: {
        labels: [],
        prices: []
    },
    ETH: {
        labels: [],
        prices: []
    }
};
let sentimentData = {
    labels: [],
    BTC: [],
    ETH: []
};
let balanceHistory = {
    labels: [],
    values: []
};

// Initialize the dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Set up event listeners
    setupEventListeners();
    
    // Initialize charts
    initializeCharts();
    
    // Start data polling
    startDataPolling();
});

// Set up event listeners for the dashboard
function setupEventListeners() {
    // Start bot button
    const startBotBtn = document.getElementById('start-bot');
    if (startBotBtn) {
        startBotBtn.addEventListener('click', startBot);
    }
    
    // Stop bot button
    const stopBotBtn = document.getElementById('stop-bot');
    if (stopBotBtn) {
        stopBotBtn.addEventListener('click', stopBot);
    }
    
    // Time period buttons for price charts
    const periodButtons = document.querySelectorAll('[data-period]');
    periodButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            periodButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            // Update charts based on selected period
            updateChartPeriod(this.dataset.period);
        });
    });
}

// Initialize all charts
function initializeCharts() {
    // BTC price chart
    const btcPriceCtx = document.getElementById('btc-price-chart').getContext('2d');
    priceCharts.BTC = new Chart(btcPriceCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'BTC Price (USDT)',
                data: [],
                borderColor: '#f2a900',
                backgroundColor: 'rgba(242, 169, 0, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: createPriceChartOptions()
    });
    
    // ETH price chart
    const ethPriceCtx = document.getElementById('eth-price-chart').getContext('2d');
    priceCharts.ETH = new Chart(ethPriceCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'ETH Price (USDT)',
                data: [],
                borderColor: '#627eea',
                backgroundColor: 'rgba(98, 126, 234, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: createPriceChartOptions()
    });
    
    // Sentiment chart
    const sentimentCtx = document.getElementById('sentiment-chart').getContext('2d');
    sentimentChart = new Chart(sentimentCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'BTC Sentiment',
                    data: [],
                    borderColor: '#f2a900',
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    tension: 0.4
                },
                {
                    label: 'ETH Sentiment',
                    data: [],
                    borderColor: '#627eea',
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    tension: 0.4
                }
            ]
        },
        options: {
            scales: {
                y: {
                    min: -1,
                    max: 1,
                    title: {
                        display: true,
                        text: 'Sentiment Score'
                    }
                }
            },
            plugins: {
                tooltip: {
                    mode: 'index',
                    intersect: false
                },
                legend: {
                    position: 'top'
                }
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
    
    // Portfolio chart
    const portfolioCtx = document.getElementById('portfolio-chart').getContext('2d');
    portfolioChart = new Chart(portfolioCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Portfolio Value (USDT)',
                data: [],
                borderColor: '#20c997',
                backgroundColor: 'rgba(32, 201, 151, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Value (USDT)'
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Value: $${context.parsed.y.toFixed(2)}`;
                        }
                    }
                },
                legend: {
                    display: false
                }
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// Create options for price charts
function createPriceChartOptions() {
    return {
        scales: {
            y: {
                beginAtZero: false,
                title: {
                    display: true,
                    text: 'Price (USDT)'
                }
            }
        },
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return `Price: $${context.parsed.y.toFixed(2)}`;
                    }
                }
            },
            legend: {
                display: false
            }
        },
        responsive: true,
        maintainAspectRatio: false
    };
}

// Start the trading bot
function startBot() {
    fetch('/api/start_bot', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById('start-bot').disabled = true;
            document.getElementById('stop-bot').disabled = false;
            updateBotStatus(true);
        } else {
            showAlert(data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error starting bot:', error);
        showAlert('Failed to start the bot', 'danger');
    });
}

// Stop the trading bot
function stopBot() {
    fetch('/api/stop_bot', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById('start-bot').disabled = false;
            document.getElementById('stop-bot').disabled = true;
            updateBotStatus(false);
        } else {
            showAlert(data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error stopping bot:', error);
        showAlert('Failed to stop the bot', 'danger');
    });
}

// Update the bot status indicator
function updateBotStatus(running) {
    const statusIndicator = document.getElementById('bot-status-indicator');
    if (running) {
        statusIndicator.textContent = 'Running';
        statusIndicator.className = 'badge bg-success';
    } else {
        statusIndicator.textContent = 'Stopped';
        statusIndicator.className = 'badge bg-danger';
    }
}

// Poll for updated data from the server
function startDataPolling() {
    // Poll immediately
    fetchData();
    
    // Then poll every 5 seconds
    setInterval(fetchData, 5000);
}

// Fetch data from the server
function fetchData() {
    fetch('/api/data')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data) {
                updateDashboard(data);
            } else {
                console.error('Received empty data from server');
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            // Show error status in the UI
            updateBotStatus(false);
            if (document.getElementById('status-message')) {
                document.getElementById('status-message').innerHTML = 
                    '<span class="badge bg-danger">Erreur de communication</span> Reconnexion...';
            }
        });
}

// Update the dashboard with new data
function updateDashboard(data) {
    // Update bot status
    updateBotStatus(data.bot_running);
    
    // Update button states
    if (document.getElementById('start-bot')) {
        document.getElementById('start-bot').disabled = data.bot_running;
    }
    if (document.getElementById('stop-bot')) {
        document.getElementById('stop-bot').disabled = !data.bot_running;
    }
    
    // Update balances
    document.getElementById('usdt-balance').textContent = formatNumber(data.asset_balances.USDT || 0, 2);
    document.getElementById('btc-balance').textContent = formatNumber(data.asset_balances.BTC || 0, 8);
    document.getElementById('eth-balance').textContent = formatNumber(data.asset_balances.ETH || 0, 8);
    
    // Update all assets table
    updateAllAssetsTable(data.asset_balances, data.asset_prices);
    
    // Update prices
    document.getElementById('btc-price').textContent = `$${formatNumber(data.asset_prices.BTC || 0, 2)}`;
    document.getElementById('eth-price').textContent = `$${formatNumber(data.asset_prices.ETH || 0, 2)}`;
    
    // Update stop losses
    document.getElementById('btc-stop-loss').textContent = `$${formatNumber(data.stop_losses.BTC || 0, 2)}`;
    document.getElementById('eth-stop-loss').textContent = `$${formatNumber(data.stop_losses.ETH || 0, 2)}`;
    
    // Update last updated timestamps
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    document.getElementById('btc-last-update').textContent = timeString;
    document.getElementById('eth-last-update').textContent = timeString;
    
    // Update sentiment indicators and gauges
    updateSentimentGauge('btc', data.sentiment_scores.BTC || 0);
    updateSentimentGauge('eth', data.sentiment_scores.ETH || 0);
    
    // Update charts
    updateCharts(data);
    
    // Update trade history
    updateTradeHistory(data.trade_history);
}

// Update all assets table
function updateAllAssetsTable(balances, prices) {
    const tableBody = document.getElementById('all-assets-table');
    
    if (!balances || Object.keys(balances).length === 0) {
        tableBody.innerHTML = '<tr><td colspan="3" class="text-center">Aucun actif disponible</td></tr>';
        return;
    }
    
    let html = '';
    let totalValue = 0;
    
    // Sort assets by value (if price available) or by name
    const assets = Object.keys(balances).sort((a, b) => {
        const valueA = balances[a] * (prices[a] || 0);
        const valueB = balances[b] * (prices[b] || 0);
        
        if (valueA === valueB) {
            return a.localeCompare(b);
        }
        return valueB - valueA; // Sort by value descending
    });
    
    assets.forEach(asset => {
        if (balances[asset] > 0) {
            const amount = balances[asset];
            let value = 0;
            
            if (asset === 'USDT') {
                value = amount;
            } else if (prices[asset]) {
                value = amount * prices[asset];
            } else {
                // Try to get price if asset/USDT exists in prices
                const normalizedAsset = asset.replace('X', '').replace('Z', '');
                if (prices[normalizedAsset]) {
                    value = amount * prices[normalizedAsset];
                }
            }
            
            totalValue += value;
            
            html += `
                <tr>
                    <td>${asset}</td>
                    <td>${formatNumber(amount, 8)}</td>
                    <td>${value > 0 ? '$' + formatNumber(value, 2) : '-'}</td>
                </tr>
            `;
        }
    });
    
    // Add total row
    html += `
        <tr class="table-active">
            <td><strong>Total</strong></td>
            <td></td>
            <td><strong>$${formatNumber(totalValue, 2)}</strong></td>
        </tr>
    `;
    
    tableBody.innerHTML = html;
}

// Update sentiment gauge display
function updateSentimentGauge(asset, score) {
    const valueElement = document.getElementById(`${asset}-sentiment-value`);
    const indicatorElement = document.getElementById(`${asset}-sentiment-indicator`);
    
    // Update the numeric value
    valueElement.textContent = score.toFixed(2);
    
    // Update the color of the value based on sentiment
    if (score > 0.1) {
        valueElement.className = 'sentiment-value positive';
    } else if (score < -0.1) {
        valueElement.className = 'sentiment-value negative';
    } else {
        valueElement.className = 'sentiment-value neutral';
    }
    
    // Update the indicator position and color
    // Normalize score from -1,1 to 0,100 for positioning
    const position = ((score + 1) / 2) * 100;
    indicatorElement.style.left = `${position}%`;
    
    // Set color based on sentiment
    if (score > 0.1) {
        indicatorElement.style.backgroundColor = '#20c997'; // Green for positive
    } else if (score < -0.1) {
        indicatorElement.style.backgroundColor = '#dc3545'; // Red for negative
    } else {
        indicatorElement.style.backgroundColor = '#6c757d'; // Gray for neutral
    }
}

// Update charts with new data
function updateCharts(data) {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    
    // Update price charts
    for (const asset of ['BTC', 'ETH']) {
        // Add new data point
        priceData[asset].labels.push(timeString);
        priceData[asset].prices.push(data.asset_prices[asset] || 0);
        
        // Limit to last 20 data points
        if (priceData[asset].labels.length > 20) {
            priceData[asset].labels.shift();
            priceData[asset].prices.shift();
        }
        
        // Update chart
        priceCharts[asset].data.labels = priceData[asset].labels;
        priceCharts[asset].data.datasets[0].data = priceData[asset].prices;
        priceCharts[asset].update();
    }
    
    // Update sentiment chart
    sentimentData.labels.push(timeString);
    sentimentData.BTC.push(data.sentiment_scores.BTC || 0);
    sentimentData.ETH.push(data.sentiment_scores.ETH || 0);
    
    // Limit to last 20 data points
    if (sentimentData.labels.length > 20) {
        sentimentData.labels.shift();
        sentimentData.BTC.shift();
        sentimentData.ETH.shift();
    }
    
    sentimentChart.data.labels = sentimentData.labels;
    sentimentChart.data.datasets[0].data = sentimentData.BTC;
    sentimentChart.data.datasets[1].data = sentimentData.ETH;
    sentimentChart.update();
    
    // Update portfolio chart - calculate total value in USDT
    const btcValue = (data.asset_balances.BTC || 0) * (data.asset_prices.BTC || 0);
    const ethValue = (data.asset_balances.ETH || 0) * (data.asset_prices.ETH || 0);
    const usdtValue = data.asset_balances.USDT || 0;
    const totalValue = btcValue + ethValue + usdtValue;
    
    balanceHistory.labels.push(timeString);
    balanceHistory.values.push(totalValue);
    
    // Limit to last 20 data points
    if (balanceHistory.labels.length > 20) {
        balanceHistory.labels.shift();
        balanceHistory.values.shift();
    }
    
    portfolioChart.data.labels = balanceHistory.labels;
    portfolioChart.data.datasets[0].data = balanceHistory.values;
    portfolioChart.update();
}

// Update trade history table
function updateTradeHistory(trades) {
    const tableBody = document.getElementById('trade-history');
    
    if (!trades || trades.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">No trading activity yet</td></tr>';
        return;
    }
    
    let html = '';
    
    trades.forEach(trade => {
        const sentimentClass = trade.sentiment > 0.1 ? 'text-success' : 
                                trade.sentiment < -0.1 ? 'text-danger' : 'text-muted';
        const actionClass = trade.action.includes('buy') ? 'text-success' : 'text-danger';
        
        html += `
            <tr>
                <td>${trade.timestamp}</td>
                <td>${trade.asset}</td>
                <td class="${actionClass}">${trade.action}</td>
                <td>${formatNumber(trade.amount, 8)}</td>
                <td>$${formatNumber(trade.price, 2)}</td>
                <td class="${sentimentClass}">${formatNumber(trade.sentiment, 2)}</td>
            </tr>
        `;
    });
    
    tableBody.innerHTML = html;
}

// Update chart period when time selector is changed
function updateChartPeriod(period) {
    // This would fetch historical data based on the period
    // For now, we'll just continue with the real-time data
    console.log(`Chart period changed to ${period}`);
}

// Format number with commas and specified decimal places
function formatNumber(number, decimals = 2) {
    return number.toLocaleString(undefined, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
}

// Show an alert message on the dashboard
function showAlert(message, type = 'info') {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    // Insert at the top of the container
    const container = document.querySelector('.container');
    container.insertAdjacentHTML('afterbegin', alertHtml);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = document.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}
