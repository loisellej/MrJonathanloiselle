// Chart.js utilities and configuration
Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
Chart.defaults.color = '#6c757d';
Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(33, 37, 41, 0.9)';
Chart.defaults.plugins.tooltip.titleColor = '#ffffff';
Chart.defaults.plugins.tooltip.bodyColor = '#ffffff';
Chart.defaults.plugins.tooltip.borderColor = 'rgba(255, 255, 255, 0.1)';
Chart.defaults.plugins.tooltip.borderWidth = 1;
Chart.defaults.plugins.tooltip.padding = 10;
Chart.defaults.plugins.tooltip.cornerRadius = 3;

// Create a smooth gradient for area charts
function createGradient(ctx, colorStart, colorEnd) {
    const gradient = ctx.createLinearGradient(0, 0, 0, 300);
    gradient.addColorStop(0, colorStart);
    gradient.addColorStop(1, colorEnd);
    return gradient;
}

// Format number with commas and specified decimal places
function formatPrice(value, decimals = 2) {
    return value.toLocaleString(undefined, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
}

// Calculate percent change between two values
function calculatePercentChange(oldValue, newValue) {
    if (oldValue === 0) return 0;
    return ((newValue - oldValue) / oldValue) * 100;
}

// Format percent change with + or - sign and color class
function formatPercentChange(percentChange) {
    const sign = percentChange >= 0 ? '+' : '';
    const colorClass = percentChange >= 0 ? 'text-success' : 'text-danger';
    return {
        text: `${sign}${percentChange.toFixed(2)}%`,
        class: colorClass
    };
}

// Create animated number counter
function animateValue(element, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const current = Math.floor(progress * (end - start) + start);
        element.textContent = formatPrice(current);
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// Update chart with smooth animation
function updateChartWithAnimation(chart, labels, data) {
    chart.data.labels = labels;
    chart.data.datasets[0].data = data;
    chart.update('normal');
}

// Create timestamp label for charts
function createTimeLabel() {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Generate random OHLC data for testing
function generateRandomOHLC(basePrice, volatility) {
    const change = basePrice * (volatility / 100) * (Math.random() - 0.5);
    const open = basePrice;
    const close = basePrice + change;
    const high = Math.max(open, close) + basePrice * (volatility / 200) * Math.random();
    const low = Math.min(open, close) - basePrice * (volatility / 200) * Math.random();
    
    return {
        open: open,
        high: high,
        low: low,
        close: close
    };
}
