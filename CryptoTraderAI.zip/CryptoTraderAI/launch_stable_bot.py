#!/usr/bin/env python3
"""
Script ultra-stable pour lancer le bot de trading sur Replit
Ce script est conçu pour redémarrer automatiquement en cas de crash
"""
import os
import time
import subprocess
import signal
import sys
import datetime
import logging

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("stable_bot.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Clés API Kraken
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

def write_api_keys_to_env():
    """Écrit les clés API dans les variables d'environnement"""
    os.environ['KRAKEN_API_KEY'] = API_KEY
    os.environ['KRAKEN_API_SECRET'] = API_SECRET

def create_heartbeat_file():
    """Crée un fichier heartbeat pour indiquer que le bot est en cours d'exécution"""
    with open("bot_heartbeat.txt", "w") as f:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"Bot actif: {timestamp}\n")

def is_process_running(pid):
    """Vérifie si un processus est en cours d'exécution"""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def start_trader_process():
    """Démarre le processus de trading et retourne son PID"""
    # Tuer les instances existantes
    try:
        subprocess.run(["pkill", "-f", "python.*start_24_7_trader.py"], 
                       stdout=subprocess.DEVNULL, 
                       stderr=subprocess.DEVNULL)
        time.sleep(2)
    except:
        pass
    
    # Démarrer le nouveau processus
    process = subprocess.Popen([
        "python3", "start_24_7_trader.py"
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Enregistrer le PID
    pid = process.pid
    with open("trader.pid", "w") as f:
        f.write(str(pid))
    
    logger.info(f"Bot de trading démarré avec PID: {pid}")
    return pid

def monitor_trader():
    """Surveille le trader et le redémarre si nécessaire"""
    max_restarts = 999999  # Nombre maximal de redémarrages
    restart_count = 0
    check_interval = 30  # Vérifier toutes les 30 secondes
    
    logger.info("""
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SYSTÈME DE SURVEILLANCE ULTRA-STABLE POUR LE BOT DE TRADING
- Redémarrage automatique en cas de crash
- Surveillance continue 24/7
- Prise en charge des clés API intégrées
- Compatible Replit (fonctionne même si l'app est fermée)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    """)
    
    # Écrire les clés API dans les variables d'environnement
    write_api_keys_to_env()
    
    # Démarrer le trader
    pid = start_trader_process()
    last_restart_time = time.time()
    
    try:
        while restart_count < max_restarts:
            # Créer un fichier heartbeat
            create_heartbeat_file()
            
            # Vérifier si le trader est en cours d'exécution
            if not is_process_running(pid):
                current_time = time.time()
                restart_delay = current_time - last_restart_time
                
                # Attendre au moins 5 secondes entre les redémarrages
                if restart_delay < 5:
                    time.sleep(5 - restart_delay)
                
                logger.warning(f"⚠️ Le trader n'est plus en cours d'exécution. Redémarrage ({restart_count + 1}/{max_restarts})...")
                pid = start_trader_process()
                last_restart_time = time.time()
                restart_count += 1
            
            # Attendre avant la prochaine vérification
            time.sleep(check_interval)
            
    except KeyboardInterrupt:
        logger.info("Arrêt manuel du système de surveillance")
    except Exception as e:
        logger.error(f"Erreur dans le système de surveillance: {e}")
        # Redémarrer en cas d'erreur critique
        os.execv(sys.executable, ['python3'] + sys.argv)

if __name__ == "__main__":
    # Handler pour redémarrer en cas de signal TERM
    def handle_term(signum, frame):
        logger.info("Signal TERM reçu, redémarrage du système de surveillance...")
        os.execv(sys.executable, ['python3'] + sys.argv)
    
    # Enregistrer le handler
    signal.signal(signal.SIGTERM, handle_term)
    
    # Démarrer la surveillance
    monitor_trader()