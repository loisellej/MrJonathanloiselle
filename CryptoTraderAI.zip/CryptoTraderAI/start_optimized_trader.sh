#!/bin/bash
# Script de démarrage du trader optimisé
# Ce script est conçu pour être exécuté directement sur Replit
# Il démarre le système complet avec toutes les optimisations

echo "=================================================="
echo "      DÉMARRAGE DU TRADER OPTIMISÉ - v2.0"
echo "=================================================="

# Fonction pour vérifier si un processus est en cours d'exécution
is_running() {
    if pgrep -f "$1" > /dev/null; then
        return 0  # Vrai
    else
        return 1  # Faux
    fi
}

# Fonction pour afficher un message en couleur
print_message() {
    local color=$1
    local message=$2
    
    case $color in
        "red")
            echo -e "\e[31m$message\e[0m"
            ;;
        "green")
            echo -e "\e[32m$message\e[0m"
            ;;
        "yellow")
            echo -e "\e[33m$message\e[0m"
            ;;
        "blue")
            echo -e "\e[34m$message\e[0m"
            ;;
        *)
            echo "$message"
            ;;
    esac
}

# Vérifier si le trader est déjà en cours d'exécution
if is_running "auto_trader_verified.py"; then
    print_message "yellow" "⚠️ Un trader est déjà en cours d'exécution"
    print_message "yellow" "⚠️ Voulez-vous l'arrêter et démarrer un nouveau trader ? (o/n)"
    read -r answer
    
    if [[ "$answer" == "o" || "$answer" == "O" || "$answer" == "oui" ]]; then
        print_message "blue" "🔄 Arrêt du trader existant..."
        pkill -f "auto_trader_verified.py"
        sleep 5
    else
        print_message "yellow" "⚠️ Utilisation du trader existant"
        exit 0
    fi
fi

# Vérifier si le système d'optimisation est déjà en cours d'exécution
if is_running "init_optimized_system.py"; then
    print_message "yellow" "⚠️ Le système d'optimisation est déjà en cours d'exécution"
    print_message "yellow" "⚠️ Voulez-vous l'arrêter et démarrer un nouveau système ? (o/n)"
    read -r answer
    
    if [[ "$answer" == "o" || "$answer" == "O" || "$answer" == "oui" ]]; then
        print_message "blue" "🔄 Arrêt du système existant..."
        pkill -f "init_optimized_system.py"
        sleep 5
    else
        print_message "yellow" "⚠️ Utilisation du système existant"
        exit 0
    fi
fi

# Vérifier les dépendances
print_message "blue" "🔍 Vérification des dépendances..."

# Vérifier si Python est installé
if ! command -v python3 &> /dev/null; then
    print_message "red" "❌ Python n'est pas installé"
    exit 1
fi

# Vérifier si psutil est installé
python3 -c "import psutil" 2>/dev/null
if [ $? -ne 0 ]; then
    print_message "yellow" "⚠️ psutil n'est pas installé, installation en cours..."
    pip install psutil
fi

# Vérifier si les fichiers nécessaires existent
if [ ! -f "auto_trader_verified.py" ]; then
    print_message "red" "❌ Le fichier auto_trader_verified.py n'existe pas"
    exit 1
fi

if [ ! -f "optimizations.py" ]; then
    print_message "red" "❌ Le fichier optimizations.py n'existe pas"
    exit 1
fi

if [ ! -f "init_optimized_system.py" ]; then
    print_message "red" "❌ Le fichier init_optimized_system.py n'existe pas"
    exit 1
fi

# Vérifier les variables d'environnement
if [ -z "$KRAKEN_API_KEY" ] || [ -z "$KRAKEN_API_SECRET" ]; then
    print_message "yellow" "⚠️ Les variables d'environnement KRAKEN_API_KEY et KRAKEN_API_SECRET ne sont pas définies"
    print_message "yellow" "⚠️ Vérification du fichier .env..."
    
    if [ -f ".env" ]; then
        print_message "green" "✅ Fichier .env trouvé, chargement des variables..."
        export $(grep -v '^#' .env | xargs)
    else
        print_message "red" "❌ Fichier .env non trouvé"
        print_message "yellow" "⚠️ Veuillez créer un fichier .env avec les variables KRAKEN_API_KEY et KRAKEN_API_SECRET"
        exit 1
    fi
fi

# Création des dossiers nécessaires
mkdir -p logs

# Nettoyer les anciens fichiers de PID
rm -f bot_pid.txt trader.pid auto_trader_pid.txt 2>/dev/null

# Démarrer le système optimisé
print_message "green" "🚀 Démarrage du système optimisé..."
nohup python3 init_optimized_system.py > logs/system_startup.log 2>&1 &

# Attendre le démarrage du système
sleep 5

# Vérifier si le système a démarré
if is_running "init_optimized_system.py"; then
    print_message "green" "✅ Système optimisé démarré avec succès"
    print_message "blue" "ℹ️ Logs disponibles dans logs/system_startup.log"
    print_message "blue" "ℹ️ Métriques disponibles dans system_metrics.json"
    print_message "blue" "ℹ️ Pour arrêter le système: pkill -f 'init_optimized_system.py'"
else
    print_message "red" "❌ Échec du démarrage du système"
    print_message "yellow" "⚠️ Consultez logs/system_startup.log pour plus d'informations"
    exit 1
fi

# Le trader est démarré automatiquement par le système
# Vérifier si le trader a démarré
sleep 5
if is_running "auto_trader_verified.py"; then
    print_message "green" "✅ Trader démarré avec succès"
    print_message "blue" "ℹ️ Logs disponibles dans auto_trader_verified.log"
else
    print_message "red" "❌ Échec du démarrage du trader"
    print_message "yellow" "⚠️ Consultez logs/system_startup.log pour plus d'informations"
    exit 1
fi

print_message "green" "=================================================="
print_message "green" "    SYSTÈME DE TRADING DÉMARRÉ AVEC SUCCÈS"
print_message "green" "    MODE: LIVE TRADING"
print_message "green" "    OPTIMISATIONS: ACTIVÉES"
print_message "green" "=================================================="

exit 0