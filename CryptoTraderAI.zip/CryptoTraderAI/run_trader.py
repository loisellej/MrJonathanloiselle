import os
import sys
import subprocess
import logging
import time
import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='launcher.log'
)
logger = logging.getLogger(__name__)

def setup_environment():
    """Configuration des variables d'environnement"""
    os.environ['KRAKEN_API_KEY'] = "IwYIUvR4AFc/VrQVCgLU4kxM00y2Omgr3XtbnR0zR6wlKy4t2RPpcexu"
    os.environ['KRAKEN_API_SECRET'] = "qMO6mqh5wgseTGIofBZoAXIYnxEZHF/FiAffgDWyNWMyULRIUPODhD9Jish7p2udgCESE2fy8mPXqGE/Pb2qeg=="
    os.environ['SESSION_SECRET'] = "crypto_trading_secret_key"
    
    logger.info("Variables d'environnement configurées avec succès")

def start_permanent_trader():
    """Démarrage du trader permanent"""
    logger.info("Démarrage du trader permanent...")
    
    # Lancer le trader permanent en processus séparé
    try:
        # Créer un fichier pour l'état du trader
        with open('trader_status.txt', 'w') as f:
            f.write(f"Démarré le {datetime.datetime.now().isoformat()}\n")
            f.write("Status: RUNNING\n")
        
        # Démarrer le trader permanent
        trader_process = subprocess.Popen(
            [sys.executable, 'permanent_trader.py'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        logger.info(f"Trader permanent démarré avec PID: {trader_process.pid}")
        
        return trader_process
    
    except Exception as e:
        logger.error(f"Erreur lors du démarrage du trader permanent: {e}")
        return None

if __name__ == '__main__':
    """Point d'entrée principal"""
    logger.info("==== DÉMARRAGE DU SYSTÈME DE TRADING ====")
    
    # Configuration des variables d'environnement
    setup_environment()
    
    # Démarrage du trader permanent
    trader_process = start_permanent_trader()
    
    if trader_process:
        logger.info("Système de trading démarré avec succès")
        
        # Afficher les informations
        print("==== SYSTÈME DE TRADING DÉMARRÉ ====")
        print(f"Trader permanent démarré avec PID: {trader_process.pid}")
        print("Le trader fonctionne maintenant 24/7 en arrière-plan")
        print("Pour accéder au tableau de bord, ouvrez l'interface web")
        
        # Maintenir le script en vie pendant 10 secondes pour voir les logs
        for i in range(10):
            print(f"Fermeture dans {10-i} secondes...", end="\r")
            time.sleep(1)
        
        print("\nLe trader continue de fonctionner en arrière-plan")
    
    else:
        logger.error("Échec du démarrage du système de trading")
        print("==== ÉCHEC DU DÉMARRAGE DU SYSTÈME DE TRADING ====")
        print("Consultez les logs pour plus d'informations (launcher.log)")
        sys.exit(1)