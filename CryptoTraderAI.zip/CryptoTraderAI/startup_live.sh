#!/bin/bash
# Script de démarrage du bot de trading en mode LIVE uniquement

echo "🚀 Démarrage du trader en mode LIVE uniquement (pas de simulation)"

# Arrêter tous les processus de trading existants
pkill -f "python.*start_24_7_trader.py"
pkill -f "python.*live_trader.py"
sleep 1

# Exporter les variables d'environnement depuis .env
export $(grep -v '^#' .env | xargs)

# Afficher les clés API (partiellement masquées)
if [ -n "$KRAKEN_API_KEY" ]; then
    echo "✅ Clé API trouvée: ${KRAKEN_API_KEY:0:5}...${KRAKEN_API_KEY: -5}"
else
    echo "❌ ERREUR: KRAKEN_API_KEY non définie dans .env"
    exit 1
fi

if [ -n "$KRAKEN_API_SECRET" ]; then
    echo "✅ Clé secrète trouvée: ${KRAKEN_API_SECRET:0:5}...${KRAKEN_API_SECRET: -5}"
else
    echo "❌ ERREUR: KRAKEN_API_SECRET non définie dans .env"
    exit 1
fi

# Démarrer le trader en mode live
echo "⚡ Démarrage du trader en arrière-plan..."
nohup python3 live_trader.py > live_trader.log 2>&1 &
echo $! > trader.pid

echo "✅ Trader démarré avec succès (PID: $(cat trader.pid))"
echo "   Les logs sont disponibles dans live_trader.log"
echo "   Ne fermez pas cette fenêtre pour maintenir le trader actif"

# Boucle de vérification pour assurer que le trader reste actif
echo "🔄 Surveillance du trader démarrée..."
while true; do
    if ! ps -p $(cat trader.pid 2>/dev/null) > /dev/null; then
        echo "⚠️ Trader arrêté, redémarrage..."
        nohup python3 live_trader.py > live_trader.log 2>&1 &
        echo $! > trader.pid
        echo "✅ Trader redémarré (PID: $(cat trader.pid))"
    else
        echo "👍 Trader en cours d'exécution ($(date))"
    fi
    
    # Vérifier le heartbeat
    if [ -f bot_heartbeat.txt ]; then
        heartbeat_age=$(($(date +%s) - $(date -r bot_heartbeat.txt +%s)))
        if [ $heartbeat_age -gt 60 ]; then
            echo "⚠️ Heartbeat trop ancien ($heartbeat_age secondes), redémarrage..."
            kill $(cat trader.pid)
            sleep 2
            nohup python3 live_trader.py > live_trader.log 2>&1 &
            echo $! > trader.pid
            echo "✅ Trader redémarré après heartbeat manqué (PID: $(cat trader.pid))"
        fi
    fi
    
    # Attendre 30 secondes avant la prochaine vérification
    sleep 30
done