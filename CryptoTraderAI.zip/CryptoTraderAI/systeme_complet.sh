#!/bin/bash

# Script de démarrage complet du système de trading
# Ce script assure le démarrage de tous les composants nécessaires

echo "===== DÉMARRAGE DU SYSTÈME DE TRADING COMPLET ====="
echo "Date: $(date)"
echo "====================================================="

# Vérifier si un composant est déjà en cours d'exécution
is_running() {
    pgrep -f "$1" > /dev/null
}

# Tuer tous les processus existants
kill_processes() {
    echo "Arrêt des processus existants..."
    pkill -f "auto_trader_verified.py" || true
    pkill -f "bot_final.py" || true 
    pkill -f "bot_logic.py" || true
    pkill -f "trading_guardian.py" || true
    pkill -f "start_trader_permanent.sh" || true
    pkill -f "keep_bot_alive.sh" || true
    sleep 2
    echo "Processus arrêtés"
}

# Démarrer le superviseur principal
start_supervisor() {
    echo "Démarrage du superviseur principal..."
    nohup python3 bot_final.py > bot_final_output.log 2>&1 &
    echo "Superviseur démarré avec PID: $!"
    sleep 5
}

# Démarrer le trader autonome avec auto-redémarrage
start_trader() {
    echo "Démarrage du trader autonome..."
    nohup bash start_trader_permanent.sh > trader_permanent.log 2>&1 &
    echo "Trader démarré avec PID: $!"
    sleep 5
}

# Démarrer le serveur web principal
start_webserver() {
    echo "Démarrage du serveur web principal..."
    # Vérifier si le serveur est déjà en cours d'exécution
    if ! is_running "gunicorn.*main:app"; then
        # Redémarrer le workflow
        echo "Redémarrage du workflow 'Start application'..."
        nohup gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app > webserver.log 2>&1 &
        echo "Serveur web démarré"
    else
        echo "Serveur web déjà en cours d'exécution"
    fi
}

# Configuration des permissions
setup_permissions() {
    echo "Configuration des permissions..."
    chmod +x auto_trader_verified.py
    chmod +x bot_final.py
    chmod +x bot_logic.py
    chmod +x execute_real_trade.py
    chmod +x keep_bot_alive.sh
    chmod +x start_trader_permanent.sh
    echo "Permissions configurées"
}

# Exécution
main() {
    # Arrêter tous les processus existants
    kill_processes
    
    # Configurer les permissions
    setup_permissions
    
    # Démarrer les composants
    start_supervisor
    start_trader
    start_webserver
    
    echo "===== SYSTÈME DE TRADING DÉMARRÉ AVEC SUCCÈS ====="
    echo "Pour voir les logs:"
    echo "- Superviseur: tail -f bot_final_output.log"
    echo "- Trader: tail -f auto_trader_output.log"
    echo "- Serveur web: tail -f webserver.log"
    echo "====================================================="
    
    # Afficher les processus en cours
    echo "Processus actifs:"
    ps aux | grep -E "python3|trader|bot_|gunicorn" | grep -v grep
}

# Exécuter la fonction principale
main