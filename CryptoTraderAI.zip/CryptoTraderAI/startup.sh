#!/bin/bash

# Configuration des variables d'environnement
export KRAKEN_API_KEY="IwYIUvR4AFc/VrQVCgLU4kxM00y2Omgr3XtbnR0zR6wlKy4t2RPpcexu"
export KRAKEN_API_SECRET="qMO6mqh5wgseTGIofBZoAXIYnxEZHF/FiAffgDWyNWMyULRIUPODhD9Jish7p2udgCESE2fy8mPXqGE/Pb2qeg=="
export SESSION_SECRET="crypto_trading_secret_key"

echo "Variables d'environnement configurées avec succès!"

# Lancer le trader en arrière-plan
echo "Démarrage du trader en arrière-plan..."
nohup python direct_trader.py > trading.log 2>&1 &
echo "Trader démarré avec PID: $!"

# Démarrer l'application Flask
echo "Démarrage de l'application web..."
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app