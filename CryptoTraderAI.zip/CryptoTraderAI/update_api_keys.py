#!/usr/bin/env python3
"""
Script pour mettre à jour les clés API Kraken dans les secrets Replit
"""
import os
import sys
import subprocess
import time

def set_replit_secret(key, value):
    """Configure un secret Replit"""
    try:
        # Utiliser la commande Replit pour définir un secret
        subprocess.run(['replit', 'secrets', 'set', key, value], 
                      capture_output=True, text=True, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Erreur lors de la configuration du secret {key}: {e}")
        return False
    except Exception as e:
        print(f"Erreur inattendue: {e}")
        return False

def clear_screen():
    """Efface l'écran"""
    os.system('clear')

def main():
    clear_screen()
    print("===== MISE À JOUR DES CLÉS API KRAKEN =====")
    print("Ce script va mettre à jour vos clés API Kraken dans les secrets Replit.")
    print("Vous pouvez générer de nouvelles clés API sur https://www.kraken.com/u/security/api")
    print("")
    print("IMPORTANT: Assurez-vous que vos clés API ont les permissions suivantes:")
    print("- Query Funds")
    print("- Query Closed Orders & Trades")
    print("- Query Ledger Entries")
    print("- Query Open Orders & Trades")
    print("- Modify Orders")
    print("")
    
    # Demander les nouvelles clés
    api_key = input("Entrez votre clé API Kraken: ").strip()
    if not api_key:
        print("Erreur: La clé API ne peut pas être vide.")
        sys.exit(1)
    
    api_secret = input("Entrez votre clé secrète API Kraken: ").strip()
    if not api_secret:
        print("Erreur: La clé secrète API ne peut pas être vide.")
        sys.exit(1)
    
    print("\nConfiguration des secrets Replit...")
    
    # Définir les secrets
    success1 = set_replit_secret('KRAKEN_API_KEY', api_key)
    success2 = set_replit_secret('KRAKEN_API_SECRET', api_secret)
    
    if success1 and success2:
        print("\n✅ Clés API Kraken mises à jour avec succès!")
        print("\nRedémarrage du bot nécessaire pour appliquer les changements.")
        print("Pour redémarrer le bot, utilisez la commande:")
        print("  ./on_replit_start.sh")
    else:
        print("\n❌ Erreur lors de la mise à jour des clés API.")
        print("Assurez-vous d'avoir les permissions nécessaires pour modifier les secrets Replit.")

if __name__ == "__main__":
    main()