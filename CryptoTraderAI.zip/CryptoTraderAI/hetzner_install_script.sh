#!/bin/bash
# Script d'installation automatique pour le bot de trading sur Hetzner
# Exécutez ce script directement sur votre serveur Hetzner

set -e  # Arrêt en cas d'erreur

echo "=== INSTALLATION DU BOT DE TRADING CRYPTO ULTRA-VOLATIL ==="
echo "Ce script va configurer votre serveur Hetzner pour exécuter le trading bot 24/7"

# Mise à jour du système
echo "Mise à jour du système..."
apt-get update
apt-get upgrade -y

# Installation des dépendances
echo "Installation des dépendances..."
apt-get install -y python3 python3-pip python3-venv git screen htop

# Création du répertoire pour le bot
echo "Création du répertoire pour le bot..."
mkdir -p /opt/trading_bot
cd /opt/trading_bot

# Clonage du code depuis le dépôt git (si applicable)
# git clone https://github.com/votre-nom-utilisateur/votre-depot.git .

# Téléchargement des fichiers depuis Github Gist ou autre source
echo "Téléchargement des fichiers du bot..."
wget -O ultra_volatility_trader.py https://raw.githubusercontent.com/votre-nom-utilisateur/votre-repo/main/ultra_volatility_trader.py || {
    echo "Vous devrez télécharger manuellement les fichiers du bot"
    echo "Utilisez SCP ou un autre outil pour transférer les fichiers vers /opt/trading_bot/"
}

# Création de l'environnement virtuel Python
echo "Configuration de l'environnement Python..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install krakenex requests numpy python-dotenv

# Création des fichiers de configuration
echo "Création des fichiers de configuration..."

# Fichier .env pour les clés API
cat > .env <<EOF
KRAKEN_API_KEY=votre_api_key_ici
KRAKEN_API_SECRET=votre_api_secret_ici
EOF

# Script de démarrage
cat > start_bot.sh <<EOF
#!/bin/bash
cd \$(dirname \$0)
source venv/bin/activate
screen -dmS trading_bot python ultra_volatility_trader.py
echo "Bot démarré dans Screen. Pour voir les logs: screen -r trading_bot"
EOF

# Script d'arrêt
cat > stop_bot.sh <<EOF
#!/bin/bash
screen -X -S trading_bot quit
echo "Bot arrêté"
EOF

# Script de vérification
cat > check_status.sh <<EOF
#!/bin/bash
if screen -list | grep -q "trading_bot"; then
    echo "Bot en cours d'exécution"
    echo "Pour voir les logs: screen -r trading_bot"
else
    echo "Le bot n'est pas en cours d'exécution"
fi
EOF

# Configuration des permissions
chmod +x *.sh

echo "=== INSTALLATION TERMINÉE ==="
echo ""
echo "ÉTAPES SUIVANTES:"
echo "1. Modifiez le fichier .env avec vos clés API Kraken:"
echo "   nano /opt/trading_bot/.env"
echo ""
echo "2. Démarrez le bot:"
echo "   cd /opt/trading_bot && ./start_bot.sh"
echo ""
echo "3. Pour vérifier le statut:"
echo "   cd /opt/trading_bot && ./check_status.sh"
echo ""
echo "4. Pour voir les logs:"
echo "   screen -r trading_bot"
echo "   (Utilisez Ctrl+A puis D pour détacher sans arrêter le bot)"
echo ""
echo "5. Pour arrêter le bot:"
echo "   cd /opt/trading_bot && ./stop_bot.sh"
echo ""
echo "Le bot sera maintenant exécuté 24/7, même après la déconnexion SSH !"