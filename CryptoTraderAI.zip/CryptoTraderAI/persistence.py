import os
import json
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Chemin du fichier de persistance
PERSISTENCE_FILE = "bot_state.json"

def save_bot_state(running=False, mode="multi_exchange", started_at=None):
    """
    Sauvegarde l'état du bot dans un fichier
    
    Args:
        running (bool): Si le bot est en cours d'exécution
        mode (str): Mode de trading
        started_at (datetime): Date et heure de démarrage
    """
    try:
        # Créer l'objet d'état
        state = {
            "running": running,
            "mode": mode,
            "started_at": started_at.isoformat() if started_at else None,
            "updated_at": datetime.utcnow().isoformat()
        }
        
        # Sauvegarder dans le fichier
        with open(PERSISTENCE_FILE, 'w') as f:
            json.dump(state, f, indent=2)
            
        logger.info(f"État du bot sauvegardé: {running}")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors de la sauvegarde de l'état du bot: {e}")
        return False

def load_bot_state():
    """
    Charge l'état du bot depuis le fichier
    
    Returns:
        dict: État du bot ou valeurs par défaut si non trouvé
    """
    try:
        # Vérifier si le fichier existe
        if not os.path.exists(PERSISTENCE_FILE):
            logger.info("Fichier d'état du bot non trouvé, utilisation des valeurs par défaut")
            return {
                "running": False,
                "mode": "multi_exchange",
                "started_at": None
            }
        
        # Charger depuis le fichier
        with open(PERSISTENCE_FILE, 'r') as f:
            state = json.load(f)
        
        # Convertir started_at en datetime si présent
        if state.get("started_at"):
            try:
                state["started_at"] = datetime.fromisoformat(state["started_at"])
            except:
                state["started_at"] = None
        
        logger.info(f"État du bot chargé: running={state.get('running', False)}")
        
        return state
    
    except Exception as e:
        logger.error(f"Erreur lors du chargement de l'état du bot: {e}")
        return {
            "running": False,
            "mode": "multi_exchange",
            "started_at": None
        }