#!/usr/bin/env python3
"""
Système de trading Béton Armé optimisé pour Replit
Intègre toutes les optimisations de ressources, rate limiting et performance
pour un fonctionnement 24/7 stable et efficace
"""
import os
import time
import logging
import threading
import signal
import queue
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("optimized_trader.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("ReplotOptimizedTrader")

# Import des modules optimisés
from optimized_resource_manager import OptimizedResourceManager
from optimized_queue_manager import OptimizedQueueManager, get_queue_manager
from optimized_api_client import OptimizedKrakenClient, setup_optimized_kraken_client
from performance_monitor import get_performance_monitor

class ReplotOptimizedTrader:
    """
    Version optimisée du trader Béton Armé spécialement conçue pour Replit
    Implémente des systèmes avancés de gestion des ressources et de robustesse
    """
    
    def __init__(self, api_key=None, api_secret=None):
        """
        Initialise le trader optimisé pour Replit
        
        Args:
            api_key (str, optional): Clé API Kraken
            api_secret (str, optional): Clé secrète API Kraken
        """
        # Charger les clés API
        self.api_key = api_key or os.environ.get("KRAKEN_API_KEY")
        self.api_secret = api_secret or os.environ.get("KRAKEN_API_SECRET")
        
        if not self.api_key or not self.api_secret:
            logger.warning("Clés API manquantes, les fonctionnalités privées seront désactivées")
        
        # Initialiser le client API optimisé
        self.api_client = setup_optimized_kraken_client(self.api_key, self.api_secret)
        
        # Initialiser le gestionnaire de files d'attente
        self.queue_manager = get_queue_manager()
        
        # Initialiser le gestionnaire de ressources
        self.resource_manager = OptimizedResourceManager(self.api_client)
        
        # Initialiser le moniteur de performances
        self.performance_monitor = get_performance_monitor(
            self.resource_manager, self.queue_manager
        )
        
        # État du trader
        self.running = False
        self.stop_event = threading.Event()
        self.paused = False
        
        # Balances et prix
        self.balances = {}  # {"USD": 100.0, "BTC": 0.1, ...}
        self.positions = {}  # {"BTC/USD": {"entry_price": 30000, "amount": 0.1}, ...}
        self.stop_losses = {}  # {"BTC/USD": {"price": 29000, "entry_price": 30000}, ...}
        self.price_cache = {}  # {"BTC/USD": {"price": 30000, "timestamp": 1234567890}, ...}
        
        # Paramètres de trading
        self.risk_per_trade = 0.1  # 10% du capital par trade
        self.stop_loss_pct = 0.5  # 0.5% sous le prix d'entrée
        self.take_profit_pct = 2.5  # 2.5% au-dessus du prix d'entrée
        
        # Volatilité minimale
        self.min_volatility = 0.5  # 0.5% minimum
        
        # Symboles à surveiller
        self.watch_symbols = [
            "ZEREBRO/USD", "MANA/USD", "GARI/USD", 
            "XRP/USD", "DOGE/USD", "AUDIO/USD"
        ]
        
        # Symboles exclus
        self.excluded_symbols = ["BTC/USD", "ETH/USD", "SOL/USD"]
        
        # Statistiques de trading
        self.stats = {
            "trades_executed": 0,
            "successful_trades": 0,
            "failed_trades": 0,
            "total_profit_loss": 0.0,
            "win_rate": 0.0
        }
        
        # Système de priorités des tâches
        self.PRIORITY_CRITICAL = 0  # Stop-loss checks
        self.PRIORITY_HIGH = 3      # Take-profit checks
        self.PRIORITY_NORMAL = 5    # Market analysis
        self.PRIORITY_LOW = 8       # Stats updates
        
        # Créer le fichier heartbeat s'il n'existe pas
        self.heartbeat_file = "bot_heartbeat.txt"
        
        logger.info("Trader optimisé pour Replit initialisé")
    
    def start(self):
        """
        Démarre le trader optimisé pour Replit
        
        Returns:
            bool: True si démarré avec succès
        """
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        try:
            logger.info("Démarrage du trader optimisé pour Replit")
            
            # Réinitialiser l'événement d'arrêt
            self.stop_event.clear()
            self.running = True
            self.paused = False
            
            # Mettre à jour les balances
            self._update_balances()
            
            # Démarrer le thread de heartbeat
            self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop)
            self.heartbeat_thread.daemon = True
            self.heartbeat_thread.start()
            
            # Démarrer le thread de surveillance du marché
            self.market_thread = threading.Thread(target=self._market_surveillance_loop)
            self.market_thread.daemon = True
            self.market_thread.start()
            
            # Démarrer le thread de vérification des stop-loss
            self.stop_loss_thread = threading.Thread(target=self._stop_loss_check_loop)
            self.stop_loss_thread.daemon = True
            self.stop_loss_thread.start()
            
            # Créer un fichier PID
            with open("bot_pid.txt", "w") as f:
                f.write(str(os.getpid()))
            
            logger.info("Trader optimisé pour Replit démarré avec succès")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors du démarrage du trader: {e}")
            self.running = False
            return False
    
    def stop(self):
        """
        Arrête le trader optimisé pour Replit
        
        Returns:
            bool: True si arrêté avec succès
        """
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        try:
            logger.info("Arrêt du trader optimisé pour Replit")
            
            # Signaler l'arrêt
            self.stop_event.set()
            self.running = False
            
            # Attendre que les threads se terminent (max 5 secondes)
            threads = [
                self.heartbeat_thread,
                self.market_thread,
                self.stop_loss_thread
            ]
            
            for thread in threads:
                if thread.is_alive():
                    thread.join(timeout=2)
            
            # Supprimer le fichier PID
            if os.path.exists("bot_pid.txt"):
                os.remove("bot_pid.txt")
            
            logger.info("Trader optimisé pour Replit arrêté avec succès")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de l'arrêt du trader: {e}")
            return False
    
    def pause(self):
        """
        Met le trader en pause (continue à surveiller mais n'exécute pas de trades)
        
        Returns:
            bool: True si mis en pause avec succès
        """
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        if self.paused:
            logger.warning("Le trader est déjà en pause")
            return False
        
        try:
            logger.info("Mise en pause du trader")
            self.paused = True
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de la mise en pause du trader: {e}")
            return False
    
    def resume(self):
        """
        Reprend le trading après une pause
        
        Returns:
            bool: True si reprise avec succès
        """
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        if not self.paused:
            logger.warning("Le trader n'est pas en pause")
            return False
        
        try:
            logger.info("Reprise du trader")
            self.paused = False
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de la reprise du trader: {e}")
            return False
    
    def _heartbeat_loop(self):
        """Thread de heartbeat pour indiquer que le trader est en vie"""
        logger.info("Démarrage du thread de heartbeat")
        
        while self.running and not self.stop_event.is_set():
            try:
                # Écrire le heartbeat
                with open(self.heartbeat_file, "w") as f:
                    f.write(f"Trader actif: {datetime.now()}")
                
                time.sleep(10)  # Toutes les 10 secondes
                
            except Exception as e:
                logger.error(f"Erreur dans le thread de heartbeat: {e}")
                time.sleep(30)  # Pause plus longue en cas d'erreur
    
    def _market_surveillance_loop(self):
        """Thread de surveillance du marché"""
        logger.info("Démarrage du thread de surveillance du marché")
        
        # Compteur pour les tâches périodiques
        counter = 0
        
        while self.running and not self.stop_event.is_set():
            try:
                if not self.paused:
                    # Utiliser le gestionnaire de files pour la surveillance du marché
                    self.queue_manager.add_priority_task(
                        self.PRIORITY_NORMAL,
                        f"market_analysis_{time.time()}",
                        self._analyze_market_opportunities
                    )
                
                # Mise à jour des balances toutes les 5 minutes
                counter += 1
                if counter % 5 == 0:
                    self.queue_manager.add_task(self._update_balances)
                
                # Pause optimisée (1 minute)
                time.sleep(60)
                
            except Exception as e:
                logger.error(f"Erreur dans le thread de surveillance du marché: {e}")
                time.sleep(120)  # Pause plus longue en cas d'erreur
    
    def _stop_loss_check_loop(self):
        """Thread de vérification des stop-loss (haute fréquence)"""
        logger.info("Démarrage du thread de vérification des stop-loss")
        
        while self.running and not self.stop_event.is_set():
            try:
                if not self.paused and self.stop_losses:
                    # Vérifier les stop-loss avec haute priorité
                    self.queue_manager.add_priority_task(
                        self.PRIORITY_CRITICAL,
                        f"stop_loss_check_{time.time()}",
                        self._check_stop_losses
                    )
                
                # Pause courte pour vérification fréquente
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Erreur dans le thread de vérification des stop-loss: {e}")
                time.sleep(5)  # Pause plus longue en cas d'erreur
    
    def _update_balances(self):
        """Met à jour les balances depuis l'API Kraken"""
        try:
            # Vérifier si les clés API sont disponibles
            if not self.api_key or not self.api_secret:
                logger.warning("Impossible de mettre à jour les balances: clés API manquantes")
                return False
            
            # Utiliser le client API optimisé
            balances = self.api_client.get_balance()
            
            if not balances:
                logger.warning("Impossible de récupérer les balances")
                return False
            
            # Mettre à jour les balances
            self.balances = balances
            
            # Identifier les positions significatives (>1 USD)
            significant_positions = []
            
            # Mettre à jour les positions
            for asset, balance in self.balances.items():
                if asset == 'ZUSD':
                    # Stocker le solde USD
                    self.balances['USD'] = float(balance)
                    continue
                
                if float(balance) > 0.001:
                    # Calculer la valeur en USD
                    price = self.get_ticker_price(f"{asset}/USD")
                    if price:
                        usd_value = float(balance) * price
                        if usd_value > 1:
                            significant_positions.append(f"{asset}: {float(balance):.4f} (~{usd_value:.2f}$)")
            
            # Journaliser les positions significatives
            if significant_positions:
                logger.info(f"Positions significatives: {', '.join(significant_positions)}")
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de la mise à jour des balances: {e}")
            return False
    
    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel avec cache optimisé
        
        Args:
            symbol (str): Symbole de la paire (ex: "BTC/USD")
            
        Returns:
            float: Prix actuel ou None si non disponible
        """
        # Utiliser le gestionnaire de ressources pour récupérer le prix avec cache
        return self.resource_manager.get_cached_price(symbol)
    
    def _analyze_market_opportunities(self):
        """Analyse les opportunités de marché"""
        try:
            logger.info("Analyse des opportunités de marché...")
            
            opportunities = []
            
            # Analyser chaque symbole surveillé
            for symbol in self.watch_symbols:
                # Vérifier si le symbole est exclu
                if symbol in self.excluded_symbols:
                    continue
                
                # Récupérer les données pour l'analyse
                price = self.get_ticker_price(symbol)
                if not price:
                    continue
                
                # Analyser la volatilité et la tendance
                volatility = self._calculate_volatility(symbol)
                trend = self._calculate_trend(symbol)
                
                if volatility and trend:
                    # Calculer un score d'opportunité
                    score = (volatility * 0.6) + (trend * 0.4)
                    
                    # Ajouter à la liste des opportunités
                    opportunities.append({
                        'symbol': symbol,
                        'price': price,
                        'volatility': volatility,
                        'trend': trend,
                        'score': score
                    })
                    
                    logger.info(f"{symbol}: Volatilité {volatility:.2f}%, Tendance {trend:.2f}%, Score {score:.2f}")
            
            # Trier les opportunités par score
            opportunities.sort(key=lambda x: x['score'], reverse=True)
            
            # Exécuter des trades si de bonnes opportunités sont disponibles
            if opportunities and not self.paused:
                self._evaluate_trade_opportunities(opportunities)
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse des opportunités: {e}")
            self.performance_monitor.record_error("market_analysis", str(e))
            return False
    
    def _calculate_volatility(self, symbol):
        """
        Calcule la volatilité d'un symbole sur 1h
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            float: Volatilité en pourcentage ou None si non disponible
        """
        try:
            # Récupérer les données OHLCV
            ohlcv = self.api_client.get_ohlcv(symbol, timeframe='1h', limit=12)
            
            if not ohlcv or len(ohlcv) < 6:
                return None
            
            # Calculer la volatilité sur les 6 dernières heures
            highs = [candle[2] for candle in ohlcv[-6:]]
            lows = [candle[3] for candle in ohlcv[-6:]]
            
            # Volatilité = (max - min) / min * 100
            max_price = max(highs)
            min_price = min(lows)
            
            volatility = (max_price - min_price) / min_price * 100
            
            return volatility
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul de la volatilité pour {symbol}: {e}")
            return None
    
    def _calculate_trend(self, symbol):
        """
        Calcule la tendance d'un symbole (pourcentage de changement 6h)
        
        Args:
            symbol (str): Symbole de la paire
            
        Returns:
            float: Tendance en pourcentage ou None si non disponible
        """
        try:
            # Récupérer les données OHLCV
            ohlcv = self.api_client.get_ohlcv(symbol, timeframe='1h', limit=7)
            
            if not ohlcv or len(ohlcv) < 7:
                return None
            
            # Calculer la tendance sur les 6 dernières heures
            open_price = ohlcv[-7][1]  # Prix d'ouverture il y a 6h
            close_price = ohlcv[-1][4]  # Prix de clôture actuel
            
            # Tendance = (close - open) / open * 100
            trend = (close_price - open_price) / open_price * 100
            
            return trend
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul de la tendance pour {symbol}: {e}")
            return None
    
    def _evaluate_trade_opportunities(self, opportunities):
        """
        Évalue les opportunités de trading et exécute des trades si pertinent
        
        Args:
            opportunities (list): Liste des opportunités triées par score
        """
        try:
            # Vérifier s'il y a des opportunités
            if not opportunities:
                return
            
            # Récupérer la meilleure opportunité
            best_opportunity = opportunities[0]
            
            # Vérifier si le score est suffisant
            if best_opportunity['score'] <= 1.0:
                logger.info("Aucune opportunité avec un score suffisant")
                return
            
            # Vérifier si la volatilité est suffisante
            if best_opportunity['volatility'] < self.min_volatility:
                logger.info(f"{best_opportunity['symbol']}: Volatilité trop faible ({best_opportunity['volatility']:.2f}%)")
                return
            
            # Vérifier si la tendance est positive
            if best_opportunity['trend'] <= 0:
                logger.info(f"{best_opportunity['symbol']}: Tendance négative ({best_opportunity['trend']:.2f}%)")
                return
            
            # Vérifier si on a déjà une position sur ce symbole
            symbol = best_opportunity['symbol']
            if symbol in self.stop_losses:
                logger.info(f"Position existante pour {symbol}, pas de nouvel achat")
                return
            
            # Vérifier s'il y a assez de capital
            if 'USD' not in self.balances or float(self.balances['USD']) < 2.0:
                logger.warning(f"Capital insuffisant: {self.balances.get('USD', 0):.2f} USD")
                return
            
            # Calculer la taille de la position
            position_size = self._calculate_position_size(symbol, best_opportunity['price'])
            
            if position_size > 0:
                # Exécuter l'achat via le gestionnaire de files avec haute priorité
                self.queue_manager.add_priority_task(
                    self.PRIORITY_HIGH,
                    f"execute_buy_{time.time()}",
                    self._execute_buy,
                    symbol, position_size
                )
        
        except Exception as e:
            logger.error(f"Erreur lors de l'évaluation des opportunités: {e}")
    
    def _calculate_position_size(self, symbol, price):
        """
        Calcule la taille optimale de la position
        
        Args:
            symbol (str): Symbole de la paire
            price (float): Prix actuel
            
        Returns:
            float: Taille de la position ou 0 si erreur
        """
        try:
            # Vérifier s'il y a un solde USD
            if 'USD' not in self.balances:
                return 0
            
            # Récupérer le solde USD
            usd_balance = float(self.balances['USD'])
            
            # Calculer le montant à investir
            invest_amount = usd_balance * self.risk_per_trade
            
            # S'assurer d'un minimum de 2 USD
            invest_amount = max(invest_amount, 2.0)
            
            # S'assurer de ne pas dépasser le solde
            invest_amount = min(invest_amount, usd_balance * 0.99)
            
            # Calculer la quantité
            quantity = invest_amount / price
            
            # Ajuster pour les frais
            quantity *= 0.997  # 0.3% de marge pour les frais
            
            # Arrondir selon les règles de Kraken (dépend du symbole)
            # Pour la plupart des cryptos, 8 décimales sont suffisantes
            quantity = round(quantity, 8)
            
            return quantity
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul de la taille de position pour {symbol}: {e}")
            return 0
    
    def _execute_buy(self, symbol, quantity):
        """
        Exécute un ordre d'achat
        
        Args:
            symbol (str): Symbole de la paire
            quantity (float): Quantité à acheter
            
        Returns:
            bool: True si l'achat est réussi
        """
        try:
            logger.info(f"Exécution d'un achat de {quantity:.8f} {symbol}...")
            
            # Récupérer le prix actuel
            price = self.get_ticker_price(symbol)
            if not price:
                logger.error(f"Impossible d'obtenir le prix pour {symbol}")
                return False
            
            # Créer l'ordre d'achat
            order = self.api_client.create_order(
                symbol, "market", "buy", quantity
            )
            
            if not order:
                logger.error(f"Erreur lors de la création de l'ordre pour {symbol}")
                return False
            
            # Récupérer l'ID de transaction
            txid = order['txid'][0] if 'txid' in order else None
            
            logger.info(f"✅ ACHAT EXÉCUTÉ: {quantity:.8f} {symbol} à ~{price:.6f} - ID: {txid}")
            
            # Mettre à jour les balances
            self._update_balances()
            
            # Définir un stop-loss
            self._set_stop_loss(symbol, price)
            
            # Mettre à jour les statistiques
            self.stats['trades_executed'] += 1
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {symbol}: {e}")
            self.performance_monitor.record_error("buy_execution", str(e))
            return False
    
    def _set_stop_loss(self, symbol, entry_price):
        """
        Définit un stop-loss pour une position
        
        Args:
            symbol (str): Symbole de la paire
            entry_price (float): Prix d'entrée
        """
        try:
            # Calculer le prix du stop-loss
            stop_loss_price = entry_price * (1 - self.stop_loss_pct / 100)
            
            # Enregistrer le stop-loss
            self.stop_losses[symbol] = {
                'entry_price': entry_price,
                'price': stop_loss_price,
                'entry_time': time.time()
            }
            
            logger.info(f"Stop-loss défini pour {symbol} à {stop_loss_price:.6f} "
                       f"({self.stop_loss_pct:.2f}% sous le prix d'entrée)")
        
        except Exception as e:
            logger.error(f"Erreur lors de la définition du stop-loss pour {symbol}: {e}")
    
    def _check_stop_losses(self):
        """Vérifie tous les stop-losses et exécute les ventes si nécessaire"""
        try:
            # Vérifier chaque stop-loss
            for symbol in list(self.stop_losses.keys()):
                # Récupérer le prix actuel
                current_price = self.get_ticker_price(symbol)
                if not current_price:
                    continue
                
                # Récupérer les informations du stop-loss
                stop_loss = self.stop_losses[symbol]
                
                # Vérifier si le prix est inférieur au stop-loss
                if current_price <= stop_loss['price']:
                    logger.warning(f"⚠️ STOP-LOSS DÉCLENCHÉ pour {symbol} à {current_price:.6f}")
                    
                    # Exécuter la vente
                    self._execute_sell(symbol, stop_loss_triggered=True)
        
        except Exception as e:
            logger.error(f"Erreur lors de la vérification des stop-loss: {e}")
    
    def _execute_sell(self, symbol, percentage=1.0, stop_loss_triggered=False):
        """
        Exécute un ordre de vente
        
        Args:
            symbol (str): Symbole de la paire
            percentage (float): Pourcentage de la position à vendre
            stop_loss_triggered (bool): Si la vente est déclenchée par un stop-loss
            
        Returns:
            bool: True si la vente est réussie
        """
        try:
            # Extraire l'actif
            asset = symbol.split('/')[0]
            
            # Vérifier si l'actif est dans les balances
            if asset not in self.balances:
                logger.warning(f"Actif {asset} non disponible dans le portefeuille")
                
                # Supprimer le stop-loss
                if symbol in self.stop_losses:
                    del self.stop_losses[symbol]
                
                return False
            
            # Calculer la quantité à vendre
            balance = float(self.balances[asset])
            quantity = balance * percentage
            
            # Arrondir selon les règles de Kraken
            quantity = round(quantity, 8)
            
            logger.info(f"Exécution d'une vente de {quantity:.8f} {asset}...")
            
            # Récupérer le prix actuel
            price = self.get_ticker_price(symbol)
            if not price:
                logger.error(f"Impossible d'obtenir le prix pour {symbol}")
                return False
            
            # Créer l'ordre de vente
            order = self.api_client.create_order(
                symbol, "market", "sell", quantity
            )
            
            if not order:
                logger.error(f"Erreur lors de la création de l'ordre pour {symbol}")
                return False
            
            # Récupérer l'ID de transaction
            txid = order['txid'][0] if 'txid' in order else None
            
            # Calculer le profit/perte
            profit_loss = 0.0
            if symbol in self.stop_losses:
                entry_price = self.stop_losses[symbol]['entry_price']
                profit_loss = (price - entry_price) / entry_price * 100
            
            logger.info(f"✅ VENTE EXÉCUTÉE: {quantity:.8f} {asset} à ~{price:.6f} "
                       f"({profit_loss:+.2f}%) - ID: {txid}")
            
            # Mettre à jour les balances
            self._update_balances()
            
            # Mettre à jour les statistiques
            self.stats['trades_executed'] += 1
            
            if profit_loss > 0:
                self.stats['successful_trades'] += 1
            else:
                self.stats['failed_trades'] += 1
            
            self.stats['total_profit_loss'] += profit_loss
            
            total_trades = self.stats['successful_trades'] + self.stats['failed_trades']
            if total_trades > 0:
                self.stats['win_rate'] = self.stats['successful_trades'] / total_trades * 100
            
            # Supprimer le stop-loss si vente totale
            if percentage == 1.0 and symbol in self.stop_losses:
                del self.stop_losses[symbol]
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de la vente de {symbol}: {e}")
            self.performance_monitor.record_error("sell_execution", str(e))
            return False
    
    def get_status(self):
        """
        Récupère le statut complet du trader
        
        Returns:
            dict: Statut complet
        """
        try:
            # Récupérer les métriques système
            system_metrics = self.performance_monitor.get_metrics_summary()
            
            # Assembler le statut
            status = {
                'running': self.running,
                'paused': self.paused,
                'balances': self.balances,
                'positions': self.stop_losses,
                'stats': self.stats,
                'system': system_metrics
            }
            
            return status
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du statut: {e}")
            return {'error': str(e)}
    
    def convert_to_volatile(self):
        """
        Convertit tous les actifs en cryptos volatiles
        
        Returns:
            dict: Résultats des conversions
        """
        try:
            logger.info("Conversion des actifs en cryptos volatiles...")
            
            # Mettre à jour les balances
            self._update_balances()
            
            # Trouver les actifs significatifs (>1 USD)
            significant_assets = []
            
            for asset, balance in self.balances.items():
                if asset == 'USD' or asset == 'ZUSD':
                    continue
                
                # Convertir en float
                balance_float = float(balance)
                
                # Vérifier si le solde est significatif
                if balance_float > 0.001:
                    # Estimer la valeur en USD
                    price = self.get_ticker_price(f"{asset}/USD")
                    if price:
                        usd_value = balance_float * price
                        if usd_value > 1:
                            significant_assets.append({
                                'asset': asset,
                                'balance': balance_float,
                                'usd_value': usd_value
                            })
            
            # Trier par valeur USD (du plus grand au plus petit)
            significant_assets.sort(key=lambda x: x['usd_value'], reverse=True)
            
            # Convertir chaque actif en crypto volatile
            results = {}
            
            for asset_info in significant_assets:
                asset = asset_info['asset']
                balance = asset_info['balance']
                
                # Trouver la crypto volatile cible
                target_asset = self._find_best_volatile_crypto()
                
                if target_asset:
                    # Exécuter la conversion
                    result = self._convert_asset(asset, target_asset, balance)
                    results[asset] = result
                else:
                    results[asset] = {'success': False, 'reason': "Aucune crypto volatile cible trouvée"}
            
            # Convertir également USD si disponible
            if 'USD' in self.balances and float(self.balances['USD']) > 5:
                target_asset = self._find_best_volatile_crypto()
                
                if target_asset:
                    # Exécuter la conversion
                    result = self._buy_asset(target_asset, float(self.balances['USD']) * 0.98)
                    results['USD'] = result
            
            return results
        
        except Exception as e:
            logger.error(f"Erreur lors de la conversion des actifs: {e}")
            return {'error': str(e)}
    
    def _find_best_volatile_crypto(self):
        """
        Trouve la meilleure crypto volatile pour investir
        
        Returns:
            str: Symbole de la crypto ou None si aucune trouvée
        """
        try:
            # Analyser la volatilité et la tendance des cryptos surveillées
            best_score = 0
            best_crypto = None
            
            for symbol in self.watch_symbols:
                if symbol in self.excluded_symbols:
                    continue
                
                # Analyser la volatilité et la tendance
                volatility = self._calculate_volatility(symbol)
                trend = self._calculate_trend(symbol)
                
                if volatility and trend:
                    # Calculer un score
                    score = volatility * 0.5 + trend * 0.5
                    
                    # Si meilleur score et tendance positive
                    if score > best_score and trend > 0:
                        best_score = score
                        best_crypto = symbol.split('/')[0]  # Extraire l'actif
            
            return best_crypto
        
        except Exception as e:
            logger.error(f"Erreur lors de la recherche de crypto volatile: {e}")
            return None
    
    def _convert_asset(self, from_asset, to_asset, amount):
        """
        Convertit un actif en un autre
        
        Args:
            from_asset (str): Actif source
            to_asset (str): Actif cible
            amount (float): Montant à convertir
            
        Returns:
            dict: Résultat de la conversion
        """
        try:
            logger.info(f"Conversion de {amount:.8f} {from_asset} en {to_asset}...")
            
            # Étape 1: Vendre l'actif source contre USD
            sell_result = self._execute_sell(f"{from_asset}/USD", percentage=1.0)
            
            if not sell_result:
                return {'success': False, 'reason': "Échec de la vente"}
            
            # Mise à jour des balances
            self._update_balances()
            
            # Étape 2: Acheter l'actif cible avec USD
            if 'USD' in self.balances and float(self.balances['USD']) > 2:
                buy_result = self._buy_asset(to_asset, float(self.balances['USD']) * 0.98)
                
                if not buy_result:
                    return {'success': False, 'reason': "Échec de l'achat"}
                
                return {'success': True, 'from': from_asset, 'to': to_asset}
            
            return {'success': False, 'reason': "Solde USD insuffisant après la vente"}
        
        except Exception as e:
            logger.error(f"Erreur lors de la conversion {from_asset} -> {to_asset}: {e}")
            return {'success': False, 'reason': str(e)}
    
    def _buy_asset(self, asset, usd_amount):
        """
        Achète un actif avec un montant USD
        
        Args:
            asset (str): Actif à acheter
            usd_amount (float): Montant USD à utiliser
            
        Returns:
            bool: True si l'achat est réussi
        """
        try:
            symbol = f"{asset}/USD"
            
            # Récupérer le prix actuel
            price = self.get_ticker_price(symbol)
            if not price:
                logger.error(f"Impossible d'obtenir le prix pour {symbol}")
                return False
            
            # Calculer la quantité
            quantity = usd_amount / price
            
            # Ajuster pour les frais
            quantity *= 0.997
            
            # Arrondir selon les règles de Kraken
            quantity = round(quantity, 8)
            
            logger.info(f"Achat de {quantity:.8f} {asset} avec {usd_amount:.2f} USD...")
            
            # Exécuter l'achat
            return self._execute_buy(symbol, quantity)
        
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {asset}: {e}")
            return False


def main():
    """Fonction principale pour démarrer le trader optimisé pour Replit"""
    try:
        logger.info("Démarrage du trader optimisé pour Replit")
        
        # Créer le trader
        trader = ReplotOptimizedTrader()
        
        # Démarrer le trader
        if trader.start():
            logger.info("Trader démarré avec succès")
            
            # Configurer le gestionnaire de signaux pour l'arrêt propre
            def signal_handler(sig, frame):
                logger.info("Signal d'arrêt reçu")
                trader.stop()
                sys.exit(0)
            
            signal.signal(signal.SIGINT, signal_handler)
            signal.signal(signal.SIGTERM, signal_handler)
            
            # Garder le processus en vie
            while trader.running:
                time.sleep(1)
        
        else:
            logger.error("Échec du démarrage du trader")
    
    except Exception as e:
        logger.error(f"Erreur critique lors du démarrage du trader: {e}")


if __name__ == "__main__":
    main()