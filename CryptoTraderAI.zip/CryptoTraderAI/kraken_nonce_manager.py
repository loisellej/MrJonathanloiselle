#!/usr/bin/env python3
"""
Gestionnaire de Nonce pour l'API Kraken
Résout les problèmes d'erreur de nonce ('EAPI:Invalid nonce')

Un "nonce" est un numéro qui ne peut être utilisé qu'une seule fois.
L'API Kraken utilise des nonces pour éviter les attaques par rejeu.
Le nonce doit être strictement croissant pour chaque requête API.
"""
import os
import time
import json
import logging
from pathlib import Path

logger = logging.getLogger("KrakenNonceManager")

class KrakenNonceManager:
    """
    Gestionnaire de nonce pour les requêtes API Kraken
    Résout les problèmes d'erreur 'EAPI:Invalid nonce'
    """
    def __init__(self, cache_file="kraken_nonce.json"):
        """
        Initialise le gestionnaire de nonce
        
        Args:
            cache_file (str): Chemin vers le fichier de cache des nonces
        """
        self.cache_file = cache_file
        self.last_nonce = self._load_last_nonce()
        self.nonce_increment = 1  # Incrément minimal
    
    def _load_last_nonce(self):
        """Charge le dernier nonce utilisé depuis le fichier de cache"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    return data.get('last_nonce', 0)
            return 0  # Valeur par défaut
        except Exception as e:
            logger.warning(f"Erreur lors du chargement du nonce: {e}")
            return 0
    
    def _save_last_nonce(self):
        """Sauvegarde le dernier nonce utilisé dans le fichier de cache"""
        try:
            with open(self.cache_file, 'w') as f:
                json.dump({'last_nonce': self.last_nonce}, f)
        except Exception as e:
            logger.warning(f"Erreur lors de la sauvegarde du nonce: {e}")
    
    def get_nonce(self):
        """
        Génère un nouveau nonce unique et strictement croissant
        
        Returns:
            int: Le nouveau nonce
        """
        # Le temps actuel en microsecondes
        current_nonce = int(time.time() * 1000000)
        
        # S'assurer que le nonce est supérieur au dernier utilisé
        if current_nonce <= self.last_nonce:
            current_nonce = self.last_nonce + self.nonce_increment
            # Augmenter l'incrément pour éviter des collisions dans le futur
            self.nonce_increment += 1
        else:
            # Réinitialiser l'incrément si le temps a avancé suffisamment
            self.nonce_increment = 1
        
        # Mettre à jour et sauvegarder le dernier nonce
        self.last_nonce = current_nonce
        self._save_last_nonce()
        
        return current_nonce
    
    def reset_nonce(self):
        """Réinitialise le nonce en cas de problème majeur"""
        self.last_nonce = int(time.time() * 1000000) + 10000  # Ajoute un offset pour éviter les collisions
        self._save_last_nonce()
        logger.info(f"Nonce réinitialisé à {self.last_nonce}")
        return self.last_nonce

# Instance globale du gestionnaire de nonce
_nonce_manager = None

def get_nonce_manager():
    """
    Récupère l'instance globale du gestionnaire de nonce
    
    Returns:
        KrakenNonceManager: Instance du gestionnaire de nonce
    """
    global _nonce_manager
    if _nonce_manager is None:
        _nonce_manager = KrakenNonceManager()
    return _nonce_manager

def get_new_nonce():
    """
    Obtient un nouveau nonce unique pour l'API Kraken
    
    Returns:
        int: Un nonce unique et croissant
    """
    return get_nonce_manager().get_nonce()

def reset_kraken_nonce():
    """
    Réinitialise le nonce en cas d'erreurs persistantes
    
    Returns:
        int: Le nouveau nonce de départ
    """
    return get_nonce_manager().reset_nonce()

# Réinitialiser le nonce si ce script est exécuté directement
if __name__ == "__main__":
    import sys
    
    # Configurer le logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    print("Gestionnaire de Nonce Kraken")
    print("---------------------------")
    
    if len(sys.argv) > 1 and sys.argv[1] == "reset":
        new_nonce = reset_kraken_nonce()
        print(f"🔄 Nonce réinitialisé à: {new_nonce}")
    else:
        manager = get_nonce_manager()
        current = manager.last_nonce
        new_nonce = manager.get_nonce()
        print(f"📊 État du nonce:")
        print(f"  Dernier nonce: {current}")
        print(f"  Nouveau nonce: {new_nonce}")
        print(f"  Fichier de cache: {manager.cache_file}")
    
    print("\n✅ Terminé")