#!/usr/bin/env python3
"""
Client API optimisé pour Kraken avec gestion de cache et rate-limiting
Module conçu pour réduire la consommation de ressources sur Replit
tout en maintenant des performances optimales pour le trading
"""
import time
import json
import hmac
import base64
import hashlib
import urllib.parse
import requests
import logging
import threading
import os
from datetime import datetime, timedelta
from functools import lru_cache

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("api_client.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("OptimizedAPIClient")

class OptimizedKrakenClient:
    """
    Client API Kraken optimisé pour réduire la consommation de ressources
    Implémente un cache de prix, rate limiting et backoff intelligent
    """
    
    def __init__(self, api_key=None, api_secret=None):
        """
        Initialise le client API Kraken optimisé
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.api_url = "https://api.kraken.com"
        
        # Cache de prix avec TTL
        self.price_cache = {}  # {symbol: {'price': float, 'timestamp': float}}
        self.cache_ttl = 60  # 60 secondes par défaut
        
        # Cache du carnet d'ordres
        self.orderbook_cache = {}  # {symbol: {'data': dict, 'timestamp': float}}
        
        # Rate limiting
        self.api_calls = {}  # {endpoint: [timestamp1, timestamp2, ...]}
        self.max_calls_per_minute = {
            'default': 15,
            'Ticker': 20,
            'OHLC': 15,
            'Depth': 10,
            'AddOrder': 5,
            'Balance': 5
        }
        
        # Backoff exponentiel
        self.retry_count = {}  # {endpoint: count}
        self.max_retries = 3
        
        # Carnet d'ordres en temps réel
        self.live_orderbook = {}  # {symbol: {'bids': [...], 'asks': [...]}}
        
        # Cache des taux de frais
        self.fee_rates = {}  # {symbol: {'maker': float, 'taker': float}}
        
        # Nonce manager pour requêtes privées
        self.nonce_lock = threading.Lock()
        self.last_nonce = 0
        self.nonce_file = "kraken_nonce.json"
        self._load_last_nonce()
        
        # Thread de nettoyage de cache
        self.cache_cleanup_thread = threading.Thread(target=self._cache_cleanup_loop)
        self.cache_cleanup_thread.daemon = True
        self.cache_cleanup_thread.start()
        
        logger.info("Client API Kraken optimisé initialisé")
    
    def _load_last_nonce(self):
        """Charge le dernier nonce utilisé depuis le fichier"""
        try:
            if os.path.exists(self.nonce_file):
                with open(self.nonce_file, 'r') as f:
                    data = json.load(f)
                    self.last_nonce = data.get('nonce', int(time.time() * 1000))
        except Exception as e:
            logger.error(f"Erreur lors du chargement du nonce: {e}")
            self.last_nonce = int(time.time() * 1000)
    
    def _save_nonce(self):
        """Sauvegarde le nonce actuel dans un fichier"""
        try:
            with open(self.nonce_file, 'w') as f:
                json.dump({'nonce': self.last_nonce}, f)
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde du nonce: {e}")
    
    def get_nonce(self):
        """
        Génère un nonce unique pour les requêtes privées
        avec prise en charge multi-threads
        
        Returns:
            int: Nonce unique
        """
        with self.nonce_lock:
            # Obtenir le timestamp actuel en millisecondes
            current_time = int(time.time() * 1000)
            
            # Assurer que le nonce est supérieur au dernier utilisé
            self.last_nonce = max(self.last_nonce + 1, current_time)
            
            # Sauvegarder le nonce périodiquement
            if current_time % 100 == 0:  # ~tous les 100ms
                self._save_nonce()
            
            return self.last_nonce
    
    def _cache_cleanup_loop(self):
        """Thread de nettoyage des caches périmés"""
        while True:
            try:
                now = time.time()
                
                # Nettoyer le cache de prix
                for symbol in list(self.price_cache.keys()):
                    if now - self.price_cache[symbol]['timestamp'] > self.cache_ttl:
                        del self.price_cache[symbol]
                
                # Nettoyer le cache du carnet d'ordres
                for symbol in list(self.orderbook_cache.keys()):
                    if now - self.orderbook_cache[symbol]['timestamp'] > 10:  # TTL de 10s
                        del self.orderbook_cache[symbol]
                
                # Nettoyer les timestamps d'appels API
                for endpoint in self.api_calls:
                    self.api_calls[endpoint] = [
                        t for t in self.api_calls[endpoint] if now - t < 60
                    ]
                
                # Pause de 30 secondes
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Erreur dans le nettoyage de cache: {e}")
                time.sleep(60)
    
    def _check_rate_limit(self, endpoint='default'):
        """
        Vérifie et applique le rate limiting
        
        Args:
            endpoint (str): Endpoint API
            
        Returns:
            bool: True si l'appel est autorisé, False sinon
        """
        # Initialiser l'historique des appels pour cet endpoint si nécessaire
        if endpoint not in self.api_calls:
            self.api_calls[endpoint] = []
        
        now = time.time()
        
        # Nettoyer les timestamps plus vieux que 60 secondes
        self.api_calls[endpoint] = [
            t for t in self.api_calls[endpoint] if now - t < 60
        ]
        
        # Obtenir la limite pour cet endpoint
        limit = self.max_calls_per_minute.get(endpoint, self.max_calls_per_minute['default'])
        
        # Vérifier si nous avons atteint la limite
        if len(self.api_calls[endpoint]) >= limit:
            # Calculer le temps à attendre
            oldest_call = min(self.api_calls[endpoint])
            wait_time = 60 - (now - oldest_call)
            
            if wait_time > 0:
                logger.warning(f"Rate limit atteint pour {endpoint}, attente de {wait_time:.2f}s")
                time.sleep(wait_time)
        
        # Ajouter le timestamp actuel
        self.api_calls[endpoint].append(now)
        
        # Petite pause après chaque appel API
        time.sleep(0.05)
        
        return True
    
    def _handle_retry(self, endpoint, error, retry=0):
        """
        Gère la logique de retry avec backoff exponentiel
        
        Args:
            endpoint (str): Endpoint API
            error: Erreur rencontrée
            retry (int): Nombre de tentatives déjà effectuées
            
        Returns:
            float: Temps d'attente avant retry
        """
        if retry >= self.max_retries:
            raise Exception(f"Nombre maximum de tentatives atteint pour {endpoint}: {error}")
        
        # Backoff exponentiel
        wait_time = 0.5 * (2 ** retry)
        
        # Ajouter un jitter aléatoire
        jitter = wait_time * 0.1 * (time.time() % 1)
        wait_time += jitter
        
        logger.warning(f"Retry {retry+1}/{self.max_retries} pour {endpoint} dans {wait_time:.2f}s: {error}")
        
        return wait_time
    
    def _make_request(self, uri_path, data, headers=None, retry=0):
        """
        Exécute une requête HTTP avec gestion d'erreur et retry
        
        Args:
            uri_path (str): Chemin API
            data (dict): Données de la requête
            headers (dict, optional): En-têtes de la requête
            retry (int): Nombre de tentatives déjà effectuées
            
        Returns:
            dict: Réponse JSON
        """
        url = self.api_url + uri_path
        
        try:
            if headers:
                response = requests.post(url, data=data, headers=headers, timeout=10)
            else:
                response = requests.post(url, data=data, timeout=10)
            
            # Vérifier le code de réponse
            if response.status_code not in (200, 201, 202):
                wait_time = self._handle_retry(
                    uri_path,
                    f"Code HTTP {response.status_code}: {response.text}",
                    retry
                )
                time.sleep(wait_time)
                return self._make_request(uri_path, data, headers, retry + 1)
            
            # Parser la réponse
            result = response.json()
            
            # Vérifier les erreurs
            if result.get('error') and result['error']:
                error_msg = ', '.join(result['error'])
                
                # Vérifier si l'erreur est due au rate limiting
                if "Rate limit exceeded" in error_msg:
                    logger.warning(f"Rate limit Kraken atteint, attente de 5s")
                    time.sleep(5)
                    return self._make_request(uri_path, data, headers, retry)
                
                # Retry pour certaines erreurs
                if "EGeneral:Temporary unavailable" in error_msg:
                    wait_time = self._handle_retry(uri_path, error_msg, retry)
                    time.sleep(wait_time)
                    return self._make_request(uri_path, data, headers, retry + 1)
                
                # Shadow ban ou API en maintenance
                if "EService:Unavailable" in error_msg:
                    logger.error(f"API Kraken en maintenance ou shadow ban: {error_msg}")
                    # Attente plus longue pour les erreurs de service
                    time.sleep(60)
                    return {"error": [error_msg], "result": {}}
                
                # Retourner l'erreur pour autres cas
                return {"error": [error_msg], "result": {}}
            
            return result
            
        except (requests.RequestException, json.JSONDecodeError) as e:
            wait_time = self._handle_retry(uri_path, str(e), retry)
            time.sleep(wait_time)
            return self._make_request(uri_path, data, headers, retry + 1)
    
    def _get_kraken_signature(self, urlpath, data):
        """
        Génère la signature Kraken pour l'authentification API
        
        Args:
            urlpath (str): Chemin API
            data (dict): Données de la requête
            
        Returns:
            str: Signature encodée en base64
        """
        if not self.api_secret:
            raise ValueError("API secret non configurée")
        
        # Convertir la clé secrète de base64 en bytes
        api_secret = base64.b64decode(self.api_secret)
        
        # Créer le message de signature
        message = urlpath.encode() + hashlib.sha256(
            urllib.parse.urlencode(data).encode()
        ).digest()
        
        # Générer la signature
        signature = hmac.new(api_secret, message, hashlib.sha512).digest()
        
        # Encoder la signature en base64
        return base64.b64encode(signature).decode()
    
    def query_public(self, method, data=None, cache=True):
        """
        Exécute une requête publique Kraken avec cache et rate limiting
        
        Args:
            method (str): Méthode API
            data (dict, optional): Paramètres de la requête
            cache (bool): Utiliser le cache si disponible
            
        Returns:
            dict: Réponse JSON
        """
        # Vérifier le rate limiting
        self._check_rate_limit(method)
        
        # Créer une clé de cache
        cache_key = f"{method}_{json.dumps(data or {})}"
        
        # Vérifier le cache
        if cache and hasattr(self, 'public_cache') and cache_key in self.public_cache:
            cache_entry = self.public_cache[cache_key]
            if time.time() - cache_entry['timestamp'] < self.cache_ttl:
                return cache_entry['data']
        
        # Construire le chemin API
        urlpath = f"/0/public/{method}"
        
        # Exécuter la requête
        response = self._make_request(urlpath, data or {})
        
        # Mettre en cache la réponse
        if cache and 'result' in response and not response.get('error'):
            if not hasattr(self, 'public_cache'):
                self.public_cache = {}
            
            self.public_cache[cache_key] = {
                'data': response,
                'timestamp': time.time()
            }
        
        return response
    
    def query_private(self, method, data=None):
        """
        Exécute une requête privée Kraken avec authentification
        
        Args:
            method (str): Méthode API
            data (dict, optional): Paramètres de la requête
            
        Returns:
            dict: Réponse JSON
        """
        if not self.api_key or not self.api_secret:
            raise ValueError("API key et secret sont requis pour les requêtes privées")
        
        # Vérifier le rate limiting
        self._check_rate_limit(method)
        
        # Construire le chemin API
        urlpath = f"/0/private/{method}"
        
        # Préparer les données
        data = data or {}
        data['nonce'] = self.get_nonce()
        
        # Générer la signature
        signature = self._get_kraken_signature(urlpath, data)
        
        # Préparer les en-têtes
        headers = {
            'API-Key': self.api_key,
            'API-Sign': signature
        }
        
        # Exécuter la requête
        return self._make_request(urlpath, data, headers)
    
    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel d'un symbole avec cache optimisé
        
        Args:
            symbol (str): Symbole de la paire (ex: "BTC/USD")
            
        Returns:
            float: Prix actuel ou None en cas d'erreur
        """
        # Vérifier le cache
        now = time.time()
        if symbol in self.price_cache:
            cache_entry = self.price_cache[symbol]
            if now - cache_entry['timestamp'] < self.cache_ttl:
                return cache_entry['price']
        
        # Convertir le format du symbole pour Kraken
        kraken_symbol = self._get_kraken_symbol(symbol)
        
        try:
            # Récupérer le ticker
            response = self.query_public("Ticker", {"pair": kraken_symbol})
            
            # Vérifier les erreurs
            if 'error' in response and response['error']:
                logger.warning(f"Erreur ticker: {response['error']} pour {symbol}")
                return None
            
            # Extraire le prix
            result = response['result']
            pair_data = result[list(result.keys())[0]]
            price = float(pair_data['c'][0])  # 'c' est le prix de clôture
            
            # Mettre à jour le cache
            self.price_cache[symbol] = {
                'price': price,
                'timestamp': now
            }
            
            return price
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {symbol}: {e}")
            return None
    
    def get_ohlcv(self, symbol, timeframe='1h', limit=100):
        """
        Récupère les données OHLCV pour un symbole
        
        Args:
            symbol (str): Symbole de la paire (ex: "BTC/USD")
            timeframe (str): Intervalle de temps
            limit (int): Nombre de périodes
            
        Returns:
            list: Données OHLCV ou None en cas d'erreur
        """
        # Convertir le timeframe au format Kraken
        interval_map = {
            '1m': 1, '5m': 5, '15m': 15, '30m': 30,
            '1h': 60, '4h': 240, '1d': 1440, '1w': 10080
        }
        
        if timeframe not in interval_map:
            logger.error(f"Timeframe non supporté: {timeframe}")
            return None
        
        # Convertir le format du symbole pour Kraken
        kraken_symbol = self._get_kraken_symbol(symbol)
        
        try:
            # Récupérer les données OHLCV
            response = self.query_public("OHLC", {
                "pair": kraken_symbol,
                "interval": interval_map[timeframe],
                "since": int(time.time() - limit * interval_map[timeframe] * 60)
            }, cache=True)
            
            # Vérifier les erreurs
            if 'error' in response and response['error']:
                logger.warning(f"Erreur OHLCV: {response['error']} pour {symbol}")
                return None
            
            # Extraire les données
            result = response['result']
            pair_data = result[list(filter(lambda x: x != 'last', result.keys()))[0]]
            
            # Convertir au format standard
            ohlcv = [
                [
                    data[0] * 1000,  # timestamp (ms)
                    float(data[1]),  # open
                    float(data[2]),  # high
                    float(data[3]),  # low
                    float(data[4]),  # close
                    float(data[6])   # volume
                ] for data in pair_data
            ]
            
            return ohlcv
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération OHLCV pour {symbol}: {e}")
            return None
    
    def get_orderbook(self, symbol, limit=10):
        """
        Récupère le carnet d'ordres pour un symbole
        
        Args:
            symbol (str): Symbole de la paire (ex: "BTC/USD")
            limit (int): Profondeur du carnet
            
        Returns:
            dict: Carnet d'ordres ou None en cas d'erreur
        """
        # Vérifier le cache
        now = time.time()
        if symbol in self.orderbook_cache:
            cache_entry = self.orderbook_cache[symbol]
            if now - cache_entry['timestamp'] < 5:  # TTL de 5s pour orderbook
                return cache_entry['data']
        
        # Convertir le format du symbole pour Kraken
        kraken_symbol = self._get_kraken_symbol(symbol)
        
        try:
            # Récupérer le carnet d'ordres
            response = self.query_public("Depth", {
                "pair": kraken_symbol,
                "count": limit
            })
            
            # Vérifier les erreurs
            if 'error' in response and response['error']:
                logger.warning(f"Erreur orderbook: {response['error']} pour {symbol}")
                return None
            
            # Extraire les données
            result = response['result']
            pair_data = result[list(result.keys())[0]]
            
            # Convertir au format standard
            orderbook = {
                'asks': [[float(ask[0]), float(ask[1])] for ask in pair_data['asks']],
                'bids': [[float(bid[0]), float(bid[1])] for bid in pair_data['bids']]
            }
            
            # Mettre à jour le cache
            self.orderbook_cache[symbol] = {
                'data': orderbook,
                'timestamp': now
            }
            
            return orderbook
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du carnet d'ordres pour {symbol}: {e}")
            return None
    
    def get_balance(self):
        """
        Récupère les soldes du compte
        
        Returns:
            dict: Soldes ou None en cas d'erreur
        """
        try:
            # Récupérer les soldes
            response = self.query_private("Balance")
            
            # Vérifier les erreurs
            if 'error' in response and response['error']:
                logger.warning(f"Erreur balance: {response['error']}")
                return None
            
            # Extraire les données
            balances = response['result']
            
            # Convertir au format standard
            return balances
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances: {e}")
            return None
    
    def create_order(self, symbol, order_type, side, amount, price=None):
        """
        Crée un ordre sur Kraken
        
        Args:
            symbol (str): Symbole de la paire (ex: "BTC/USD")
            order_type (str): Type d'ordre ("market", "limit")
            side (str): Côté de l'ordre ("buy", "sell")
            amount (float): Quantité
            price (float, optional): Prix pour les ordres limit
            
        Returns:
            dict: Réponse ou None en cas d'erreur
        """
        # Convertir le format du symbole pour Kraken
        kraken_symbol = self._get_kraken_symbol(symbol)
        
        # Préparer les données de l'ordre
        data = {
            "pair": kraken_symbol,
            "type": side,
            "ordertype": order_type,
            "volume": str(amount)
        }
        
        # Ajouter le prix pour les ordres limit
        if order_type == "limit" and price:
            data["price"] = str(price)
        
        try:
            # Créer l'ordre
            response = self.query_private("AddOrder", data)
            
            # Vérifier les erreurs
            if 'error' in response and response['error']:
                logger.warning(f"Erreur création d'ordre: {response['error']}")
                return None
            
            # Extraire les données
            result = response['result']
            
            # Convertir au format standard
            return result
            
        except Exception as e:
            logger.error(f"Erreur lors de la création d'ordre pour {symbol}: {e}")
            return None
    
    def get_trading_fees(self, symbol=None):
        """
        Récupère les frais de trading
        
        Args:
            symbol (str, optional): Symbole de la paire
            
        Returns:
            dict: Frais de trading ou None en cas d'erreur
        """
        # Si les frais sont déjà en cache pour ce symbole
        if symbol and symbol in self.fee_rates:
            return self.fee_rates[symbol]
        
        try:
            # Récupérer les frais
            response = self.query_private("TradeVolume", {"pair": symbol} if symbol else {})
            
            # Vérifier les erreurs
            if 'error' in response and response['error']:
                logger.warning(f"Erreur frais: {response['error']}")
                return None
            
            # Extraire les données
            result = response['result']
            
            # Frais par défaut si non spécifiés
            fees = {
                'maker': 0.0016,  # 0.16%
                'taker': 0.0026   # 0.26%
            }
            
            # Extraire les frais spécifiques si disponibles
            if 'fees' in result and symbol:
                kraken_symbol = self._get_kraken_symbol(symbol)
                if kraken_symbol in result['fees']:
                    fee_info = result['fees'][kraken_symbol]
                    fees = {
                        'maker': float(fee_info['maker']),
                        'taker': float(fee_info['taker'])
                    }
            
            # Mettre en cache
            if symbol:
                self.fee_rates[symbol] = fees
            
            return fees
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des frais: {e}")
            return None
    
    def _get_kraken_symbol(self, symbol):
        """
        Convertit un symbole standard en format Kraken
        
        Args:
            symbol (str): Symbole standard (ex: "BTC/USD")
            
        Returns:
            str: Symbole au format Kraken
        """
        if '/' not in symbol:
            return symbol
            
        base, quote = symbol.split('/')
        
        # Map des symboles spéciaux
        special_symbols = {
            'BTC': 'XBT',
            'DOGE': 'XDG'
        }
        
        # Convertir les symboles spéciaux
        if base in special_symbols:
            base = special_symbols[base]
        if quote in special_symbols:
            quote = special_symbols[quote]
        
        # Ajouter le préfixe Z/X pour certaines paires
        majors = ['USD', 'EUR', 'CAD', 'GBP', 'JPY', 'CHF']
        crypto_with_prefix = ['XBT', 'ETH', 'XRP', 'XLM', 'LTC', 'XMR', 'DASH', 'XDG', 'EOS', 'BCH']
        
        if base in crypto_with_prefix and quote in majors:
            base = 'X' + base
            quote = 'Z' + quote
        
        # Combiner les symboles
        return base + quote
    
    def get_server_time(self):
        """
        Récupère l'heure du serveur Kraken
        
        Returns:
            int: Timestamp Unix ou None en cas d'erreur
        """
        try:
            response = self.query_public("Time")
            
            if 'error' in response and response['error']:
                logger.warning(f"Erreur time: {response['error']}")
                return None
            
            return response['result']['unixtime']
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération de l'heure: {e}")
            return None
    
    def test_connectivity(self):
        """
        Teste la connectivité à l'API Kraken
        
        Returns:
            bool: True si la connexion fonctionne
        """
        try:
            server_time = self.get_server_time()
            return server_time is not None
        except Exception:
            return False
    
    @lru_cache(maxsize=100)
    def get_asset_info(self, asset):
        """
        Récupère les informations sur un actif
        
        Args:
            asset (str): Symbole de l'actif
            
        Returns:
            dict: Informations sur l'actif
        """
        try:
            response = self.query_public("Assets", {"asset": asset})
            
            if 'error' in response and response['error']:
                logger.warning(f"Erreur asset info: {response['error']}")
                return None
            
            if asset in response['result']:
                return response['result'][asset]
            
            return None
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des infos pour {asset}: {e}")
            return None
    
    def get_open_orders(self):
        """
        Récupère les ordres ouverts
        
        Returns:
            dict: Ordres ouverts ou None en cas d'erreur
        """
        try:
            response = self.query_private("OpenOrders")
            
            if 'error' in response and response['error']:
                logger.warning(f"Erreur open orders: {response['error']}")
                return None
            
            return response['result']
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des ordres ouverts: {e}")
            return None
    
    def cancel_order(self, order_id):
        """
        Annule un ordre
        
        Args:
            order_id (str): ID de l'ordre
            
        Returns:
            bool: True si l'ordre a été annulé
        """
        try:
            response = self.query_private("CancelOrder", {"txid": order_id})
            
            if 'error' in response and response['error']:
                logger.warning(f"Erreur cancel order: {response['error']}")
                return False
            
            return response['result']['count'] > 0
            
        except Exception as e:
            logger.error(f"Erreur lors de l'annulation de l'ordre {order_id}: {e}")
            return False


# Fonctions utilitaires
def setup_optimized_kraken_client(api_key=None, api_secret=None):
    """
    Configure un client Kraken optimisé
    
    Args:
        api_key (str, optional): Clé API Kraken
        api_secret (str, optional): Clé secrète API Kraken
        
    Returns:
        OptimizedKrakenClient: Client optimisé
    """
    # Charger les clés depuis les variables d'environnement si non fournies
    if not api_key:
        api_key = os.environ.get('KRAKEN_API_KEY')
    if not api_secret:
        api_secret = os.environ.get('KRAKEN_API_SECRET')
    
    # Créer le client
    client = OptimizedKrakenClient(api_key, api_secret)
    
    # Tester la connectivité
    if client.test_connectivity():
        logger.info("Connexion à Kraken établie avec succès")
    else:
        logger.warning("Impossible de se connecter à Kraken")
    
    return client