"""
Bot de trading en cryptomonnaies - REAL TRADING MODE
- Se connecte à l'API Kraken
- Utilise l'analyse de sentiment et de volatilité
- Trading 24/7 sur les cryptos les plus volatiles
- Stop-loss dynamique adapté au momentum
- Trading HF avec réponses en microsecondes
"""
import os
import logging
from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration de Flask
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "crypto_trading_bot_secret")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configuration de la base de données
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

# Import d'autres modules après l'initialisation de l'application
from models import APIKey, Trade, AssetData, BotState
from advanced_real_trader import AdvancedRealTrader

# Variable globale pour le bot
trader = None

@app.before_request
def initialize_database():
    """Initialise la base de données si ce n'est pas déjà fait"""
    with app.app_context():
        db.create_all()

def get_trader():
    """Récupère ou initialise le trader"""
    global trader
    
    if trader is None:
        # Récupérer la clé API la plus récente
        api_key_record = APIKey.query.order_by(APIKey.last_used.desc()).first()
        
        if api_key_record:
            logger.info("Utilisation de clés API depuis la base de données")
            api_key = api_key_record.api_key
            api_secret = api_key_record.api_secret
            
            # Mise à jour de l'horodatage de dernière utilisation
            api_key_record.last_used = datetime.utcnow()
            db.session.commit()
        else:
            # Utiliser les variables d'environnement
            logger.info("Utilisation de clés API depuis les variables d'environnement")
            api_key = os.environ.get('KRAKEN_API_KEY')
            api_secret = os.environ.get('KRAKEN_API_SECRET')
        
        if not api_key or not api_secret:
            raise ValueError("Clés API Kraken manquantes")
        
        # Créer le trader
        trader = AdvancedRealTrader(api_key, api_secret)
        
        # Enregistrer l'état initial dans la base de données
        bot_state = BotState.query.first()
        if not bot_state:
            bot_state = BotState(running=False)
            db.session.add(bot_state)
            db.session.commit()
    
    return trader

@app.route('/')
def index():
    """Page principale de l'application"""
    # Vérifier l'état du bot
    bot_state = BotState.query.first()
    bot_running = bot_state.running if bot_state else False
    
    return render_template('index.html', bot_running=bot_running)

@app.route('/configure_api', methods=['POST'])
def configure_api():
    """Configure les clés API Kraken"""
    try:
        api_key = request.form.get('api_key')
        api_secret = request.form.get('api_secret')
        
        if not api_key or len(api_key) < 10 or not api_secret or len(api_secret) < 10:
            return jsonify({'success': False, 'error': 'Clés API invalides ou trop courtes'})
        
        # Enregistrer les nouvelles clés API
        new_key = APIKey(api_key=api_key, api_secret=api_secret, last_used=datetime.utcnow())
        db.session.add(new_key)
        db.session.commit()
        
        # Mettre à jour les variables d'environnement
        os.environ['KRAKEN_API_KEY'] = api_key
        os.environ['KRAKEN_API_SECRET'] = api_secret
        
        # Réinitialiser le trader
        global trader
        if trader:
            trader.stop()
            trader = None
        
        # Initialiser le nouveau trader
        try:
            trader = get_trader()
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'success': False, 'error': f"Impossible d'initialiser le trader: {str(e)}"})
    except Exception as e:
        logger.error(f"Erreur de configuration API: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/start_bot', methods=['POST'])
def start_bot():
    """Démarre le bot de trading"""
    try:
        trader = get_trader()
        
        # Vérifier s'il est déjà en cours d'exécution
        bot_state = BotState.query.first()
        if bot_state and bot_state.running:
            return jsonify({'success': False, 'error': 'Le bot est déjà en cours d\'exécution'})
        
        # Démarrer le trader
        success = trader.start()
        
        if success:
            # Mettre à jour l'état dans la base de données
            bot_state.running = True
            bot_state.started_at = datetime.utcnow()
            bot_state.stopped_at = None
            db.session.commit()
        
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Erreur de démarrage du bot: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/stop_bot', methods=['POST'])
def stop_bot():
    """Arrête le bot de trading"""
    try:
        trader = get_trader()
        
        # Vérifier s'il est en cours d'exécution
        bot_state = BotState.query.first()
        if bot_state and not bot_state.running:
            return jsonify({'success': False, 'error': 'Le bot n\'est pas en cours d\'exécution'})
        
        # Arrêter le trader
        success = trader.stop()
        
        if success:
            # Mettre à jour l'état dans la base de données
            bot_state.running = False
            bot_state.stopped_at = datetime.utcnow()
            db.session.commit()
        
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Erreur d'arrêt du bot: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/force_trade_btc', methods=['POST'])
def force_trade_btc():
    """Convertit des actifs en BTC"""
    try:
        trader = get_trader()
        success = trader.convert_to_btc()
        
        # Synchroniser les données du trader avec la base de données
        sync_trader_data()
        
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Erreur de conversion en BTC: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/force_trade_audio', methods=['POST'])
def force_trade_audio():
    """Convertit des actifs en AUDIO"""
    try:
        trader = get_trader()
        success = trader.convert_to_audio()
        
        # Synchroniser les données du trader avec la base de données
        sync_trader_data()
        
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Erreur de conversion en AUDIO: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/force_trade_any', methods=['POST'])
def force_trade_any():
    """Convertit des actifs en cryptos volatiles"""
    try:
        trader = get_trader()
        success = trader.convert_to_volatile()
        
        # Synchroniser les données du trader avec la base de données
        sync_trader_data()
        
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Erreur de conversion en cryptos volatiles: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get_data', methods=['GET'])
def get_data():
    """Récupère les données actuelles du trader"""
    try:
        trader = get_trader()
        status = trader.get_status()
        
        # Ajouter les trades récents depuis la base de données
        recent_trades = []
        trades = Trade.query.order_by(Trade.timestamp.desc()).limit(20).all()
        
        for trade in trades:
            recent_trades.append({
                'timestamp': trade.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'asset': trade.asset,
                'action': trade.action,
                'amount': trade.amount,
                'price': trade.price,
                'sentiment': trade.sentiment,
                'volatility': trade.volatility,
                'bubble_score': trade.bubble_score,
                'total_usdt': trade.total_usdt
            })
        
        status['recent_trades'] = recent_trades
        
        # Ajouter l'état du bot
        bot_state = BotState.query.first()
        status['bot_running'] = bot_state.running if bot_state else False
        
        return jsonify(status)
    except Exception as e:
        logger.error(f"Erreur de récupération des données: {e}")
        return jsonify({'success': False, 'error': str(e)})

def sync_trader_data():
    """Synchronise les données du trader avec la base de données"""
    try:
        trader = get_trader()
        
        # Synchroniser les trades
        if hasattr(trader, 'trade_history'):
            for trade_data in trader.trade_history:
                # Vérifier si le trade existe déjà
                existing_trade = Trade.query.filter(
                    Trade.timestamp == trade_data['timestamp'],
                    Trade.asset == trade_data['asset'],
                    Trade.action == trade_data['action'],
                    Trade.amount == trade_data['amount']
                ).first()
                
                if not existing_trade:
                    # Créer un nouveau trade
                    new_trade = Trade(
                        timestamp=trade_data['timestamp'],
                        asset=trade_data['asset'],
                        action=trade_data['action'],
                        amount=trade_data['amount'],
                        price=trade_data['price'],
                        sentiment=trade_data.get('sentiment'),
                        volatility=trade_data.get('volatility'),
                        bubble_score=trade_data.get('bubble_score'),
                        total_usdt=trade_data.get('total_usdt')
                    )
                    db.session.add(new_trade)
        
        # Synchroniser les données des actifs
        if hasattr(trader, 'asset_data'):
            for asset, data in trader.asset_data.items():
                # Vérifier si les données existent déjà
                existing_data = AssetData.query.filter(
                    AssetData.asset == asset,
                    AssetData.timestamp >= datetime.utcnow() - timedelta(minutes=5)
                ).first()
                
                if not existing_data:
                    # Créer de nouvelles données
                    new_data = AssetData(
                        asset=asset,
                        price=data.get('price', 0),
                        volatility=data.get('volatility', 0),
                        sentiment=data.get('sentiment', 0),
                        bubble_score=data.get('bubble_score', 0),
                        timestamp=datetime.utcnow()
                    )
                    db.session.add(new_data)
        
        db.session.commit()
    except Exception as e:
        logger.error(f"Erreur de synchronisation des données: {e}")
        db.session.rollback()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)