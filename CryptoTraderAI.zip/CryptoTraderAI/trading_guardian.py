#!/usr/bin/env python3
"""
GUARDIAN DU TRADER - SURVEILLE 24/7
S'assure que le trader tourne en permanence et gère tous les problèmes

Ce script a une tolérance aux pannes extrême:
1. Vérifie la santé du trader toutes les minutes
2. Redémarre automatiquement en cas de crash
3. Réinitialise le nonce Kraken en cas d'erreur d'API
4. Garde une trace de toutes les actions dans un fichier de log
"""
import os
import sys
import time
import logging
import datetime
import subprocess
import signal
from pathlib import Path

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("guardian.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Guardian")

# Variables globales
TRADER_PID_FILE = "trader.pid"
TRADER_HEARTBEAT_FILE = "trader_heartbeat.txt"
GUARDIAN_HEARTBEAT_FILE = "guardian_heartbeat.txt"
MAX_HEARTBEAT_AGE = 90  # secondes
RESTART_COOLDOWN = 600  # secondes (10 minutes)
last_restart_time = 0
restart_count = 0

def update_guardian_heartbeat():
    """Met à jour le fichier de heartbeat du guardian"""
    try:
        with open(GUARDIAN_HEARTBEAT_FILE, "w") as f:
            f.write(f"Guardian actif: {datetime.datetime.now()}\n")
            f.write(f"Redémarrages: {restart_count}\n")
            f.write(f"Dernier redémarrage: {datetime.datetime.fromtimestamp(last_restart_time) if last_restart_time else 'Jamais'}\n")
    except Exception as e:
        logger.error(f"Erreur lors de la mise à jour du heartbeat guardian: {e}")

def check_trader_health():
    """
    Vérifie si le trader est en bonne santé
    
    Returns:
        tuple: (is_running, reason, pid)
    """
    # Vérifier le fichier PID
    if os.path.exists(TRADER_PID_FILE):
        try:
            with open(TRADER_PID_FILE, "r") as f:
                pid = int(f.read().strip())
            
            # Vérifier si le processus existe
            try:
                os.kill(pid, 0)  # Vérifie seulement, ne tue pas le processus
                
                # Vérifier aussi le heartbeat pour s'assurer que le trader n'est pas bloqué
                if os.path.exists(TRADER_HEARTBEAT_FILE):
                    heartbeat_age = time.time() - os.path.getmtime(TRADER_HEARTBEAT_FILE)
                    if heartbeat_age > MAX_HEARTBEAT_AGE:
                        return False, f"Heartbeat périmé ({heartbeat_age:.1f}s)", pid
                
                return True, "PID actif", pid
            except OSError:
                return False, "PID invalide", None
        except Exception as e:
            return False, f"Erreur PID: {e}", None
    
    # Vérifier le heartbeat même sans fichier PID
    if os.path.exists(TRADER_HEARTBEAT_FILE):
        heartbeat_age = time.time() - os.path.getmtime(TRADER_HEARTBEAT_FILE)
        if heartbeat_age <= MAX_HEARTBEAT_AGE:
            return True, "Heartbeat récent", None
    
    return False, "Aucun signe de vie", None

def reset_kraken_nonce():
    """Réinitialise le nonce Kraken en cas de problème"""
    try:
        logger.info("Réinitialisation du nonce Kraken...")
        subprocess.run([sys.executable, "kraken_nonce_manager.py", "reset"], 
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        logger.info("✅ Nonce Kraken réinitialisé")
        return True
    except Exception as e:
        logger.error(f"❌ Erreur lors de la réinitialisation du nonce: {e}")
        return False

def kill_trader_process(pid=None):
    """Tue le processus du trader s'il est encore en vie"""
    try:
        # Tuer par PID si disponible
        if pid:
            try:
                os.kill(pid, signal.SIGTERM)
                time.sleep(1)
                try:
                    os.kill(pid, signal.SIGKILL)  # Kill forcé si toujours en vie
                except OSError:
                    pass  # Déjà mort
                logger.info(f"Trader (PID {pid}) tué")
                return True
            except OSError:
                pass  # Processus déjà mort
        
        # Tuer tous les processus potentiels
        subprocess.run(["pkill", "-f", "auto_trader_verified.py"], 
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Supprimer le fichier PID
        if os.path.exists(TRADER_PID_FILE):
            os.remove(TRADER_PID_FILE)
        
        return True
    except Exception as e:
        logger.error(f"Erreur lors de la tentative de tuer le trader: {e}")
        return False

def restart_trader():
    """Redémarre le trader automatique"""
    global last_restart_time, restart_count
    
    # Vérifier le cooldown
    current_time = time.time()
    if current_time - last_restart_time < RESTART_COOLDOWN:
        remaining = RESTART_COOLDOWN - (current_time - last_restart_time)
        logger.warning(f"Délai de redémarrage en cours ({remaining:.1f}s restantes)")
        return False
    
    try:
        logger.info("🔄 REDÉMARRAGE DU TRADER")
        
        # Vérifier la santé actuelle
        running, reason, pid = check_trader_health()
        
        # Tuer le processus existant si nécessaire
        if running or pid:
            kill_trader_process(pid)
        
        # Réinitialiser le nonce Kraken
        reset_kraken_nonce()
        
        # S'assurer que les scripts sont exécutables
        os.system('chmod +x auto_trader_verified.py')
        
        # Démarrer le trader
        logger.info("Démarrage d'une nouvelle instance...")
        subprocess.Popen([
            sys.executable, "auto_trader_verified.py"
        ], stdout=open("auto_trader_output.log", "a"), stderr=subprocess.STDOUT)
        
        # Mettre à jour les compteurs
        last_restart_time = current_time
        restart_count += 1
        
        logger.info(f"✅ Trader redémarré (redémarrage #{restart_count})")
        return True
    except Exception as e:
        logger.error(f"❌ Erreur lors du redémarrage du trader: {e}")
        return False

def check_log_for_errors():
    """Vérifie les logs pour des erreurs connues qui nécessitent une action"""
    try:
        # Vérifier uniquement les 20 dernières lignes pour être efficace
        recent_logs = subprocess.check_output(
            ["tail", "-n", "20", "auto_trader_verified.log"]
        ).decode('utf-8')
        
        # Rechercher des messages d'erreur spécifiques
        if "EAPI:Invalid nonce" in recent_logs:
            logger.warning("Erreur de nonce détectée dans les logs")
            reset_kraken_nonce()
            return True
        
        # On pourrait ajouter plus de détection d'erreurs ici
        
        return False
    except Exception as e:
        logger.error(f"Erreur lors de la vérification des logs: {e}")
        return False

def main():
    """Fonction principale - Boucle de surveillance infinie"""
    global last_restart_time
    
    logger.info("=" * 80)
    logger.info("🛡️  GUARDIAN DU TRADER DÉMARRÉ - SURVEILLANCE 24/7")
    logger.info("=" * 80)
    
    # Initialisation
    if not os.path.exists(GUARDIAN_HEARTBEAT_FILE):
        update_guardian_heartbeat()
    
    # Démarrer le trader au lancement du guardian
    restart_trader()
    
    # Boucle de surveillance infinie
    try:
        while True:
            # Mettre à jour le heartbeat du guardian
            update_guardian_heartbeat()
            
            # Vérifier la santé du trader
            running, reason, pid = check_trader_health()
            
            if running:
                logger.info(f"Trader en bonne santé: {reason}")
            else:
                logger.warning(f"Trader non fonctionnel: {reason}")
                
                # Vérifier les logs pour des erreurs connues
                check_log_for_errors()
                
                # Redémarrer le trader
                restart_trader()
            
            # Pause avant la prochaine vérification
            time.sleep(60)  # Vérification toutes les minutes
            
    except KeyboardInterrupt:
        logger.info("Guardian arrêté par l'utilisateur")
    finally:
        logger.info("Guardian terminé")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.error(f"Erreur fatale dans le guardian: {e}")
        # Essayer de relancer le guardian lui-même
        os.execv(sys.executable, [sys.executable] + sys.argv)