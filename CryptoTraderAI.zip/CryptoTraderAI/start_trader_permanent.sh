#!/bin/bash
# Script pour démarrer le trader de façon permanente
# Ce script relance automatiquement le trader en cas d'échec

echo "===== DÉMARRAGE DU SYSTÈME DE TRADING PERMANENT ====="
echo "Date: $(date)"
echo "====================================================="

# Fonction pour vérifier si le trader est en vie
is_trader_alive() {
    if [ -f "auto_trader_pid.txt" ]; then
        PID=$(cat auto_trader_pid.txt)
        if ps -p $PID > /dev/null; then
            return 0  # Trader vivant
        fi
    fi
    return 1  # Trader mort ou inexistant
}

# Fonction pour tuer tout processus existant
kill_existing_processes() {
    echo "Arrêt des processus existants..."
    pkill -f "auto_trader_verified.py" || true
    pkill -f "trading_guardian.py" || true
    sleep 2
    echo "Processus arrêtés"
}

# Nettoyer tout au démarrage
kill_existing_processes

# Mettre les droits d'exécution sur les scripts si besoin
chmod +x auto_trader_verified.py

# Boucle de redémarrage infinie
while true; do
    echo "$(date) - Démarrage du trader avec gestion des frais..."
    
    # Lancer le trader en arrière-plan
    nohup python3 auto_trader_verified.py > auto_trader_output.log 2>&1 &
    TRADER_PID=$!
    echo $TRADER_PID > auto_trader_pid.txt
    echo "Trader démarré avec PID: $TRADER_PID"
    
    # Attendre 5 secondes pour s'assurer que le trader démarre correctement
    sleep 5
    
    # Vérifier si le trader est toujours en vie
    if is_trader_alive; then
        echo "Trader démarré avec succès"
    else
        echo "Erreur: Le trader n'a pas pu démarrer correctement"
    fi
    
    # Maintenir le trader en vie
    while is_trader_alive; do
        echo "$(date) - Trader en cours d'exécution (PID: $TRADER_PID)" > trader_status.log
        sleep 60
    done
    
    echo "$(date) - ⚠️ TRADER ARRÊTÉ ! Redémarrage dans 5 secondes..."
    sleep 5
    kill_existing_processes
done