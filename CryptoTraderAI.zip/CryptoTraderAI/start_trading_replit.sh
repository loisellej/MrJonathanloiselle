#!/bin/bash

# Fichier pour démarrer automatiquement le trader sur Replit
# Ce script est prévu pour être exécuté au démarrage de Replit

echo "=== DÉMARRAGE DU BOT DE TRADING ULTRA-VOLATIL ==="
date

# Tuer les instances existantes
pkill -f "python.*start_24_7_trader.py" || true
sleep 1

# Vérifier les clés API
echo "Vérification des clés API Kraken..."
python3 test_api_key.py

# Si les clés sont valides, démarrer le bot
if [ $? -eq 0 ]; then
    echo "Démarrage du bot de trading en arrière-plan..."
    nohup python3 start_24_7_trader.py > trader_24_7.log 2>&1 &
    PID=$!
    echo $PID > trader.pid
    
    # Attendre que le bot démarre
    sleep 5
    
    # Vérifier si le bot est en cours d'exécution
    if ps -p $PID > /dev/null; then
        echo -e "\e[32mBot démarré avec succès!\e[0m"
        echo "=== BOT DE TRADING DÉMARRÉ AVEC SUCCÈS ==="
        echo "Les logs sont disponibles dans trader_24_7.log"
        echo
        echo "Vous pouvez vérifier l'état du bot à tout moment avec:"
        echo "  python3 check_status.py"
        echo
        echo "----- $(date) -----"
        # Afficher les premières lignes de log
        head -n 20 trader_24_7.log
        
        echo
        echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
        echo "TRADER DÉMARRÉ AVEC SUCCÈS!"
        echo "Le système recherche et trade maintenant les cryptos ultra-volatiles en uptrend"
        echo "Objectif: 2-3% par trade, stop-loss serré 0.5-0.8%"
        echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    else
        echo -e "\e[31mErreur: Le bot n'a pas pu démarrer correctement.\e[0m"
        echo "Vérifiez les logs pour plus d'informations: trader_24_7.log"
    fi
else
    echo -e "\e[31mErreur: Les clés API Kraken ne sont pas valides.\e[0m"
    echo "Le bot ne peut pas démarrer sans clés API valides."
    echo "Veuillez configurer des clés API valides."
fi