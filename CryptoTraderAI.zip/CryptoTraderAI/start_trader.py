#!/usr/bin/env python3
"""
Script de démarrage du trader automatique
Ce script démarre le trader et s'assure qu'il reste en cours d'exécution
"""
import os
import sys
import time
import logging
import subprocess
from pathlib import Path

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("start_trader.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("StartTrader")

def is_trader_running():
    """Vérifie si le trader est déjà en cours d'exécution"""
    # Vérifier le fichier PID
    if os.path.exists("trader.pid"):
        try:
            with open("trader.pid", "r") as f:
                pid = int(f.read().strip())
            
            # Vérifier si le processus existe
            try:
                os.kill(pid, 0)
                return True, pid
            except OSError:
                return False, None
        except:
            return False, None
    
    # Vérifier le heartbeat
    if os.path.exists("trader_heartbeat.txt"):
        try:
            mtime = os.path.getmtime("trader_heartbeat.txt")
            # Si le heartbeat date de moins de 60 secondes
            if time.time() - mtime < 60:
                return True, None
        except:
            pass
    
    return False, None

def start_trader():
    """Démarre le trader automatique"""
    try:
        # Vérifier si le trader est déjà en cours d'exécution
        running, pid = is_trader_running()
        if running:
            logger.info(f"Le trader est déjà en cours d'exécution (PID: {pid})")
            return True
        
        # S'assurer que les script sont exécutables
        os.system('chmod +x auto_trader_verified.py')
        
        # Démarrer le trader en arrière-plan
        logger.info("Démarrage du trader automatique...")
        subprocess.Popen([
            sys.executable, "auto_trader_verified.py"
        ], stdout=open("auto_trader_output.log", "w"), stderr=subprocess.STDOUT)
        
        # Vérifier si le démarrage a réussi
        time.sleep(5)
        running, pid = is_trader_running()
        if running:
            logger.info(f"✅ Trader démarré avec succès (PID: {pid})")
            return True
        else:
            logger.error("❌ Échec du démarrage du trader")
            return False
    except Exception as e:
        logger.error(f"❌ Erreur lors du démarrage du trader: {e}")
        return False

def reset_kraken_nonce():
    """Réinitialise le nonce Kraken en cas de problème"""
    try:
        # Réinitialiser le nonce
        subprocess.run([sys.executable, "kraken_nonce_manager.py", "reset"], 
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        logger.info("✅ Nonce Kraken réinitialisé")
        return True
    except Exception as e:
        logger.error(f"❌ Erreur lors de la réinitialisation du nonce: {e}")
        return False

def main():
    """Fonction principale"""
    logger.info("=" * 80)
    logger.info("🚀 DÉMARRAGE DU TRADER AUTOMATIQUE - MODE LIVE UNIQUEMENT")
    logger.info("=" * 80)
    
    # Réinitialiser le nonce en premier pour éviter les erreurs
    reset_kraken_nonce()
    
    # Démarrer le trader
    if start_trader():
        logger.info("Trader démarré. Surveillance active...")
        
        # Surveiller le trader
        try:
            while True:
                running, pid = is_trader_running()
                if not running:
                    logger.warning("Le trader n'est plus en cours d'exécution, redémarrage...")
                    reset_kraken_nonce()  # Réinitialiser le nonce avant le redémarrage
                    start_trader()
                
                # Attendre 30 secondes
                time.sleep(30)
        except KeyboardInterrupt:
            logger.info("Surveillance arrêtée par l'utilisateur")
    else:
        logger.error("Impossible de démarrer le trader")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Programme arrêté par l'utilisateur")
    except Exception as e:
        logger.error(f"Erreur fatale: {e}")
        sys.exit(1)