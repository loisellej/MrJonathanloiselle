import os
import ccxt
import time
import random
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='volatile_assets.log'
)
logger = logging.getLogger()

# Liste d'actifs à exclure
EXCLUDED_ASSETS = ['BTC', 'ETH', 'SOL']

def setup_exchange():
    """Configure la connexion à Kraken avec les clés API"""
    api_key = os.environ.get('KRAKEN_API_KEY')
    api_secret = os.environ.get('KRAKEN_API_SECRET')
    
    if not api_key or not api_secret:
        logger.error("Clés API Kraken manquantes")
        return None
    
    try:
        exchange = ccxt.kraken({
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True,
            'timeout': 30000
        })
        logger.info("Connexion à Kraken établie avec succès")
        return exchange
    except Exception as e:
        logger.error(f"Erreur lors de la connexion à Kraken: {e}")
        return None
        
def get_all_tradeable_assets(exchange):
    """Récupère la liste de tous les actifs négociables sur USDT ou USD"""
    try:
        # Récupérer tous les marchés
        markets = exchange.load_markets()
        
        # Filtrer les paires négociables contre USDT ou USD
        tradeable_assets = []
        for symbol in markets:
            if '/USDT' in symbol or '/USD' in symbol:
                # Extraire le symbole de base (première partie de la paire)
                base = symbol.split('/')[0]
                if base not in EXCLUDED_ASSETS and base not in tradeable_assets:
                    tradeable_assets.append(base)
        
        logger.info(f"Récupération de {len(tradeable_assets)} actifs négociables")
        return tradeable_assets
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des actifs négociables: {e}")
        return []

def analyze_volatility(exchange, asset, timeframe='1h', limit=24):
    """Analyse la volatilité d'un actif"""
    try:
        # Construire le symbole en fonction de la disponibilité
        symbol_usdt = f"{asset}/USDT"
        symbol_usd = f"{asset}/USD"
        
        symbol = symbol_usdt if symbol_usdt in exchange.markets else symbol_usd
        
        if symbol not in exchange.markets:
            logger.warning(f"Symbole {symbol} non disponible sur l'exchange")
            return 0.0
            
        # Récupérer les données OHLCV
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        
        if not ohlcv or len(ohlcv) < 2:
            logger.warning(f"Données OHLCV insuffisantes pour {symbol}")
            return 0.0
            
        # Calculer les changements de prix en pourcentage
        changes = []
        for i in range(1, len(ohlcv)):
            prev_close = ohlcv[i-1][4]  # Prix de clôture précédent
            current_close = ohlcv[i][4]  # Prix de clôture actuel
            if prev_close > 0:
                pct_change = abs((current_close - prev_close) / prev_close) * 100
                changes.append(pct_change)
        
        # Calculer la volatilité moyenne
        if changes:
            volatility = sum(changes) / len(changes)
            logger.info(f"Volatilité de {symbol}: {volatility:.2f}%")
            return volatility
        else:
            logger.warning(f"Aucun changement de prix calculé pour {symbol}")
            return 0.0
            
    except Exception as e:
        logger.error(f"Erreur lors de l'analyse de la volatilité pour {asset}: {e}")
        return 0.0

def analyze_uptrend(exchange, asset, timeframes=['1h', '4h', '1d']):
    """Analyse si un actif est en tendance haussière"""
    try:
        # Construire le symbole en fonction de la disponibilité
        symbol_usdt = f"{asset}/USDT"
        symbol_usd = f"{asset}/USD"
        
        symbol = symbol_usdt if symbol_usdt in exchange.markets else symbol_usd
        
        if symbol not in exchange.markets:
            logger.warning(f"Symbole {symbol} non disponible pour l'analyse de tendance")
            return 0.0
            
        # Analyser chaque timeframe
        uptrend_scores = []
        
        for timeframe in timeframes:
            # Récupérer les données OHLCV
            ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=14)
            
            if not ohlcv or len(ohlcv) < 5:
                continue
                
            # Calculer une moyenne mobile simple sur 3 périodes
            closes = [candle[4] for candle in ohlcv]
            sma3 = sum(closes[-3:]) / 3
            
            # Calculer une moyenne mobile simple sur 7 périodes
            sma7 = sum(closes[-7:]) / 7
            
            # Le dernier prix de clôture
            last_close = closes[-1]
            
            # Prix d'ouverture et de clôture de la dernière bougie
            last_open = ohlcv[-1][1]
            
            # Vérifier si le prix est au-dessus des moyennes mobiles
            above_sma3 = last_close > sma3
            above_sma7 = last_close > sma7
            
            # Vérifier si la dernière bougie est haussière
            bullish_candle = last_close > last_open
            
            # Calculer un score de tendance haussière
            score = 0.0
            if above_sma3:
                score += 0.3
            if above_sma7:
                score += 0.3
            if bullish_candle:
                score += 0.2
                
            # Vérifier si le dernier prix est plus élevé que celui d'il y a 3 périodes
            if closes[-1] > closes[-4]:
                score += 0.2
                
            uptrend_scores.append(score)
        
        # Calculer le score moyen de tendance haussière
        if uptrend_scores:
            avg_score = sum(uptrend_scores) / len(uptrend_scores)
            logger.info(f"Score de tendance pour {symbol}: {avg_score:.2f}")
            return avg_score
        else:
            logger.warning(f"Impossible de calculer le score de tendance pour {symbol}")
            return 0.0
            
    except Exception as e:
        logger.error(f"Erreur lors de l'analyse de la tendance pour {asset}: {e}")
        return 0.0

def get_volatile_assets(max_assets=20):
    """Trouve les actifs les plus volatils en tendance haussière"""
    exchange = setup_exchange()
    if not exchange:
        logger.error("Impossible de configurer l'exchange")
        return []
        
    try:
        # Récupérer tous les actifs négociables
        all_assets = get_all_tradeable_assets(exchange)
        logger.info(f"Analyse de {len(all_assets)} actifs")
        
        # Analyser chaque actif
        asset_data = []
        
        for asset in all_assets:
            try:
                # Vérifier s'il s'agit d'un actif exclu
                if asset in EXCLUDED_ASSETS:
                    continue
                    
                # Analyser la volatilité
                volatility = analyze_volatility(exchange, asset)
                
                # Analyser la tendance
                uptrend_score = analyze_uptrend(exchange, asset)
                
                # Obtenir le dernier prix
                symbol_usdt = f"{asset}/USDT"
                symbol_usd = f"{asset}/USD"
                
                symbol = symbol_usdt if symbol_usdt in exchange.markets else symbol_usd
                
                if symbol not in exchange.markets:
                    continue
                    
                ticker = exchange.fetch_ticker(symbol)
                last_price = ticker['last'] if ticker and 'last' in ticker else 0
                
                # Calcul du score global
                combined_score = volatility * 0.6 + uptrend_score * 0.4
                
                if volatility > 0 and uptrend_score > 0 and last_price > 0:
                    asset_data.append({
                        'asset': asset,
                        'symbol': symbol,
                        'volatility': volatility,
                        'uptrend_score': uptrend_score,
                        'price': last_price,
                        'combined_score': combined_score
                    })
                    logger.info(f"Asset évalué: {asset}, Volatilité: {volatility:.2f}, Uptrend: {uptrend_score:.2f}, Score: {combined_score:.2f}")
                
            except Exception as e:
                logger.error(f"Erreur lors de l'analyse de {asset}: {e}")
                continue
        
        # Trier par score combiné
        asset_data.sort(key=lambda x: x['combined_score'], reverse=True)
        
        # Filtrer les assets avec un score d'uptrend minimal et une volatilité minimale
        filtered_assets = [a for a in asset_data if a['uptrend_score'] > 0.5 and a['volatility'] > 2.0]
        
        # Limiter au nombre maximum spécifié
        top_assets = filtered_assets[:max_assets]
        
        logger.info(f"Assets les plus volatils trouvés: {len(top_assets)}")
        for asset in top_assets:
            logger.info(f"{asset['asset']}: Volatilité: {asset['volatility']:.2f}, Uptrend: {asset['uptrend_score']:.2f}, Score: {asset['combined_score']:.2f}")
        
        return top_assets
        
    except Exception as e:
        logger.error(f"Erreur lors de la recherche d'actifs volatils: {e}")
        return []

if __name__ == "__main__":
    # Exécution directe du script
    volatile_assets = get_volatile_assets()
    
    print(f"\nActifs ultra-volatils trouvés: {len(volatile_assets)}")
    for i, asset in enumerate(volatile_assets):
        print(f"{i+1}. {asset['asset']} - Prix: ${asset['price']:.4f}, Volatilité: {asset['volatility']:.2f}%, Uptrend: {asset['uptrend_score']:.2f}")