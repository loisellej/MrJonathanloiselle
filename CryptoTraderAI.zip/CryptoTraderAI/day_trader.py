#!/usr/bin/env python3
"""
DAY TRADER CRYPTO ULTRA-VOLATIL
- Spécialisé dans les cryptos ULTRA-VOLATILES en UPTREND
- Trading intraday avec entrées/sorties rapides
- Détection des actifs en forte tendance haussière
- Optimisé pour des gains de 20-50% par mois
"""
import os
import time
import logging
import sys
import json
import ccxt
import numpy as np
from datetime import datetime, timedelta
from secure_api_client import SecureAPIClient
from integration_kraken import KrakenIntegration
from sentiment_analyzer import SentimentAnalyzer

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('day_trading_logs.txt')
    ]
)
logger = logging.getLogger(__name__)

class DayTrader:
    """
    Day Trader spécialisé dans les cryptos ultra-volatiles en uptrend
    """
    
    def __init__(self, api_key=None, api_secret=None):
        """
        Initialise le day trader
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
        """
        self.api_key = api_key or os.environ.get("KRAKEN_API_KEY")
        self.api_secret = api_secret or os.environ.get("KRAKEN_API_SECRET")
        
        # Si les clés API ne sont pas fournies, tenter de les récupérer des variables d'environnement
        if not self.api_key or not self.api_secret:
            logger.error("Clés API non trouvées. Assurez-vous de définir KRAKEN_API_KEY et KRAKEN_API_SECRET")
            raise ValueError("Clés API manquantes")
        
        # Initialiser l'intégration Kraken
        logger.info("Initialisation de l'intégration Kraken...")
        self.kraken = KrakenIntegration(api_key=self.api_key, api_secret=self.api_secret)
        
        # Vérifier que la connexion est établie
        if not self.kraken.is_connected:
            logger.error("Impossible de se connecter à l'API Kraken")
            raise ConnectionError("Échec de la connexion à l'API Kraken")
        
        # Récupérer les soldes
        self.balances = self.kraken.get_balances()
        logger.info(f"Soldes récupérés: {self.balances}")
        
        # Initialiser l'analyseur de sentiment
        self.sentiment_analyzer = SentimentAnalyzer()
        
        # Paramètres spécifiques au day trading
        self.excluded_assets = ["BTC", "ETH", "SOL"]  # Actifs stables à exclure
        self.min_order_size_usd = 5.0  # Taille minimale d'un ordre en USD
        self.max_positions = 3  # Nombre maximum de positions simultanées
        self.position_size_pct = 0.95  # 95% du capital disponible (fractionnement par max_positions)
        self.running = False
        self.trade_history = []
        
        # Data pour le tracking des actifs
        self.asset_sentiment = {}
        self.asset_volatility = {}
        self.asset_momentum = {}
        self.asset_uptrend_score = {}
        self.volatile_assets = []
        
        # Paramètres pour le day trading
        self.profit_target_pct = 0.08  # 8% de profit visé par trade
        self.stop_loss_pct = 0.04  # 4% de perte maximale par trade
        self.extended_stop_loss_pct = 0.10  # 10% pour les actifs à fort momentum
        
        # Tracking des positions ouvertes
        self.open_positions = {}
        
        # Limites de temps pour le day trading
        self.max_holding_time = 4  # 4 heures maximum par position
        
        logger.info("Day Trader initialisé avec succès")
    
    def analyze_uptrend(self, symbol, timeframes=['5m', '15m', '1h']):
        """
        Analyse si un actif est en uptrend (tendance haussière)
        Utilise plusieurs timeframes pour confirmer la tendance
        
        Args:
            symbol (str): Symbole de l'actif (ex: 'BTC/USD')
            timeframes (list): Liste des timeframes à analyser
            
        Returns:
            dict: Scores de tendance par timeframe et score global
        """
        try:
            result = {
                'uptrend': False,
                'scores': {},
                'global_score': 0.0
            }
            
            # Analyser chaque timeframe
            for tf in timeframes:
                # Récupérer les données OHLCV
                ohlcv = self.kraken.get_ohlcv(symbol, tf, 20)
                
                if not ohlcv or len(ohlcv) < 12:
                    logger.warning(f"Données OHLCV insuffisantes pour {symbol} sur {tf}")
                    result['scores'][tf] = 0.0
                    continue
                
                # Extraire les prix de clôture
                closes = [candle[4] for candle in ohlcv]
                
                # Calculer les moyennes mobiles
                ma_fast = sum(closes[-5:]) / 5
                ma_medium = sum(closes[-10:]) / 10
                ma_slow = sum(closes[-20:]) / min(20, len(closes))
                
                # Calculer les variations récentes
                last_changes = [((closes[i] - closes[i-1]) / closes[i-1]) * 100 
                               for i in range(max(1, len(closes)-5), len(closes))]
                recent_change_pct = sum(last_changes)
                
                # Vérifier si les moyennes mobiles sont alignées pour un uptrend
                ma_aligned = ma_fast > ma_medium > ma_slow
                
                # Vérifier si la majorité des dernières bougies sont haussières
                bullish_candles = sum(1 for i in range(1, min(10, len(ohlcv))) 
                                     if ohlcv[-i][4] > ohlcv[-i][1])
                mostly_bullish = bullish_candles > 5
                
                # Calculer le score d'uptrend pour ce timeframe
                score = 0.0
                
                if ma_aligned:
                    score += 0.5
                
                if mostly_bullish:
                    score += 0.3
                
                if recent_change_pct > 0:
                    score += min(0.2, recent_change_pct / 10)
                
                # Stocker le score pour ce timeframe
                result['scores'][tf] = score
            
            # Calculer le score global (pondéré selon les timeframes)
            if timeframes:
                # Les timeframes courts ont plus de poids pour le day trading
                weights = {
                    '5m': 0.5,
                    '15m': 0.3,
                    '1h': 0.2,
                    '4h': 0.1
                }
                
                # Calculer la moyenne pondérée des scores
                weighted_sum = sum(result['scores'].get(tf, 0) * weights.get(tf, 0.1) 
                                  for tf in timeframes)
                total_weight = sum(weights.get(tf, 0.1) for tf in timeframes if tf in result['scores'])
                
                result['global_score'] = weighted_sum / total_weight if total_weight else 0.0
                result['uptrend'] = result['global_score'] > 0.6  # Seuil pour considérer un uptrend
            
            return result
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse d'uptrend pour {symbol}: {e}")
            return {'uptrend': False, 'scores': {}, 'global_score': 0.0}
    
    def analyze_volatility(self, symbol, timeframe='1h', limit=24):
        """
        Analyse la volatilité d'un actif
        
        Args:
            symbol (str): Symbole de l'actif (ex: 'BTC/USD')
            timeframe (str): Intervalle de temps
            limit (int): Nombre de points de données
            
        Returns:
            float: Score de volatilité
        """
        try:
            # Récupérer les données OHLCV
            ohlcv = self.kraken.get_ohlcv(symbol, timeframe, limit)
            
            if not ohlcv or len(ohlcv) < 5:
                logger.warning(f"Données OHLCV insuffisantes pour {symbol}")
                return 0.0
            
            # Calculer les variations en pourcentage
            closes = [candle[4] for candle in ohlcv]
            pct_changes = [abs((closes[i] - closes[i-1]) / closes[i-1]) * 100 for i in range(1, len(closes))]
            
            # Calculer l'écart-type (volatilité)
            volatility = np.std(pct_changes)
            
            # Calculer les écarts high-low pour chaque bougie
            hl_ranges = [(candle[2] - candle[3]) / candle[3] * 100 for candle in ohlcv]
            avg_hl_range = sum(hl_ranges) / len(hl_ranges)
            
            # Combiner les deux mesures pour un score de volatilité
            volatility_score = (volatility * 0.7) + (avg_hl_range * 0.3)
            
            # Stocker dans le cache
            base_symbol = symbol.split('/')[0]
            self.asset_volatility[base_symbol] = volatility_score
            
            return volatility_score
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de volatilité pour {symbol}: {e}")
            return 0.0
    
    def analyze_momentum(self, symbol, timeframes=['5m', '15m', '1h']):
        """
        Analyse le momentum d'un actif (vitesse et force de la tendance)
        
        Args:
            symbol (str): Symbole de l'actif (ex: 'BTC/USD')
            timeframes (list): Liste des timeframes à analyser
            
        Returns:
            float: Score de momentum entre -1 et 1
        """
        try:
            momentum_scores = []
            
            for tf in timeframes:
                # Récupérer les données OHLCV
                ohlcv = self.kraken.get_ohlcv(symbol, tf, 20)
                
                if not ohlcv or len(ohlcv) < 10:
                    continue
                
                # Extraire les prix de clôture
                closes = [candle[4] for candle in ohlcv]
                
                # Calculer les variations en pourcentage
                pct_changes = [((closes[i] - closes[i-1]) / closes[i-1]) * 100 
                              for i in range(1, len(closes))]
                
                # Utiliser une moyenne pondérée (plus de poids aux variations récentes)
                weights = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
                weights = weights[-len(pct_changes):]
                
                # Normaliser les poids
                weights = [w / sum(weights) for w in weights]
                
                # Calculer le momentum pondéré
                weighted_momentum = sum(pct * w for pct, w in zip(pct_changes[-len(weights):], weights))
                
                # Normaliser entre -1 et 1
                normalized_momentum = max(-1.0, min(1.0, weighted_momentum / 5.0))
                
                # Ajouter à la liste des scores
                momentum_scores.append(normalized_momentum)
            
            # Calculer le momentum moyen sur tous les timeframes
            avg_momentum = sum(momentum_scores) / len(momentum_scores) if momentum_scores else 0.0
            
            # Stocker dans le cache
            base_symbol = symbol.split('/')[0]
            self.asset_momentum[base_symbol] = avg_momentum
            
            return avg_momentum
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse du momentum pour {symbol}: {e}")
            return 0.0
    
    def analyze_sentiment(self, asset):
        """
        Analyse le sentiment pour un actif
        
        Args:
            asset (str): Symbole de l'actif
            
        Returns:
            float: Score de sentiment entre -1 et 1
        """
        try:
            sentiment = self.sentiment_analyzer.analyze_sentiment(asset)
            
            # Stocker dans le cache
            self.asset_sentiment[asset] = sentiment
            
            return sentiment
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de sentiment pour {asset}: {e}")
            return 0.0
    
    def find_ultra_volatile_uptrends(self, max_assets=10):
        """
        Trouve les cryptos ULTRA-VOLATILES en UPTREND
        Spécifiquement pour le day trading
        
        Args:
            max_assets (int): Nombre maximal d'actifs à retourner
            
        Returns:
            list: Liste des actifs ultra-volatils en uptrend
        """
        try:
            logger.info("Recherche des cryptos ULTRA-VOLATILES en UPTREND...")
            
            # Récupérer la liste des actifs disponibles
            markets = ccxt.kraken().load_markets()
            
            # Filtrer pour n'inclure que les paires USD ou USDT
            tradable_markets = [m for m in markets.keys() if '/USD' in m or '/USDT' in m]
            
            # Données pour le scoring
            market_data = {}
            
            # Analyser chaque marché
            for symbol in tradable_markets:
                try:
                    # Extraire le symbole de base
                    base_symbol = symbol.split('/')[0]
                    
                    # Ignorer les actifs exclus
                    if base_symbol in self.excluded_assets:
                        continue
                    
                    # Analyser l'uptrend (prioritaire pour le day trading)
                    uptrend_result = self.analyze_uptrend(symbol)
                    uptrend_score = uptrend_result['global_score']
                    
                    # Si pas en uptrend, on ignore directement
                    if uptrend_score < 0.4:  # Seuil minimum
                        continue
                    
                    # Analyser la volatilité
                    volatility = self.analyze_volatility(symbol)
                    
                    # Si pas assez volatile, on ignore également
                    if volatility < 3.0:  # Seuil minimum de volatilité
                        continue
                    
                    # Analyser le momentum
                    momentum = self.analyze_momentum(symbol)
                    
                    # Analyser le sentiment
                    sentiment = self.analyze_sentiment(base_symbol)
                    
                    # Récupérer le prix actuel
                    price = self.kraken.get_ticker_price(symbol)
                    
                    # Stocker les données
                    market_data[base_symbol] = {
                        'symbol': symbol,
                        'uptrend_score': uptrend_score,
                        'volatility': volatility,
                        'momentum': momentum,
                        'sentiment': sentiment,
                        'price': price
                    }
                    
                    # Stocker le score d'uptrend dans le cache
                    self.asset_uptrend_score[base_symbol] = uptrend_score
                
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse du marché {symbol}: {e}")
            
            # Calculer les scores combinés pour le day trading
            for asset, data in market_data.items():
                # STRATÉGIE DAY TRADING ULTRA-VOLATILE:
                # 1. L'uptrend est la priorité absolue
                # 2. La volatilité est essentielle pour des mouvements rapides
                # 3. Le momentum positif confirme la force de la tendance
                # 4. Le sentiment positif est un bonus
                
                # Base: score d'uptrend
                score = data['uptrend_score'] * 10.0  # Coefficient important pour l'uptrend
                
                # Bonus pour la volatilité (essentiel en day trading)
                volatility_factor = min(5.0, data['volatility']) / 5.0
                score *= (1.0 + volatility_factor)
                
                # Bonus ou malus pour le momentum
                if data['momentum'] > 0:
                    score *= (1.0 + data['momentum'])
                else:
                    score *= (1.0 / (1.0 - min(0.9, data['momentum'])))
                
                # Petit bonus pour le sentiment positif
                if data['sentiment'] > 0.1:
                    score *= (1.0 + data['sentiment'] * 0.2)
                
                data['day_trading_score'] = score
            
            # Trier par score de day trading
            sorted_assets = sorted(market_data.items(), key=lambda x: x[1]['day_trading_score'], reverse=True)
            
            # Limiter le nombre d'actifs
            top_assets = []
            for asset, data in sorted_assets[:max_assets]:
                # Enregistrer les détails pour le logging
                top_assets.append({
                    'asset': asset,
                    'uptrend_score': data['uptrend_score'],
                    'volatility': data['volatility'],
                    'momentum': data['momentum'],
                    'sentiment': data['sentiment'],
                    'score': data['day_trading_score']
                })
                logger.info(f"Actif ultra-volatile en uptrend: {asset}, Score: {data['day_trading_score']:.2f}, "
                           f"Uptrend: {data['uptrend_score']:.2f}, Volatilité: {data['volatility']:.2f}, "
                           f"Momentum: {data['momentum']:.2f}")
            
            # Mettre à jour la liste des actifs volatils
            self.volatile_assets = [asset['asset'] for asset in top_assets]
            
            return self.volatile_assets
        
        except Exception as e:
            logger.error(f"Erreur lors de la recherche d'actifs ultra-volatils en uptrend: {e}")
            return []
    
    def calculate_position_size(self, asset, available_balance):
        """
        Calcule la taille optimale d'une position pour le day trading
        
        Args:
            asset (str): Symbole de l'actif
            available_balance (float): Solde disponible en USD
            
        Returns:
            float: Taille de la position en unités de l'actif
        """
        try:
            # Récupérer le prix actuel
            symbol = f"{asset}/USD"
            price = self.kraken.get_ticker_price(symbol)
            
            if not price:
                logger.error(f"Prix non disponible pour {symbol}")
                return 0.0
            
            # Calculer le montant à allouer par position
            # Position size = (Capital * Risk%) / Nombre maximal de positions
            allocation = available_balance * self.position_size_pct / self.max_positions
            
            # Vérifier si on a déjà des positions ouvertes
            open_positions_count = len(self.open_positions)
            if open_positions_count >= self.max_positions:
                logger.warning(f"Nombre maximum de positions atteint ({self.max_positions})")
                return 0.0
            
            # Ajuster en fonction des positions déjà ouvertes
            remaining_positions = self.max_positions - open_positions_count
            if remaining_positions < self.max_positions:
                allocation = available_balance * self.position_size_pct / remaining_positions
            
            # Si l'actif a un momentum exceptionnel, augmenter l'allocation
            momentum = self.asset_momentum.get(asset, 0.0)
            if momentum > 0.7:  # Momentum très fort
                allocation *= 1.2  # +20%
            
            # Calculer la quantité
            quantity = allocation / price
            
            # Vérifier la taille minimale
            if quantity * price < self.min_order_size_usd:
                logger.warning(f"Taille de position trop petite pour {asset}: ${quantity * price:.2f} < ${self.min_order_size_usd}")
                return 0.0
            
            return quantity
        
        except Exception as e:
            logger.error(f"Erreur lors du calcul de la taille de position pour {asset}: {e}")
            return 0.0
    
    def place_buy_order(self, asset, quantity):
        """
        Place un ordre d'achat
        
        Args:
            asset (str): Symbole de l'actif
            quantity (float): Quantité à acheter
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        try:
            symbol = f"{asset}/USD"
            
            logger.info(f"Placement d'un ordre d'achat pour {quantity} {asset}...")
            
            # Récupérer le prix actuel
            price = self.kraken.get_ticker_price(symbol)
            
            if not price:
                logger.error(f"Prix non disponible pour {symbol}")
                return None
            
            # Placer l'ordre
            result = self.kraken.place_buy_order(symbol, quantity)
            
            if result:
                # Récupérer le prix réel de l'exécution
                executed_price = float(result.get('info', {}).get('price', price))
                
                # Calculer les niveaux de profit target et stop loss
                profit_target = executed_price * (1 + self.profit_target_pct)
                
                # Déterminer le stop loss en fonction du momentum
                momentum = self.asset_momentum.get(asset, 0.0)
                if momentum > 0.7:  # Fort momentum => stop loss plus large
                    stop_loss = executed_price * (1 - self.extended_stop_loss_pct)
                else:
                    stop_loss = executed_price * (1 - self.stop_loss_pct)
                
                # Mettre à jour l'historique des trades
                trade = {
                    'timestamp': datetime.utcnow(),
                    'asset': asset,
                    'action': 'buy',
                    'amount': quantity,
                    'price': executed_price,
                    'total_usd': executed_price * quantity,
                    'uptrend_score': self.asset_uptrend_score.get(asset, 0.0),
                    'volatility': self.asset_volatility.get(asset, 0.0),
                    'momentum': self.asset_momentum.get(asset, 0.0),
                    'sentiment': self.asset_sentiment.get(asset, 0.0)
                }
                self.trade_history.append(trade)
                
                # Mettre à jour la liste des positions ouvertes
                self.open_positions[asset] = {
                    'entry_price': executed_price,
                    'amount': quantity,
                    'entry_time': datetime.utcnow(),
                    'profit_target': profit_target,
                    'stop_loss': stop_loss
                }
                
                logger.info(f"Achat réussi: {quantity} {asset} à ${executed_price:.4f}")
                logger.info(f"Profit Target: ${profit_target:.4f} (gain: {self.profit_target_pct*100:.1f}%)")
                logger.info(f"Stop Loss: ${stop_loss:.4f} (perte max: {(executed_price-stop_loss)/executed_price*100:.1f}%)")
                
                return result
            
            logger.error(f"Échec de l'ordre d'achat pour {asset}")
            return None
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre d'achat pour {asset}: {e}")
            return None
    
    def place_sell_order(self, asset, quantity, reason="manuel"):
        """
        Place un ordre de vente
        
        Args:
            asset (str): Symbole de l'actif
            quantity (float): Quantité à vendre
            reason (str): Raison de la vente ("profit", "stop-loss", "timeout", "manuel")
            
        Returns:
            dict: Résultat de l'ordre ou None en cas d'erreur
        """
        try:
            symbol = f"{asset}/USD"
            
            logger.info(f"Placement d'un ordre de vente pour {quantity} {asset} (raison: {reason})...")
            
            # Récupérer le prix actuel
            price = self.kraken.get_ticker_price(symbol)
            
            if not price:
                logger.error(f"Prix non disponible pour {symbol}")
                return None
            
            # Placer l'ordre
            result = self.kraken.place_sell_order(symbol, quantity)
            
            if result:
                # Récupérer le prix réel de l'exécution
                executed_price = float(result.get('info', {}).get('price', price))
                
                # Mettre à jour l'historique des trades
                trade = {
                    'timestamp': datetime.utcnow(),
                    'asset': asset,
                    'action': f"sell_{reason}",
                    'amount': quantity,
                    'price': executed_price,
                    'total_usd': executed_price * quantity
                }
                self.trade_history.append(trade)
                
                # Calculer le P&L si on avait une position ouverte
                if asset in self.open_positions:
                    entry_price = self.open_positions[asset]['entry_price']
                    profit_pct = ((executed_price / entry_price) - 1) * 100
                    trade['profit_pct'] = profit_pct
                    
                    logger.info(f"Vente réussie: {quantity} {asset} à ${executed_price:.4f} "
                               f"(P&L: {profit_pct:+.2f}%, Raison: {reason})")
                    
                    # Supprimer la position ouverte
                    del self.open_positions[asset]
                else:
                    logger.info(f"Vente réussie: {quantity} {asset} à ${executed_price:.4f} (Raison: {reason})")
                
                return result
            
            logger.error(f"Échec de l'ordre de vente pour {asset}")
            return None
        
        except Exception as e:
            logger.error(f"Erreur lors du placement de l'ordre de vente pour {asset}: {e}")
            return None
    
    def check_exit_conditions(self):
        """Vérifie les conditions de sortie pour toutes les positions ouvertes"""
        current_time = datetime.utcnow()
        
        for asset, position in list(self.open_positions.items()):
            try:
                symbol = f"{asset}/USD"
                price = self.kraken.get_ticker_price(symbol)
                
                if not price:
                    continue
                
                entry_price = position['entry_price']
                entry_time = position['entry_time']
                amount = position['amount']
                profit_target = position['profit_target']
                stop_loss = position['stop_loss']
                
                # Calculer le temps écoulé depuis l'entrée
                elapsed_time = current_time - entry_time
                elapsed_hours = elapsed_time.total_seconds() / 3600
                
                # Vérifier si on a atteint le profit target
                if price >= profit_target:
                    logger.info(f"Profit target atteint pour {asset}: ${price:.4f} >= ${profit_target:.4f}")
                    self.place_sell_order(asset, amount, reason="profit")
                    continue
                
                # Vérifier si on a déclenché le stop loss
                if price <= stop_loss:
                    logger.warning(f"Stop loss déclenché pour {asset}: ${price:.4f} <= ${stop_loss:.4f}")
                    self.place_sell_order(asset, amount, reason="stop-loss")
                    continue
                
                # Vérifier le timeout (max holding time)
                if elapsed_hours >= self.max_holding_time:
                    logger.info(f"Timeout atteint pour {asset}: {elapsed_hours:.1f}h >= {self.max_holding_time}h")
                    
                    # Calculer le profit actuel
                    profit_pct = ((price / entry_price) - 1) * 100
                    
                    if profit_pct > 0:
                        reason = "timeout_profit"
                    else:
                        reason = "timeout"
                    
                    self.place_sell_order(asset, amount, reason=reason)
                    continue
                
                # Vérifier les conditions de marché (tendance inversée ?)
                uptrend_result = self.analyze_uptrend(symbol)
                uptrend_score = uptrend_result['global_score']
                
                # Si l'uptrend est clairement cassé, on sort
                if uptrend_score < 0.3 and elapsed_hours > 0.5:  # Minimum 30 minutes de holding
                    logger.warning(f"Uptrend cassé pour {asset}: score {uptrend_score:.2f} < 0.3")
                    
                    # Calculer le profit actuel
                    profit_pct = ((price / entry_price) - 1) * 100
                    
                    if profit_pct > 0:
                        reason = "trend_change_profit"
                    else:
                        reason = "trend_change"
                    
                    self.place_sell_order(asset, amount, reason=reason)
            
            except Exception as e:
                logger.error(f"Erreur lors de la vérification des conditions de sortie pour {asset}: {e}")
    
    def day_trading_loop(self):
        """Boucle principale de day trading"""
        logger.info("Démarrage de la boucle de day trading...")
        
        next_scan_time = time.time()
        
        while self.running:
            try:
                current_time = time.time()
                
                # 1. Vérifier les conditions de sortie pour les positions ouvertes
                self.check_exit_conditions()
                
                # 2. Scanner régulièrement pour de nouvelles opportunités
                if current_time >= next_scan_time:
                    # Trouver de nouveaux actifs ultra-volatils en uptrend
                    self.volatile_assets = self.find_ultra_volatile_uptrends()
                    
                    # Programmer le prochain scan dans 15 minutes
                    next_scan_time = current_time + 900  # 15 minutes
                
                # 3. Gérer les entrées en position si opportunités et capital disponible
                if len(self.open_positions) < self.max_positions:
                    self.manage_entries()
                
                # Petite pause
                time.sleep(5)
            
            except Exception as e:
                logger.error(f"Erreur dans la boucle de day trading: {e}")
                time.sleep(30)
    
    def manage_entries(self):
        """Gère les entrées en position selon la stratégie de day trading"""
        try:
            # Rafraîchir les soldes
            self.balances = self.kraken.get_balances()
            
            # Calculer le capital disponible en USD
            usd_balance = 0.0
            for asset, amount in self.balances.items():
                if asset in ["USD", "USDT"]:
                    usd_balance += amount
            
            if usd_balance < self.min_order_size_usd:
                logger.warning(f"Solde USD insuffisant pour de nouvelles positions: ${usd_balance:.2f}")
                return
            
            logger.info(f"Capital disponible pour de nouvelles positions: ${usd_balance:.2f}")
            
            # Évaluer chaque actif ultra-volatil en uptrend
            for asset in self.volatile_assets:
                # Éviter d'acheter si on a déjà une position
                if asset in self.open_positions:
                    continue
                
                # Vérifier les critères pour l'achat
                uptrend_score = self.asset_uptrend_score.get(asset, 0.0)
                momentum = self.asset_momentum.get(asset, 0.0)
                volatility = self.asset_volatility.get(asset, 0.0)
                
                # Critères stricts pour le day trading
                buy_signal = (uptrend_score > 0.7 and  # Fort uptrend
                             volatility > 3.0 and      # Volatilité significative
                             momentum > 0.0)           # Momentum positif
                
                if buy_signal:
                    # Vérifier si on n'a pas déjà atteint le nombre max de positions
                    if len(self.open_positions) >= self.max_positions:
                        logger.info(f"Nombre maximum de positions atteint ({self.max_positions})")
                        break
                    
                    # Calculer la taille de la position
                    quantity = self.calculate_position_size(asset, usd_balance)
                    
                    if quantity > 0:
                        # Placer l'ordre d'achat
                        logger.info(f"OPPORTUNITÉ DE DAY TRADING: {asset}, Uptrend: {uptrend_score:.2f}, "
                                   f"Volatilité: {volatility:.2f}, Momentum: {momentum:.2f}")
                        result = self.place_buy_order(asset, quantity)
                        
                        if result:
                            # Réduire le solde disponible
                            symbol = f"{asset}/USD"
                            price = self.kraken.get_ticker_price(symbol)
                            if price:
                                usd_balance -= quantity * price
        
        except Exception as e:
            logger.error(f"Erreur lors de la gestion des entrées: {e}")
    
    def start(self):
        """Démarre le day trader"""
        if self.running:
            logger.warning("Le day trader est déjà en cours d'exécution")
            return False
        
        logger.info("🚀 Démarrage du DAY TRADER en MODE RÉEL...")
        self.running = True
        
        # Démarrer la boucle de day trading dans un thread
        import threading
        self.trading_thread = threading.Thread(target=self.day_trading_loop)
        self.trading_thread.daemon = True
        self.trading_thread.start()
        
        logger.info("Day Trader démarré avec succès!")
        return True
    
    def stop(self):
        """Arrête le day trader"""
        if not self.running:
            logger.warning("Le day trader n'est pas en cours d'exécution")
            return False
        
        logger.info("Arrêt du day trader...")
        self.running = False
        
        # Attendre que le thread se termine
        if hasattr(self, 'trading_thread') and self.trading_thread.is_alive():
            self.trading_thread.join(timeout=5.0)
        
        logger.info("Day Trader arrêté avec succès!")
        return True
    
    def get_status(self):
        """Récupère le statut du day trader"""
        # Rafraîchir les soldes
        self.balances = self.kraken.get_balances()
        
        # Calculer la valeur totale en USD
        total_value_usd = 0.0
        balances_with_value = {}
        
        for asset, amount in self.balances.items():
            if amount <= 0:
                continue
            
            if asset in ["USD", "USDT"]:
                value_usd = amount
            else:
                symbol = f"{asset}/USD"
                price = self.kraken.get_ticker_price(symbol)
                value_usd = amount * price if price else 0
            
            balances_with_value[asset] = {
                'balance': amount,
                'value_usd': value_usd
            }
            total_value_usd += value_usd
        
        # Préparer les données sur les actifs volatils
        volatile_assets_data = []
        for asset in self.volatile_assets:
            symbol = f"{asset}/USD"
            price = self.kraken.get_ticker_price(symbol)
            
            volatile_assets_data.append({
                'asset': asset,
                'price': price,
                'uptrend_score': self.asset_uptrend_score.get(asset, 0),
                'volatility': self.asset_volatility.get(asset, 0),
                'momentum': self.asset_momentum.get(asset, 0),
                'sentiment': self.asset_sentiment.get(asset, 0)
            })
        
        # Informations sur les positions ouvertes
        positions_data = []
        for asset, position in self.open_positions.items():
            symbol = f"{asset}/USD"
            current_price = self.kraken.get_ticker_price(symbol)
            
            if current_price:
                profit_pct = ((current_price / position['entry_price']) - 1) * 100
                entry_time = position['entry_time']
                elapsed_time = (datetime.utcnow() - entry_time).total_seconds() / 3600
                
                positions_data.append({
                    'asset': asset,
                    'amount': position['amount'],
                    'entry_price': position['entry_price'],
                    'entry_time': entry_time.isoformat(),
                    'elapsed_hours': elapsed_time,
                    'current_price': current_price,
                    'profit_pct': profit_pct,
                    'profit_target': position['profit_target'],
                    'stop_loss': position['stop_loss']
                })
        
        # Analyse des P&L
        trades = self.trade_history
        profitable_trades = [t for t in trades if t.get('action', '').startswith('sell') and t.get('profit_pct', 0) > 0]
        losing_trades = [t for t in trades if t.get('action', '').startswith('sell') and t.get('profit_pct', 0) <= 0]
        
        win_rate = len(profitable_trades) / len(trades) * 100 if trades else 0
        avg_profit = sum(t.get('profit_pct', 0) for t in profitable_trades) / len(profitable_trades) if profitable_trades else 0
        avg_loss = sum(t.get('profit_pct', 0) for t in losing_trades) / len(losing_trades) if losing_trades else 0
        
        return {
            'running': self.running,
            'total_value_usd': total_value_usd,
            'balances': balances_with_value,
            'volatile_uptrend_assets': volatile_assets_data,
            'open_positions': positions_data,
            'trade_history': self.trade_history[-20:] if self.trade_history else [],
            'statistics': {
                'total_trades': len(trades),
                'profitable_trades': len(profitable_trades),
                'losing_trades': len(losing_trades),
                'win_rate': win_rate,
                'avg_profit': avg_profit,
                'avg_loss': avg_loss
            }
        }

def run_day_trader():
    """Fonction principale pour démarrer le day trader"""
    try:
        # Vérifier les clés API
        api_key = os.environ.get("KRAKEN_API_KEY")
        api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        if not api_key or not api_secret:
            logger.error("Clés API Kraken non trouvées dans les variables d'environnement")
            return False
        
        # Afficher un avertissement
        print("=" * 80)
        print("ATTENTION: LANCEMENT DU DAY TRADER ULTRA-VOLATIL EN MODE RÉEL")
        print("Cryptos ciblées: ULTRA-VOLATILES en UPTREND")
        print("Objectif: Trades rapides avec gains de 20-50% par mois")
        print("=" * 80)
        
        # Initialiser le trader
        trader = DayTrader(api_key=api_key, api_secret=api_secret)
        
        # Afficher les soldes initiaux
        status = trader.get_status()
        print(f"Solde total: ${status['total_value_usd']:.2f}")
        print("Actifs disponibles:")
        for asset, data in status['balances'].items():
            print(f"  {asset}: {data['balance']} ≈ ${data['value_usd']:.2f}")
        
        # Démarrer le trader
        trader.start()
        
        print("=" * 80)
        print("DAY TRADER DÉMARRÉ AVEC SUCCÈS")
        print("Recherche d'opportunités de trading en cours...")
        print("Utilisez Ctrl+C pour arrêter")
        print("=" * 80)
        
        # Boucle pour afficher le statut périodiquement
        try:
            while True:
                time.sleep(60)  # Attendre 1 minute
                status = trader.get_status()
                print(f"\nStatut actuel (Solde: ${status['total_value_usd']:.2f}):")
                
                # Afficher les positions ouvertes
                if status['open_positions']:
                    print("Positions ouvertes:")
                    for pos in status['open_positions']:
                        print(f"  {pos['asset']}: {pos['amount']} @ ${pos['entry_price']:.4f} "
                              f"(Actuel: ${pos['current_price']:.4f}, "
                              f"{pos['profit_pct']:+.2f}%, depuis {pos['elapsed_hours']:.1f}h)")
                else:
                    print("Aucune position ouverte, recherche d'opportunités...")
                
                # Afficher les derniers trades
                if status['trade_history']:
                    print("Derniers trades:")
                    for trade in status['trade_history'][-3:]:
                        action = trade['action'].upper()
                        profit_info = f" ({trade.get('profit_pct', 0):+.2f}%)" if 'profit_pct' in trade else ""
                        print(f"  {action}: {trade['amount']} {trade['asset']} @ ${trade['price']:.4f}{profit_info}")
        
        except KeyboardInterrupt:
            print("\nArrêt demandé par l'utilisateur...")
            trader.stop()
            print("Day Trader arrêté avec succès.")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors du lancement du day trader: {e}")
        return False

if __name__ == "__main__":
    run_day_trader()