#!/usr/bin/env python3
"""
Script de démarrage pour le trader optimisé Replit
Ce script initialise le système de trading avec toutes les optimisations
et les protections contre les crashs
"""
import os
import sys
import time
import signal
import logging
import threading
import subprocess
import psutil

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("start_optimized_trader.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("StartOptimizedTrader")

def is_process_running(pid):
    """
    Vérifie si un processus avec le PID donné est en cours d'exécution
    
    Args:
        pid (int): PID du processus
        
    Returns:
        bool: True si le processus est en cours d'exécution
    """
    try:
        process = psutil.Process(pid)
        return process.is_running() and process.status() != psutil.STATUS_ZOMBIE
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
        return False

def get_running_pid():
    """
    Récupère le PID du trader s'il est en cours d'exécution
    
    Returns:
        int: PID du trader ou None s'il n'est pas en cours d'exécution
    """
    try:
        # Vérifier le fichier PID
        if os.path.exists("bot_pid.txt"):
            with open("bot_pid.txt", "r") as f:
                pid = int(f.read().strip())
                
                # Vérifier si le processus est en cours d'exécution
                if is_process_running(pid):
                    return pid
        
        # Vérifier également le fichier heartbeat
        if os.path.exists("bot_heartbeat.txt"):
            with open("bot_heartbeat.txt", "r") as f:
                content = f.read().strip()
                
                # Vérifier si le heartbeat est récent (< 30 secondes)
                if "Trader actif:" in content:
                    # Rechercher le processus Python qui exécute le trader
                    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                        if proc.info['name'] == 'python' and any('replit_optimized_trader.py' in cmd for cmd in proc.info['cmdline']):
                            return proc.info['pid']
        
        return None
    
    except Exception as e:
        logger.error(f"Erreur lors de la recherche du PID: {e}")
        return None

def start_trader():
    """
    Démarre le trader optimisé pour Replit
    
    Returns:
        int: PID du trader ou None en cas d'erreur
    """
    try:
        logger.info("Démarrage du trader optimisé pour Replit")
        
        # Vérifier si le trader est déjà en cours d'exécution
        running_pid = get_running_pid()
        if running_pid:
            logger.warning(f"Le trader est déjà en cours d'exécution (PID: {running_pid})")
            return running_pid
        
        # Démarrer le trader en tant que processus séparé
        process = subprocess.Popen(
            ["python", "replit_optimized_trader.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Attendre que le processus démarre correctement
        time.sleep(5)
        
        # Vérifier si le processus est toujours en cours d'exécution
        if process.poll() is None:
            logger.info(f"Trader démarré avec succès (PID: {process.pid})")
            return process.pid
        else:
            # Récupérer les erreurs
            stdout, stderr = process.communicate()
            logger.error(f"Échec du démarrage: {stderr.decode()}")
            return None
        
    except Exception as e:
        logger.error(f"Erreur lors du démarrage du trader: {e}")
        return None

def stop_trader():
    """
    Arrête le trader optimisé pour Replit
    
    Returns:
        bool: True si l'arrêt est réussi
    """
    try:
        logger.info("Arrêt du trader optimisé pour Replit")
        
        # Récupérer le PID du trader
        pid = get_running_pid()
        if not pid:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return True
        
        # Envoyer un signal SIGTERM au processus
        os.kill(pid, signal.SIGTERM)
        
        # Attendre que le processus se termine
        for _ in range(10):  # Attendre max 10 secondes
            if not is_process_running(pid):
                logger.info("Trader arrêté avec succès")
                return True
            time.sleep(1)
        
        # Si le processus ne s'est pas terminé, envoyer un signal SIGKILL
        logger.warning("Le trader ne répond pas, envoi de SIGKILL")
        os.kill(pid, signal.SIGKILL)
        
        # Supprimer le fichier PID et heartbeat
        if os.path.exists("bot_pid.txt"):
            os.remove("bot_pid.txt")
        
        if os.path.exists("bot_heartbeat.txt"):
            os.remove("bot_heartbeat.txt")
        
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors de l'arrêt du trader: {e}")
        return False

def restart_trader():
    """
    Redémarre le trader optimisé pour Replit
    
    Returns:
        int: PID du trader ou None en cas d'erreur
    """
    try:
        logger.info("Redémarrage du trader optimisé pour Replit")
        
        # Arrêter le trader
        stop_trader()
        
        # Petite pause pour assurer l'arrêt complet
        time.sleep(2)
        
        # Démarrer le trader
        return start_trader()
        
    except Exception as e:
        logger.error(f"Erreur lors du redémarrage du trader: {e}")
        return None

def check_trader_status():
    """
    Vérifie le statut du trader
    
    Returns:
        dict: Statut du trader
    """
    try:
        # Récupérer le PID du trader
        pid = get_running_pid()
        
        if not pid:
            return {
                'running': False,
                'pid': None,
                'message': "Le trader n'est pas en cours d'exécution"
            }
        
        # Vérifier le heartbeat
        heartbeat_time = None
        if os.path.exists("bot_heartbeat.txt"):
            with open("bot_heartbeat.txt", "r") as f:
                content = f.read().strip()
                if "Trader actif:" in content:
                    heartbeat_time = content.split("Trader actif:")[1].strip()
        
        # Vérifier la charge système
        process = psutil.Process(pid)
        status = {
            'running': True,
            'pid': pid,
            'cpu_percent': process.cpu_percent(interval=0.5),
            'memory_percent': process.memory_percent(),
            'heartbeat': heartbeat_time,
            'message': "Le trader est en cours d'exécution"
        }
        
        return status
        
    except Exception as e:
        logger.error(f"Erreur lors de la vérification du statut: {e}")
        return {
            'running': False,
            'pid': None,
            'message': f"Erreur lors de la vérification: {e}"
        }

def monitor_trader():
    """
    Surveille le trader et le redémarre en cas de crash
    
    Returns:
        Thread: Thread de surveillance
    """
    def monitor_loop():
        while True:
            try:
                # Vérifier le statut du trader
                status = check_trader_status()
                
                if not status['running']:
                    logger.warning("Le trader n'est pas en cours d'exécution, redémarrage...")
                    start_trader()
                    
                # Pause de 30 secondes
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Erreur dans la boucle de surveillance: {e}")
                time.sleep(60)  # Pause plus longue en cas d'erreur
    
    # Créer et démarrer le thread
    monitor_thread = threading.Thread(target=monitor_loop)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    return monitor_thread

def initialize_system():
    """
    Initialise tous les composants du système de trading optimisé
    
    Returns:
        bool: True si l'initialisation est réussie
    """
    try:
        logger.info("Initialisation du système de trading optimisé")
        
        # Importer les modules une seule fois
        from optimized_resource_manager import OptimizedResourceManager
        from optimized_queue_manager import get_queue_manager
        from optimized_api_client import setup_optimized_kraken_client
        from performance_monitor import get_performance_monitor
        
        # Initialiser le système de files d'attente
        queue_manager = get_queue_manager()
        logger.info("Système de files d'attente initialisé")
        
        # Initialiser le client API
        api_client = setup_optimized_kraken_client()
        logger.info("Client API initialisé")
        
        # Initialiser le gestionnaire de ressources
        resource_manager = OptimizedResourceManager(api_client)
        logger.info("Gestionnaire de ressources initialisé")
        
        # Initialiser le moniteur de performances
        performance_monitor = get_performance_monitor(resource_manager, queue_manager)
        logger.info("Moniteur de performances initialisé")
        
        # Nettoyer les anciens fichiers de log
        cleanup_old_logs()
        
        # Vérifier si le trader est déjà en cours d'exécution
        status = check_trader_status()
        if status['running']:
            logger.info("Le trader est déjà en cours d'exécution, pas besoin de le démarrer")
            return True
        
        # Démarrer le trader
        if start_trader():
            logger.info("Système de trading initialisé avec succès")
            
            # Démarrer la surveillance
            monitor_trader()
            
            return True
        else:
            logger.error("Échec de l'initialisation du système")
            return False
        
    except Exception as e:
        logger.error(f"Erreur lors de l'initialisation du système: {e}")
        return False

def cleanup_old_logs():
    """Nettoie les anciens fichiers de log"""
    try:
        # Liste des fichiers de log
        log_files = [
            'optimized_trader.log', 
            'resource_manager.log',
            'api_client.log',
            'queue_manager.log',
            'performance_monitor.log'
        ]
        
        # Vérifier et nettoyer chaque fichier de log
        for log_file in log_files:
            if os.path.exists(log_file) and os.path.getsize(log_file) > 10 * 1024 * 1024:  # 10 Mo
                # Renommer le fichier log
                timestamp = time.strftime("%Y%m%d%H%M%S")
                os.rename(log_file, f"{log_file}.{timestamp}")
                
                # Créer un nouveau fichier log
                with open(log_file, 'w') as f:
                    f.write(f"Log file rotated at {time.ctime()}\n")
                
                logger.info(f"Fichier log {log_file} nettoyé")
                
        logger.info("Nettoyage des fichiers log terminé")
        
    except Exception as e:
        logger.error(f"Erreur lors du nettoyage des logs: {e}")

def print_status():
    """Affiche le statut complet du trader"""
    try:
        # Récupérer le statut
        status = check_trader_status()
        
        # Afficher le statut
        print("\n" + "=" * 50)
        print(" STATUT DU TRADER OPTIMISÉ REPLIT ".center(50, "="))
        print("=" * 50)
        
        if status['running']:
            print(f"✅ ÉTAT:     En cours d'exécution (PID: {status['pid']})")
            print(f"🔄 HEARTBEAT: {status['heartbeat']}")
            print(f"📊 CPU:      {status['cpu_percent']:.2f}%")
            print(f"💾 MÉMOIRE:  {status['memory_percent']:.2f}%")
        else:
            print(f"❌ ÉTAT:     Arrêté")
            print(f"ℹ️ MESSAGE:  {status['message']}")
        
        print("=" * 50)
        
        # Récupérer les dernières lignes du log
        if os.path.exists("optimized_trader.log"):
            print("\nDERNIERS LOGS:")
            print("-" * 50)
            
            with open("optimized_trader.log", "r") as f:
                lines = f.readlines()
                for line in lines[-5:]:  # 5 dernières lignes
                    print(line.strip())
                    
            print("-" * 50)
        
    except Exception as e:
        print(f"Erreur lors de l'affichage du statut: {e}")

def main():
    """Fonction principale"""
    try:
        # Afficher l'en-tête
        print("\n" + "*" * 60)
        print(" SYSTÈME DE TRADING OPTIMISÉ REPLIT - BÉTON ARMÉ ".center(60, "*"))
        print("*" * 60 + "\n")
        
        # Vérifier les arguments
        if len(sys.argv) > 1:
            command = sys.argv[1].lower()
            
            if command == "start":
                if start_trader():
                    print("✅ Trader démarré avec succès")
                else:
                    print("❌ Échec du démarrage du trader")
                    
            elif command == "stop":
                if stop_trader():
                    print("✅ Trader arrêté avec succès")
                else:
                    print("❌ Échec de l'arrêt du trader")
                    
            elif command == "restart":
                if restart_trader():
                    print("✅ Trader redémarré avec succès")
                else:
                    print("❌ Échec du redémarrage du trader")
                    
            elif command == "status":
                print_status()
                
            elif command == "init":
                if initialize_system():
                    print("✅ Système initialisé avec succès")
                else:
                    print("❌ Échec de l'initialisation du système")
                    
            else:
                print("❌ Commande inconnue")
                print("Usage: python start_optimized_trader.py [start|stop|restart|status|init]")
        else:
            # Par défaut, initialiser le système et afficher le statut
            initialize_system()
            print_status()
            
            # Garder le processus en vie pour la surveillance
            print("\nSurveillance du trader en cours (Ctrl+C pour quitter)...")
            
            try:
                while True:
                    time.sleep(10)
                    status = check_trader_status()
                    if not status['running']:
                        print("⚠️ Le trader n'est pas en cours d'exécution, redémarrage...")
                        start_trader()
            except KeyboardInterrupt:
                print("\n✅ Surveillance arrêtée")
        
    except Exception as e:
        print(f"❌ Erreur critique: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())