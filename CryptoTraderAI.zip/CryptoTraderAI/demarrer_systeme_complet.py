#!/usr/bin/env python3
"""
SYSTÈME DE TRADING AUTOMATIQUE COMPLET - DÉMARRAGE UNIFIÉ
Démarre tous les composants nécessaires au fonctionnement 24/7 du trader

Ce script garantit le fonctionnement continu du système:
1. Réinitialise le nonce Kraken pour éviter les erreurs API
2. Lance le trader automatique vérifié avec gestion robuste des API
3. Lance le guardian de surveillance pour assurer la continuité du service
4. Implémente des sécurités en cas de crash pour une disponibilité maximale
"""
import os
import sys
import time
import logging
import datetime
import subprocess
import threading
import signal
from pathlib import Path

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("systeme_complet.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("SystemComplet")

# Variables globales
REQUIRED_SCRIPTS = [
    "auto_trader_verified.py",
    "enhanced_kraken_api.py",
    "kraken_nonce_manager.py",
    "trading_guardian.py",
    "execute_real_trade.py"
]
running_processes = {}

def check_environment():
    """Vérifie que l'environnement est correctement configuré"""
    try:
        # Vérifier que les scripts requis existent
        logger.info("Vérification des scripts requis...")
        missing_scripts = []
        for script in REQUIRED_SCRIPTS:
            if not os.path.exists(script):
                missing_scripts.append(script)
        
        if missing_scripts:
            logger.error(f"Scripts manquants: {', '.join(missing_scripts)}")
            return False
        
        # Vérifier que les scripts sont exécutables
        logger.info("Vérification des permissions...")
        os.system(f"chmod +x {' '.join(REQUIRED_SCRIPTS)}")
        
        # Vérifier les variables d'environnement
        logger.info("Vérification des variables d'environnement...")
        env_vars = []
        with open('.env', 'r') as f:
            for line in f:
                if line.strip() and not line.startswith('#'):
                    env_vars.append(line.strip().split('=', 1)[0])
        
        required_vars = ['KRAKEN_API_KEY', 'KRAKEN_API_SECRET']
        missing_vars = []
        for var in required_vars:
            if var not in env_vars and not os.environ.get(var):
                missing_vars.append(var)
        
        if missing_vars:
            logger.error(f"Variables d'environnement manquantes: {', '.join(missing_vars)}")
            return False
        
        logger.info("✅ Environnement correctement configuré")
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors de la vérification de l'environnement: {e}")
        return False

def reset_kraken_nonce():
    """Réinitialise le nonce Kraken"""
    try:
        logger.info("Réinitialisation du nonce Kraken...")
        result = subprocess.run(
            [sys.executable, "kraken_nonce_manager.py", "reset"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        
        if result.returncode == 0:
            logger.info("✅ Nonce Kraken réinitialisé avec succès")
            return True
        else:
            logger.error(f"❌ Échec de la réinitialisation du nonce: {result.stderr}")
            return False
    
    except Exception as e:
        logger.error(f"Erreur lors de la réinitialisation du nonce: {e}")
        return False

def start_trader():
    """Démarre le trader automatique"""
    try:
        logger.info("Démarrage du trader automatique...")
        
        # Arrêter toute instance existante
        stop_process("trader")
        
        # Démarrer le trader
        trader_process = subprocess.Popen(
            [sys.executable, "auto_trader_verified.py"],
            stdout=open("auto_trader_output.log", "w"),
            stderr=subprocess.STDOUT
        )
        
        # Enregistrer le processus
        running_processes["trader"] = trader_process
        
        logger.info(f"✅ Trader démarré (PID: {trader_process.pid})")
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors du démarrage du trader: {e}")
        return False

def start_guardian():
    """Démarre le guardian de surveillance"""
    try:
        logger.info("Démarrage du guardian de surveillance...")
        
        # Arrêter toute instance existante
        stop_process("guardian")
        
        # Démarrer le guardian
        guardian_process = subprocess.Popen(
            [sys.executable, "trading_guardian.py"],
            stdout=open("guardian_output.log", "w"),
            stderr=subprocess.STDOUT
        )
        
        # Enregistrer le processus
        running_processes["guardian"] = guardian_process
        
        logger.info(f"✅ Guardian démarré (PID: {guardian_process.pid})")
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors du démarrage du guardian: {e}")
        return False

def stop_process(name):
    """Arrête un processus par son nom"""
    if name in running_processes:
        try:
            process = running_processes[name]
            if process.poll() is None:  # Le processus est en cours d'exécution
                logger.info(f"Arrêt de {name} (PID: {process.pid})...")
                
                # Envoi d'un signal SIGTERM
                process.terminate()
                
                # Attendre la fin du processus (max 5 secondes)
                for _ in range(10):
                    if process.poll() is not None:
                        break
                    time.sleep(0.5)
                
                # Si le processus est toujours en vie, le tuer
                if process.poll() is None:
                    logger.warning(f"{name} ne répond pas, envoi de SIGKILL...")
                    process.kill()
                
                logger.info(f"✅ {name} arrêté")
            
            # Supprimer de la liste des processus
            del running_processes[name]
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de l'arrêt de {name}: {e}")
    
    return False

def verify_trader_running():
    """Vérifie que le trader est bien en cours d'exécution"""
    try:
        # Vérifier si le processus est en vie
        if "trader" in running_processes:
            trader_process = running_processes["trader"]
            if trader_process.poll() is None:  # None signifie en cours d'exécution
                logger.info("Trader en cours d'exécution")
                return True
        
        # Vérifier le fichier PID
        if os.path.exists("trader.pid"):
            with open("trader.pid", "r") as f:
                pid = int(f.read().strip())
            
            try:
                os.kill(pid, 0)  # Vérifie seulement, ne tue pas le processus
                logger.info(f"Trader en cours d'exécution (PID: {pid})")
                return True
            except OSError:
                logger.warning("Fichier PID présent mais processus inexistant")
        
        # Vérifier le heartbeat
        if os.path.exists("trader_heartbeat.txt"):
            heartbeat_age = time.time() - os.path.getmtime("trader_heartbeat.txt")
            if heartbeat_age <= 90:  # Heartbeat de moins de 90 secondes
                logger.info(f"Trader actif selon le heartbeat ({heartbeat_age:.1f}s)")
                return True
            else:
                logger.warning(f"Heartbeat périmé ({heartbeat_age:.1f}s)")
        
        logger.error("❌ Trader non détecté")
        return False
    
    except Exception as e:
        logger.error(f"Erreur lors de la vérification du trader: {e}")
        return False

def display_status_continuously():
    """Affiche le statut du système en continu"""
    try:
        while True:
            # Vérifier l'état des processus
            for name, process in list(running_processes.items()):
                if process.poll() is not None:  # Le processus s'est terminé
                    logger.warning(f"⚠️ {name} s'est arrêté (code: {process.poll()})")
                    del running_processes[name]
            
            # Vérifier le trader spécifiquement
            if not verify_trader_running() and "guardian" in running_processes:
                # Le guardian devrait redémarrer le trader
                logger.info("Guardian devrait redémarrer le trader...")
            
            # Pause
            time.sleep(30)
    
    except Exception as e:
        logger.error(f"Erreur dans l'affichage du statut: {e}")
    except KeyboardInterrupt:
        logger.info("Affichage du statut arrêté")

def handle_signals(signum, frame):
    """Gestionnaire de signaux pour un arrêt propre"""
    logger.info(f"Signal reçu: {signum}, arrêt du système...")
    
    # Arrêter les processus dans l'ordre
    stop_process("guardian")
    stop_process("trader")
    
    logger.info("Système arrêté")
    sys.exit(0)

def main():
    """Fonction principale"""
    try:
        # Configurer le gestionnaire de signaux
        signal.signal(signal.SIGTERM, handle_signals)
        signal.signal(signal.SIGINT, handle_signals)
        
        logger.info("=" * 80)
        logger.info("🚀 DÉMARRAGE DU SYSTÈME DE TRADING AUTOMATIQUE COMPLET")
        logger.info("=" * 80)
        
        # Vérifier l'environnement
        if not check_environment():
            logger.error("❌ Environnement non configuré correctement, arrêt du système")
            return False
        
        # Réinitialiser le nonce Kraken
        if not reset_kraken_nonce():
            logger.warning("⚠️ Problème lors de la réinitialisation du nonce, tentative de démarrage quand même")
        
        # Démarrer le trader
        if not start_trader():
            logger.error("❌ Échec du démarrage du trader, arrêt du système")
            return False
        
        # Démarrer le guardian
        if not start_guardian():
            logger.warning("⚠️ Échec du démarrage du guardian, le trader peut s'arrêter sans surveillance")
        
        # Vérifier que le trader est bien en cours d'exécution
        time.sleep(5)  # Attendre le démarrage
        if not verify_trader_running():
            logger.warning("⚠️ Le trader ne semble pas être démarré correctement")
        
        # Démarrer l'affichage du statut dans un thread
        status_thread = threading.Thread(target=display_status_continuously, daemon=True)
        status_thread.start()
        
        logger.info("✅ Système de trading automatique complet démarré")
        logger.info("🔄 Appuyez sur Ctrl+C pour arrêter le système")
        
        # Garder le processus principal en vie
        while True:
            time.sleep(1)
    
    except KeyboardInterrupt:
        logger.info("Arrêt demandé par l'utilisateur")
        
        # Arrêter les processus dans l'ordre
        stop_process("guardian")
        stop_process("trader")
        
        logger.info("Système arrêté")
    
    except Exception as e:
        logger.error(f"Erreur critique: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)