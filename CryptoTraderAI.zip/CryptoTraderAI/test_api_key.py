#!/usr/bin/env python3
"""
Script pour tester la validité des clés API Kraken
"""
import krakenex
import os
import sys

def test_kraken_api():
    """Teste les clés API Kraken"""
    print("Test des clés API Kraken...")
    
    # Utiliser directement les clés API
    api_key = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
    api_secret = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="
    
    if not api_key or not api_secret:
        print("⚠️ Erreur: Clés API Kraken non trouvées dans les variables d'environnement!")
        return False
    
    print(f"API Key: {api_key[:5]}...{api_key[-5:]}")
    print(f"API Secret: {api_secret[:5]}...{api_secret[-5:]}")
    
    # Initialiser l'API Kraken
    k = krakenex.API(api_key, api_secret)
    
    try:
        # Tester une requête privée
        print("\nTest d'une requête privée (Balance)...")
        balance = k.query_private('Balance')
        
        if 'error' in balance and balance['error']:
            print(f"⚠️ Erreur: {balance['error']}")
            return False
        
        # Afficher le résultat
        print("✅ Connexion réussie!")
        print("\nBalances:")
        for asset, amount in balance['result'].items():
            print(f"  {asset}: {amount}")
        
        return True
    except Exception as e:
        print(f"⚠️ Exception: {e}")
        return False

if __name__ == "__main__":
    
    # Tester l'API
    if test_kraken_api():
        print("\n✅ Test réussi: Les clés API Kraken sont valides!")
    else:
        print("\n❌ Test échoué: Les clés API Kraken semblent invalides.")
        print("Assurez-vous que:")
        print("1. Les clés sont correctement formatées (sans espaces)")
        print("2. Les clés ont les permissions nécessaires")
        print("3. Les clés n'ont pas expiré")
        print("4. Vous n'avez pas atteint la limite de requêtes API")