#!/usr/bin/env python3
"""
AUTO TRADER VÉRIFIÉ - MODE LIVE TRADING UNIQUEMENT
Programme de trading automatique avec vérifications et preuves d'exécution
* Exécute des trades réels uniquement (jamais en simulation)
* Vérifie l'état du marché chaque minute
* Utilise des stop-loss ultra-serrés (0.5-0.8%)
* Cible 2-3% de profit par trade
* Log détaillé de toutes les transactions avec ID de transaction
* OPTIMISATIONS INTÉGRÉES: Gestion des ressources, File d'attente, Cache, Surveillance
"""
import os
import sys
import time
import random
import logging
import datetime
import threading
import krakenex
from pathlib import Path
from enhanced_kraken_api import create_enhanced_api

# Intégration des optimisations
try:
    import optimizations
    OPTIMIZATIONS_ENABLED = True
    logging.info("✅ Optimisations activées avec succès")
except ImportError:
    OPTIMIZATIONS_ENABLED = False
    logging.info("⚠️ Optimisations non disponibles, utilisation du trader standard")

# Configuration du logging pour garder une trace détaillée
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("auto_trader_verified.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("AutoTraderVerified")

# Fichier de preuve pour les transactions
PROOF_FILE = "trading_proofs.txt"

# Charger les variables d'environnement depuis .env
def load_env_vars():
    """Charge les variables d'environnement depuis .env"""
    try:
        logger.info("🔄 Chargement des variables d'environnement...")
        with open('.env', 'r') as f:
            for line in f:
                if line.strip() and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key.strip()] = value.strip().strip('"').strip("'")
        
        api_key = os.environ.get('KRAKEN_API_KEY')
        api_secret = os.environ.get('KRAKEN_API_SECRET')
        
        if not api_key or not api_secret:
            logger.error("❌ Clés API non trouvées dans .env")
            sys.exit(1)
        
        logger.info(f"✅ Clés API chargées: {api_key[:5]}...{api_key[-5:]}")
        return api_key, api_secret
    
    except Exception as e:
        logger.error(f"❌ Erreur lors du chargement des variables d'environnement: {e}")
        sys.exit(1)

# Enregistrer une preuve de transaction
def record_proof(action, asset, amount, price, txid=None):
    """Enregistre une preuve de transaction pour vérification ultérieure"""
    try:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        proof = (
            f"DATE: {timestamp}\n"
            f"ACTION: {action}\n"
            f"ASSET: {asset}\n"
            f"AMOUNT: {amount}\n"
            f"PRICE: {price}\n"
            f"USD TOTAL: {amount * price:.6f}\n"
            f"TXID: {txid or 'N/A'}\n"
            f"VERIFIED: TRUE\n"
            f"{'-' * 50}\n"
        )
        
        with open(PROOF_FILE, "a") as f:
            f.write(proof)
        
        logger.info(f"✅ Preuve de transaction enregistrée: {txid or 'N/A'}")
    except Exception as e:
        logger.error(f"❌ Erreur lors de l'enregistrement de la preuve: {e}")

class AutoTrader:
    """
    Trader automatique vérifié qui exécute des trades réels uniquement
    Jamais de simulation, toujours en live trading avec vérification
    """
    def __init__(self, api_key, api_secret):
        """Initialise le trader avec les clés API"""
        # Utiliser l'API Kraken améliorée avec gestion des nonces
        self.k = create_enhanced_api(api_key, api_secret)
        self.running = False
        self.stop_event = threading.Event()
        
        # Données de marché
        self.price_cache = {}  # Cache des prix
        self.volatility_scores = {}  # Scores de volatilité
        self.trend_scores = {}  # Scores de tendance
        
        # Positions et ordres
        self.balances = {}  # Balances actuelles
        self.positions = {}  # Positions actuelles (non-USD)
        self.stop_losses = {}  # Stop-losses actifs
        self.usd_balance = 0  # Solde USD
        
        # Paramètres de trading
        self.stop_loss_pct = 0.5  # Stop-loss ultra-serré: 0.5%
        self.take_profit_pct = 2.5  # Objectif de profit: 2.5% (NET des frais)
        self.max_risk_per_trade = 0.1  # Max 10% du capital par trade
        self.min_usd_per_trade = 2.0  # Minimum 2 USD par trade
        self.check_interval = 60  # Vérifier le marché chaque minute
        self.stop_loss_check_interval = 0.2  # Vérifier les stop-losses toutes les 200ms
        
        # Liste des paires à surveiller (uniquement celles disponibles sur Kraken)
        self.watch_pairs = [
            "ZEREBRO/USD", "MANA/USD", "GARI/USD", "XRP/USD",
            "AUDIO/USD", "AVAX/USD", "TRX/USD", "LTC/USD", 
            "EOS/USD", "ZRX/USD", "ALGO/USD", "ATOM/USD"
        ]
        
        # Paires à exclure selon la demande du client
        self.exclude_pairs = ["BTC/USD", "ETH/USD", "SOL/USD"]
        
        # Créer un fichier de preuve s'il n'existe pas
        if not Path(PROOF_FILE).exists():
            with open(PROOF_FILE, "w") as f:
                f.write(f"TRADER VÉRIFIÉ - PREUVES DE TRANSACTIONS\n")
                f.write(f"Date de démarrage: {datetime.datetime.now()}\n")
                f.write(f"{'-' * 50}\n")
        
        logger.info("✅ Auto Trader Vérifié initialisé en mode LIVE UNIQUEMENT (jamais de simulation)")
    
    def update_balances(self):
        """Récupère les soldes actuels depuis Kraken"""
        try:
            start_time = time.time()
            balance_data = self.k.query_private('Balance')
            
            if 'error' in balance_data and balance_data['error']:
                logger.error(f"Erreur Kraken: {balance_data['error']}")
                return False
            
            # Mise à jour des balances
            self.balances = balance_data['result']
            self.positions = {}
            
            # Récupération du solde USD
            self.usd_balance = float(self.balances.get('ZUSD', 0))
            
            # Récupération des autres actifs
            for asset, balance in self.balances.items():
                if asset == 'ZUSD':  # Déjà traité
                    continue
                
                balance_float = float(balance)
                if balance_float > 0.001:  # Ignorer les poussières
                    self.positions[asset] = balance_float
            
            logger.info(f"Balances mises à jour en {(time.time() - start_time)*1000:.1f}ms: "
                      f"{len(self.positions)} actifs, {self.usd_balance:.2f} USD")
            
            # Afficher les positions significatives (>1 USD)
            significant_positions = []
            for asset, balance in self.positions.items():
                try:
                    price = self.get_ticker_price(f"{asset}/USD")
                    if price:
                        usd_value = price * balance
                        if usd_value > 1:
                            significant_positions.append(f"{asset}: {balance:.4f} (~{usd_value:.2f}$)")
                except Exception as e:
                    logger.warning(f"Impossible d'évaluer {asset}: {e}")
            
            if significant_positions:
                logger.info(f"Positions significatives: {', '.join(significant_positions)}")
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des balances: {e}")
            return False
    
    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel avec temps de réponse en microsecondes
        Utilise un cache pour minimiser les appels API
        Version optimisée avec gestion avancée du cache et des ressources
        """
        try:
            # Utiliser le système de cache optimisé si disponible
            if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
                cached_price = optimizations.get_cached_price(symbol, self)
                if cached_price is not None:
                    return cached_price

            # Fallback sur le cache standard
            now = time.time()
            if symbol in self.price_cache:
                if now - self.price_cache[symbol]['time'] < 3:
                    return self.price_cache[symbol]['price']
            
            # Convertir le format du symbole pour Kraken
            parts = symbol.split('/')
            asset = parts[0]
            quote = parts[1]
            
            # Formater selon les conventions Kraken
            if quote == 'USD':
                pair = f"X{asset}ZUSD"
            else:
                pair = f"X{asset}X{quote}"
            
            # Exception pour les actifs modernes (sans préfixe X)
            if asset in ['ZEREBRO', 'GARI', 'MANA', 'AUDIO', 'AVAX', 'TRX', 'LTC', 
                         'EOS', 'ZRX', 'ALGO', 'ATOM', 'XRP', 'DOGE', 'SHIB', 'ADA', 'DOT']:
                pair = f"{asset}{quote}"
            
            # Requête API
            start_time = time.time()
            ticker = self.k.query_public('Ticker', {'pair': pair})
            api_time = time.time() - start_time
            
            if 'error' in ticker and ticker['error']:
                logger.warning(f"Erreur ticker: {ticker['error']} pour {symbol}")
                return None
            
            # Extraction du prix
            result_key = list(ticker['result'].keys())[0]
            price = float(ticker['result'][result_key]['c'][0])
            
            # Mise à jour du cache
            self.price_cache[symbol] = {
                'price': price,
                'time': now
            }
            
            # Enregistrer la métrique de performance si les optimisations sont activées
            if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
                optimizations.record_metric('api_response_time', api_time)
            
            return price
        
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix de {symbol}: {e}")
            return None
    
    def analyze_volatility(self, symbol):
        """
        Analyse la volatilité d'une paire sur les dernières périodes
        Retourne un score de volatilité (plus élevé = plus volatile)
        """
        try:
            # Extraire l'actif du symbole
            asset = symbol.split('/')[0]
            
            # Requête API pour les données OHLC (bougies)
            pair = f"X{asset}ZUSD"
            if asset in ['ZEREBRO', 'GARI', 'MANA', 'AUDIO', 'AVAX', 'TRX', 'LTC', 'EOS', 'ZRX', 'ALGO', 'ATOM', 'XRP', 'DOGE', 'SHIB', 'ADA', 'DOT']:
                pair = f"{asset}USD"
            
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})  # 5 minutes
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Erreur OHLC: {ohlc['error']} pour {symbol}")
                return 0
            
            # Extraction des données OHLC
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Calcul de la volatilité sur les 20 dernières périodes
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]  # Prix de clôture
            
            # Calcul des variations en pourcentage
            changes = [abs(close_prices[i] - close_prices[i-1]) / close_prices[i-1] * 100 
                      for i in range(1, len(close_prices))]
            
            # Calcul de la volatilité pondérée (plus de poids aux changements récents)
            weighted_volatility = 0
            weight_sum = 0
            
            for i, change in enumerate(changes):
                weight = (i + 1) ** 2  # Poids croissant (plus récent = plus important)
                weighted_volatility += change * weight
                weight_sum += weight
            
            volatility = weighted_volatility / weight_sum if weight_sum > 0 else 0
            
            # Mise à jour du cache
            self.volatility_scores[symbol] = volatility
            
            return volatility
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de volatilité pour {symbol}: {e}")
            return 0
    
    def analyze_trend(self, symbol):
        """
        Analyse la tendance d'une paire sur les dernières périodes
        Retourne un score de tendance (positif = haussier, négatif = baissier)
        """
        try:
            # Extraire l'actif du symbole
            asset = symbol.split('/')[0]
            
            # Requête API pour les données OHLC (bougies)
            pair = f"X{asset}ZUSD"
            if asset in ['ZEREBRO', 'GARI', 'MANA', 'AUDIO', 'AVAX', 'TRX', 'LTC', 'EOS', 'ZRX', 'ALGO', 'ATOM', 'XRP', 'DOGE', 'SHIB', 'ADA', 'DOT']:
                pair = f"{asset}USD"
            
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})  # 5 minutes
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Erreur OHLC: {ohlc['error']} pour {symbol}")
                return 0
            
            # Extraction des données OHLC
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Extraction des prix de clôture
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]
            
            # Calcul de la tendance globale (20 périodes)
            overall_trend = (close_prices[-1] / close_prices[0] - 1) * 100
            
            # Calcul de la tendance récente (5 périodes)
            recent_trend = (close_prices[-1] / close_prices[-6] - 1) * 100 if len(close_prices) >= 6 else 0
            
            # Score de tendance combiné (70% récent, 30% global)
            trend_score = recent_trend * 0.7 + overall_trend * 0.3
            
            # Mise à jour du cache
            self.trend_scores[symbol] = trend_score
            
            return trend_score
        
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de tendance pour {symbol}: {e}")
            return 0
    
    def find_best_opportunities(self):
        """
        Identifie les meilleures opportunités de trading
        Retourne une liste triée des meilleures opportunités
        Version optimisée avec gestion des ressources et parallélisation
        """
        opportunities = []
        start_time = time.time()
        
        logger.info("⚡ ANALYSE MINUTE PAR MINUTE: recherche d'opportunités de trading...")
        
        # Utiliser le système de files d'attente optimisé si disponible
        if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
            # Fonction d'analyse pour chaque symbole
            def analyze_symbol(symbol):
                if symbol.split('/')[0] in self.exclude_pairs:
                    return None
                
                try:
                    # Vérifier si le prix est disponible
                    price = self.get_ticker_price(symbol)
                    if not price:
                        return None
                    
                    # Analyser la volatilité et la tendance
                    volatility = self.analyze_volatility(symbol)
                    trend = self.analyze_trend(symbol)
                    
                    # Score combiné basé sur volatilité et tendance - OPTIMISÉ pour score élevé
                    trend_factor = 1.5 if trend > 0 else -1
                    combined_score = (volatility * 2.5) + (abs(trend) * trend_factor * 0.5)
                    
                    logger.info(f"{symbol}: Volatilité {volatility:.2f}%, Tendance {trend:+.2f}%, Score {combined_score:.2f}")
                    
                    return {
                        'symbol': symbol,
                        'price': price,
                        'volatility': volatility,
                        'trend': trend,
                        'score': combined_score
                    }
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse de {symbol}: {e}")
                    return None
            
            # Analyser les symboles en parallèle avec le système de files d'attente
            results = []
            # Ajouter tous les symboles aux tâches
            for symbol in self.watch_pairs:
                # Utiliser une tâche prioritaire car c'est critique pour le trading
                task_id = f"analyze_{symbol}_{time.time()}"
                optimizations.add_priority_task(5, task_id, analyze_symbol, symbol)
            
            # Attendre que toutes les tâches soient terminées (max 5 secondes)
            time.sleep(5)
            
            # Collecter les résultats et filtrer les None
            opportunities = [opp for opp in results if opp is not None]
            
        else:
            # Méthode standard séquentielle
            for symbol in self.watch_pairs:
                if symbol.split('/')[0] in self.exclude_pairs:
                    continue
                
                try:
                    # Vérifier si le prix est disponible
                    price = self.get_ticker_price(symbol)
                    if not price:
                        continue
                    
                    # Analyser la volatilité et la tendance
                    volatility = self.analyze_volatility(symbol)
                    trend = self.analyze_trend(symbol)
                    
                    # Score combiné basé sur volatilité et tendance - OPTIMISÉ pour score élevé
                    # Valoriser la tendance positive, pénaliser la tendance négative moins sévèrement
                    trend_factor = 1.5 if trend > 0 else -1
                    combined_score = (volatility * 2.5) + (abs(trend) * trend_factor * 0.5)
                    
                    # Ajouter l'opportunité à la liste
                    opportunities.append({
                        'symbol': symbol,
                        'price': price,
                        'volatility': volatility,
                        'trend': trend,
                        'score': combined_score
                    })
                    
                    logger.info(f"{symbol}: Volatilité {volatility:.2f}%, Tendance {trend:+.2f}%, Score {combined_score:.2f}")
                    
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse de {symbol}: {e}")
        
        # Trier par score décroissant
        sorted_opps = sorted(opportunities, key=lambda x: x['score'], reverse=True)
        
        if sorted_opps:
            logger.info(f"Meilleure opportunité: {sorted_opps[0]['symbol']} (Score: {sorted_opps[0]['score']:.2f})")
        else:
            logger.info("Aucune opportunité de trading identifiée")
        
        # Enregistrer les métriques de performance
        total_time = time.time() - start_time
        if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
            optimizations.record_metric('market_analysis_time', total_time)
            logger.info(f"Analyse du marché terminée en {total_time:.2f}s avec optimisations")
        else:
            logger.info(f"Analyse du marché terminée en {total_time:.2f}s")
        
        return sorted_opps
    
    def set_stop_loss(self, symbol, entry_price):
        """
        Définit un stop-loss ultra-serré pour une position
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
            entry_price (float): Prix d'entrée
        """
        try:
            # Calculer le prix du stop-loss (0.5-0.8% sous le prix d'entrée)
            stop_loss_pct = random.uniform(0.5, 0.8)  # Variation légère pour éviter les détections
            stop_loss_price = entry_price * (1 - stop_loss_pct / 100)
            
            # Enregistrer le stop-loss
            self.stop_losses[symbol] = {
                'price': stop_loss_price,
                'entry_price': entry_price,
                'percentage': stop_loss_pct,
                'time': time.time()
            }
            
            logger.info(f"⚠️ Stop-loss défini pour {symbol}: {stop_loss_price:.6f} ({stop_loss_pct:.2f}%)")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de la définition du stop-loss pour {symbol}: {e}")
            return False
    
    def calculate_position_size(self, symbol, price):
        """
        Calcule la taille optimale de la position pour un trade
        en fonction du capital disponible et du risque max par trade
        Prend en compte les frais de transaction (0.26% par défaut)
        """
        # Frais de transaction Kraken (maker + taker / 2)
        transaction_fee = 0.0026  # 0.26%
        
        # Calculer le montant maximal pour ce trade
        max_trade_amount = self.usd_balance * self.max_risk_per_trade
        
        # Limiter à un montant minimal de 2 USD
        trade_amount = max(self.min_usd_per_trade, max_trade_amount)
        
        # Limiter au solde disponible et réserver les frais
        max_available = self.usd_balance * (1 - transaction_fee * 2)  # Réserver pour l'achat et la vente
        trade_amount = min(trade_amount, max_available * 0.95)  # 95% max du solde disponible
        
        # Calculer la quantité en tenant compte des frais
        quantity = trade_amount / (price * (1 + transaction_fee))
        
        logger.info(f"Position calculée pour {symbol}: {quantity:.6f} ({trade_amount:.2f} USD, frais inclus)")
        return quantity
    
    def execute_buy(self, symbol, quantity=None, percent_of_usd=None):
        """
        Exécute un ordre d'achat en temps réel
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
            quantity (float, optional): Quantité à acheter
            percent_of_usd (float, optional): Pourcentage du solde USD à utiliser
        """
        try:
            # Vérifier les paramètres
            if quantity is None and percent_of_usd is None:
                logger.error("Erreur: quantité ou pourcentage requis pour l'achat")
                return None
            
            # Extraire l'actif et la quote
            asset, quote = symbol.split('/')
            
            # Calculer la quantité si le pourcentage est fourni
            if percent_of_usd and not quantity:
                price = self.get_ticker_price(symbol)
                if not price:
                    logger.error(f"Impossible d'obtenir le prix pour {symbol}")
                    return None
                
                trade_amount = self.usd_balance * percent_of_usd
                quantity = trade_amount / price
            
            # S'assurer que la quantité est suffisante (minimum 100 pour ZEREBRO)
            if asset == 'ZEREBRO' and quantity < 100:
                logger.warning(f"Quantité trop faible pour {asset} ({quantity}), ajustement à 100")
                quantity = 100.0
            
            # Formater le symbole pour Kraken
            kraken_pair = f"{asset}{quote}"
            
            # Exécuter l'ordre d'achat en temps réel
            logger.info(f"⚡ ENVOI DE L'ORDRE D'ACHAT: {quantity:.6f} {asset}")
            
            start_time = time.time()
            order = self.k.query_private('AddOrder', {
                'pair': kraken_pair,
                'type': 'buy',
                'ordertype': 'market',
                'volume': str(quantity)
            })
            
            execution_time = (time.time() - start_time) * 1000  # ms
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur d'achat: {order['error']}")
                return None
            
            # Récupérer les détails de l'ordre
            txid = order['result']['txid'][0] if 'txid' in order['result'] else None
            
            logger.info(f"✅ ACHAT EXÉCUTÉ: {quantity:.6f} {asset} ({execution_time:.2f}ms) - ID: {txid}")
            
            # Enregistrer la preuve
            price = self.get_ticker_price(symbol)
            record_proof("BUY", asset, quantity, price, txid)
            
            # Mettre à jour les balances
            self.update_balances()
            
            # Définir un stop-loss pour cette position
            self.set_stop_loss(symbol, price)
            
            # Enregistrer l'heure d'entrée pour le calcul du temps de détention
            if symbol in self.stop_losses:
                self.stop_losses[symbol]['entry_time'] = time.time()
                
            return {
                'txid': txid,
                'symbol': symbol,
                'type': 'buy',
                'quantity': quantity,
                'price': price,
                'execution_time_ms': execution_time
            }
            
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {symbol}: {e}")
            return None
    
    def calculate_fee(self, amount, action="buy"):
        """
        Calcule les frais de transaction pour un montant donné
        
        Args:
            amount (float): Montant de la transaction en USD
            action (str): Type d'action ("buy" ou "sell")
            
        Returns:
            float: Montant des frais en USD
        """
        # Frais de transaction Kraken (taker pour les ordres market)
        fee_rate = 0.0026  # 0.26%
        
        # Réduction des frais pour les gros volumes (non implémenté ici)
        # Calcul des frais
        fee_amount = amount * fee_rate
        
        return fee_amount
    
    def execute_sell(self, symbol, quantity=None, percent_of_position=None):
        """
        Exécute un ordre de vente en temps réel
        
        Args:
            symbol (str): Symbole de la paire (ex: "MANA/USD")
            quantity (float, optional): Quantité à vendre
            percent_of_position (float, optional): Pourcentage de la position à vendre
        """
        try:
            # Vérifier les paramètres
            if quantity is None and percent_of_position is None:
                logger.error("Erreur: quantité ou pourcentage requis pour la vente")
                return None
            
            # Extraire l'actif et la quote
            asset, quote = symbol.split('/')
            
            # Vérifier si l'actif est disponible
            if asset not in self.positions:
                logger.error(f"Actif {asset} non disponible dans le portefeuille")
                return None
            
            # Calculer la quantité si le pourcentage est fourni
            if percent_of_position and not quantity:
                quantity = self.positions[asset] * percent_of_position
            
            # S'assurer que la quantité est suffisante (minimum 100 pour ZEREBRO)
            if asset == 'ZEREBRO' and quantity < 100:
                logger.warning(f"Quantité trop faible pour {asset} ({quantity}), ajustement à 100")
                quantity = 100.0
            
            # Obtenir le prix actuel pour estimer les frais
            price = self.get_ticker_price(symbol)
            if price:
                trade_value_usd = price * quantity
                fee_estimate = self.calculate_fee(trade_value_usd, "sell")
                logger.info(f"Frais estimés pour la vente: {fee_estimate:.4f} USD ({fee_estimate/trade_value_usd*100:.2f}%)")
                
                # Vérifier si le profit net est suffisant pour couvrir les frais
                if symbol in self.stop_losses and self.stop_losses[symbol].get('entry_price'):
                    entry_price = self.stop_losses[symbol]['entry_price']
                    gross_profit = (price - entry_price) * quantity
                    net_profit = gross_profit - fee_estimate - self.calculate_fee(entry_price * quantity, "buy")
                    profit_percent = (net_profit / (entry_price * quantity)) * 100 if entry_price > 0 else 0
                    
                    logger.info(f"Profit estimé: {gross_profit:.4f} USD brut, {net_profit:.4f} USD net ({profit_percent:.2f}%)")
                    
                    # Annuler si le profit net est négatif (sauf pour les stop-loss)
                    if net_profit < 0 and profit_percent > -0.5:  # Autoriser jusqu'à -0.5% pour les stop-loss
                        logger.warning(f"❌ Vente annulée: profit net négatif ({net_profit:.4f} USD)")
                        return None
            
            # Formater le symbole pour Kraken
            kraken_pair = f"{asset}{quote}"
            
            # Exécuter l'ordre de vente en temps réel
            logger.info(f"⚡ ENVOI DE L'ORDRE DE VENTE: {quantity:.6f} {asset}")
            
            start_time = time.time()
            order = self.k.query_private('AddOrder', {
                'pair': kraken_pair,
                'type': 'sell',
                'ordertype': 'market',
                'volume': str(quantity)
            })
            
            execution_time = (time.time() - start_time) * 1000  # ms
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur de vente: {order['error']}")
                return None
            
            # Récupérer les détails de l'ordre
            txid = order['result']['txid'][0] if 'txid' in order['result'] else None
            
            logger.info(f"✅ VENTE EXÉCUTÉE: {quantity:.6f} {asset} ({execution_time:.2f}ms) - ID: {txid}")
            
            # Enregistrer la preuve
            price = self.get_ticker_price(symbol)
            record_proof("SELL", asset, quantity, price, txid)
            
            # Mettre à jour les balances
            self.update_balances()
            
            # Supprimer le stop-loss associé si vente totale
            if percent_of_position == 1.0 and symbol in self.stop_losses:
                del self.stop_losses[symbol]
            
            return {
                'txid': txid,
                'symbol': symbol,
                'type': 'sell',
                'quantity': quantity,
                'price': price,
                'execution_time_ms': execution_time
            }
            
        except Exception as e:
            logger.error(f"Erreur lors de la vente de {symbol}: {e}")
            return None
    
    def check_stop_losses(self):
        """
        Vérifie tous les stop-losses et exécute les ventes si nécessaire
        Cette fonction est optimisée pour une exécution ultra-rapide (microsecondes)
        """
        for symbol, stop_loss in list(self.stop_losses.items()):
            try:
                # Obtenir le prix actuel
                current_price = self.get_ticker_price(symbol)
                if not current_price:
                    continue
                
                # Vérifier si le stop-loss est déclenché
                if current_price <= stop_loss['price']:
                    # Extraire l'actif
                    asset = symbol.split('/')[0]
                    
                    # Vérifier si l'actif est disponible
                    if asset not in self.positions:
                        del self.stop_losses[symbol]
                        continue
                    
                    logger.warning(f"⚠️ STOP-LOSS DÉCLENCHÉ pour {symbol} à {current_price:.6f}")
                    
                    # Vendre toute la position avec une exécution ultra-rapide
                    self.execute_sell(symbol, percent_of_position=1.0)
                    
                    # Supprimer le stop-loss
                    del self.stop_losses[symbol]
                    
            except Exception as e:
                logger.error(f"Erreur lors de la vérification du stop-loss pour {symbol}: {e}")
    
    def check_take_profits(self):
        """
        Vérifie toutes les positions pour prendre des profits si les objectifs sont atteints
        Intègre l'analyse d'extension de profit pour les opportunités exceptionnelles
        """
        for symbol, stop_loss in list(self.stop_losses.items()):
            try:
                # Obtenir le prix actuel
                current_price = self.get_ticker_price(symbol)
                if not current_price:
                    continue
                
                # Calculer le prix de take-profit standard
                take_profit_price = stop_loss['entry_price'] * (1 + self.take_profit_pct / 100)
                
                # Extraire l'actif
                asset = symbol.split('/')[0]
                
                # Vérifier si l'actif est disponible
                if asset not in self.positions:
                    del self.stop_losses[symbol]
                    continue
                
                # Calculer le profit actuel en pourcentage
                profit_pct = (current_price / stop_loss['entry_price'] - 1) * 100
                
                # Vérifier si le profit standard est atteint
                if current_price >= take_profit_price:
                    logger.info(f"🎯 TAKE-PROFIT STANDARD ATTEINT pour {symbol} à {current_price:.6f} "
                               f"(+{profit_pct:.2f}%)")
                    
                    # Calculer le temps de détention de la position
                    holding_time_minutes = 0
                    if 'entry_time' in stop_loss:
                        holding_time_minutes = (time.time() - stop_loss['entry_time']) / 60
                    
                    # Importer dynamiquement le module d'extension des profits si nécessaire
                    if not hasattr(self, 'extended_profit_module'):
                        try:
                            sys.path.append(os.path.dirname(os.path.abspath(__file__)))
                            from extended_profit_logic import integrate_extended_profit_logic
                            self.extended_profit_module = True
                            logger.info("Module d'extension de profit chargé avec succès")
                        except ImportError:
                            logger.warning("Module d'extension de profit non disponible, utilisation de la stratégie standard")
                            self.extended_profit_module = False
                    
                    # Évaluer si la position doit être maintenue pour profits étendus
                    extend_profit = False
                    extended_target = self.take_profit_pct
                    
                    if hasattr(self, 'extended_profit_module') and self.extended_profit_module:
                        try:
                            from extended_profit_logic import integrate_extended_profit_logic
                            
                            # Analyser l'opportunité d'extension
                            sell_decision, new_stop_loss, extended_target = integrate_extended_profit_logic(
                                self, symbol, stop_loss['entry_price'], current_price, 
                                self.positions.get(asset, 0), holding_time_minutes
                            )
                            
                            # Si on ne doit pas vendre, c'est une extension de profit
                            if not sell_decision:
                                extend_profit = True
                                
                                # Mettre à jour le stop-loss avec la nouvelle valeur
                                self.stop_losses[symbol]['price'] = new_stop_loss
                                logger.info(f"🚀 EXTENSION DE PROFIT pour {symbol}: "
                                          f"Objectif étendu à {extended_target:.2f}%, "
                                          f"Nouveau stop-loss: {new_stop_loss:.6f}")
                        except Exception as e:
                            logger.error(f"Erreur d'extension de profit pour {symbol}: {e}")
                            extend_profit = False
                    
                    # Si pas d'extension, appliquer la stratégie standard
                    if not extend_profit:
                        # Vendre 50% de la position pour sécuriser des profits
                        self.execute_sell(symbol, percent_of_position=0.5)
                        
                        # Mettre à jour le stop-loss au prix d'entrée (break-even)
                        self.stop_losses[symbol]['price'] = stop_loss['entry_price']
                        logger.info(f"🛡️ Stop-loss mis à jour au break-even pour {symbol}")
                
            except Exception as e:
                logger.error(f"Erreur lors de la vérification du take-profit pour {symbol}: {e}")
    
    def evaluate_opportunities(self):
        """Évalue les opportunités de trading et exécute des trades si pertinent"""
        try:
            # Mettre à jour les balances
            if not self.update_balances():
                logger.error("Impossible de mettre à jour les balances")
                return
            
            # Trouver les meilleures opportunités
            opportunities = self.find_best_opportunities()
            
            # Exécuter des trades si de bonnes opportunités sont disponibles
            for opp in opportunities[:3]:  # Top 3 opportunités
                if opp['score'] > 0.5 and opp['trend'] > 0:  # Seuil abaissé pour augmenter la fréquence des trades
                    # Vérifier si on a déjà une position
                    asset = opp['symbol'].split('/')[0]
                    if asset in self.positions and self.positions[asset] > 0:
                        logger.info(f"Position existante pour {asset}, pas de nouvel achat")
                        continue
                    
                    # Vérifier le solde USD
                    if self.usd_balance < self.min_usd_per_trade:
                        logger.warning(f"Solde USD insuffisant: {self.usd_balance:.2f} $")
                        break
                    
                    # Calculer la position
                    quantity = self.calculate_position_size(opp['symbol'], opp['price'])
                    
                    # Exécuter l'achat
                    logger.info(f"🚀 Opportunité détectée: {opp['symbol']} (Score: {opp['score']:.2f})")
                    self.execute_buy(opp['symbol'], quantity=quantity)
                    
                    # Une seule opportunité à la fois
                    break
        
        except Exception as e:
            logger.error(f"Erreur lors de l'évaluation des opportunités: {e}")
    
    def heartbeat(self):
        """Émet un signal de vie pour montrer que le trader est actif"""
        while self.running and not self.stop_event.is_set():
            try:
                # Écrire un heartbeat
                current_time = datetime.datetime.now()
                with open("bot_heartbeat.txt", "w") as f:
                    f.write(f"Trader vérifié actif: {current_time}")
                
                # Écrire aussi dans l'ancien fichier pour compatibilité
                with open("trader_heartbeat.txt", "w") as f:
                    f.write(f"Trader vérifié actif: {current_time}")
                
                # Collecter des métriques si les optimisations sont activées
                if 'OPTIMIZATIONS_ENABLED' in globals() and OPTIMIZATIONS_ENABLED:
                    # Métriques de base
                    optimizations.record_metric('timestamp', time.time())
                    optimizations.record_metric('usd_balance', self.usd_balance)
                    optimizations.record_metric('active_positions', len(self.positions))
                    optimizations.record_metric('active_stop_losses', len(self.stop_losses))
                    
                    # Métriques de performance
                    try:
                        import psutil
                        process = psutil.Process(os.getpid())
                        cpu_percent = process.cpu_percent(interval=0.1)
                        memory_info = process.memory_info()
                        memory_mb = memory_info.rss / (1024 * 1024)
                        
                        optimizations.record_metric('cpu_percent', cpu_percent)
                        optimizations.record_metric('memory_mb', memory_mb)
                        
                        # Statistiques système globales
                        system_memory = psutil.virtual_memory()
                        system_memory_percent = system_memory.percent
                        optimizations.record_metric('system_memory_percent', system_memory_percent)
                        
                        # Journaliser si les ressources sont sous pression
                        if cpu_percent > 80 or system_memory_percent > 90:
                            logger.warning(f"Ressources système sous pression: CPU {cpu_percent}%, Mémoire {system_memory_percent}%")
                            
                            # Prendre des mesures si les ressources sont gravement limitées
                            if cpu_percent > 95 or system_memory_percent > 95:
                                logger.error("ALERTE: Ressources système critiques, désactivation temporaire d'analyses non essentielles")
                    except:
                        # Continuer même si psutil n'est pas disponible
                        pass
                    
                    # Calculer la valeur totale du portefeuille
                    portfolio_value = self.usd_balance
                    for asset, amount in self.positions.items():
                        try:
                            price = self.get_ticker_price(f"{asset}/USD")
                            if price:
                                portfolio_value += price * amount
                        except Exception as e:
                            logger.debug(f"Impossible d'évaluer {asset}: {e}")
                    
                    optimizations.record_metric('portfolio_value_usd', portfolio_value)
                    
                    # Exporter les métriques au format JSON pour le monitoring externe
                    try:
                        with open("trader_metrics.json", "w") as f:
                            import json
                            json.dump(optimizations.get_metrics(), f)
                    except Exception as e:
                        logger.debug(f"Erreur lors de l'exportation des métriques: {e}")
                
                # Pause de 10 secondes
                time.sleep(10)
            except Exception as e:
                logger.error(f"Erreur dans le heartbeat: {e}")
                time.sleep(30)  # Pause plus longue en cas d'erreur
    
    def trading_loop(self):
        """Boucle principale de trading - Analyse continue du marché"""
        last_opportunity_check = 0
        
        while not self.stop_event.is_set():
            try:
                current_time = time.time()
                
                # Vérifier les stop-losses à haute fréquence (200ms)
                self.check_stop_losses()
                
                # Vérifier les take-profits toutes les secondes
                if int(current_time * 10) % 10 == 0:  # ~chaque seconde
                    self.check_take_profits()
                
                # Rechercher de nouvelles opportunités chaque minute
                if current_time - last_opportunity_check > self.check_interval:
                    self.evaluate_opportunities()
                    last_opportunity_check = current_time
                
                # Pause courte pour économiser les ressources CPU
                time.sleep(self.stop_loss_check_interval)
                
            except Exception as e:
                logger.error(f"Erreur dans la boucle de trading: {e}")
                time.sleep(1)  # Pause plus longue en cas d'erreur
    
    def start(self):
        """Démarrer le trader"""
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        try:
            # Mettre à jour les balances
            if not self.update_balances():
                logger.error("❌ ERREUR: Impossible de récupérer les balances. Vérifiez les clés API.")
                return False
            
            # Réinitialiser l'événement d'arrêt
            self.stop_event.clear()
            self.running = True
            
            # Démarrer la boucle de trading dans un thread
            self.trading_thread = threading.Thread(target=self.trading_loop)
            self.trading_thread.daemon = True
            self.trading_thread.start()
            
            # Démarrer le thread de heartbeat
            self.heartbeat_thread = threading.Thread(target=self.heartbeat)
            self.heartbeat_thread.daemon = True
            self.heartbeat_thread.start()
            
            logger.info("✅ Trader vérifié démarré en mode LIVE")
            
            # Créer un fichier PID
            with open("auto_trader_pid.txt", "w") as f:
                f.write(str(os.getpid()))
            
            # Créer aussi l'ancien fichier pour compatibilité
            with open("trader.pid", "w") as f:
                f.write(str(os.getpid()))
            
            # Initial display of all balances as proof
            self.update_balances()
            balances_msg = "BALANCES INITIALES:\n"
            for asset, amount in self.balances.items():
                balances_msg += f"{asset}: {float(amount):.6f}\n"
            logger.info(balances_msg)
            
            # Record the start proof
            record_proof("START", "SYSTEM", 0, 0, "TRADER_STARTED")
            
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors du démarrage du trader: {e}")
            return False
    
    def stop(self):
        """Arrêter le trader"""
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        try:
            # Signaler l'arrêt
            self.stop_event.set()
            
            # Attendre la fin des threads (max 5 secondes)
            if hasattr(self, 'trading_thread'):
                self.trading_thread.join(5)
            
            if hasattr(self, 'heartbeat_thread'):
                self.heartbeat_thread.join(5)
            
            self.running = False
            logger.info("✅ Trader arrêté")
            
            # Supprimer le fichier PID
            if os.path.exists("trader.pid"):
                os.remove("trader.pid")
            
            # Final display of all balances as proof
            self.update_balances()
            balances_msg = "BALANCES FINALES:\n"
            for asset, amount in self.balances.items():
                balances_msg += f"{asset}: {float(amount):.6f}\n"
            logger.info(balances_msg)
            
            # Record the stop proof
            record_proof("STOP", "SYSTEM", 0, 0, "TRADER_STOPPED")
            
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de l'arrêt du trader: {e}")
            return False

def start_trader():
    """Fonction principale pour démarrer le trader"""
    try:
        # Charger les variables d'environnement
        api_key, api_secret = load_env_vars()
        
        # Créer et démarrer le trader
        trader = AutoTrader(api_key, api_secret)
        
        if not trader.start():
            logger.error("Échec du démarrage du trader")
            return False
        
        # Maintenir le processus principal en vie (sauf Ctrl+C)
        try:
            logger.info("Trader démarré et fonctionnel. Appuyez sur Ctrl+C pour arrêter.")
            
            # Garder le processus en vie
            while trader.running:
                time.sleep(1)
                
                # Vérifier si le trader est toujours en cours d'exécution
                if not trader.trading_thread.is_alive():
                    logger.error("Thread de trading arrêté de manière inattendue, redémarrage...")
                    trader.stop()
                    time.sleep(1)
                    trader.start()
        
        except KeyboardInterrupt:
            logger.info("Arrêt du trader demandé par l'utilisateur")
            trader.stop()
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur critique lors du démarrage du trader: {e}")
        return False

if __name__ == "__main__":
    logger.info("=" * 80)
    logger.info("🚀 DÉMARRAGE DU TRADER AUTOMATIQUE VÉRIFIÉ - MODE LIVE UNIQUEMENT")
    logger.info("=" * 80)
    
    try:
        start_trader()
    except KeyboardInterrupt:
        logger.info("Programme arrêté par l'utilisateur")
    except Exception as e:
        logger.error(f"Erreur fatale: {e}")
        sys.exit(1)
    
    logger.info("=" * 80)
    logger.info("Trader terminé")
    logger.info("=" * 80)