#!/usr/bin/env python3
"""
TRADER MULTIASSET ULTRA-VOLATIL
- Analyse et trade TOUTES les cryptos volatiles à la microseconde
- Vise 2-3% de profit par trade
- Stop-loss ultra-serré (0.5-0.8%)
- Détecte et exploite les cryptos en forte tendance haussière
- Mesure précise des performances (µs) pour optimisation
"""
import krakenex
import time
import logging
from datetime import datetime, timedelta
import sys
import threading
import json
import os
import random

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("volatile_trades.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Logger dédié pour les métriques de performance
perf_logger = logging.getLogger('performance')
perf_handler = logging.FileHandler('performance_metrics.log')
perf_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
perf_logger.addHandler(perf_handler)
perf_logger.setLevel(logging.INFO)
perf_logger.propagate = False  # Ne pas envoyer au logger parent

def log_performance(stage, start_time, asset=None):
    """Log les métriques de performance d'une étape
    
    Args:
        stage (str): Nom de l'étape (fetch_data, analyze, etc.)
        start_time (float): Temps de démarrage (time.perf_counter())
        asset (str, optional): Actif concerné
    """
    duration_ms = (time.perf_counter() - start_time) * 1000
    asset_info = f" [{asset}]" if asset else ""
    perf_logger.info(f"{stage}{asset_info}: {duration_ms:.3f} ms")

# Clés API Kraken
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

# Crypto-monnaies à surveiller pour opportunities
WATCH_LIST = [
    "ZEREBRO", "MANA", "FTM", "GARI", "AVAX", "LINK", "DOGE", "SHIB", "MATIC",
    "DOT", "ADA", "ATOM", "XRP", "SAND", "ALGO", "ENJ", "1INCH", "AAVE", "KAVA", "DYDX"
]

# Crypto-monnaies à exclure (selon la demande du client)
EXCLUDE_LIST = ["BTC", "ETH", "SOL"]

class VolatilityTrader:
    def __init__(self):
        """Initialise le trader multiasset"""
        self.k = krakenex.API(API_KEY, API_SECRET)
        self.running = False
        self.threads = []
        
        # Cache pour les prix et les scores
        self.price_cache = {}
        self.volatility_scores = {}
        self.trend_scores = {}
        self.combined_scores = {}
        self.last_analysis_time = 0  # Dernière analyse complète
        
        # Positions actuelles
        self.current_positions = {}
        self.usd_balance = 0
        
        # État des trades
        self.pending_trades = {}
        self.trade_history = []
        
        # Paramètres de trading
        self.check_interval = 5  # secondes - vérification très fréquente
        self.analysis_interval = 60  # secondes - analyse complète chaque minute
        self.min_trade_value_usd = 5  # Valeur minimale pour trader
        
        logger.info("✅ Trader Multiasset initialisé")
    
    def update_balances(self):
        """Mise à jour des balances du compte"""
        try:
            balances = self.k.query_private('Balance')
            
            if 'error' in balances and balances['error']:
                logger.error(f"Erreur lors de la récupération des balances: {balances['error']}")
                return False
            
            self.current_positions = {}
            self.usd_balance = float(balances['result'].get('ZUSD', 0))
            
            for asset, balance in balances['result'].items():
                if asset == 'ZUSD':
                    continue
                    
                balance_float = float(balance)
                if balance_float > 0.001:  # Ignorer les très petits soldes
                    self.current_positions[asset] = balance_float
            
            logger.info(f"Balances mises à jour: {len(self.current_positions)} actifs trouvés")
            logger.info(f"Solde USD: {self.usd_balance} USD")
            
            # Journaliser les actifs avec un solde significatif
            significant_assets = []
            for asset, balance in self.current_positions.items():
                try:
                    # Obtenir le prix actuel
                    price = self.get_price(asset)
                    if price:
                        usd_value = price * balance
                        
                        if usd_value > self.min_trade_value_usd:
                            significant_assets.append(f"{asset}: {balance:.4f} (~{usd_value:.2f} USD)")
                except Exception as e:
                    logger.warning(f"Impossible d'obtenir le prix pour {asset}: {e}")
            
            if significant_assets:
                logger.info(f"Actifs significatifs: {', '.join(significant_assets)}")
            
            return True
        except Exception as e:
            logger.error(f"Erreur lors de la mise à jour des balances: {e}")
            return False
    
    def get_price(self, asset):
        """Obtenir le prix actuel d'un actif"""
        start_time = time.perf_counter()
        try:
            # Vérifier si on a un prix en cache récent (<3 secondes)
            if asset in self.price_cache:
                cache_age = time.time() - self.price_cache[asset]['timestamp']
                if cache_age < 3.0:  # Utiliser le cache pour 3 secondes max
                    log_performance("get_price_cache", start_time, asset)
                    return self.price_cache[asset]['price']
            
            # Sinon, requête à l'API
            pair = f"{asset}USD"
            api_start = time.perf_counter()
            ticker = self.k.query_public('Ticker', {'pair': pair})
            log_performance("kraken_api_ticker", api_start, asset)
            
            if 'error' in ticker and ticker['error']:
                # Essayer avec USDT si USD ne fonctionne pas
                pair = f"{asset}USDT"
                ticker = self.k.query_public('Ticker', {'pair': pair})
            
            if 'error' in ticker and ticker['error']:
                logger.warning(f"Paire {asset}/USD et {asset}/USDT non disponible")
                return None
            
            # Récupérer le prix de clôture
            price = float(ticker['result'][list(ticker['result'].keys())[0]]['c'][0])
            
            # Mettre à jour le cache
            self.price_cache[asset] = {
                'price': price,
                'timestamp': time.time()
            }
            
            log_performance("get_price_total", start_time, asset)
            return price
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix pour {asset}: {e}")
            return None
    
    def analyze_volatility(self, asset):
        """Analyser la volatilité d'un actif"""
        start_time = time.perf_counter()
        try:
            # Obtenir les données OHLC
            pair = f"{asset}USD"
            api_start = time.perf_counter()
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})  # 5 minutes
            log_performance("kraken_api_ohlc", api_start, asset)
            
            if 'error' in ohlc and ohlc['error']:
                # Essayer avec USDT
                pair = f"{asset}USDT"
                ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Données OHLC non disponibles pour {asset}")
                return 0
            
            # Récupérer les dernières données
            calc_start = time.perf_counter()
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Extraire les prix de clôture
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]
            
            # Calculer les variations en pourcentage
            changes = [abs(close_prices[i] - close_prices[i-1]) / close_prices[i-1] * 100 
                      for i in range(1, len(close_prices))]
            
            # Donner plus de poids aux changements récents
            weighted_volatility = 0
            weight_sum = 0
            
            for i, change in enumerate(changes):
                # Poids plus élevé pour les changements récents
                weight = (i + 1) ** 2
                weighted_volatility += change * weight
                weight_sum += weight
            
            volatility = weighted_volatility / weight_sum if weight_sum > 0 else 0
            log_performance("volatility_calculation", calc_start, asset)
            
            # Mettre à jour le cache de volatilité
            self.volatility_scores[asset] = volatility
            
            log_performance("volatility_analysis_total", start_time, asset)
            return volatility
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de volatilité pour {asset}: {e}")
            return 0
    
    def analyze_trend(self, asset):
        """Analyser la tendance d'un actif"""
        try:
            pair = f"{asset}USD"
            ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})
            
            if 'error' in ohlc and ohlc['error']:
                # Essayer avec USDT
                pair = f"{asset}USDT"
                ohlc = self.k.query_public('OHLC', {'pair': pair, 'interval': 5})
            
            if 'error' in ohlc and ohlc['error']:
                logger.warning(f"Données OHLC non disponibles pour {asset}")
                return 0
            
            # Récupérer les dernières données
            ohlc_data = ohlc['result'][list(ohlc['result'].keys())[0]]
            
            # Extraire les prix de clôture
            close_prices = [float(candle[4]) for candle in ohlc_data[-20:]]
            
            # Tendance globale (20 périodes)
            overall_trend = (close_prices[-1] / close_prices[0] - 1) * 100
            
            # Tendance récente (5 périodes)
            recent_trend = (close_prices[-1] / close_prices[-6] - 1) * 100 if len(close_prices) >= 6 else 0
            
            # Score de tendance combiné (70% récent, 30% global)
            trend_score = recent_trend * 0.7 + overall_trend * 0.3
            
            # Mettre à jour le cache de tendance
            self.trend_scores[asset] = trend_score
            
            return trend_score
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse de tendance pour {asset}: {e}")
            return 0
    
    def find_best_opportunities(self):
        """Trouver les meilleures opportunités de trading"""
        try:
            # Vérifier si une analyse complète est nécessaire (toutes les minutes)
            current_time = time.time()
            force_analysis = (current_time - self.last_analysis_time) >= self.analysis_interval
            
            if not force_analysis and self.combined_scores:
                # Utiliser les résultats précédents s'ils existent et sont récents
                return sorted(self.combined_scores.items(), key=lambda x: x[1], reverse=True)
            
            # Mise à jour de l'heure de dernière analyse
            self.last_analysis_time = current_time
            logger.info("⚡ ANALYSE MINUTE PAR MINUTE: recherche des meilleures opportunités...")
            
            # Construire la liste des actifs à analyser
            assets_to_analyze = list(set(WATCH_LIST) | set(self.current_positions.keys()))
            assets_to_analyze = [asset for asset in assets_to_analyze if asset not in EXCLUDE_LIST]
            
            # Réinitialiser les scores
            self.combined_scores = {}
            
            for asset in assets_to_analyze:
                try:
                    # Vérifier si le prix est disponible
                    price = self.get_price(asset)
                    if not price:
                        continue
                    
                    # Analyser la volatilité
                    volatility = self.analyze_volatility(asset)
                    
                    # Analyser la tendance
                    trend = self.analyze_trend(asset)
                    
                    # Score combiné: 60% volatilité, 40% tendance
                    # Tendance positive valorisée, tendance négative pénalisée
                    trend_factor = 1 if trend > 0 else -2
                    combined_score = (volatility * 0.6) + (abs(trend) * trend_factor * 0.4)
                    
                    # Stocker le score
                    self.combined_scores[asset] = combined_score
                    
                    logger.info(f"{asset}: Volatilité {volatility:.2f}%, Tendance {trend:+.2f}%, Score {combined_score:.2f}")
                    
                except Exception as e:
                    logger.error(f"Erreur lors de l'analyse de {asset}: {e}")
            
            # Trier par score
            sorted_opportunities = sorted(
                self.combined_scores.items(), 
                key=lambda x: x[1], 
                reverse=True
            )
            
            # Retourner les meilleures opportunités
            return sorted_opportunities
            
        except Exception as e:
            logger.error(f"Erreur lors de la recherche d'opportunités: {e}")
            return []
    
    def sell_asset(self, asset, reason="TARGET_PROFIT"):
        """Vendre un actif"""
        start_time = time.perf_counter()
        try:
            # Vérifier si nous avons cet actif
            if asset not in self.current_positions or self.current_positions[asset] < 0.001:
                logger.warning(f"Pas de {asset} à vendre")
                return False
            
            quantity = self.current_positions[asset]
            price = self.get_price(asset)
            
            if not price:
                logger.error(f"Impossible d'obtenir le prix pour {asset}")
                return False
            
            logger.info(f"VENTE de {quantity:.4f} {asset} à environ {price:.6f} USD (raison: {reason})")
            
            # Placer l'ordre de vente
            pair = f"{asset}USD"
            api_start = time.perf_counter()
            order = self.k.query_private('AddOrder', {
                'pair': pair,
                'type': 'sell',
                'ordertype': 'market',
                'volume': str(quantity)
            })
            log_performance("kraken_api_sell_order", api_start, asset)
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur lors de la vente de {asset}: {order['error']}")
                return False
            
            tx_id = order['result']['txid'][0]
            logger.info(f"✅ Vente de {asset} réussie! ID: {tx_id}")
            
            # Si c'était un trade en cours, calculer le profit
            if asset in self.pending_trades:
                entry_price = self.pending_trades[asset]['entry_price']
                profit_pct = (price / entry_price - 1) * 100
                
                trade_record = {
                    "timestamp": datetime.now().isoformat(),
                    "asset": asset,
                    "action": "sell",
                    "quantity": quantity,
                    "price": price,
                    "profit_pct": profit_pct,
                    "entry_price": entry_price,
                    "reason": reason,
                    "txid": tx_id
                }
                
                self.trade_history.append(trade_record)
                
                # Journaliser dans un fichier
                with open('trading_history.json', 'a') as f:
                    f.write(json.dumps(trade_record) + '\n')
                
                # Supprimer des trades en cours
                del self.pending_trades[asset]
                
                logger.info(f"💰 Profit réalisé: {profit_pct:+.2f}%")
            
            # Mettre à jour les balances
            balance_start = time.perf_counter()
            self.update_balances()
            log_performance("update_balances_after_sell", balance_start)
            
            log_performance("sell_asset_total", start_time, asset)
            return True
        except Exception as e:
            logger.error(f"Erreur lors de la vente de {asset}: {e}")
            return False
    
    def buy_asset(self, asset, usd_amount=None):
        """Acheter un actif"""
        start_time = time.perf_counter()
        try:
            # Si aucun montant spécifié, utiliser 95% du solde USD disponible
            if usd_amount is None:
                usd_amount = self.usd_balance * 0.95
            
            # Vérifier si on a assez d'USD
            if self.usd_balance < usd_amount or usd_amount < self.min_trade_value_usd:
                logger.warning(f"Solde USD insuffisant: {self.usd_balance} USD")
                return False
            
            # Obtenir le prix actuel (déjà optimisé avec cache)
            price = self.get_price(asset)
            if not price:
                logger.error(f"Impossible d'obtenir le prix pour {asset}")
                return False
            
            # Calculer la quantité à acheter
            calc_start = time.perf_counter()
            quantity = usd_amount / price * 0.995  # Réduction légère pour compenser les fluctuations
            
            # Placer l'ordre d'achat
            pair = f"{asset}USD"
            
            logger.info(f"ACHAT de {quantity:.4f} {asset} à environ {price:.6f} USD")
            
            api_start = time.perf_counter()
            order = self.k.query_private('AddOrder', {
                'pair': pair,
                'type': 'buy',
                'ordertype': 'market',
                'volume': str(quantity)
            })
            log_performance("kraken_api_buy_order", api_start, asset)
            
            if 'error' in order and order['error']:
                logger.error(f"Erreur lors de l'achat de {asset}: {order['error']}")
                return False
            
            tx_id = order['result']['txid'][0]
            logger.info(f"✅ Achat de {asset} réussi! ID: {tx_id}")
            
            # Définir les paramètres de sortie en tenant compte des frais
            setup_start = time.perf_counter()
            fee_rate = 0.0026  # 0.26% de frais sur Kraken (taker)
            total_fees = fee_rate * 2  # Frais pour acheter + vendre
            
            # Objectif de profit NET incluant les frais
            target_gross_profit_rate = 0.025 + total_fees  # 2.5% net + frais
            
            # Définir un stop loss adaptatif en fonction de la volatilité
            volatility = self.volatility_scores.get(asset, 2.0)
            
            # Pour les actifs plus volatils, stop-loss légèrement plus large
            # Mais toujours tenant compte des frais pour éviter de sortir à perte
            # sur de simples fluctuations normales
            base_stop_loss = total_fees * 1.5  # Minimum: 1.5x les frais totaux
            
            if volatility > 4.0:  # Volatilité très élevée
                stop_loss_rate = max(0.008, base_stop_loss)  # 0.8% ou plus
            elif volatility > 2.0:  # Volatilité modérée à élevée
                stop_loss_rate = max(0.006, base_stop_loss)  # 0.6% ou plus
            else:  # Volatilité faible
                stop_loss_rate = max(0.005, base_stop_loss)  # 0.5% ou plus
            
            logger.info(f"Configuration du trade: Objectif brut {target_gross_profit_rate*100:.2f}% (net: 2.5%), Stop-loss {stop_loss_rate*100:.2f}%")
            logger.info(f"Frais totaux estimés: {total_fees*100:.2f}% ({fee_rate*100:.2f}% x2)")
            
            target_price = price * (1 + target_gross_profit_rate)
            stop_loss_price = price * (1 - stop_loss_rate)
            log_performance("setup_trade_params", setup_start, asset)
            
            # Enregistrer dans les trades en cours
            self.pending_trades[asset] = {
                'entry_price': price,
                'quantity': quantity,
                'entry_time': time.time(),
                'target_price': target_price,
                'stop_loss_price': stop_loss_price,
                'target_profit_rate': target_gross_profit_rate,
                'stop_loss_rate': stop_loss_rate,
                'txid': tx_id
            }
            
            logger.info(f"🎯 Objectif pour {asset}: {target_price:.6f} USD (+{target_gross_profit_rate*100:.1f}%)")
            logger.info(f"🛑 Stop loss: {stop_loss_price:.6f} USD (-{stop_loss_rate*100:.1f}%)")
            
            # Mettre à jour les balances
            balance_start = time.perf_counter()
            self.update_balances()
            log_performance("update_balances_after_buy", balance_start)
            
            log_performance("buy_asset_total", start_time, asset)
            return True
        except Exception as e:
            logger.error(f"Erreur lors de l'achat de {asset}: {e}")
            return False
    
    def check_positions(self):
        """Vérifier toutes les positions pour stop loss ou take profit"""
        overall_start = time.perf_counter()
        positions_checked = 0
        
        for asset, trade_data in list(self.pending_trades.items()):
            position_start = time.perf_counter()
            try:
                # Obtenir le prix actuel - utilise déjà le cache (3 secondes max)
                price = self.get_price(asset)
                if not price:
                    continue
                
                entry_price = trade_data['entry_price']
                target_price = trade_data['target_price']
                stop_loss_price = trade_data['stop_loss_price']
                
                # Calculer le profit actuel
                decision_start = time.perf_counter()
                profit_pct = (price / entry_price - 1) * 100
                time_held = (time.time() - trade_data['entry_time']) / 60  # minutes
                
                # Vérifier si on atteint l'objectif de profit
                if price >= target_price:
                    logger.info(f"🎯 OBJECTIF DE PROFIT ATTEINT pour {asset}: {profit_pct:+.2f}% en {time_held:.1f} minutes")
                    log_performance("decision_take_profit", decision_start, asset)
                    self.sell_asset(asset, reason="TARGET_PROFIT")
                
                # Vérifier si on atteint le stop loss
                elif price <= stop_loss_price:
                    logger.info(f"⚠️ STOP LOSS DÉCLENCHÉ pour {asset}: {profit_pct:+.2f}% en {time_held:.1f} minutes")
                    log_performance("decision_stop_loss", decision_start, asset)
                    self.sell_asset(asset, reason="STOP_LOSS")
                
                # Afficher le statut
                else:
                    # Calculer la distance par rapport aux objectifs
                    target_distance = (target_price - price) / price * 100
                    stop_loss_distance = (price - stop_loss_price) / price * 100
                    
                    logger.info(f"{asset}: P&L actuel {profit_pct:+.2f}% | "
                               f"Target: {target_distance:.2f}% restant | "
                               f"Stop-loss: {stop_loss_distance:.2f}% restant")
                    log_performance("decision_holding", decision_start, asset)
                
                positions_checked += 1
                log_performance(f"check_position", position_start, asset)
            except Exception as e:
                logger.error(f"Erreur lors de la vérification de {asset}: {e}")
        
        if positions_checked > 0:
            log_performance(f"check_all_positions ({positions_checked})", overall_start)
    
    def evaluate_new_opportunities(self):
        """Évaluer les nouvelles opportunités de trading"""
        start_time = time.perf_counter()
        
        # Vérifier si on a de l'USD disponible
        if self.usd_balance < self.min_trade_value_usd:
            logger.info(f"Pas assez d'USD pour de nouvelles opportunités: {self.usd_balance:.2f} USD")
            return
        
        # Trouver les meilleures opportunités
        opportunities_start = time.perf_counter()
        opportunities = self.find_best_opportunities()
        log_performance("find_opportunities", opportunities_start)
        
        if not opportunities:
            logger.info("Aucune opportunité intéressante trouvée")
            return
        
        # Prendre les 3 meilleures opportunités
        decision_start = time.perf_counter()
        top_opportunities = opportunities[:3]
        
        for asset, score in top_opportunities:
            # Ignorer si déjà en trade
            if asset in self.pending_trades:
                continue
                
            # Ignorer si score trop bas
            if score < 1.0:
                logger.info(f"Score trop bas pour {asset}: {score:.2f}")
                continue
            
            logger.info(f"🔍 Opportunité détectée: {asset} (Score: {score:.2f})")
            log_performance("decision_trading", decision_start, asset)
            
            # Calculer le montant à investir (division du capital disponible)
            usd_amount = self.usd_balance * 0.95
            
            # Exécuter l'achat - mesure incluse dans buy_asset
            order_start = time.perf_counter()
            trade_result = self.buy_asset(asset, usd_amount)
            log_performance("order_execution", order_start, asset)
            
            if trade_result:
                logger.info(f"💹 Nouvelle position ouverte sur {asset}")
                break  # Une seule position à la fois pour l'instant
        
        log_performance("evaluate_opportunities_total", start_time)
    
    def trading_loop(self):
        """Boucle principale de trading"""
        logger.info("⚡ DÉMARRAGE DE LA BOUCLE DE TRADING ULTRA-VOLATIL (ANALYSE MINUTE PAR MINUTE)")
        
        # Mise à jour des balances
        self.update_balances()
        
        try:
            while self.running:
                # 1. Vérifier les positions existantes - très fréquemment pour réagir rapidement
                if self.pending_trades:
                    logger.info(f"Surveillance en temps réel: {len(self.pending_trades)} positions actives")
                    self.check_positions()
                
                # 2. Chercher de nouvelles opportunités si on a des fonds disponibles
                else:
                    # L'analyse complète se fait maintenant chaque minute automatiquement
                    # (contrôlé par le paramètre analysis_interval)
                    logger.info("Scan minute par minute des opportunités de marché")
                    self.evaluate_new_opportunities()
                
                # Pause courte pour une réactivité quasi-immédiate
                time.sleep(self.check_interval)
                
        except Exception as e:
            logger.error(f"Erreur dans la boucle de trading: {e}")
        finally:
            logger.info("Boucle de trading arrêtée")
    
    def start(self):
        """Démarrer le trader"""
        if self.running:
            logger.warning("Le trader est déjà en cours d'exécution")
            return False
        
        self.running = True
        
        # Démarrer la boucle de trading dans un thread
        thread = threading.Thread(target=self.trading_loop)
        thread.daemon = True
        thread.start()
        
        self.threads.append(thread)
        
        logger.info("🚀 Trader volatil démarré")
        return True
    
    def stop(self):
        """Arrêter le trader"""
        if not self.running:
            logger.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        logger.info("Arrêt du trader en cours...")
        self.running = False
        
        # Attendre que les threads se terminent
        for thread in self.threads:
            thread.join(timeout=2)
        
        logger.info("🛑 Trader arrêté")
        return True


def main():
    """Fonction principale"""
    print("=" * 80)
    print("DÉMARRAGE DU TRADER MULTI-CRYPTO ULTRA-VOLATIL")
    print("=" * 80)
    print("Version: 1.0 (optimisée pour profits rapides de 2-3% par trade)")
    print("=" * 80)
    
    trader = VolatilityTrader()
    
    # Mise à jour des balances initiales
    trader.update_balances()
    
    # Démarrer le trader
    print("Démarrage du trader...")
    trader.start()
    
    print("\n" + "!" * 80)
    print("TRADER DÉMARRÉ AVEC SUCCÈS!")
    print("Le système recherche et trade maintenant les cryptos ultra-volatiles en uptrend")
    print("Objectif: 2-3% par trade, stop-loss serré 0.5-0.8%")
    print("!" * 80)
    
    # Afficher les mises à jour périodiques
    try:
        while True:
            time.sleep(60)  # Mise à jour toutes les minutes
            
            # Afficher les positions actuelles
            if trader.pending_trades:
                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] POSITIONS EN COURS:")
                
                for asset, trade_data in trader.pending_trades.items():
                    price = trader.get_price(asset)
                    if price:
                        profit_pct = (price / trade_data['entry_price'] - 1) * 100
                        time_held = (time.time() - trade_data['entry_time']) / 60
                        
                        print(f"  {asset}: {profit_pct:+.2f}% en {time_held:.1f} min | "
                              f"Entrée: {trade_data['entry_price']:.6f} | "
                              f"Actuel: {price:.6f} | "
                              f"Target: {trade_data['target_price']:.6f} | "
                              f"Stop: {trade_data['stop_loss_price']:.6f}")
            else:
                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Aucune position ouverte")
                print(f"  USD disponible: {trader.usd_balance:.2f} USD")
                print(f"  Recherche de cryptos ultra-volatiles en uptrend...")
    
    except KeyboardInterrupt:
        print("\nArrêt demandé par l'utilisateur...")
        trader.stop()
        print("Trader arrêté avec succès.")


if __name__ == "__main__":
    main()