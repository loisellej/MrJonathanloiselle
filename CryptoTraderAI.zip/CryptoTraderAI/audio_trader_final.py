import krakenex
import json
import time
import logging
from datetime import datetime

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "b9HszO4heogjmug190T2O4LSBG1dZEjlD72WwGnNVrNZtVelCofyQIi8"
API_SECRET = "+zEmXlUxhaR4mAyqyE/A6vnfaaF7wPzUHmfDpe0yUSgftagOoRS4BMAP0MjZKh0rDxIKKtORGcgL+V7jMVX77w=="

def trade_audio():
    """
    Trader AUDIO:
    - Vérifie le solde actuel
    - Vend un petit montant d'AUDIO
    - Place un ordre limite pour racheter à un prix plus bas
    """
    logger.info("=== 🔄 DÉMARRAGE DU TRADING AUDIO ===")
    logger.info(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Récupérer les balances
        balances = k.query_private('Balance')
        
        if 'error' in balances and balances['error']:
            logger.error(f"❌ Erreur lors de la récupération des balances: {balances['error']}")
            return False
        
        # Afficher les balances actuelles
        logger.info("💰 Balances actuelles:")
        for asset, balance in balances['result'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Vérifier le solde AUDIO
        audio_balance = float(balances['result'].get('AUDIO', 0))
        
        if audio_balance < 10:
            logger.error(f"❌ Solde AUDIO insuffisant: {audio_balance}")
            return False
        
        # Obtenir le prix actuel d'AUDIO
        ticker = k.query_public('Ticker', {'pair': 'AUDIOUSD'})
        current_price = float(ticker['result']['AUDIOUSD']['c'][0])
        logger.info(f"💹 Prix actuel d'AUDIO: {current_price} USD")
        
        # Calculer le montant à vendre (3% de l'AUDIO disponible)
        amount_to_sell = audio_balance * 0.03
        amount_to_sell = round(amount_to_sell, 1)  # Arrondir à 1 décimale
        
        if amount_to_sell < 10:
            amount_to_sell = 10  # Minimum 10 AUDIO pour éviter les ordres trop petits
        
        # Maximum 100 AUDIO par trade pour limiter le risque
        if amount_to_sell > 100:
            amount_to_sell = 100
            
        logger.info(f"📊 Stratégie de vente: {amount_to_sell} AUDIO à environ {current_price} USD")
        
        # Vérifier si le montant à vendre est raisonnable par rapport au solde
        sell_value_usd = amount_to_sell * current_price
        logger.info(f"💵 Valeur de la vente: environ {sell_value_usd:.2f} USD")
        
        # Exécuter la vente (ordre market)
        logger.info("🔴 Placement de l'ordre de vente (market)...")
        sell_order = k.query_private('AddOrder', {
            'pair': 'AUDIOUSD',
            'type': 'sell',
            'ordertype': 'market',
            'volume': str(amount_to_sell)
        })
        
        if 'error' in sell_order and sell_order['error']:
            logger.error(f"❌ Erreur lors de la vente: {sell_order['error']}")
            return False
        
        # Récupérer l'ID de l'ordre pour le suivi
        order_txid = sell_order['result']['txid'][0]
        logger.info(f"✅ Ordre de vente placé avec succès: ID {order_txid}")
        
        # Attendre la confirmation de l'exécution (5 secondes)
        logger.info("⏳ Attente de la confirmation de l'exécution...")
        time.sleep(5)
        
        # Vérifier l'état de l'ordre
        order_status = k.query_private('QueryOrders', {'txid': order_txid})
        
        if 'error' in order_status and order_status['error']:
            logger.error(f"❌ Erreur lors de la vérification de l'état de l'ordre: {order_status['error']}")
        else:
            logger.info(f"📋 État de l'ordre: {order_status['result'][order_txid]['status']}")
        
        # Récupérer les nouvelles balances
        new_balances = k.query_private('Balance')
        
        logger.info("💰 Balances après la vente:")
        for asset, balance in new_balances['result'].items():
            if float(balance) > 0.001:
                logger.info(f"  {asset}: {balance}")
        
        # Récupérer le solde USD disponible
        usd_balance = float(new_balances['result'].get('ZUSD', 0))
        logger.info(f"💵 Solde USD disponible: {usd_balance}")
        
        if usd_balance < 5:
            logger.warning("⚠️ Solde USD insuffisant pour placer un ordre d'achat")
            return True  # On considère que l'opération a réussi
        
        # Placer un ordre d'achat limit à un prix 2.5% inférieur
        buy_price = current_price * 0.975
        buy_price = round(buy_price, 4)  # Arrondir à 4 décimales (maximum autorisé pour AUDIO/USD)
        
        # Calculer combien d'AUDIO on peut racheter
        # Utiliser 95% du solde USD pour tenir compte des frais
        amount_to_buy = (usd_balance * 0.95) / buy_price
        amount_to_buy = round(amount_to_buy, 1)  # Arrondir à 1 décimale
        
        logger.info(f"🟢 Placement d'un ordre d'achat limit: {amount_to_buy} AUDIO à {buy_price} USD")
        
        # Exécuter l'achat (ordre limit)
        buy_order = k.query_private('AddOrder', {
            'pair': 'AUDIOUSD',
            'type': 'buy',
            'ordertype': 'limit',
            'price': str(buy_price),
            'volume': str(amount_to_buy)
        })
        
        if 'error' in buy_order and buy_order['error']:
            logger.error(f"❌ Erreur lors de la création de l'ordre d'achat: {buy_order['error']}")
            return True  # La vente a réussi, c'est déjà ça
        
        # Récupérer l'ID de l'ordre pour le suivi
        buy_txid = buy_order['result']['txid'][0]
        logger.info(f"✅ Ordre d'achat placé avec succès: ID {buy_txid}")
        
        # Enregistrer les détails du trade dans un fichier journal
        with open('audio_trades.log', 'a') as f:
            f.write(f"[{datetime.now().isoformat()}] VENTE: {amount_to_sell} AUDIO à {current_price} USD (ID: {order_txid})\n")
            f.write(f"[{datetime.now().isoformat()}] ACHAT: {amount_to_buy} AUDIO à {buy_price} USD (ID: {buy_txid})\n")
            f.write(f"[{datetime.now().isoformat()}] PROFIT POTENTIEL: {(current_price - buy_price) * amount_to_buy:.2f} USD ({(1 - buy_price/current_price) * 100:.2f}%)\n")
            f.write("-" * 50 + "\n")
        
        logger.info(f"📈 Profit potentiel: {(current_price - buy_price) * amount_to_buy:.2f} USD ({(1 - buy_price/current_price) * 100:.2f}%)")
        logger.info("✅ TRADING AUDIO TERMINÉ AVEC SUCCÈS")
        
        return True
    
    except Exception as e:
        logger.error(f"❌ Erreur critique lors du trading: {e}")
        return False

def check_open_orders(cancel_all=False):
    """Vérifie et affiche les ordres ouverts, les annule si demandé"""
    logger.info("=== VÉRIFICATION DES ORDRES OUVERTS ===")
    
    try:
        # Initialiser l'API Kraken
        k = krakenex.API(API_KEY, API_SECRET)
        
        # Récupérer les ordres ouverts
        open_orders = k.query_private('OpenOrders')
        
        if 'error' in open_orders and open_orders['error']:
            logger.error(f"Erreur lors de la récupération des ordres ouverts: {open_orders['error']}")
            return False
        
        # Compter le nombre d'ordres ouverts
        num_orders = len(open_orders['result']['open'])
        
        if num_orders == 0:
            logger.info("Aucun ordre ouvert actuellement.")
            return True
        
        logger.info(f"Nombre d'ordres ouverts: {num_orders}")
        
        # Afficher les détails de chaque ordre
        for order_id, order_details in open_orders['result']['open'].items():
            order_type = order_details['descr']['type']
            order_pair = order_details['descr']['pair']
            order_price = order_details['descr']['price']
            order_volume = order_details['vol']
            order_time = datetime.fromtimestamp(order_details['opentm'])
            
            logger.info(f"Ordre {order_id}: {order_type.upper()} {order_volume} {order_pair} à {order_price} (ouvert depuis {order_time})")
            
            # Annuler l'ordre si demandé
            if cancel_all:
                logger.info(f"Annulation de l'ordre {order_id}...")
                cancel_result = k.query_private('CancelOrder', {'txid': order_id})
                
                if 'error' in cancel_result and cancel_result['error']:
                    logger.error(f"Erreur lors de l'annulation de l'ordre {order_id}: {cancel_result['error']}")
                else:
                    logger.info(f"✅ Ordre {order_id} annulé avec succès")
        
        return True
    
    except Exception as e:
        logger.error(f"Erreur lors de la vérification des ordres: {e}")
        return False

if __name__ == "__main__":
    print("\n🚀 DÉMARRAGE DU TRADER AUDIO\n")
    
    # Vérifier et annuler tous les ordres ouverts
    if check_open_orders(cancel_all=True):
        print("\n=== LANCEMENT DU TRADING ===")
        # Petite pause pour s'assurer que l'annulation est bien prise en compte
        time.sleep(3)
        if trade_audio():
            print("\n✅ TRADE AUDIO RÉUSSI!")
        else:
            print("\n⚠️ LE TRADE AUDIO A ÉCHOUÉ")
    else:
        print("\n⚠️ ERREUR LORS DE LA VÉRIFICATION DES ORDRES")