#!/bin/bash
# Script pour maintenir le bot actif en permanence

echo "$(date) - Vérification du bot..."

# Vérifier si le trader est en cours d'exécution
if [ -f "auto_trader_pid.txt" ]; then
    TRADER_PID=$(cat auto_trader_pid.txt)
    if ps -p $TRADER_PID > /dev/null; then
        echo "$(date) - Bot en cours d'exécution avec PID $TRADER_PID"
        exit 0
    else
        echo "$(date) - Le trader n'est pas en cours d'exécution, démarrage automatique..."
    fi
else
    echo "$(date) - Fichier PID non trouvé, démarrage du bot..."
fi

# Arrêter tout processus existant
pkill -f "auto_trader_verified.py" || true
sleep 1
echo "$(date) - Bot arrêté avec succès"

# Démarrer le bot
nohup bash start_trader_permanent.sh > trader_permanent.log 2>&1 &
echo "$(date) - Bot démarré avec succès via keep_bot_alive.sh"