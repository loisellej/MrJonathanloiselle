#!/usr/bin/env python3
"""
SUPERVISEUR DE BOT ULTRA-SIMPLE ET ULTRA-FIABLE
Cette version minimaliste n'a qu'un seul but : garantir que le bot ne s'arrête JAMAIS
"""

import os
import time
import subprocess
import logging
import sys
import threading

# Configuration du logging minimal pour éviter la surcharge
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    handlers=[
        logging.FileHandler("watchdog_minimal.log"),
        logging.StreamHandler()
    ]
)

# Variable globale pour arrêter le script
running = True

def safe_print(msg):
    """Fonction d'affichage sécurisée qui ne crashe jamais"""
    try:
        print(msg)
        logging.info(msg)
    except:
        pass

def update_heartbeat():
    """Met à jour le heartbeat minimaliste"""
    try:
        with open("supervisor_heartbeat.txt", "w") as f:
            f.write(str(time.time()))
    except:
        pass

def check_bot_process():
    """Vérifie si le bot est en cours d'exécution de manière simplifiée"""
    try:
        # Vérifier si le processus existe
        output = subprocess.check_output(["pgrep", "-f", "ultra_stable_bot.py"], stderr=subprocess.DEVNULL)
        pid = int(output.strip())
        return pid > 0
    except:
        return False

def get_heartbeat_age():
    """Récupère l'âge du dernier heartbeat du bot en secondes"""
    try:
        if os.path.exists("trader_heartbeat.txt"):
            mtime = os.path.getmtime("trader_heartbeat.txt")
            return time.time() - mtime
        return float('inf')  # Très vieux si le fichier n'existe pas
    except:
        return float('inf')

def is_bot_healthy():
    """Vérifie si le bot est en bonne santé"""
    return check_bot_process() and get_heartbeat_age() < 300  # 5 minutes

def start_bot():
    """Démarre le bot de trading de la manière la plus simple possible"""
    try:
        # Tuer tout processus existant pour éviter les doublons
        subprocess.run(["pkill", "-f", "ultra_stable_bot.py"], stderr=subprocess.DEVNULL)
        time.sleep(2)
        
        # Démarrer le bot en arrière-plan
        subprocess.Popen(
            ["python3", "ultra_stable_bot.py"], 
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        safe_print("🚀 Bot démarré")
        return True
    except Exception as e:
        safe_print(f"❌ Erreur de démarrage du bot: {e}")
        return False

def monitor_bot():
    """Surveille et redémarre le bot si nécessaire"""
    global running
    while running:
        try:
            update_heartbeat()
            
            if not is_bot_healthy():
                safe_print("⚠️ Bot non détecté ou inactif. Redémarrage...")
                start_bot()
            
            # Attendre avant la prochaine vérification
            time.sleep(60)
        except Exception as e:
            safe_print(f"❌ Erreur dans la surveillance: {e}")
            time.sleep(60)

def keep_replit_alive():
    """Fonction minimaliste pour garder Replit actif"""
    global running
    while running:
        try:
            # Rien de complexe ici - juste un heartbeat périodique
            update_heartbeat()
            time.sleep(30)
        except:
            time.sleep(30)

def main():
    """Fonction principale ultra-simplifiée"""
    global running
    
    safe_print("""
===================================================
SUPERVISEUR ULTRA-FIABLE DÉMARRÉ
But unique: Garantir que le bot fonctionne 24/7
Sans fioritures, juste l'essentiel pour la stabilité
===================================================
""")
    
    # Démarrer le thread de surveillance
    monitor_thread = threading.Thread(target=monitor_bot)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    # Démarrer le thread de maintien en vie
    alive_thread = threading.Thread(target=keep_replit_alive)
    alive_thread.daemon = True
    alive_thread.start()
    
    # Démarrer le bot initialement
    if not is_bot_healthy():
        safe_print("Bot non détecté au démarrage, lancement initial...")
        start_bot()
    
    try:
        # Boucle principale simple qui ne fait rien d'autre que maintenir le script actif
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        safe_print("Arrêt du superviseur...")
        running = False
        sys.exit(0)

if __name__ == "__main__":
    main()