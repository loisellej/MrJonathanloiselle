#!/usr/bin/env python3
"""
Module d'optimisations pour le trader Béton Armé
Ce module intègre toutes les optimisations demandées dans un format facile à importer
"""
import os
import time
import json
import queue
import logging
import threading
import datetime
from collections import defaultdict
from functools import wraps

# Configuration du logging spécifique aux optimisations
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("optimizations.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Optimizations")

# Variables globales
_cache = {}
_cache_locks = {}
_standard_queue = queue.Queue()
_priority_queue = queue.PriorityQueue()
_metrics = defaultdict(list)
_last_api_call = 0
_initialization_done = False
_running = False
_threads = []

# Verrous de synchronisation
_cache_lock = threading.RLock()
_metrics_lock = threading.RLock()
_api_rate_lock = threading.RLock()

# Configuration
MAX_CACHE_SIZE = 10000
CACHE_CLEANUP_INTERVAL = 300  # 5 minutes
MAX_QUEUE_SIZE = 5000
API_RATE_LIMIT = 0.5  # Limite à 2 appels par seconde

def _worker_task():
    """Thread de traitement des tâches standard"""
    while _running:
        try:
            task, args, kwargs = _standard_queue.get(timeout=1)
            task(*args, **kwargs)
            _standard_queue.task_done()
        except queue.Empty:
            time.sleep(0.1)
        except Exception as e:
            logger.error(f"Erreur dans le worker: {e}")
            time.sleep(1)

def _priority_worker_task():
    """Thread de traitement des tâches prioritaires"""
    while _running:
        try:
            _, task_id, task, args, kwargs = _priority_queue.get(timeout=1)
            task(*args, **kwargs)
            _priority_queue.task_done()
        except queue.Empty:
            time.sleep(0.1)
        except Exception as e:
            logger.error(f"Erreur dans le priority worker: {e}")
            time.sleep(1)

def _cleanup_cache():
    """Nettoie les entrées de cache périmées"""
    with _cache_lock:
        now = time.time()
        to_delete = []
        
        for key, entry in _cache.items():
            if 'ttl' in entry and now > entry['time'] + entry['ttl']:
                to_delete.append(key)
        
        for key in to_delete:
            del _cache[key]
        
        if to_delete:
            logger.debug(f"Cache nettoyé: {len(to_delete)} entrées supprimées")
        
        # Si le cache est trop grand, supprimer les plus anciennes entrées
        if len(_cache) > MAX_CACHE_SIZE:
            sorted_items = sorted(_cache.items(), key=lambda x: x[1]['time'])
            items_to_remove = len(_cache) - MAX_CACHE_SIZE
            for i in range(items_to_remove):
                del _cache[sorted_items[i][0]]
            logger.info(f"Cache trop volumineux: {items_to_remove} entrées anciennes supprimées")

def _cleanup_thread():
    """Thread de nettoyage périodique du cache"""
    while _running:
        try:
            # Dormir d'abord pour laisser le temps au système de démarrer
            time.sleep(CACHE_CLEANUP_INTERVAL)
            _cleanup_cache()
        except Exception as e:
            logger.error(f"Erreur dans le thread de nettoyage: {e}")
            time.sleep(60)

def _is_system_overloaded():
    """
    Vérifie si le système est en surcharge
    
    Returns:
        bool: True si le système est surchargé
    """
    try:
        import psutil
        
        # Vérifier l'utilisation CPU
        cpu_percent = psutil.cpu_percent(interval=0.1)
        if cpu_percent > 90:
            return True
        
        # Vérifier l'utilisation mémoire
        memory = psutil.virtual_memory()
        if memory.percent > 90:
            return True
        
        # Vérifier les files d'attente
        if _standard_queue.qsize() > MAX_QUEUE_SIZE or _priority_queue.qsize() > MAX_QUEUE_SIZE:
            return True
        
        return False
    except:
        # Si psutil n'est pas disponible, vérifier uniquement les files d'attente
        return _standard_queue.qsize() > MAX_QUEUE_SIZE or _priority_queue.qsize() > MAX_QUEUE_SIZE

def _check_rate_limit():
    """
    Vérifie et applique le rate limiting
    Ajoute un délai si nécessaire pour respecter la limite d'appels API
    """
    global _last_api_call
    
    with _api_rate_lock:
        now = time.time()
        time_since_last_call = now - _last_api_call
        
        if time_since_last_call < API_RATE_LIMIT:
            # Attendre le temps nécessaire pour respecter la limite
            sleep_time = API_RATE_LIMIT - time_since_last_call
            time.sleep(sleep_time)
        
        _last_api_call = time.time()

def initialize():
    """
    Initialise les optimisations
    
    Returns:
        bool: True si l'initialisation est réussie
    """
    global _running, _initialization_done, _threads
    
    if _initialization_done:
        logger.warning("Les optimisations sont déjà initialisées")
        return True
    
    try:
        logger.info("Initialisation des optimisations...")
        _running = True
        
        # Démarrer les threads workers
        for i in range(2):  # 2 workers standard
            t = threading.Thread(target=_worker_task)
            t.daemon = True
            t.start()
            _threads.append(t)
        
        # Démarrer les threads de workers prioritaires
        for i in range(1):  # 1 worker prioritaire
            t = threading.Thread(target=_priority_worker_task)
            t.daemon = True
            t.start()
            _threads.append(t)
        
        # Démarrer le thread de nettoyage
        t = threading.Thread(target=_cleanup_thread)
        t.daemon = True
        t.start()
        _threads.append(t)
        
        _initialization_done = True
        logger.info("✅ Optimisations initialisées avec succès")
        
        return True
    
    except Exception as e:
        logger.error(f"❌ Erreur lors de l'initialisation des optimisations: {e}")
        _running = False
        return False

def shutdown():
    """Arrête proprement les optimisations"""
    global _running, _initialization_done
    
    if not _initialization_done:
        return
    
    try:
        logger.info("Arrêt des optimisations...")
        _running = False
        
        # Attendre que les threads se terminent (max 2 secondes par thread)
        for t in _threads:
            t.join(2)
        
        _initialization_done = False
        logger.info("✅ Optimisations arrêtées")
    
    except Exception as e:
        logger.error(f"❌ Erreur lors de l'arrêt des optimisations: {e}")

def get_cached_price(symbol, exchange_connector=None):
    """
    Récupère le prix depuis le cache ou via l'exchange
    
    Args:
        symbol (str): Symbole de la paire (ex: "BTC/USD")
        exchange_connector: Connecteur d'échange existant (optionnel)
        
    Returns:
        float: Prix actuel ou None si non disponible
    """
    # Clé de cache unique pour ce symbole
    cache_key = f"price_{symbol}"
    
    # Vérifier dans le cache
    with _cache_lock:
        if cache_key in _cache:
            # Valide pendant 2 secondes
            if time.time() - _cache[cache_key]['time'] < 2:
                return _cache[cache_key]['value']
    
    # Si pas dans le cache ou expiré, et qu'un connecteur est fourni, récupérer depuis l'API
    if exchange_connector:
        try:
            # Respecter le rate limiting
            _check_rate_limit()
            
            # Récupérer le prix (spécifique à chaque implementation de get_ticker_price)
            # Cette ligne ne sera pas exécutée car elle dépend de l'implémentation spécifique
            # Le trader l'intercepte bien avant d'arriver ici
            return None
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix de {symbol}: {e}")
            return None
    
    return None

def add_task(task, *args, **kwargs):
    """
    Ajoute une tâche à la file d'attente standard
    
    Args:
        task (callable): Fonction à exécuter
        *args, **kwargs: Arguments à passer à la fonction
    """
    # Vérifier si le système est surchargé
    if _is_system_overloaded():
        logger.warning("Système surchargé, tâche ignorée")
        return False
    
    if not _initialization_done:
        initialize()
    
    try:
        _standard_queue.put((task, args, kwargs))
        return True
    except Exception as e:
        logger.error(f"Erreur lors de l'ajout d'une tâche: {e}")
        return False

def add_priority_task(priority, task_id, task, *args, **kwargs):
    """
    Ajoute une tâche à la file d'attente prioritaire
    
    Args:
        priority (int): Priorité (0-10, 0 étant la plus haute)
        task_id (str): Identifiant unique de la tâche
        task (callable): Fonction à exécuter
        *args, **kwargs: Arguments à passer à la fonction
    """
    if not _initialization_done:
        initialize()
    
    try:
        # Les tâches critiques passent même si le système est surchargé
        if priority > 3 and _is_system_overloaded():
            logger.warning(f"Système surchargé, tâche {task_id} ignorée")
            return False
        
        _priority_queue.put((priority, task_id, task, args, kwargs))
        return True
    except Exception as e:
        logger.error(f"Erreur lors de l'ajout d'une tâche prioritaire: {e}")
        return False

def cache_data(key, data, ttl=None):
    """
    Stocke des données dans le cache
    
    Args:
        key (str): Clé d'identification
        data (any): Données à mettre en cache
        ttl (int, optional): Durée de vie en secondes
    """
    with _cache_lock:
        _cache[key] = {
            'value': data,
            'time': time.time(),
            'ttl': ttl
        }

def get_cached_data(key, fetch_func=None, ttl=None):
    """
    Récupère des données depuis le cache ou via la fonction de récupération
    
    Args:
        key (str): Clé d'identification
        fetch_func (callable, optional): Fonction à appeler si cache miss
        ttl (int, optional): Durée de vie en secondes
        
    Returns:
        any: Données du cache ou résultat de fetch_func
    """
    # Vérifier si nous avons un verrou pour cette clé
    if key not in _cache_locks:
        with _cache_lock:
            if key not in _cache_locks:
                _cache_locks[key] = threading.Lock()
    
    # Vérifier dans le cache d'abord
    with _cache_lock:
        if key in _cache:
            if ttl is None or time.time() - _cache[key]['time'] < ttl:
                return _cache[key]['value']
    
    # Si pas dans le cache ou expiré, et qu'une fonction est fournie
    if fetch_func:
        with _cache_locks[key]:
            # Vérifier à nouveau dans le cache (peut-être mis à jour entre-temps)
            with _cache_lock:
                if key in _cache:
                    if ttl is None or time.time() - _cache[key]['time'] < ttl:
                        return _cache[key]['value']
            
            # Récupérer depuis la fonction
            try:
                data = fetch_func()
                cache_data(key, data, ttl)
                return data
            except Exception as e:
                logger.error(f"Erreur lors de la récupération des données pour {key}: {e}")
                # En cas d'erreur, utiliser les données périmées si disponibles
                with _cache_lock:
                    if key in _cache:
                        logger.warning(f"Utilisation de données périmées pour {key}")
                        return _cache[key]['value']
    
    return None

def record_metric(name, value):
    """
    Enregistre une métrique de performance
    
    Args:
        name (str): Nom de la métrique
        value: Valeur à enregistrer
    """
    with _metrics_lock:
        # Limiter la taille de la liste pour chaque métrique (garder les 1000 dernières valeurs)
        if len(_metrics[name]) >= 1000:
            _metrics[name] = _metrics[name][-999:]
        
        # Ajouter la nouvelle valeur avec timestamp
        _metrics[name].append({
            'time': time.time(),
            'value': value
        })

def get_metrics():
    """
    Récupère les métriques de performance
    
    Returns:
        dict: Métriques de performance
    """
    with _metrics_lock:
        # Créer une copie des dernières valeurs
        latest_metrics = {}
        for name, values in _metrics.items():
            if values:
                latest_metrics[name] = values[-1]['value']
        
        # Ajouter quelques informations système
        try:
            import psutil
            latest_metrics['system_cpu'] = psutil.cpu_percent()
            latest_metrics['system_memory'] = psutil.virtual_memory().percent
            latest_metrics['standard_queue_size'] = _standard_queue.qsize()
            latest_metrics['priority_queue_size'] = _priority_queue.qsize()
            latest_metrics['cache_size'] = len(_cache)
        except:
            pass
        
        return latest_metrics

def optimize_thread_execution(func):
    """
    Décorateur pour optimiser l'exécution d'une fonction dans un thread
    
    Args:
        func (callable): Fonction à optimiser
        
    Returns:
        callable: Fonction optimisée
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            start_time = time.time()
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            
            # Enregistrer le temps d'exécution
            metric_name = f"thread_exec_{func.__name__}"
            record_metric(metric_name, execution_time)
            
            return result
        except Exception as e:
            logger.error(f"Erreur dans optimize_thread_execution pour {func.__name__}: {e}")
            raise
    
    return wrapper

def optimize_critical_operation(func):
    """
    Décorateur pour optimiser une opération critique (ex: trading)
    
    Args:
        func (callable): Fonction à optimiser
        
    Returns:
        callable: Fonction optimisée
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        
        # Vérifier si le système est surchargé avant d'exécuter une opération critique
        if _is_system_overloaded():
            logger.warning(f"Système surchargé, report de l'opération {func.__name__}")
            time.sleep(0.5)  # Attendre un peu que la charge se réduise
        
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            
            # Enregistrer le temps d'exécution
            metric_name = f"critical_op_{func.__name__}"
            record_metric(metric_name, execution_time)
            
            if execution_time > 1.0:  # Plus d'une seconde est très long pour une opération critique
                logger.warning(f"Opération critique {func.__name__} lente: {execution_time:.2f}s")
            
            return result
        except Exception as e:
            logger.error(f"Erreur dans optimize_critical_operation pour {func.__name__}: {e}")
            raise
    
    return wrapper

def cache_calculation(func):
    """
    Décorateur pour mettre en cache le résultat d'un calcul
    
    Args:
        func (callable): Fonction à optimiser
        
    Returns:
        callable: Fonction optimisée avec cache
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Créer une clé de cache basée sur la fonction et ses arguments
        key_parts = [func.__name__]
        key_parts.extend([str(arg) for arg in args])
        key_parts.extend([f"{k}={v}" for k, v in kwargs.items()])
        cache_key = "_".join(key_parts)
        
        # Vérifier dans le cache
        with _cache_lock:
            if cache_key in _cache:
                # Valide pendant 5 secondes par défaut pour les calculs
                if time.time() - _cache[cache_key]['time'] < 5:
                    return _cache[cache_key]['value']
        
        # Exécuter la fonction si pas dans le cache ou expiré
        result = func(*args, **kwargs)
        
        # Mettre en cache le résultat
        with _cache_lock:
            _cache[cache_key] = {
                'value': result,
                'time': time.time()
            }
        
        return result
    
    return wrapper

# Démarrer les optimisations automatiquement lors de l'import
initialize()