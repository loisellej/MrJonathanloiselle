"""
TRADER MULTI-POSITIONS ULTRA-VOLATIL
- Utilise TOUTES les positions existantes pour trader (pas seulement USD)
- Échange entre cryptos volatiles selon les opportunités
- Analyse minute par minute des meilleures opportunités
- Stop-loss ultra-serré (0.5-0.8%)
- Cible 2-3% de gain par trade
"""

import os
import time
import logging
import random
import threading
import ccxt
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("trader_24_7.log"),
        logging.StreamHandler()
    ]
)

class MultiPositionTrader:
    """
    Trader qui utilise toutes les positions existantes (pas uniquement USD)
    pour échanger entre les cryptos volatiles selon les opportunités
    """

    def __init__(self, api_key=None, api_secret=None, risk_per_trade=0.9):
        """
        Initialisation du trader multi-positions
        
        Args:
            api_key (str): Clé API Kraken
            api_secret (str): Clé secrète API Kraken
            risk_per_trade (float): Pourcentage du solde à utiliser par trade (0-1)
        """
        self.api_key = api_key or os.environ.get("KRAKEN_API_KEY")
        self.api_secret = api_secret or os.environ.get("KRAKEN_API_SECRET")
        self.risk_per_trade = risk_per_trade
        
        # État du trader
        self.running = False
        self.stop_event = threading.Event()
        
        # Données de marché
        self.balances = {}
        self.price_cache = {}
        self.price_history = {}
        self.volatile_assets = []
        self.active_trades = {}
        self.open_positions = {}
        
        # Threads
        self.trader_thread = None
        self.price_updater_thread = None
        self.volatile_finder_thread = None

        # Initialisation
        self.initialize_exchange()
        self.sentiment_analyzer = SentimentIntensityAnalyzer()
        
        # Paramètres de performance
        self.use_microsecond_timing = True
        self.performance_metrics = {}
        
        logging.info("✅ Trader Multiasset initialisé")

    def initialize_exchange(self):
        """Initialise la connexion à l'exchange Kraken"""
        try:
            self.exchange = ccxt.kraken({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'options': {
                    'adjustForTimeDifference': True,
                    'recvWindow': 60000
                }
            })
            self.refresh_balances()
            logging.info("✅ Connexion à Kraken établie avec succès")
            return True
        except Exception as e:
            logging.error(f"❌ Erreur d'initialisation de l'exchange: {e}")
            return False

    def refresh_balances(self):
        """Récupère les balances depuis l'exchange"""
        try:
            start_time = time.time()
            balance_data = self.exchange.fetch_balance()
            
            # Mise à jour des balances
            self.balances = {
                asset: float(data['free']) 
                for asset, data in balance_data['free'].items() 
                if float(data) > 0
            }
            
            # Log des performances
            elapsed = time.time() - start_time
            logging.info(f"Balances mises à jour: {len(self.balances)} actifs trouvés")
            
            # Calcul et log des soldes USD
            if 'ZUSD' in self.balances:
                logging.info(f"Solde USD: {self.balances['ZUSD']:.4f} USD")
            
            # Identifier les actifs significatifs (ceux qui ont une valeur)
            significant_assets = []
            for asset, balance in self.balances.items():
                if asset == 'ZUSD' or balance <= 0:
                    continue
                
                # Obtenir le prix en USD
                symbol = f"{asset}/USD"
                try:
                    price = self.get_ticker_price(symbol)
                    if price:
                        usd_value = balance * price
                        if usd_value > 1.0:  # Considérer seulement les actifs de plus de 1 USD
                            significant_assets.append((asset, balance, usd_value))
                except:
                    pass
            
            # Afficher les actifs significatifs
            if significant_assets:
                assets_str = ", ".join([f"{asset}: {balance:.4f} (~{usd_value:.2f} USD)" 
                                      for asset, balance, usd_value in significant_assets])
                logging.info(f"Actifs significatifs: {assets_str}")
            else:
                logging.info("Aucun actif significatif trouvé")
            
            return self.balances
        except Exception as e:
            logging.error(f"❌ Erreur de rafraîchissement des balances: {e}")
            return {}

    def _run_price_cache_updater(self):
        """Thread qui met à jour le cache de prix pour un accès en microsecondes"""
        while not self.stop_event.is_set():
            try:
                assets_to_update = list(self.price_cache.keys())
                
                # Ajouter les actifs volatils s'ils ne sont pas déjà dans le cache
                for asset in self.volatile_assets:
                    if asset not in assets_to_update and asset != 'USD':
                        symbol = f"{asset}/USD"
                        assets_to_update.append(symbol)
                
                # Ajouter les actifs de notre portefeuille
                for asset in self.balances:
                    if asset != 'ZUSD' and float(self.balances[asset]) > 0:
                        symbol = f"{asset}/USD"
                        if symbol not in assets_to_update:
                            assets_to_update.append(symbol)
                
                # Mettre à jour les prix par lots
                for symbol in assets_to_update:
                    self._update_single_price(symbol)
                    time.sleep(0.1)  # Pause pour éviter de dépasser la limite de requêtes
                
                # Attendre avant la prochaine mise à jour
                time.sleep(5)  # Mise à jour toutes les 5 secondes
            except Exception as e:
                logging.error(f"Erreur dans le thread de mise à jour des prix: {e}")
                time.sleep(5)

    def _update_single_price(self, market):
        """Met à jour un seul prix dans le cache"""
        try:
            start_time = time.time()
            ticker = self.exchange.fetch_ticker(market)
            
            # Mesure du temps de réponse
            response_time = (time.time() - start_time) * 1000
            logging.info(f"kraken_api_ticker [{market.split('/')[0]}]: {response_time:.3f} ms")
            
            if ticker and 'last' in ticker and ticker['last']:
                self.price_cache[market] = float(ticker['last'])
                
                # Mettre à jour l'historique des prix
                asset = market.split('/')[0]
                self.update_price_history(asset, self.price_cache[market])
            
            # Mesure du temps total
            total_time = (time.time() - start_time) * 1000
            logging.info(f"get_price_total [{market.split('/')[0]}]: {total_time:.3f} ms")
            
            return self.price_cache.get(market)
        except Exception as e:
            logging.error(f"Erreur de mise à jour du prix pour {market}: {e}")
            return None

    def update_price_history(self, asset, price):
        """Met à jour l'historique des prix pour un actif"""
        if asset not in self.price_history:
            self.price_history[asset] = []
        
        self.price_history[asset].append({
            'timestamp': time.time(),
            'price': price
        })
        
        # Garder seulement les 100 derniers points de données
        if len(self.price_history[asset]) > 100:
            self.price_history[asset] = self.price_history[asset][-100:]

    def _find_volatile_assets_thread(self):
        """Thread qui recherche en continu les actifs les plus volatils"""
        while not self.stop_event.is_set():
            try:
                self.volatile_assets = self.find_volatile_assets()
                # Attendre avant la prochaine recherche (toutes les 5 minutes)
                time.sleep(300)
            except Exception as e:
                logging.error(f"Erreur dans le thread de recherche d'actifs volatils: {e}")
                time.sleep(60)

    def find_volatile_assets(self, max_assets=10):
        """
        Trouve les actifs les plus volatils sur Kraken - Analyse TOUS les actifs disponibles
        Vise des gains de 20-50% mensuels grâce à une analyse approfondie
        
        Returns:
            list: Liste des actifs les plus volatils
        """
        try:
            # Récupérer tous les marchés disponibles
            markets = self.exchange.load_markets()
            
            # Filtrer les marchés USD et exclure BTC, ETH, et Solana
            usd_markets = [
                m for m in markets 
                if '/USD' in m 
                and m.split('/')[0] not in ['BTC', 'ETH', 'SOL', 'XBT']
            ]
            
            # Évaluer la volatilité de chaque marché
            volatile_markets = []
            for market in usd_markets[:50]:  # Limiter pour éviter trop de requêtes
                try:
                    asset = market.split('/')[0]
                    
                    # Récupérer les données OHLCV pour calculer la volatilité
                    ohlcv = self.exchange.fetch_ohlcv(market, timeframe='5m', limit=24)
                    
                    if not ohlcv or len(ohlcv) < 12:
                        continue
                    
                    # Calculer la volatilité (écart-type des rendements en %)
                    prices = [candle[4] for candle in ohlcv]
                    returns = [
                        ((prices[i] - prices[i-1]) / prices[i-1]) * 100
                        for i in range(1, len(prices))
                    ]
                    
                    if not returns:
                        continue
                    
                    # Calculer l'écart-type des rendements (volatilité)
                    volatility = sum([(r - sum(returns)/len(returns))**2 for r in returns])
                    volatility = (volatility / len(returns)) ** 0.5
                    
                    # Calculer le momentum (moyenne des rendements récents)
                    momentum = sum(returns[-6:]) / 6 if len(returns) >= 6 else 0
                    
                    # Calculer un score de tendance à la hausse
                    uptrend_score = 0
                    if len(prices) >= 12:
                        # Tendance haussière si le prix actuel > moyenne mobile
                        ma_12 = sum(prices[-12:]) / 12
                        uptrend_score = 1 if prices[-1] > ma_12 else 0
                    
                    # Calculer un score de volume
                    volumes = [candle[5] for candle in ohlcv]
                    avg_volume = sum(volumes) / len(volumes)
                    volume_score = 1 if volumes[-1] > avg_volume else 0
                    
                    # Score sentiment (basé sur la performance récente)
                    sentiment_score = self.analyze_sentiment(asset)
                    
                    # Score combiné (volatilité + momentum positif + tendance + volume + sentiment)
                    combined_score = (
                        volatility * 0.4 +         # 40% volatilité
                        max(0, momentum) * 0.3 +   # 30% momentum positif
                        uptrend_score * 0.15 +     # 15% tendance
                        volume_score * 0.05 +      # 5% volume
                        max(0, sentiment_score) * 0.1  # 10% sentiment
                    )
                    
                    # Ajouter à la liste si le score est positif
                    if combined_score > 0:
                        volatile_markets.append({
                            'asset': asset,
                            'volatility': volatility,
                            'momentum': momentum,
                            'uptrend': uptrend_score,
                            'volume': volume_score,
                            'sentiment': sentiment_score,
                            'score': combined_score
                        })
                except Exception as e:
                    logging.error(f"Erreur d'analyse pour {market}: {e}")
            
            # Trier par score combiné et prendre les meilleurs
            volatile_markets.sort(key=lambda x: x['score'], reverse=True)
            top_volatile = volatile_markets[:max_assets]
            
            # Extraire les symboles des actifs
            results = [m['asset'] for m in top_volatile]
            
            if results:
                logging.info(f"Actifs les plus volatils: {', '.join(results[:5])}")
            
            return results
        except Exception as e:
            logging.error(f"Erreur lors de la recherche d'actifs volatils: {e}")
            return []

    def _trading_thread(self):
        """Thread principal de trading"""
        logging.info("⚡ DÉMARRAGE DE LA BOUCLE DE TRADING ULTRA-VOLATIL (ANALYSE MINUTE PAR MINUTE)")
        
        # S'assurer que les balances sont à jour
        self.refresh_balances()
        
        while not self.stop_event.is_set():
            try:
                # Mettre à jour les balances
                self.refresh_balances()
                
                # Vérifier les stop-losses pour les positions ouvertes
                self.check_stop_losses()
                
                # Effectuer une analyse des opportunités
                logging.info("Scan minute par minute des opportunités de marché")
                
                # 1. Vérifier les opportunités de conversion entre cryptos
                self.check_crypto_to_crypto_opportunities()
                
                # 2. Vérifier les opportunités USD -> crypto volatile
                if 'ZUSD' in self.balances and self.balances['ZUSD'] > 5:
                    logging.info(f"Recherche d'opportunités d'achat avec {self.balances['ZUSD']:.2f} USD")
                    self.find_and_execute_usd_opportunities()
                else:
                    logging.info(f"Pas assez d'USD pour de nouvelles opportunités: {self.balances.get('ZUSD', 0):.2f} USD")
                
                # Attendre avant la prochaine analyse (analyse minute par minute)
                time.sleep(60)
            except Exception as e:
                logging.error(f"Erreur dans la boucle de trading: {e}")
                time.sleep(60)

    def get_ticker_price(self, symbol):
        """
        Récupère le prix actuel avec temps de réponse en microsecondes
        
        Args:
            symbol (str): Symbole de la paire de trading (ex: 'BTC/USDT')
        
        Returns:
            float: Prix actuel ou None si non disponible
        """
        try:
            # Essayer d'abord le cache pour une réponse en microsecondes
            if self.use_microsecond_timing:
                start_time = time.time()
                if symbol in self.price_cache:
                    price = self.price_cache[symbol]
                    elapsed = (time.time() - start_time) * 1000
                    logging.info(f"get_price_cache [{symbol.split('/')[0]}]: {elapsed:.3f} ms")
                    return price
            
            # Si pas dans le cache, faire une requête API
            start_time = time.time()
            ticker = self.exchange.fetch_ticker(symbol)
            elapsed = (time.time() - start_time) * 1000
            logging.info(f"get_price_api [{symbol.split('/')[0]}]: {elapsed:.3f} ms")
            
            if ticker and 'last' in ticker:
                return float(ticker['last'])
            return None
        except Exception as e:
            logging.error(f"Erreur de récupération du prix pour {symbol}: {e}")
            return None

    def analyze_sentiment(self, asset):
        """
        Analyse le sentiment pour un actif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            float: Score de sentiment entre -1 et 1
        """
        try:
            # Simuler la récupération de titres d'actualité
            headlines = self._simulate_headlines(asset)
            
            # Analyser le sentiment de chaque titre
            if not headlines:
                return 0
            
            scores = []
            for headline in headlines:
                vs = self.sentiment_analyzer.polarity_scores(headline)
                scores.append(vs['compound'])
            
            # Retourner la moyenne des scores
            return sum(scores) / len(scores)
        except Exception as e:
            logging.error(f"Erreur d'analyse de sentiment pour {asset}: {e}")
            return 0

    def _simulate_headlines(self, asset):
        """
        Simule la récupération de titres d'actualité pour une cryptomonnaie
        À remplacer par une vraie source d'actualités comme NewsAPI ou Twitter
        """
        # Titres positifs simulés
        positive_headlines = [
            f"{asset} shows strong momentum as adoption increases",
            f"Analysts bullish on {asset} price target for Q2",
            f"{asset} partnership announcement drives investor interest",
            f"New use cases for {asset} spark price discovery",
            f"{asset} technical indicators suggest upward movement"
        ]
        
        # Titres négatifs simulés
        negative_headlines = [
            f"{asset} faces regulatory scrutiny in key markets",
            f"Investors cautious about {asset} after recent volatility",
            f"{asset} faces competition from newer projects",
            f"Technical analysis suggests {asset} may be overbought",
            f"{asset} volumes decline as traders move to alternatives"
        ]
        
        # Titres neutres simulés
        neutral_headlines = [
            f"{asset} price remains stable amid market fluctuations",
            f"Experts weigh in on {asset}'s long-term prospects",
            f"{asset} community discusses potential protocol updates",
            f"Market makers maintain positions in {asset}",
            f"{asset} trading volume consistent with weekly averages"
        ]
        
        # Sélectionner aléatoirement entre 3 et 5 titres
        num_headlines = random.randint(3, 5)
        
        # Répartition des sentiments (biaisée légèrement vers le positif pour les actifs volatils)
        # Cette répartition simule un marché haussier dans l'ensemble
        sentiment_weights = [0.4, 0.3, 0.3]  # [positif, neutre, négatif]
        
        headlines = []
        for _ in range(num_headlines):
            sentiment_type = random.choices(
                ['positive', 'neutral', 'negative'], 
                weights=sentiment_weights
            )[0]
            
            if sentiment_type == 'positive':
                headlines.append(random.choice(positive_headlines))
            elif sentiment_type == 'neutral':
                headlines.append(random.choice(neutral_headlines))
            else:
                headlines.append(random.choice(negative_headlines))
        
        return headlines

    def calculate_bubble_score(self, asset):
        """
        Calcule un score de bulle pour un actif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            float: Score de bulle entre 0 et 1
        """
        try:
            symbol = f"{asset}/USD"
            
            # Récupérer les données OHLCV pour les dernières 24h (intervalles de 1h)
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe='1h', limit=24)
            
            if not ohlcv or len(ohlcv) < 12:
                return 0.5  # Score neutre si pas assez de données
            
            # Extraire les prix de clôture
            prices = [candle[4] for candle in ohlcv]
            
            # Calculer les rendements
            returns = [((prices[i] - prices[i-1]) / prices[i-1]) * 100 for i in range(1, len(prices))]
            
            # Facteurs indiquant une bulle potentielle
            
            # 1. Accélération des rendements (rendements de plus en plus élevés)
            acceleration = 0
            if len(returns) >= 6:
                recent_returns = returns[-6:]
                if sum(recent_returns[:3]) > 0 and sum(recent_returns[3:]) > sum(recent_returns[:3]):
                    acceleration = 0.3
            
            # 2. Volatilité anormale
            volatility = 0
            if returns:
                std_dev = (sum([(r - sum(returns)/len(returns))**2 for r in returns]) / len(returns)) ** 0.5
                if std_dev > 3:  # Seuil arbitraire pour une volatilité élevée
                    volatility = 0.3
            
            # 3. Écart par rapport à la moyenne mobile
            deviation = 0
            if len(prices) >= 24:
                ma_24 = sum(prices) / len(prices)
                percent_above = (prices[-1] - ma_24) / ma_24 * 100
                if percent_above > 15:  # Plus de 15% au-dessus de la moyenne mobile
                    deviation = 0.4
            
            # Score de bulle combiné
            bubble_score = min(1.0, acceleration + volatility + deviation)
            
            return bubble_score
        except Exception as e:
            logging.error(f"Erreur de calcul du score de bulle pour {asset}: {e}")
            return 0.5  # Score neutre en cas d'erreur

    def calculate_momentum(self, asset):
        """
        Calcule le momentum pour un actif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            float: Score de momentum entre -1 et 1
        """
        try:
            symbol = f"{asset}/USD"
            
            # Récupérer les données OHLCV
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe='15m', limit=24)
            
            if not ohlcv or len(ohlcv) < 8:
                return 0  # Pas de momentum si pas assez de données
            
            # Extraire les prix de clôture
            prices = [candle[4] for candle in ohlcv]
            
            # Calculer les rendements
            returns = [((prices[i] - prices[i-1]) / prices[i-1]) for i in range(1, len(prices))]
            
            # Calculer le momentum (moyenne pondérée des rendements récents)
            # Les rendements les plus récents ont plus de poids
            weights = [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3][:len(returns)]
            weighted_returns = [returns[i] * weights[i] for i in range(min(len(returns), len(weights)))]
            
            momentum = sum(weighted_returns) / sum(weights[:len(weighted_returns)])
            
            # Normaliser entre -1 et 1
            momentum = max(-1, min(1, momentum * 10))  # Facteur 10 pour amplifier
            
            return momentum
        except Exception as e:
            logging.error(f"Erreur de calcul du momentum pour {asset}: {e}")
            return 0

    def has_strong_momentum(self, asset):
        """
        Vérifie si un actif a un fort momentum positif
        
        Args:
            asset (str): Symbole de l'actif
        
        Returns:
            bool: True si l'actif a un fort momentum positif
        """
        momentum = self.calculate_momentum(asset)
        return momentum > 0.3  # Seuil pour un momentum fort

    def dynamic_stop_loss(self, current_price, entry_price, asset=None):
        """
        Calcule un stop-loss dynamique adapté au momentum et à la volatilité
        
        Args:
            current_price (float): Prix actuel
            entry_price (float): Prix d'entrée
            asset (str): Symbole de l'actif
        
        Returns:
            float: Prix du stop-loss
        """
        # Stop-loss par défaut (0.5% sous le prix d'entrée)
        default_stop = entry_price * 0.995
        
        # Si nous avons réalisé un profit, déplacer le stop-loss pour sécuriser des gains
        profit_pct = (current_price - entry_price) / entry_price
        
        if profit_pct >= 0.01:  # 1% de profit
            # Stop-loss à 0.3% sous le prix actuel
            return current_price * 0.997
        elif profit_pct >= 0.005:  # 0.5% de profit
            # Stop-loss à 0.3% sous le prix d'entrée (sécurise une partie du gain)
            return entry_price * 1.002
        else:
            # Utiliser un stop-loss ultra-serré de 0.5% sous le prix d'entrée
            return default_stop

    def check_stop_losses(self):
        """Vérifie tous les stop-losses et exécute les ventes si nécessaire"""
        positions_to_close = []
        
        for asset, position in self.open_positions.items():
            try:
                symbol = f"{asset}/USD"
                current_price = self.get_ticker_price(symbol)
                
                if not current_price:
                    continue
                
                entry_price = position['entry_price']
                stop_loss = position['stop_loss']
                
                # Calculer le profit actuel
                profit_pct = (current_price - entry_price) / entry_price * 100
                
                # Vérifier si le prix est tombé sous le stop-loss
                if current_price <= stop_loss:
                    logging.info(f"⚠️ Stop-loss déclenché pour {asset} à {current_price:.6f} (stop: {stop_loss:.6f})")
                    
                    # Exécuter la vente
                    result = self.sell(asset, percentage=100)
                    
                    if result:
                        positions_to_close.append(asset)
                        logging.info(f"✅ Position {asset} fermée par stop-loss. Profit/Perte: {profit_pct:.2f}%")
                    else:
                        logging.error(f"❌ Échec de fermeture de la position {asset} par stop-loss")
                
                # Mettre à jour le stop-loss dynamique
                new_stop_loss = self.dynamic_stop_loss(current_price, entry_price, asset)
                
                # Ne mettre à jour le stop-loss que s'il est plus élevé (trailing stop)
                if new_stop_loss > stop_loss:
                    self.open_positions[asset]['stop_loss'] = new_stop_loss
                    logging.info(f"Stop-loss mis à jour pour {asset}: {new_stop_loss:.6f}")
                
                # Prendre des profits si atteint l'objectif de 2-3%
                if profit_pct >= 2.0:
                    logging.info(f"🎯 Objectif de profit atteint pour {asset}: {profit_pct:.2f}%")
                    
                    # Vendre une partie (50%) pour sécuriser des profits
                    if profit_pct >= 3.0:
                        # Objectif 3% atteint - vendre tout
                        result = self.sell(asset, percentage=100)
                        logging.info(f"🎯 Objectif 3% atteint - Vente complète de {asset}")
                        if result:
                            positions_to_close.append(asset)
                    elif profit_pct >= 2.5:
                        # Objectif 2.5% atteint - vendre 75%
                        result = self.sell(asset, percentage=75)
                        logging.info(f"🎯 Objectif 2.5% atteint - Vente 75% de {asset}")
                    else:
                        # Objectif 2% atteint - vendre 50%
                        result = self.sell(asset, percentage=50)
                        logging.info(f"🎯 Objectif 2% atteint - Vente 50% de {asset}")
            except Exception as e:
                logging.error(f"Erreur lors de la vérification du stop-loss pour {asset}: {e}")
        
        # Supprimer les positions fermées
        for asset in positions_to_close:
            if asset in self.open_positions:
                del self.open_positions[asset]

    def calculate_trade_size(self, balance, price, asset=None):
        """
        Calcule la taille optimale du trade
        
        Args:
            balance (float): Solde disponible
            price (float): Prix actuel
            asset (str): Symbole de l'actif
        
        Returns:
            float: Taille du trade
        """
        # Convertir le pourcentage de risque en montant
        amount_to_risk = balance * self.risk_per_trade
        
        # Calculer la taille du trade (nombre d'unités)
        units = amount_to_risk / price
        
        # Réduire légèrement pour prendre en compte les frais
        units *= 0.998  # 0.2% pour les frais
        
        return units

    def buy(self, asset, amount=None, percentage=None):
        """
        Exécute un ordre d'achat
        
        Args:
            asset (str): Symbole de l'actif
            amount (float): Montant à acheter (en actif)
            percentage (float): Pourcentage du solde USDT à utiliser
        
        Returns:
            dict: Détails de l'ordre ou None en cas d'erreur
        """
        try:
            symbol = f"{asset}/USD"
            
            # Vérifier si nous avons un solde USD
            if 'ZUSD' not in self.balances or self.balances['ZUSD'] <= 1:
                logging.warning(f"Solde USD insuffisant pour acheter {asset}")
                return None
            
            # Déterminer le montant à acheter
            if percentage and not amount:
                # Calculer le montant basé sur le pourcentage du solde USD
                available_usd = self.balances['ZUSD'] * (percentage / 100)
                price = self.get_ticker_price(symbol)
                if not price:
                    return None
                amount = available_usd / price
            
            if not amount or amount <= 0:
                logging.error(f"Montant invalide pour l'achat de {asset}: {amount}")
                return None
            
            # Arrondir le montant pour éviter les erreurs de précision
            amount = float(f"{amount:.8f}")
            
            # Exécuter l'ordre
            order = self.exchange.create_market_buy_order(symbol, amount)
            
            if order:
                logging.info(f"✅ Achat de {amount:.8f} {asset} exécuté avec succès")
                
                # Mettre à jour les balances
                self.refresh_balances()
                
                # Enregistrer la position ouverte
                price = self.get_ticker_price(symbol)
                if price:
                    stop_loss = price * 0.995  # Stop-loss initial à 0.5% sous le prix d'entrée
                    self.open_positions[asset] = {
                        'entry_price': price,
                        'amount': amount,
                        'stop_loss': stop_loss,
                        'entry_time': time.time()
                    }
                    logging.info(f"Position ouverte pour {asset} à {price:.6f} avec stop-loss à {stop_loss:.6f}")
                
                return order
            return None
        except Exception as e:
            logging.error(f"❌ Erreur lors de l'achat de {asset}: {e}")
            return None

    def sell(self, asset, amount=None, percentage=None):
        """
        Exécute un ordre de vente
        
        Args:
            asset (str): Symbole de l'actif
            amount (float): Montant à vendre (en actif)
            percentage (float): Pourcentage du solde de l'actif à vendre
        
        Returns:
            dict: Détails de l'ordre ou None en cas d'erreur
        """
        try:
            # Vérifier si nous avons le solde de l'actif
            if asset not in self.balances or self.balances[asset] <= 0:
                logging.warning(f"Solde {asset} insuffisant pour vendre")
                return None
            
            symbol = f"{asset}/USD"
            
            # Déterminer le montant à vendre
            if percentage and not amount:
                # Calculer le montant basé sur le pourcentage du solde de l'actif
                amount = self.balances[asset] * (percentage / 100)
            
            if not amount or amount <= 0:
                logging.error(f"Montant invalide pour la vente de {asset}: {amount}")
                return None
            
            # S'assurer que nous ne vendons pas plus que ce que nous avons
            amount = min(amount, self.balances[asset])
            
            # Arrondir le montant pour éviter les erreurs de précision
            amount = float(f"{amount:.8f}")
            
            # Exécuter l'ordre
            order = self.exchange.create_market_sell_order(symbol, amount)
            
            if order:
                logging.info(f"✅ Vente de {amount:.8f} {asset} exécutée avec succès")
                
                # Mettre à jour les balances
                self.refresh_balances()
                
                return order
            return None
        except Exception as e:
            logging.error(f"❌ Erreur lors de la vente de {asset}: {e}")
            return None

    def check_crypto_to_crypto_opportunities(self):
        """
        Vérifie les opportunités de conversion entre cryptos
        Échange une crypto contre une autre si une meilleure opportunité est trouvée
        """
        try:
            crypto_assets = {}
            
            # Identifier les cryptos significatives dans notre portefeuille
            for asset, balance in self.balances.items():
                if asset == 'ZUSD' or balance <= 0:
                    continue
                
                # Obtenir le prix en USD
                symbol = f"{asset}/USD"
                try:
                    price = self.get_ticker_price(symbol)
                    if price:
                        usd_value = balance * price
                        if usd_value > 5.0:  # Considérer seulement les actifs de plus de 5 USD
                            crypto_assets[asset] = {
                                'balance': balance,
                                'usd_value': usd_value,
                                'price': price
                            }
                except Exception as e:
                    logging.error(f"Erreur d'évaluation pour {asset}: {e}")
            
            if not crypto_assets:
                logging.info("Aucun actif crypto significatif pour chercher des opportunités de conversion")
                return
            
            # Évaluer chaque crypto par rapport aux autres opportunités
            for asset, data in crypto_assets.items():
                # Obtenir les informations actuelles
                current_momentum = self.calculate_momentum(asset)
                current_bubble = self.calculate_bubble_score(asset)
                current_sentiment = self.analyze_sentiment(asset)
                
                # Score actuel
                current_score = (
                    current_momentum * 0.5 +  # 50% momentum
                    (1 - current_bubble) * 0.3 +  # 30% inverse du score de bulle (moins de bulle est mieux)
                    max(0, current_sentiment) * 0.2  # 20% sentiment positif
                )
                
                # Chercher une meilleure opportunité
                best_opportunity = None
                best_score = current_score
                
                for opportunity in self.volatile_assets:
                    # Ignorer l'actif actuel
                    if opportunity == asset:
                        continue
                    
                    # Évaluer l'opportunité
                    opp_momentum = self.calculate_momentum(opportunity)
                    opp_bubble = self.calculate_bubble_score(opportunity)
                    opp_sentiment = self.analyze_sentiment(opportunity)
                    
                    # Score de l'opportunité
                    opp_score = (
                        opp_momentum * 0.5 +  # 50% momentum
                        (1 - opp_bubble) * 0.3 +  # 30% inverse du score de bulle
                        max(0, opp_sentiment) * 0.2  # 20% sentiment positif
                    )
                    
                    # Si l'opportunité est significativement meilleure (au moins 30% meilleure)
                    if opp_score > (best_score * 1.3):
                        best_opportunity = opportunity
                        best_score = opp_score
                
                # Si une meilleure opportunité a été trouvée, convertir
                if best_opportunity:
                    logging.info(f"🔄 Opportunité de conversion détectée: {asset} → {best_opportunity}")
                    logging.info(f"Score actuel {asset}: {current_score:.4f}, Score {best_opportunity}: {best_score:.4f}")
                    
                    # Convertir l'actif actuel vers le nouveau (vendre puis acheter)
                    sell_result = self.sell(asset, percentage=100)
                    
                    if sell_result:
                        # Attendre un moment pour que la vente soit prise en compte
                        time.sleep(2)
                        
                        # Mettre à jour les balances
                        self.refresh_balances()
                        
                        # Acheter le nouvel actif avec la totalité des USD disponibles
                        buy_result = self.buy(best_opportunity, percentage=90)
                        
                        if buy_result:
                            logging.info(f"✅ Conversion réussie: {asset} → {best_opportunity}")
                        else:
                            logging.error(f"❌ Échec de l'achat de {best_opportunity} après la vente de {asset}")
                    else:
                        logging.error(f"❌ Échec de la vente de {asset} pour conversion")
        except Exception as e:
            logging.error(f"Erreur lors de la recherche d'opportunités de conversion: {e}")

    def find_and_execute_usd_opportunities(self):
        """
        Recherche et exécute les meilleures opportunités d'achat avec USD
        """
        try:
            if 'ZUSD' not in self.balances or self.balances['ZUSD'] < 5:
                return
            
            best_opportunity = None
            best_score = 0
            
            # Évaluer chaque actif volatil
            for asset in self.volatile_assets:
                # Ignorer les actifs que nous possédons déjà
                if asset in self.balances and self.balances[asset] > 0:
                    continue
                
                # Évaluer l'actif
                momentum = self.calculate_momentum(asset)
                bubble = self.calculate_bubble_score(asset)
                sentiment = self.analyze_sentiment(asset)
                
                # Score combiné
                score = (
                    momentum * 0.5 +  # 50% momentum
                    (1 - bubble) * 0.3 +  # 30% inverse du score de bulle
                    max(0, sentiment) * 0.2  # 20% sentiment positif
                )
                
                # Si c'est la meilleure opportunité jusqu'à présent
                if score > best_score and score > 0.4:  # Seuil minimum de score
                    best_opportunity = asset
                    best_score = score
            
            # Si une bonne opportunité a été trouvée, acheter
            if best_opportunity:
                logging.info(f"💰 Opportunité d'achat détectée: {best_opportunity} (score: {best_score:.4f})")
                
                # Acheter avec 90% des USD disponibles
                buy_result = self.buy(best_opportunity, percentage=90)
                
                if buy_result:
                    logging.info(f"✅ Achat réussi de {best_opportunity}")
                else:
                    logging.error(f"❌ Échec de l'achat de {best_opportunity}")
            else:
                logging.info("Aucune opportunité d'achat suffisamment bonne trouvée")
        except Exception as e:
            logging.error(f"Erreur lors de la recherche d'opportunités d'achat: {e}")

    def execute_trade_logic(self, asset):
        """
        Exécute la logique de trading pour un actif avec scaling out 25/25/50
        
        Args:
            asset (str): Symbole de l'actif
        """
        try:
            symbol = f"{asset}/USD"
            current_price = self.get_ticker_price(symbol)
            
            if not current_price:
                return
            
            # Vérifier si l'actif a un fort momentum et n'est pas en bulle
            momentum = self.calculate_momentum(asset)
            bubble_score = self.calculate_bubble_score(asset)
            sentiment = self.analyze_sentiment(asset)
            
            # Conditions d'achat: fort momentum positif, faible score de bulle, sentiment positif
            if momentum > 0.3 and bubble_score < 0.6 and sentiment > 0:
                logging.info(f"📈 Conditions d'achat remplies pour {asset}")
                
                # Vérifier si nous avons déjà une position sur cet actif
                if asset in self.open_positions:
                    logging.info(f"Position déjà ouverte sur {asset}, pas d'achat supplémentaire")
                    return
                
                # Vérifier que nous avons des USD disponibles
                if 'ZUSD' not in self.balances or self.balances['ZUSD'] < 10:
                    logging.info(f"Pas assez d'USD disponibles pour acheter {asset}")
                    return
                
                # Calculer la taille du trade
                trade_size = self.calculate_trade_size(self.balances['ZUSD'], current_price, asset)
                
                # Exécuter l'achat
                result = self.buy(asset, amount=trade_size)
                
                if result:
                    logging.info(f"✅ Achat réussi de {trade_size:.8f} {asset} à {current_price:.6f}")
            
            # Conditions de vente: momentum faible ou négatif, score de bulle élevé
            elif asset in self.balances and self.balances[asset] > 0:
                if momentum < 0 or bubble_score > 0.8:
                    logging.info(f"📉 Conditions de vente remplies pour {asset}")
                    
                    # Exécuter la vente
                    result = self.sell(asset, percentage=100)
                    
                    if result:
                        logging.info(f"✅ Vente réussie de {asset}")
                        
                        # Supprimer la position si elle existe
                        if asset in self.open_positions:
                            del self.open_positions[asset]
        except Exception as e:
            logging.error(f"Erreur dans la logique de trading pour {asset}: {e}")

    def convert_to_volatile(self):
        """
        ÉCHANGE RAPIDE: Convertit TOUS les actifs disponibles en cryptos ultra-volatiles
        Reconnaissance automatique des actifs de valeur et conversion ultra-rapide
        Vise des gains mensuels de 20-50% 
        
        Returns:
            bool: True si au moins une conversion a réussi
        """
        logging.info("🔄 Conversion en cryptos ultra-volatiles démarrée")
        
        # Rafraîchir les balances
        self.refresh_balances()
        
        # Vérifier si nous avons des actifs non-volatils
        non_volatile_assets = []
        for asset, balance in self.balances.items():
            if asset == 'ZUSD' or balance <= 0:
                continue
            
            # Obtenir le prix en USD pour vérifier si l'actif a une valeur significative
            symbol = f"{asset}/USD"
            try:
                price = self.get_ticker_price(symbol)
                if price:
                    usd_value = balance * price
                    if usd_value > 5.0:  # Considérer seulement les actifs de plus de 5 USD
                        # Vérifier si l'actif est déjà dans notre liste d'actifs volatils
                        if asset not in self.volatile_assets:
                            non_volatile_assets.append((asset, balance, usd_value))
            except:
                pass
        
        if not non_volatile_assets:
            logging.info("Aucun actif non-volatil significatif trouvé pour conversion")
            return False
        
        # Trouver les meilleures opportunités volatiles
        if not self.volatile_assets:
            self.volatile_assets = self.find_volatile_assets()
        
        if not self.volatile_assets:
            logging.warning("Aucun actif volatil trouvé pour la conversion")
            return False
        
        # Convertir chaque actif non-volatil
        success = False
        for asset, balance, usd_value in non_volatile_assets:
            logging.info(f"Conversion de {balance:.8f} {asset} (~{usd_value:.2f} USD)")
            
            # Vendre l'actif
            sell_result = self.sell(asset, percentage=100)
            
            if sell_result:
                logging.info(f"✅ Vente réussie de {asset}")
                success = True
                
                # Attendre un moment pour que la vente soit prise en compte
                time.sleep(2)
                
                # Mettre à jour les balances
                self.refresh_balances()
            else:
                logging.error(f"❌ Échec de la vente de {asset}")
        
        # Si nous avons vendu quelque chose, acheter des actifs volatils
        if success and 'ZUSD' in self.balances and self.balances['ZUSD'] > 10:
            # Diviser les USD disponibles entre plusieurs actifs volatils
            available_usd = self.balances['ZUSD'] * 0.95  # Garder 5% en USD pour les frais
            
            # Choisir jusqu'à 3 actifs volatils pour diversifier
            target_assets = self.volatile_assets[:min(3, len(self.volatile_assets))]
            usd_per_asset = available_usd / len(target_assets)
            
            for volatile_asset in target_assets:
                # Obtenir le prix actuel
                symbol = f"{volatile_asset}/USD"
                price = self.get_ticker_price(symbol)
                
                if not price:
                    continue
                
                # Calculer le montant à acheter
                amount = usd_per_asset / price
                
                # Acheter l'actif volatil
                buy_result = self.buy(volatile_asset, amount=amount)
                
                if buy_result:
                    logging.info(f"✅ Achat réussi de {amount:.8f} {volatile_asset}")
                else:
                    logging.error(f"❌ Échec de l'achat de {volatile_asset}")
        
        return success

    def convert_to_audio(self):
        """
        Convertit tous les actifs significatifs en AUDIO
        
        Returns:
            bool: True si la conversion a réussi
        """
        logging.info("🔄 Conversion en AUDIO démarrée")
        
        # Rafraîchir les balances
        self.refresh_balances()
        
        # Vérifier si nous avons des actifs non-AUDIO
        non_audio_assets = []
        for asset, balance in self.balances.items():
            if asset == 'AUDIO' or asset == 'ZUSD' or balance <= 0:
                continue
            
            # Obtenir le prix en USD pour vérifier si l'actif a une valeur significative
            symbol = f"{asset}/USD"
            try:
                price = self.get_ticker_price(symbol)
                if price:
                    usd_value = balance * price
                    if usd_value > 5.0:  # Considérer seulement les actifs de plus de 5 USD
                        non_audio_assets.append((asset, balance, usd_value))
            except:
                pass
        
        if not non_audio_assets:
            logging.info("Aucun actif non-AUDIO significatif trouvé pour conversion")
            return False
        
        # Convertir chaque actif en USD d'abord
        success = False
        for asset, balance, usd_value in non_audio_assets:
            logging.info(f"Conversion de {balance:.8f} {asset} (~{usd_value:.2f} USD) en AUDIO")
            
            # Vendre l'actif
            sell_result = self.sell(asset, percentage=100)
            
            if sell_result:
                logging.info(f"✅ Vente réussie de {asset}")
                success = True
                
                # Attendre un moment pour que la vente soit prise en compte
                time.sleep(2)
                
                # Mettre à jour les balances
                self.refresh_balances()
            else:
                logging.error(f"❌ Échec de la vente de {asset}")
        
        # Si nous avons vendu quelque chose, acheter AUDIO
        if success and 'ZUSD' in self.balances and self.balances['ZUSD'] > 10:
            # Acheter AUDIO avec 95% des USD disponibles
            available_usd = self.balances['ZUSD'] * 0.95  # Garder 5% en USD pour les frais
            
            # Obtenir le prix actuel d'AUDIO
            symbol = "AUDIO/USD"
            price = self.get_ticker_price(symbol)
            
            if price:
                # Calculer le montant à acheter
                amount = available_usd / price
                
                # Acheter AUDIO
                buy_result = self.buy("AUDIO", amount=amount)
                
                if buy_result:
                    logging.info(f"✅ Achat réussi de {amount:.8f} AUDIO")
                else:
                    logging.error("❌ Échec de l'achat d'AUDIO")
        
        return success

    def convert_to_btc(self):
        """
        Convertit tous les actifs significatifs en BTC
        
        Returns:
            bool: True si la conversion a réussi
        """
        logging.info("🔄 Conversion en BTC démarrée")
        
        # Rafraîchir les balances
        self.refresh_balances()
        
        # Vérifier si nous avons des actifs non-BTC
        non_btc_assets = []
        for asset, balance in self.balances.items():
            if asset == 'XXBT' or asset == 'ZUSD' or balance <= 0:
                continue
            
            # Obtenir le prix en USD pour vérifier si l'actif a une valeur significative
            symbol = f"{asset}/USD"
            try:
                price = self.get_ticker_price(symbol)
                if price:
                    usd_value = balance * price
                    if usd_value > 5.0:  # Considérer seulement les actifs de plus de 5 USD
                        non_btc_assets.append((asset, balance, usd_value))
            except:
                pass
        
        if not non_btc_assets:
            logging.info("Aucun actif non-BTC significatif trouvé pour conversion")
            return False
        
        # Convertir chaque actif en USD d'abord
        success = False
        for asset, balance, usd_value in non_btc_assets:
            logging.info(f"Conversion de {balance:.8f} {asset} (~{usd_value:.2f} USD) en BTC")
            
            # Vendre l'actif
            sell_result = self.sell(asset, percentage=100)
            
            if sell_result:
                logging.info(f"✅ Vente réussie de {asset}")
                success = True
                
                # Attendre un moment pour que la vente soit prise en compte
                time.sleep(2)
                
                # Mettre à jour les balances
                self.refresh_balances()
            else:
                logging.error(f"❌ Échec de la vente de {asset}")
        
        # Si nous avons vendu quelque chose, acheter BTC
        if success and 'ZUSD' in self.balances and self.balances['ZUSD'] > 10:
            # Acheter BTC avec 95% des USD disponibles
            available_usd = self.balances['ZUSD'] * 0.95  # Garder 5% en USD pour les frais
            
            # Obtenir le prix actuel de BTC
            symbol = "BTC/USD"
            price = self.get_ticker_price(symbol)
            
            if price:
                # Calculer le montant à acheter
                amount = available_usd / price
                
                # Acheter BTC
                buy_result = self.buy("BTC", amount=amount)
                
                if buy_result:
                    logging.info(f"✅ Achat réussi de {amount:.8f} BTC")
                else:
                    logging.error("❌ Échec de l'achat de BTC")
        
        return success

    def start(self):
        """
        Démarre le trader
        
        Returns:
            bool: True si démarré avec succès
        """
        if self.running:
            logging.warning("Le trader est déjà en cours d'exécution")
            return False
        
        try:
            # Réinitialiser l'événement d'arrêt
            self.stop_event.clear()
            
            # Rafraîchir les balances et initialiser les données
            self.refresh_balances()
            
            # Démarrer le thread de mise à jour des prix
            self.price_updater_thread = threading.Thread(target=self._run_price_cache_updater)
            self.price_updater_thread.daemon = True
            self.price_updater_thread.start()
            
            # Démarrer le thread de recherche d'actifs volatils
            self.volatile_finder_thread = threading.Thread(target=self._find_volatile_assets_thread)
            self.volatile_finder_thread.daemon = True
            self.volatile_finder_thread.start()
            
            # Démarrer le thread principal de trading
            self.trader_thread = threading.Thread(target=self._trading_thread)
            self.trader_thread.daemon = True
            self.trader_thread.start()
            
            self.running = True
            logging.info("🚀 Trader volatil démarré")
            return True
        except Exception as e:
            logging.error(f"❌ Erreur lors du démarrage du trader: {e}")
            return False

    def stop(self):
        """
        Arrête le trader
        
        Returns:
            bool: True si arrêté avec succès
        """
        if not self.running:
            logging.warning("Le trader n'est pas en cours d'exécution")
            return False
        
        try:
            # Signaler l'arrêt à tous les threads
            self.stop_event.set()
            
            # Attendre que les threads se terminent
            if self.trader_thread and self.trader_thread.is_alive():
                self.trader_thread.join(timeout=5)
            
            if self.price_updater_thread and self.price_updater_thread.is_alive():
                self.price_updater_thread.join(timeout=5)
            
            if self.volatile_finder_thread and self.volatile_finder_thread.is_alive():
                self.volatile_finder_thread.join(timeout=5)
            
            self.running = False
            logging.info("⚠️ Trader arrêté")
            return True
        except Exception as e:
            logging.error(f"❌ Erreur lors de l'arrêt du trader: {e}")
            return False

    def get_status(self):
        """
        Récupère le statut complet du trader
        
        Returns:
            dict: Statut du trader
        """
        return {
            'running': self.running,
            'balances': self.balances,
            'volatile_assets': self.volatile_assets,
            'open_positions': self.open_positions,
            'price_cache': {
                k: v for k, v in self.price_cache.items() if k.endswith('/USD')
            }
        }

def create_trader():
    """Crée et initialise le trader avec les clés API de l'environnement"""
    try:
        api_key = os.environ.get("KRAKEN_API_KEY")
        api_secret = os.environ.get("KRAKEN_API_SECRET")
        
        if not api_key or not api_secret:
            logging.error("❌ Clés API Kraken non disponibles dans les variables d'environnement")
            return None
        
        trader = MultiPositionTrader(api_key=api_key, api_secret=api_secret)
        return trader
    except Exception as e:
        logging.error(f"❌ Erreur lors de la création du trader: {e}")
        return None

def main():
    """Fonction principale"""
    try:
        # Bannière de démarrage
        logging.info("""
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
TRADER MULTI-POSITIONS 24/7 DÉMARRÉ - MODE TEMPS RÉEL KRAKEN 
Utilise TOUTES les positions pour trader entre actifs volatils
Analyse minute par minute - Stop loss ultra-serré (0.5-0.8%)
Trades volatilité + momentum - Target profit 2-3% par trade
Clés API intégrées - Fonctionnement continu sur Replit
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
""")
        
        logging.info("=== DÉMARRAGE DU TRADER MULTI-POSITIONS 24/7 SUR REPLIT ===")
        logging.info("Création du trader...")
        
        # Créer et démarrer le trader
        trader = create_trader()
        
        if trader:
            success = trader.start()
            
            if success:
                logging.info("""
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
TRADER DÉMARRÉ AVEC SUCCÈS!
Le système utilise TOUTES vos positions et trade entre cryptos volatiles
Objectif: 2-3% par trade, stop-loss serré 0.5-0.8%
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
""")
            else:
                logging.error("❌ Échec du démarrage du trader")
        else:
            logging.error("❌ Échec de création du trader")
    except Exception as e:
        logging.error(f"❌ Erreur dans la fonction principale: {e}")

if __name__ == "__main__":
    main()