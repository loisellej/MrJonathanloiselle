#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LOGIQUE DU TRADER AUTOMATIQUE ULTRA-STABLE
Ce module contient la logique métier du trader automatique
Il est lancé par bot_final.py via le watchdog
"""

import os
import time
import json
import logging
import random
import krakenex
from datetime import datetime

# Import des utilitaires
from bot_final import log, send_discord_alert, state, save_state, TIMEOUT_SECONDS, update_heartbeat

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("trader_logic.log"),
        logging.StreamHandler()
    ]
)

# === CONFIGURATION TRADER ===
RISK_PER_TRADE = 0.90  # Pourcentage du solde à utiliser par trade (0-1)
PROFIT_TARGET = 0.03   # Cible de profit de 3%
STOP_LOSS = 0.008      # Stop-loss de 0.8%
KRAKEN_FEE = 0.0026    # Frais Kraken de 0.26%

# Variables globales
active_positions = {}
price_cache = {}
last_check_time = time.time()
volatile_assets = []

# === INITIALISATION ===
def initialize_kraken():
    """Initialise la connexion à l'API Kraken"""
    api_key = os.environ.get("KRAKEN_API_KEY")
    api_secret = os.environ.get("KRAKEN_API_SECRET")
    
    if not api_key or not api_secret:
        logging.error("❌ Clés API Kraken non trouvées dans les variables d'environnement")
        return None
    
    logging.info(f"✅ Clés API chargées: {api_key[:5]}.../{api_secret[:4]}")
    return krakenex.API(api_key, api_secret)

def check_timeout():
    """Vérifie si le bot est inactif depuis trop longtemps"""
    if time.time() - state.get("last_trade_time", 0) > TIMEOUT_SECONDS:
        logging.warning(f"⏱️ Bot inactif depuis {TIMEOUT_SECONDS}s. Sortie forcée...")
        send_discord_alert(f"⏱️ Inactivité détectée ({TIMEOUT_SECONDS}s). Redémarrage en cours...")
        exit(1)  # Sortie avec code d'erreur pour forcer le redémarrage

def update_heartbeat_state():
    """Met à jour le heartbeat et l'état"""
    update_heartbeat()  # Mettre à jour le fichier heartbeat
    state["last_check_time"] = time.time()
    save_state()

# === FONCTIONS EXCHANGE ===
def get_balances(k):
    """Récupère les balances du compte Kraken"""
    try:
        for _ in range(3):  # Essayer 3 fois en cas d'erreur
            response = k.query_private('Balance')
            if response.get('error'):
                logging.warning(f"⚠️ Erreur Kraken (balance): {response['error']}")
                time.sleep(1)
                continue
            
            balances = response.get('result', {})
            
            # Convertir les chaînes en nombres flottants
            formatted_balances = {}
            for asset, balance in balances.items():
                formatted_balances[asset] = float(balance)
            
            # Mettre à jour l'état
            state["balances"] = formatted_balances
            save_state()
            
            return formatted_balances
        
        logging.error("❌ Échec de récupération des balances après 3 tentatives")
        return {}
    except Exception as e:
        logging.error(f"❌ Exception lors de la récupération des balances: {e}")
        return {}

def get_asset_pairs(k):
    """Récupère la liste des paires d'actifs disponibles sur Kraken"""
    try:
        response = k.query_public('AssetPairs')
        if response.get('error'):
            logging.error(f"❌ Erreur lors de la récupération des paires d'actifs: {response['error']}")
            return {}
        
        return response.get('result', {})
    except Exception as e:
        logging.error(f"❌ Exception lors de la récupération des paires d'actifs: {e}")
        return {}

def get_ticker(k, pair):
    """Récupère les informations de ticker pour une paire d'actifs"""
    # Vérifier le cache d'abord
    if pair in price_cache and time.time() - price_cache[pair]['timestamp'] < 5:
        return price_cache[pair]['data']
    
    for attempt in range(3):  # Essayer 3 fois en cas d'erreur
        try:
            response = k.query_public('Ticker', {'pair': pair})
            if response.get('error'):
                logging.warning(f"⚠️ Erreur API publique ({attempt+1}/3): {response['error']}")
                time.sleep(0.5)
                continue
            
            # Mettre en cache
            price_cache[pair] = {
                'data': response.get('result', {}),
                'timestamp': time.time()
            }
            
            return response.get('result', {})
        except Exception as e:
            logging.warning(f"⚠️ Exception ticker ({attempt+1}/3): {e}")
            time.sleep(0.5)
    
    logging.error(f"❌ Impossible de récupérer le ticker pour {pair} après 3 tentatives")
    return {}

def get_volatility(k, pair):
    """Calcule la volatilité d'une paire d'actifs basée sur le ticker"""
    ticker_data = get_ticker(k, pair)
    if not ticker_data or pair not in ticker_data:
        return 0.0
    
    try:
        high = float(ticker_data[pair]['h'][0])
        low = float(ticker_data[pair]['l'][0])
        last = float(ticker_data[pair]['c'][0])
        
        # Calculer la volatilité comme l'amplitude High-Low en pourcentage du prix actuel
        if last > 0:
            volatility = ((high - low) / last) * 100
            return volatility
        return 0.0
    except (KeyError, ValueError, ZeroDivisionError) as e:
        logging.warning(f"⚠️ Erreur lors du calcul de la volatilité pour {pair}: {e}")
        return 0.0

def get_price_trend(k, pair, timeframe='1h', periods=12):
    """Calcule la tendance de prix (positive, négative) sur plusieurs périodes"""
    try:
        response = k.query_public('OHLC', {'pair': pair, 'interval': timeframe_to_minutes(timeframe)})
        if response.get('error'):
            logging.warning(f"⚠️ Erreur lors de la récupération des données OHLC: {response['error']}")
            return 0.0
        
        ohlc_data = response.get('result', {})
        if pair not in ohlc_data:
            return 0.0
        
        # Récupérer les périodes demandées
        periods_data = ohlc_data[pair][-periods:]
        
        if len(periods_data) < 2:
            return 0.0
        
        # Calculer la tendance comme la variation en pourcentage du premier au dernier prix
        first_close = float(periods_data[0][4])
        last_close = float(periods_data[-1][4])
        
        if first_close > 0:
            trend = ((last_close - first_close) / first_close) * 100
            return trend
        return 0.0
    except Exception as e:
        logging.warning(f"⚠️ Erreur lors du calcul de la tendance pour {pair}: {e}")
        return 0.0

def timeframe_to_minutes(timeframe):
    """Convertit un timeframe en minutes pour l'API Kraken"""
    if timeframe == '1m':
        return 1
    elif timeframe == '5m':
        return 5
    elif timeframe == '15m':
        return 15
    elif timeframe == '30m':
        return 30
    elif timeframe == '1h':
        return 60
    elif timeframe == '4h':
        return 240
    elif timeframe == '1d':
        return 1440
    elif timeframe == '1w':
        return 10080
    else:
        return 60  # Par défaut 1h

def get_trading_score(k, pair):
    """Calcule un score global de trading pour une paire d'actifs"""
    # Récupérer les métriques
    volatility = get_volatility(k, pair)
    trend = get_price_trend(k, pair)
    
    # Calculer le score (valorise la volatilité avec une tendance positive)
    # La volatilité est normalisée pour avoir un impact plus important
    volatility_score = min(1.0, volatility / 10.0)  # Normaliser entre 0 et 1
    trend_score = max(-1.0, min(1.0, trend / 5.0))  # Normaliser entre -1 et 1
    
    # Le score favorise la volatilité ET la tendance positive
    score = (volatility_score * 0.7) + (trend_score * 0.3)
    
    # Journaliser les métriques
    logging.info(f"{pair}: Volatilité {volatility:.2f}%, Tendance {trend:.2f}%, Score {score:.2f}")
    
    return score

def find_volatile_pairs(k, quote="ZUSD", min_volume=10000, max_pairs=10):
    """Trouve les paires les plus volatiles parmi celles disponibles"""
    logging.info("🔍 Recherche des paires les plus volatiles...")
    
    all_pairs = get_asset_pairs(k)
    volatile_pairs = []
    
    # Filtrer les paires qui correspondent à nos critères
    counter = 0
    for pair_name, pair_data in all_pairs.items():
        # Limiter à un certain nombre de requêtes pour éviter la surcharge
        counter += 1
        if counter > 30:
            break
            
        # Vérifier que la paire utilise la devise de cotation spécifiée
        if not pair_name.endswith(quote):
            continue
        
        # Sauter BTC, ETH et SOL (selon les exigences)
        if pair_name.startswith("XXBT") or pair_name.startswith("XETH") or "SOL" in pair_name:
            continue
        
        # Récupérer la volatilité et la tendance
        volatility = get_volatility(k, pair_name)
        trend = get_price_trend(k, pair_name)
        score = get_trading_score(k, pair_name)
        
        # Ajouter la paire à notre liste si la volatilité est mesurable
        if volatility > 0:
            volatile_pairs.append({
                'pair': pair_name,
                'volatility': volatility,
                'trend': trend,
                'score': score,
                'base': pair_data.get('base', ''),
                'quote': pair_data.get('quote', '')
            })
    
    # Trier par score décroissant
    volatile_pairs.sort(key=lambda x: x['score'], reverse=True)
    
    # Mettre à jour l'état
    if volatile_pairs:
        state["volatile_assets"] = [p['base'].replace("X", "").replace("Z", "") for p in volatile_pairs[:5]]
        save_state()
    
    # Limiter au nombre demandé
    return volatile_pairs[:max_pairs]

def execute_market_order(k, pair, type, volume):
    """Exécute un ordre au marché"""
    try:
        # Ajouter un nonce supplémentaire pour éviter les erreurs de nonce
        rand_nonce = random.randint(1000, 100000)
        
        params = {
            'pair': pair,
            'type': type,  # 'buy' ou 'sell'
            'ordertype': 'market',
            'volume': str(volume),
            'nonce': str(int(time.time() * 1000) + rand_nonce)
        }
        
        logging.info(f"🚀 Exécution de l'ordre: {type} {volume} {pair}")
        response = k.query_private('AddOrder', params)
        
        if response.get('error'):
            logging.error(f"❌ Erreur lors de l'exécution de l'ordre: {response['error']}")
            return None
        
        result = response.get('result')
        logging.info(f"✅ Ordre exécuté avec succès: {result}")
        
        # Mettre à jour l'état
        state["last_trade"] = f"{type.upper()} {volume} {pair} à {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        state["last_trade_time"] = time.time()
        state["trades_count"] = state.get("trades_count", 0) + 1
        save_state()
        
        # Notifier
        send_discord_alert(f"💸 Trade exécuté: {type.upper()} {volume} {pair}")
        
        return result
    except Exception as e:
        logging.error(f"❌ Exception lors de l'exécution de l'ordre: {e}")
        return None

def execute_volatile_trade(k):
    """Exécute un trade sur un actif volatil avec tendance haussière"""
    # Récupérer les balances
    balances = get_balances(k)
    if not balances:
        logging.error("❌ Impossible de récupérer les balances")
        return False
    
    # Vérifier s'il y a assez d'USD pour trader
    usd_balance = balances.get('ZUSD', 0)
    if usd_balance < 2:
        logging.warning(f"⚠️ Solde USD insuffisant pour trader: {usd_balance}")
        
        # Rechercher un autre actif à vendre
        for asset, balance in balances.items():
            # Ignorer USD et les actifs avec solde insignifiant
            if asset == 'ZUSD' or balance < 0.001:
                continue
            
            # Trouver une paire de trading pour cet actif
            pair_name = None
            for pair in get_asset_pairs(k).keys():
                if pair.startswith(asset) and pair.endswith('ZUSD'):
                    pair_name = pair
                    break
            
            if pair_name:
                # Calculer le montant à vendre (50% de la position)
                sell_amount = balance * 0.5
                logging.info(f"📉 Tentative de vente de {sell_amount} {asset} via {pair_name}")
                
                # Exécuter l'ordre de vente
                result = execute_market_order(k, pair_name, 'sell', sell_amount)
                if result:
                    logging.info(f"💰 Vente réussie: {result}")
                    time.sleep(5)  # Attendre que l'ordre soit traité
                    balances = get_balances(k)  # Mettre à jour les balances
                    usd_balance = balances.get('ZUSD', 0)
                    break
    
    # Si toujours pas assez d'USD, abandonner
    if usd_balance < 2:
        logging.error("❌ Impossible de libérer suffisamment d'USD pour trader")
        return False
    
    # Trouver les paires volatiles
    volatile_pairs = find_volatile_pairs(k)
    if not volatile_pairs:
        logging.error("❌ Aucune paire volatile trouvée")
        return False
    
    # Choisir la paire avec le meilleur score
    target_pair = volatile_pairs[0]
    logging.info(f"🎯 Cible: {target_pair['pair']} (volatilité: {target_pair['volatility']:.2f}%, tendance: {target_pair['trend']:.2f}%, score: {target_pair['score']:.2f})")
    
    # Calculer le montant à acheter (95% du solde USD disponible)
    buy_amount_usd = usd_balance * RISK_PER_TRADE
    
    # Obtenir le prix actuel
    ticker = get_ticker(k, target_pair['pair'])
    if not ticker or target_pair['pair'] not in ticker:
        logging.error(f"❌ Impossible de récupérer le prix pour {target_pair['pair']}")
        return False
    
    # Calculer le volume en unités de l'actif de base
    current_price = float(ticker[target_pair['pair']]['c'][0])
    volume = buy_amount_usd / current_price
    
    # Arrondir à 8 décimales (standard pour les crypto)
    volume = round(volume, 8)
    
    logging.info(f"📈 Achat de {volume} {target_pair['base']} à environ {current_price} USD")
    
    # Exécuter l'ordre d'achat
    result = execute_market_order(k, target_pair['pair'], 'buy', volume)
    if not result:
        logging.error("❌ Échec de l'exécution de l'ordre d'achat")
        return False
    
    tx_id = result.get('txid', ['AUCUN'])[0]
    logging.info(f"✅ Trade exécuté avec succès: {result}")
    logging.info(f"📝 TRANSACTION ID: {tx_id}")
    
    # Mettre à jour l'état avec la transaction
    state["last_trade"] = f"BUY {volume} {target_pair['base']} à {current_price} USD - ID: {tx_id}"
    state["last_trade_time"] = time.time()
    save_state()
    
    return True

# === BOUCLE PRINCIPALE ===
def main_loop():
    """Boucle principale du trader automatique"""
    # Initialiser Kraken
    k = initialize_kraken()
    if not k:
        logging.error("❌ Impossible d'initialiser l'API Kraken")
        return
    
    # Enregistrer le PID
    with open("auto_trader_pid.txt", "w") as f:
        f.write(str(os.getpid()))
    
    # Log de démarrage
    logging.info("🚀 DÉMARRAGE DU TRADER AUTOMATIQUE VÉRIFIÉ - MODE LIVE UNIQUEMENT")
    logging.info("="*80)
    logging.info("🔄 Chargement des variables d'environnement...")
    
    # Notifier le démarrage
    send_discord_alert("🚀 Trader automatique démarré")
    
    # Récupérer les balances initiales
    balances = get_balances(k)
    if balances:
        # Calculer les positions significatives
        positions = []
        for asset, balance in balances.items():
            if asset == 'ZUSD':
                continue
            if balance > 0.001:
                # Trouver la paire correspondante pour obtenir le prix
                pair_name = None
                for pair in get_asset_pairs(k).keys():
                    if pair.startswith(asset) and pair.endswith('ZUSD'):
                        pair_name = pair
                        break
                
                if pair_name:
                    ticker = get_ticker(k, pair_name)
                    if ticker and pair_name in ticker:
                        price = float(ticker[pair_name]['c'][0])
                        value_usd = balance * price
                        positions.append(f"{asset.replace('X', '').replace('Z', '')}: {balance} (~{value_usd:.2f}$)")
        
        if positions:
            position_text = ", ".join(positions)
            logging.info(f"Positions significatives: {position_text}")
    
    logging.info("✅ Trader vérifié démarré en mode LIVE")
    
    # Boucle principale
    cycle_count = 0
    while True:
        try:
            # Mettre à jour le heartbeat
            update_heartbeat()
            
            # Vérifier l'inactivité
            check_timeout()
            
            # Exécuter l'analyse toutes les minutes
            cycle_count += 1
            if cycle_count % 5 == 0:  # Toutes les 5 itérations
                # Rechercher les opportunités
                volatile_pairs = find_volatile_pairs(k)
                if volatile_pairs:
                    best_pair = volatile_pairs[0]
                    
                    # Si le score est très bon, exécuter un trade
                    if best_pair['score'] > 0.5:  # Seuil de score élevé
                        logging.info(f"🔥 Score élevé détecté pour {best_pair['pair']} ({best_pair['score']:.2f}), exécution d'un trade")
                        execute_volatile_trade(k)
                        
                        # Attendre plus longtemps après un trade
                        time.sleep(300)  # 5 minutes
                        continue
            
            # Vérifier les positions ouvertes pour les stop-loss
            # (à implémenter)
            
            # Mettre à jour l'état
            state["last_check_time"] = time.time()
            save_state()
            
            # Attendre avant la prochaine itération
            time.sleep(12)  # 12 secondes entre chaque vérification
            
        except Exception as e:
            logging.error(f"❌ Erreur dans la boucle principale: {e}")
            time.sleep(30)  # Attendre avant de réessayer

if __name__ == "__main__":
    main_loop()