#!/usr/bin/env python3
"""
Système de surveillance (Watchdog) pour le trader optimisé Replit
Ce script surveille et redémarre automatiquement le trader en cas de crash
avec gestion intelligente des erreurs et des redémarrages
"""
import os
import sys
import time
import signal
import logging
import subprocess
import psutil
import threading
import json
from datetime import datetime, timedelta

# Configuration du logging avancée avec rotation
log_file = "watchdog.log"
max_log_size = 5 * 1024 * 1024  # 5 Mo

# Vérifier si le fichier de log est trop grand
if os.path.exists(log_file) and os.path.getsize(log_file) > max_log_size:
    # Renommer l'ancien fichier log
    timestamp = time.strftime("%Y%m%d%H%M%S")
    os.rename(log_file, f"{log_file}.{timestamp}")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("WatchdogSystem")

# Configuration
TRADER_SCRIPT = "replit_optimized_trader.py"
HEARTBEAT_FILE = "bot_heartbeat.txt"
PID_FILE = "bot_pid.txt"
CONFIG_FILE = "watchdog_config.json"
CRASH_LOG_FILE = "crash_log.json"

# Valeurs par défaut de configuration
DEFAULT_CONFIG = {
    "max_consecutive_crashes": 5,
    "crash_timeout_minutes": 60,
    "check_interval_seconds": 10,
    "heartbeat_max_age_seconds": 30,
    "memory_threshold_percent": 90,
    "cpu_threshold_percent": 90,
    "restart_on_high_resource": True,
    "debug_mode": False
}

class WatchdogSystem:
    """
    Système de surveillance et redémarrage automatique pour le trader
    """
    
    def __init__(self):
        """Initialise le système de surveillance"""
        self.config = self._load_config()
        self.crash_history = self._load_crash_history()
        self.running = False
        self.watchdog_thread = None
        
        # Statistiques
        self.stats = {
            "last_check": None,
            "checks_performed": 0,
            "crashes_detected": 0,
            "restarts_performed": 0,
            "high_resource_restarts": 0,
            "start_time": datetime.now().isoformat()
        }
        
        logger.info("Système Watchdog initialisé")
    
    def _load_config(self):
        """
        Charge la configuration du watchdog
        
        Returns:
            dict: Configuration
        """
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r") as f:
                    config = json.load(f)
                    
                # S'assurer que toutes les clés par défaut sont présentes
                for key, value in DEFAULT_CONFIG.items():
                    if key not in config:
                        config[key] = value
                
                return config
            else:
                # Créer le fichier de configuration par défaut
                with open(CONFIG_FILE, "w") as f:
                    json.dump(DEFAULT_CONFIG, f, indent=4)
                
                return DEFAULT_CONFIG.copy()
        
        except Exception as e:
            logger.error(f"Erreur lors du chargement de la configuration: {e}")
            return DEFAULT_CONFIG.copy()
    
    def _save_config(self):
        """Sauvegarde la configuration du watchdog"""
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(self.config, f, indent=4)
        
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde de la configuration: {e}")
    
    def _load_crash_history(self):
        """
        Charge l'historique des crashes
        
        Returns:
            list: Historique des crashes
        """
        try:
            if os.path.exists(CRASH_LOG_FILE):
                with open(CRASH_LOG_FILE, "r") as f:
                    history = json.load(f)
                
                # Nettoyer les crashes trop anciens
                cutoff = (datetime.now() - timedelta(minutes=self.config["crash_timeout_minutes"])).isoformat()
                history = [crash for crash in history if crash["timestamp"] > cutoff]
                
                return history
            else:
                return []
        
        except Exception as e:
            logger.error(f"Erreur lors du chargement de l'historique des crashes: {e}")
            return []
    
    def _save_crash_history(self):
        """Sauvegarde l'historique des crashes"""
        try:
            with open(CRASH_LOG_FILE, "w") as f:
                json.dump(self.crash_history, f, indent=4)
        
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde de l'historique des crashes: {e}")
    
    def _log_crash(self, reason, pid=None):
        """
        Ajoute un crash à l'historique
        
        Args:
            reason (str): Raison du crash
            pid (int, optional): PID du processus
        """
        try:
            crash = {
                "timestamp": datetime.now().isoformat(),
                "reason": reason,
                "pid": pid
            }
            
            self.crash_history.append(crash)
            
            # Nettoyer les crashes trop anciens
            cutoff = (datetime.now() - timedelta(minutes=self.config["crash_timeout_minutes"])).isoformat()
            self.crash_history = [crash for crash in self.crash_history if crash["timestamp"] > cutoff]
            
            # Sauvegarder l'historique
            self._save_crash_history()
            
            # Mettre à jour les statistiques
            self.stats["crashes_detected"] += 1
            
        except Exception as e:
            logger.error(f"Erreur lors de l'ajout d'un crash à l'historique: {e}")
    
    def is_process_running(self, pid):
        """
        Vérifie si un processus avec le PID donné est en cours d'exécution
        
        Args:
            pid (int): PID du processus
            
        Returns:
            bool: True si le processus est en cours d'exécution
        """
        try:
            process = psutil.Process(pid)
            return process.is_running() and process.status() != psutil.STATUS_ZOMBIE
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return False
    
    def get_trader_pid(self):
        """
        Récupère le PID du trader s'il est en cours d'exécution
        
        Returns:
            int: PID du trader ou None s'il n'est pas en cours d'exécution
        """
        try:
            # Vérifier le fichier PID
            if os.path.exists(PID_FILE):
                with open(PID_FILE, "r") as f:
                    pid = int(f.read().strip())
                    
                    # Vérifier si le processus est en cours d'exécution
                    if self.is_process_running(pid):
                        return pid
            
            # Si le fichier PID n'existe pas ou n'est pas valide, chercher le processus
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    # Vérifier si c'est le processus du trader
                    if proc.info['name'] == 'python' and any(TRADER_SCRIPT in cmd for cmd in proc.info['cmdline']):
                        return proc.info['pid']
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return None
        
        except Exception as e:
            logger.error(f"Erreur lors de la recherche du PID: {e}")
            return None
    
    def is_heartbeat_valid(self):
        """
        Vérifie si le fichier heartbeat est valide (pas trop ancien)
        
        Returns:
            bool: True si le heartbeat est valide
        """
        try:
            if not os.path.exists(HEARTBEAT_FILE):
                return False
            
            # Vérifier l'âge du fichier
            mtime = os.path.getmtime(HEARTBEAT_FILE)
            age_seconds = time.time() - mtime
            
            # Si le fichier est trop ancien, il n'est pas valide
            if age_seconds > self.config["heartbeat_max_age_seconds"]:
                return False
            
            # Vérifier le contenu du fichier
            with open(HEARTBEAT_FILE, "r") as f:
                content = f.read().strip()
                
                # Vérifier si le contenu a le format attendu
                if "Trader actif:" not in content:
                    return False
            
            return True
        
        except Exception as e:
            logger.error(f"Erreur lors de la vérification du heartbeat: {e}")
            return False
    
    def check_resources(self, pid):
        """
        Vérifie l'utilisation des ressources du trader
        
        Args:
            pid (int): PID du trader
            
        Returns:
            tuple: (bool, dict) - (ressources OK, statistiques)
        """
        try:
            if pid is None:
                return True, {}
            
            # Obtenir les statistiques du processus
            process = psutil.Process(pid)
            process_stats = {
                "cpu_percent": process.cpu_percent(interval=0.5),
                "memory_percent": process.memory_percent(),
                "num_threads": process.num_threads(),
                "create_time": datetime.fromtimestamp(process.create_time()).isoformat(),
                "running_time_seconds": time.time() - process.create_time()
            }
            
            # Vérifier si les ressources sont trop élevées
            if (process_stats["cpu_percent"] > self.config["cpu_threshold_percent"] or 
                process_stats["memory_percent"] > self.config["memory_threshold_percent"]):
                
                if self.config["restart_on_high_resource"]:
                    logger.warning(f"Utilisation ressources élevée: CPU {process_stats['cpu_percent']:.1f}%, "
                                  f"Mémoire {process_stats['memory_percent']:.1f}%")
                    return False, process_stats
            
            return True, process_stats
        
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            # Le processus n'existe plus ou est inaccessible
            return True, {}
        
        except Exception as e:
            logger.error(f"Erreur lors de la vérification des ressources: {e}")
            return True, {}
    
    def should_restart(self):
        """
        Détermine si le trader doit être redémarré en fonction de l'historique des crashes
        
        Returns:
            bool: True si le trader doit être redémarré
        """
        # Si aucun crash récemment, redémarrer
        if len(self.crash_history) < self.config["max_consecutive_crashes"]:
            return True
        
        # Vérifier si trop de crashes récents
        recent_crashes = 0
        cutoff = (datetime.now() - timedelta(minutes=self.config["crash_timeout_minutes"])).isoformat()
        
        for crash in self.crash_history:
            if crash["timestamp"] > cutoff:
                recent_crashes += 1
        
        # Si trop de crashes récents, ne pas redémarrer pour éviter une boucle
        if recent_crashes >= self.config["max_consecutive_crashes"]:
            logger.warning(f"Trop de crashes récents ({recent_crashes}), pas de redémarrage automatique")
            return False
        
        return True
    
    def start_trader(self):
        """
        Démarre le trader
        
        Returns:
            int: PID du trader ou None en cas d'erreur
        """
        try:
            logger.info("Démarrage du trader")
            
            # Vérifier si le trader est déjà en cours d'exécution
            pid = self.get_trader_pid()
            if pid:
                logger.info(f"Le trader est déjà en cours d'exécution (PID: {pid})")
                return pid
            
            # Lancer le trader en tant que processus séparé
            process = subprocess.Popen(
                ["python", TRADER_SCRIPT],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            # Attendre que le processus démarre
            time.sleep(5)
            
            # Vérifier si le processus est toujours en cours d'exécution
            if process.poll() is None:
                logger.info(f"Trader démarré avec succès (PID: {process.pid})")
                self.stats["restarts_performed"] += 1
                return process.pid
            else:
                # Récupérer les erreurs
                stdout, stderr = process.communicate()
                error_msg = stderr.decode()
                logger.error(f"Échec du démarrage: {error_msg}")
                
                # Enregistrer le crash
                self._log_crash(f"Échec du démarrage: {error_msg}")
                
                return None
            
        except Exception as e:
            logger.error(f"Erreur lors du démarrage du trader: {e}")
            self._log_crash(f"Erreur de démarrage: {e}")
            return None
    
    def stop_trader(self, pid=None):
        """
        Arrête le trader
        
        Args:
            pid (int, optional): PID du trader
            
        Returns:
            bool: True si l'arrêt est réussi
        """
        try:
            logger.info("Arrêt du trader")
            
            # Récupérer le PID si non fourni
            if pid is None:
                pid = self.get_trader_pid()
            
            if not pid:
                logger.warning("Le trader n'est pas en cours d'exécution")
                return True
            
            # Envoyer un signal SIGTERM au processus
            os.kill(pid, signal.SIGTERM)
            
            # Attendre que le processus se termine
            wait_seconds = 0
            while wait_seconds < 10:  # Attendre max 10 secondes
                if not self.is_process_running(pid):
                    logger.info("Trader arrêté avec succès")
                    
                    # Supprimer les fichiers PID et heartbeat
                    if os.path.exists(PID_FILE):
                        os.remove(PID_FILE)
                    
                    if os.path.exists(HEARTBEAT_FILE):
                        os.remove(HEARTBEAT_FILE)
                    
                    return True
                
                time.sleep(1)
                wait_seconds += 1
            
            # Si le processus ne s'est pas terminé, envoyer un signal SIGKILL
            logger.warning("Le trader ne répond pas, envoi de SIGKILL")
            os.kill(pid, signal.SIGKILL)
            time.sleep(1)
            
            # Supprimer les fichiers PID et heartbeat
            if os.path.exists(PID_FILE):
                os.remove(PID_FILE)
            
            if os.path.exists(HEARTBEAT_FILE):
                os.remove(HEARTBEAT_FILE)
            
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de l'arrêt du trader: {e}")
            
            # Essayer de nettoyer les fichiers en cas d'erreur
            try:
                if os.path.exists(PID_FILE):
                    os.remove(PID_FILE)
                
                if os.path.exists(HEARTBEAT_FILE):
                    os.remove(HEARTBEAT_FILE)
            except:
                pass
            
            return False
    
    def restart_trader(self, reason="Redémarrage manuel"):
        """
        Redémarre le trader
        
        Args:
            reason (str): Raison du redémarrage
            
        Returns:
            int: PID du trader ou None en cas d'erreur
        """
        try:
            logger.info(f"Redémarrage du trader: {reason}")
            
            # Récupérer le PID actuel
            current_pid = self.get_trader_pid()
            
            # Arrêter le trader
            if current_pid:
                if not self.stop_trader(current_pid):
                    logger.warning("Échec de l'arrêt propre du trader")
                    self._log_crash(f"Échec de l'arrêt: {reason}")
            
            # Pause pour s'assurer que tout est nettoyé
            time.sleep(2)
            
            # Démarrer le trader
            return self.start_trader()
            
        except Exception as e:
            logger.error(f"Erreur lors du redémarrage du trader: {e}")
            self._log_crash(f"Erreur de redémarrage: {e}")
            return None
    
    def watchdog_loop(self):
        """Boucle principale du watchdog"""
        logger.info("Démarrage de la boucle watchdog")
        
        try:
            while self.running:
                start_time = time.time()
                self.stats["last_check"] = datetime.now().isoformat()
                self.stats["checks_performed"] += 1
                
                # Récupérer le PID du trader
                pid = self.get_trader_pid()
                
                # Vérifier si le trader est en cours d'exécution
                if pid is None:
                    logger.warning("Le trader n'est pas en cours d'exécution")
                    
                    # Si trop de redémarrages récents, attendre
                    if self.should_restart():
                        logger.info("Redémarrage du trader")
                        self.start_trader()
                    else:
                        logger.warning("Pas de redémarrage automatique pour éviter une boucle")
                        
                elif not self.is_heartbeat_valid():
                    logger.warning("Heartbeat invalide ou manquant")
                    
                    # Vérifier si le processus est zombi
                    if self.is_process_running(pid):
                        logger.warning("Processus en cours d'exécution mais heartbeat invalide, redémarrage")
                        
                        # Enregistrer le crash
                        self._log_crash("Heartbeat invalide", pid)
                        
                        # Redémarrer le trader
                        if self.should_restart():
                            self.restart_trader("Heartbeat invalide")
                
                else:
                    # Le trader fonctionne, vérifier les ressources
                    resources_ok, process_stats = self.check_resources(pid)
                    
                    if not resources_ok:
                        logger.warning("Ressources trop élevées, redémarrage")
                        
                        # Enregistrer le crash
                        self._log_crash(f"Ressources trop élevées: CPU {process_stats.get('cpu_percent', 0):.1f}%, "
                                      f"Mémoire {process_stats.get('memory_percent', 0):.1f}%", pid)
                        
                        # Redémarrer le trader
                        self.restart_trader("Ressources trop élevées")
                        self.stats["high_resource_restarts"] += 1
                    
                    elif self.config["debug_mode"]:
                        logger.debug(f"Trader en cours d'exécution (PID: {pid}), "
                                   f"CPU: {process_stats.get('cpu_percent', 0):.1f}%, "
                                   f"Mémoire: {process_stats.get('memory_percent', 0):.1f}%")
                
                # Calculer le temps d'exécution et ajuster le délai
                elapsed = time.time() - start_time
                sleep_time = max(0.1, self.config["check_interval_seconds"] - elapsed)
                
                # Pause avant la prochaine vérification
                time.sleep(sleep_time)
                
        except Exception as e:
            logger.error(f"Erreur dans la boucle watchdog: {e}")
            self.running = False
        
        logger.info("Boucle watchdog arrêtée")
    
    def start(self):
        """
        Démarre le watchdog
        
        Returns:
            bool: True si le démarrage est réussi
        """
        try:
            if self.running:
                logger.warning("Le watchdog est déjà en cours d'exécution")
                return True
            
            logger.info("Démarrage du watchdog")
            self.running = True
            
            # Démarrer la boucle watchdog dans un thread
            self.watchdog_thread = threading.Thread(target=self.watchdog_loop)
            self.watchdog_thread.daemon = True
            self.watchdog_thread.start()
            
            logger.info("Watchdog démarré avec succès")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors du démarrage du watchdog: {e}")
            self.running = False
            return False
    
    def stop(self):
        """
        Arrête le watchdog
        
        Returns:
            bool: True si l'arrêt est réussi
        """
        try:
            if not self.running:
                logger.warning("Le watchdog n'est pas en cours d'exécution")
                return True
            
            logger.info("Arrêt du watchdog")
            self.running = False
            
            # Attendre que le thread se termine
            if self.watchdog_thread and self.watchdog_thread.is_alive():
                self.watchdog_thread.join(timeout=5)
            
            logger.info("Watchdog arrêté avec succès")
            return True
            
        except Exception as e:
            logger.error(f"Erreur lors de l'arrêt du watchdog: {e}")
            return False
    
    def get_status(self):
        """
        Récupère le statut complet du watchdog et du trader
        
        Returns:
            dict: Statut complet
        """
        try:
            # Récupérer le PID du trader
            pid = self.get_trader_pid()
            
            # Vérifier le heartbeat
            heartbeat_valid = self.is_heartbeat_valid()
            heartbeat_content = None
            
            if os.path.exists(HEARTBEAT_FILE):
                try:
                    with open(HEARTBEAT_FILE, "r") as f:
                        heartbeat_content = f.read().strip()
                except:
                    pass
            
            # Obtenir les statistiques du processus
            process_stats = {}
            if pid:
                _, process_stats = self.check_resources(pid)
            
            # Calculer les statistiques des crashes
            crash_stats = {
                "total_crashes": len(self.crash_history),
                "recent_crashes": 0,
                "last_crash": None
            }
            
            cutoff = (datetime.now() - timedelta(minutes=self.config["crash_timeout_minutes"])).isoformat()
            for crash in self.crash_history:
                if crash["timestamp"] > cutoff:
                    crash_stats["recent_crashes"] += 1
            
            if self.crash_history:
                crash_stats["last_crash"] = self.crash_history[-1]
            
            # Assembler le statut complet
            status = {
                "watchdog": {
                    "running": self.running,
                    "stats": self.stats,
                    "config": self.config
                },
                "trader": {
                    "running": pid is not None,
                    "pid": pid,
                    "heartbeat_valid": heartbeat_valid,
                    "heartbeat_content": heartbeat_content,
                    "process_stats": process_stats
                },
                "crashes": crash_stats
            }
            
            return status
            
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du statut: {e}")
            return {
                "error": str(e),
                "watchdog_running": self.running
            }


def print_status(watchdog):
    """
    Affiche le statut complet du watchdog et du trader
    
    Args:
        watchdog (WatchdogSystem): Instance du watchdog
    """
    try:
        # Récupérer le statut
        status = watchdog.get_status()
        
        # Afficher l'en-tête
        print("\n" + "=" * 60)
        print(" STATUT DU SYSTÈME DE SURVEILLANCE ".center(60, "="))
        print("=" * 60)
        
        # Statut du watchdog
        print("\n[WATCHDOG]")
        print(f"  État:         {'✅ En cours' if status['watchdog']['running'] else '❌ Arrêté'}")
        print(f"  Vérifications: {status['watchdog']['stats']['checks_performed']}")
        print(f"  Dernière:     {status['watchdog']['stats']['last_check']}")
        
        # Statut du trader
        print("\n[TRADER]")
        if status['trader']['running']:
            print(f"  État:         ✅ En cours (PID: {status['trader']['pid']})")
            print(f"  Heartbeat:    {'✅ Valide' if status['trader']['heartbeat_valid'] else '❌ Invalide'}")
            
            # Afficher les statistiques du processus
            if status['trader']['process_stats']:
                stats = status['trader']['process_stats']
                print(f"  CPU:          {stats.get('cpu_percent', 0):.1f}%")
                print(f"  Mémoire:      {stats.get('memory_percent', 0):.1f}%")
                print(f"  Threads:      {stats.get('num_threads', 0)}")
                
                # Calculer le temps d'exécution
                if 'running_time_seconds' in stats:
                    running_time = stats['running_time_seconds']
                    hours, remainder = divmod(running_time, 3600)
                    minutes, seconds = divmod(remainder, 60)
                    print(f"  Temps d'exec: {int(hours)}h {int(minutes)}m {int(seconds)}s")
        else:
            print(f"  État:         ❌ Arrêté")
        
        # Statistiques des crashes
        print("\n[CRASHES]")
        print(f"  Total:        {status['crashes']['total_crashes']}")
        print(f"  Récents:      {status['crashes']['recent_crashes']}")
        
        if status['crashes']['last_crash']:
            last_crash = status['crashes']['last_crash']
            print(f"  Dernier:      {last_crash['timestamp']}")
            print(f"  Raison:       {last_crash['reason']}")
        
        print("\n" + "=" * 60)
        
    except Exception as e:
        print(f"Erreur lors de l'affichage du statut: {e}")


def main():
    """Fonction principale"""
    try:
        # Créer le watchdog
        watchdog = WatchdogSystem()
        
        # Vérifier les arguments
        if len(sys.argv) > 1:
            command = sys.argv[1].lower()
            
            if command == "start":
                # Démarrer le watchdog
                if watchdog.start():
                    # Démarrer le trader s'il n'est pas en cours d'exécution
                    if not watchdog.get_trader_pid():
                        watchdog.start_trader()
                    
                    print("✅ Système de surveillance démarré avec succès")
                else:
                    print("❌ Échec du démarrage du système de surveillance")
                
            elif command == "stop":
                # Arrêter le watchdog et le trader
                watchdog.stop()
                watchdog.stop_trader()
                print("✅ Système de surveillance et trader arrêtés")
                
            elif command == "restart":
                # Redémarrer le trader
                if watchdog.restart_trader("Redémarrage manuel"):
                    print("✅ Trader redémarré avec succès")
                else:
                    print("❌ Échec du redémarrage du trader")
                
            elif command == "status":
                # Afficher le statut
                print_status(watchdog)
                
            else:
                print("❌ Commande inconnue")
                print("Usage: python watchdog_system.py [start|stop|restart|status]")
        else:
            # Par défaut, démarrer le watchdog et afficher le statut
            watchdog.start()
            
            # Démarrer le trader s'il n'est pas en cours d'exécution
            if not watchdog.get_trader_pid():
                watchdog.start_trader()
            
            print_status(watchdog)
            
            # Garder le processus en vie
            print("\nSystème de surveillance en cours d'exécution (Ctrl+C pour quitter)...")
            
            try:
                # Boucle principale pour garder le processus en vie
                while watchdog.running:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\nArrêt du système de surveillance...")
                watchdog.stop()
                print("✅ Système arrêté")
        
    except Exception as e:
        print(f"❌ Erreur critique: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())