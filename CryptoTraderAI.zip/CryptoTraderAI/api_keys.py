#!/usr/bin/env python3
"""
Module centralisé pour la gestion des clés API
Ce fichier contient et exporte les clés API pour tous les autres scripts
"""
import os
from dotenv import load_dotenv

# Charger les variables d'environnement depuis .env
load_dotenv()

# Clés API Kraken - utiliser les variables d'environnement
API_KEY = os.environ.get("KRAKEN_API_KEY")
API_SECRET = os.environ.get("KRAKEN_API_SECRET")

# Vérifier la présence des clés API
if not API_KEY or not API_SECRET:
    print("⚠️ ATTENTION: Clés API Kraken non trouvées dans les variables d'environnement")
    print("Utilisez le fichier .env pour définir KRAKEN_API_KEY et KRAKEN_API_SECRET")
else:
    print(f"✅ Clés API chargées: {API_KEY[:5]}...{API_KEY[-5:]}")

# Fonctions d'accès aux clés API
def get_api_key():
    """Retourne la clé API Kraken"""
    return API_KEY

def get_api_secret():
    """Retourne la clé secrète API Kraken"""
    return API_SECRET

def get_api_credentials():
    """Retourne un tuple (api_key, api_secret)"""
    return (API_KEY, API_SECRET)

# Si exécuté directement, afficher les informations des clés
if __name__ == "__main__":
    print("\n===== INFORMATIONS DES CLÉS API =====")
    if API_KEY and API_SECRET:
        print(f"API Key: {API_KEY[:5]}...{API_KEY[-5:]}")
        print(f"API Secret: {API_SECRET[:5]}...{API_SECRET[-5:]}")
        print("✅ Les clés API sont correctement configurées")
    else:
        print("❌ Les clés API ne sont pas correctement configurées")
        print("Assurez-vous que le fichier .env contient KRAKEN_API_KEY et KRAKEN_API_SECRET")