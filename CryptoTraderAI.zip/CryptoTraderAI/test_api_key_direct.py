#!/usr/bin/env python3
"""
Test simple et direct des clés API Kraken
"""
import os
import sys
import time
import base64
import hashlib
import hmac
import urllib.parse
import requests

def get_kraken_signature(urlpath, data, secret):
    """
    Génère la signature pour l'authentification à l'API Kraken
    """
    postdata = urllib.parse.urlencode(data)
    encoded = (str(data['nonce']) + postdata).encode()
    message = urlpath.encode() + hashlib.sha256(encoded).digest()
    
    signature = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    sigdigest = base64.b64encode(signature.digest())
    
    return sigdigest.decode()

def kraken_request(uri_path, data, api_key, api_secret):
    """
    Envoie une requête authentifiée à l'API Kraken
    """
    headers = {
        'API-Key': api_key,
        'API-Sign': get_kraken_signature(uri_path, data, api_secret)
    }
    
    response = requests.post(
        'https://api.kraken.com' + uri_path, 
        headers=headers, 
        data=data
    )
    
    return response.json()

def get_account_balance(api_key, api_secret):
    """
    Récupère le solde du compte Kraken
    """
    resp = kraken_request(
        '/0/private/Balance', 
        {
            "nonce": str(int(time.time() * 1000))
        },
        api_key,
        api_secret
    )
    
    return resp

def main():
    """
    Fonction principale - Test des clés API Kraken
    """
    # Récupérer les clés API des variables d'environnement
    api_key = os.environ.get('KRAKEN_API_KEY')
    api_secret = os.environ.get('KRAKEN_API_SECRET')
    
    if not api_key or not api_secret:
        print("Les variables d'environnement KRAKEN_API_KEY et/ou KRAKEN_API_SECRET ne sont pas définies.")
        sys.exit(1)
    
    print("Clés API trouvées dans les variables d'environnement.")
    print(f"API Key: {api_key[:5]}...{api_key[-5:]}")
    print(f"API Secret: {api_secret[:5]}...{api_secret[-5:]}")
    
    print("\nTest de connexion à l'API Kraken...")
    try:
        result = get_account_balance(api_key, api_secret)
        
        if 'error' in result and result['error']:
            print(f"❌ Erreur lors de la connexion à l'API Kraken: {result['error']}")
            sys.exit(1)
        
        print("✅ Connexion réussie à l'API Kraken!")
        print("\nRésultat du test (Balance):")
        print(result)
        
        if 'result' in result:
            print("\nBalances:")
            for asset, balance in result['result'].items():
                if float(balance) > 0:
                    print(f"  {asset}: {balance}")
        
        sys.exit(0)
    except Exception as e:
        print(f"❌ Erreur lors du test de connexion: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()