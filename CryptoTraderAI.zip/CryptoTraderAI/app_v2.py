import os
import json
import logging
import threading
import time
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Import du nouveau bot de trading
from trading_bot_v2 import TradingBotV2

# Configuration de Flask
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "trading_bot_secret_key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # nécessaire pour url_for afin de générer avec https

# Configuration de la base de données
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

# Variables globales pour le bot et son état
trading_bot = None
bot_thread = None
bot_running = False

# Modèles de base de données
class Trade(db.Model):
    """Historique des trades exécutés (réels ou simulés)"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    asset = db.Column(db.String(50), nullable=False)
    action = db.Column(db.String(20), nullable=False)  # buy, sell, stop-loss
    amount = db.Column(db.Float, nullable=False)
    price = db.Column(db.Float, nullable=False)
    sentiment = db.Column(db.Float)
    volatility = db.Column(db.Float)
    bubble_score = db.Column(db.Float)
    total_usdt = db.Column(db.Float)
    stop_loss = db.Column(db.Float)

class APIKey(db.Model):
    """Stocke les clés API de manière sécurisée"""
    id = db.Column(db.Integer, primary_key=True)
    api_key = db.Column(db.String(255), nullable=False)
    api_secret = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime)

class BotState(db.Model):
    """État et configuration du bot de trading"""
    id = db.Column(db.Integer, primary_key=True)
    running = db.Column(db.Boolean, default=False)
    started_at = db.Column(db.DateTime)
    stopped_at = db.Column(db.DateTime)
    config = db.Column(db.JSON)  # Paramètres de configuration

# Initialisation de la base de données
with app.app_context():
    db.create_all()

# Initialisation du bot de trading
def initialize_trading_system():
    """Initialise le système de trading avec les clés API disponibles"""
    global trading_bot
    
    try:
        logger.info("Initialisation du système de trading...")
        
        # Récupérer la clé API la plus récente
        api_key_record = APIKey.query.order_by(APIKey.last_used.desc()).first()
        
        if api_key_record:
            logger.info("Clés API trouvées dans la base de données")
            api_key = api_key_record.api_key
            api_secret = api_key_record.api_secret
            
            # Mise à jour de l'horodatage de dernière utilisation
            api_key_record.last_used = datetime.utcnow()
            db.session.commit()
            
            # Créer le bot avec les clés API
            try:
                trading_bot = TradingBotV2(api_key=api_key, api_secret=api_secret)
                logger.info("Bot de trading initialisé avec les clés API")
                return True
            except Exception as e:
                logger.error(f"Échec de l'initialisation du bot avec les clés API: {e}")
                # Continuer pour créer un bot en mode simulation
        
        # Vérifier les variables d'environnement
        env_api_key = os.environ.get('KRAKEN_API_KEY')
        env_api_secret = os.environ.get('KRAKEN_API_SECRET')
        
        if env_api_key and env_api_secret:
            logger.info("Clés API trouvées dans les variables d'environnement")
            try:
                trading_bot = TradingBotV2(api_key=env_api_key, api_secret=env_api_secret)
                
                # Enregistrer les clés dans la base de données si elles ne sont pas déjà présentes
                if not api_key_record or (api_key_record.api_key != env_api_key):
                    new_key = APIKey(api_key=env_api_key, api_secret=env_api_secret, last_used=datetime.utcnow())
                    db.session.add(new_key)
                    db.session.commit()
                    logger.info("Nouvelles clés API enregistrées dans la base de données")
                
                logger.info("Bot de trading initialisé avec les clés API des variables d'environnement")
                return True
            except Exception as e:
                logger.error(f"Échec de l'initialisation du bot avec les clés API des variables d'environnement: {e}")
                # Continuer pour créer un bot en mode simulation
        
        # Si aucune clé API valide n'est trouvée, utiliser le mode simulation
        logger.info("Initialisation du bot en mode simulation (aucune clé API valide)")
        trading_bot = TradingBotV2(api_key="demo", api_secret="demo")
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors de l'initialisation du système de trading: {e}")
        return False

# Fonction pour exécuter le bot dans un thread séparé
def bot_worker():
    """Thread du bot de trading"""
    global trading_bot, bot_running
    
    try:
        # Enregistrer l'état du bot dans la base de données
        with app.app_context():
            bot_state = BotState.query.first()
            if not bot_state:
                bot_state = BotState()
                db.session.add(bot_state)
            
            bot_state.running = True
            bot_state.started_at = datetime.utcnow()
            bot_state.stopped_at = None
            db.session.commit()
            logger.info("État du bot mis à jour dans la base de données - en cours")
        
        # Démarrer le bot
        trading_bot.start()
        
        # Boucle principale pour synchroniser les trades avec la base de données
        while bot_running:
            try:
                # Synchroniser les trades récents avec la base de données
                with app.app_context():
                    if hasattr(trading_bot, 'trade_history') and trading_bot.trade_history:
                        for trade_data in trading_bot.trade_history[-10:]:
                            # Vérifier si le trade existe déjà (éviter les doublons)
                            existing_trade = Trade.query.filter(
                                Trade.timestamp == trade_data['timestamp'],
                                Trade.asset == trade_data['asset'],
                                Trade.action == trade_data['action'],
                                Trade.amount == trade_data['amount']
                            ).first()
                            
                            if not existing_trade:
                                # Créer un nouveau trade dans la base de données
                                new_trade = Trade(
                                    timestamp=trade_data['timestamp'],
                                    asset=trade_data['asset'],
                                    action=trade_data['action'],
                                    amount=trade_data['amount'],
                                    price=trade_data['price'],
                                    sentiment=trade_data.get('sentiment'),
                                    volatility=trade_data.get('volatility'),
                                    bubble_score=trade_data.get('bubble_score'),
                                    total_usdt=trade_data.get('total_usdt'),
                                    stop_loss=trade_data.get('stop_loss')
                                )
                                db.session.add(new_trade)
                                db.session.commit()
                                logger.info(f"Nouveau trade enregistré: {trade_data['action']} {trade_data['amount']} {trade_data['asset']}")
                        
                        # Conserver uniquement les 20 derniers trades en mémoire
                        trading_bot.trade_history = trading_bot.trade_history[-20:]
                
                # Attendre avant la prochaine synchronisation
                time.sleep(5)  # 5 secondes
            except Exception as e:
                logger.error(f"Erreur dans la boucle de synchronisation du bot: {e}")
                time.sleep(10)  # Attendre plus longtemps en cas d'erreur
        
        # Arrêter le bot
        trading_bot.stop()
        
        # Mettre à jour l'état du bot dans la base de données
        with app.app_context():
            bot_state = BotState.query.first()
            if bot_state:
                bot_state.running = False
                bot_state.stopped_at = datetime.utcnow()
                db.session.commit()
                logger.info("État du bot mis à jour dans la base de données - arrêté")
    
    except Exception as e:
        logger.error(f"Erreur dans le thread du bot: {e}")
        with app.app_context():
            bot_state = BotState.query.first()
            if bot_state:
                bot_state.running = False
                bot_state.stopped_at = datetime.utcnow()
                db.session.commit()
                logger.info("État du bot mis à jour dans la base de données - arrêté après erreur")

# Routes

@app.route('/')
def index():
    """Page principale du dashboard"""
    # Récupérer l'état du bot depuis la base de données
    bot_state_record = BotState.query.first()
    bot_is_running = bot_state_record.running if bot_state_record else False
    
    return render_template('index.html', bot_running=bot_is_running)

@app.route('/configure_api', methods=['POST'])
def configure_api():
    """Route pour configurer les clés API"""
    try:
        api_key = request.form.get('api_key')
        api_secret = request.form.get('api_secret')
        
        if not api_key or len(api_key) < 10 or not api_secret or len(api_secret) < 10:
            return jsonify({'success': False, 'error': 'Clés API invalides ou trop courtes'})
        
        # Enregistrer les nouvelles clés API
        new_key = APIKey(api_key=api_key, api_secret=api_secret, last_used=datetime.utcnow())
        db.session.add(new_key)
        db.session.commit()
        
        # Mettre à jour les variables d'environnement
        os.environ['KRAKEN_API_KEY'] = api_key
        os.environ['KRAKEN_API_SECRET'] = api_secret
        
        # Réinitialiser le bot de trading
        global trading_bot
        if trading_bot and hasattr(trading_bot, 'stop'):
            trading_bot.stop()
        
        success = initialize_trading_system()
        
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Erreur lors de la configuration des clés API: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/start_bot', methods=['POST'])
def start_bot():
    """Route pour démarrer le bot de trading"""
    global trading_bot, bot_thread, bot_running
    
    try:
        if not trading_bot:
            initialize_trading_system()
        
        if bot_running:
            return jsonify({'success': False, 'error': 'Le bot est déjà en cours d\'exécution'})
        
        # Démarrer le bot dans un thread séparé
        bot_running = True
        bot_thread = threading.Thread(target=bot_worker)
        bot_thread.daemon = True
        bot_thread.start()
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Erreur lors du démarrage du bot: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/stop_bot', methods=['POST'])
def stop_bot():
    """Route pour arrêter le bot de trading"""
    global bot_running
    
    try:
        if not bot_running:
            return jsonify({'success': False, 'error': 'Le bot n\'est pas en cours d\'exécution'})
        
        # Arrêter le thread du bot
        bot_running = False
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Erreur lors de l'arrêt du bot: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/force_trade_btc', methods=['POST'])
def force_trade_btc():
    """Convertit des actifs en BTC"""
    global trading_bot
    
    try:
        if not trading_bot:
            return jsonify({'success': False, 'error': 'Bot non initialisé'})
        
        # Récupérer les paramètres
        asset = request.form.get('asset', 'all')
        percentage = float(request.form.get('percentage', 1.0))
        
        # Convertir en BTC
        if asset == 'all':
            # Convertir tous les actifs significatifs en BTC
            trading_bot.refresh_balances()
            success_count = 0
            
            for asset_name, balance in trading_bot.exchange_balances.items():
                if asset_name in ['USDT', 'BTC']:
                    continue
                
                if balance > 0:
                    result = trading_bot.convert_to_btc(asset_name, percentage)
                    if result:
                        success_count += 1
            
            success = success_count > 0
            message = f"Conversion réussie de {success_count} actifs en BTC"
        else:
            # Convertir un actif spécifique en BTC
            success = trading_bot.convert_to_btc(asset, percentage)
            message = f"Conversion réussie de {asset} en BTC" if success else f"Échec de la conversion de {asset} en BTC"
        
        return jsonify({'success': success, 'message': message})
    except Exception as e:
        logger.error(f"Erreur lors de la conversion en BTC: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/force_trade_audio', methods=['POST'])
def force_trade_audio():
    """Convertit des actifs en AUDIO"""
    global trading_bot
    
    try:
        if not trading_bot:
            return jsonify({'success': False, 'error': 'Bot non initialisé'})
        
        # Récupérer les paramètres
        asset = request.form.get('asset', 'all')
        percentage = float(request.form.get('percentage', 1.0))
        
        # Convertir en AUDIO
        if asset == 'all':
            # Convertir tous les actifs significatifs en AUDIO
            trading_bot.refresh_balances()
            success_count = 0
            
            for asset_name, balance in trading_bot.exchange_balances.items():
                if asset_name in ['USDT', 'AUDIO']:
                    continue
                
                if balance > 0:
                    result = trading_bot.convert_to_audio(asset_name, percentage)
                    if result:
                        success_count += 1
            
            success = success_count > 0
            message = f"Conversion réussie de {success_count} actifs en AUDIO"
        else:
            # Convertir un actif spécifique en AUDIO
            success = trading_bot.convert_to_audio(asset, percentage)
            message = f"Conversion réussie de {asset} en AUDIO" if success else f"Échec de la conversion de {asset} en AUDIO"
        
        return jsonify({'success': success, 'message': message})
    except Exception as e:
        logger.error(f"Erreur lors de la conversion en AUDIO: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/force_trade_any', methods=['POST'])
def force_trade_any():
    """Convertit des actifs en cryptomonnaies volatiles"""
    global trading_bot
    
    try:
        if not trading_bot:
            return jsonify({'success': False, 'error': 'Bot non initialisé'})
        
        # Convertir tous les actifs en cryptos volatiles
        success = trading_bot.convert_all_to_volatile()
        message = "Conversion réussie en cryptos volatiles" if success else "Échec de la conversion en cryptos volatiles"
        
        return jsonify({'success': success, 'message': message})
    except Exception as e:
        logger.error(f"Erreur lors de la conversion en cryptos volatiles: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get_data', methods=['GET'])
def get_data():
    """Récupère les données en temps réel sur les soldes, trades et état des actifs"""
    global trading_bot
    
    try:
        if not trading_bot:
            return jsonify({'success': False, 'error': 'Bot non initialisé'})
        
        # Récupérer les données du bot
        if hasattr(trading_bot, 'get_status'):
            status_data = trading_bot.get_status()
        else:
            trading_bot.refresh_balances()
            status_data = {
                'mode': getattr(trading_bot, 'mode', 'unknown'),
                'balances': trading_bot.exchange_balances,
                'volatile_assets': trading_bot.volatile_assets
            }
        
        # Récupérer les trades récents depuis la base de données
        recent_trades = []
        db_trades = Trade.query.order_by(Trade.timestamp.desc()).limit(20).all()
        
        for trade in db_trades:
            recent_trades.append({
                'timestamp': trade.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'asset': trade.asset,
                'action': trade.action,
                'amount': trade.amount,
                'price': trade.price,
                'sentiment': trade.sentiment,
                'volatility': trade.volatility,
                'bubble_score': trade.bubble_score,
                'total_usdt': trade.total_usdt
            })
        
        # Récupérer l'état du bot
        bot_state_record = BotState.query.first()
        bot_is_running = bot_state_record.running if bot_state_record else False
        
        # Inclure les données dans la réponse
        status_data['recent_trades'] = recent_trades
        status_data['bot_running'] = bot_is_running
        status_data['success'] = True
        
        return jsonify(status_data)
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des données: {e}")
        return jsonify({'success': False, 'error': str(e)})

# N'initialisons pas au démarrage mais lors de la première demande
trading_bot = None

# Wrapper pour initialiser le bot si nécessaire
def get_trading_bot():
    global trading_bot
    if trading_bot is None:
        with app.app_context():
            initialize_trading_system()
    return trading_bot

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)