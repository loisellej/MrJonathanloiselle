#!/usr/bin/env python3
"""
Interface de test pour le trader avancé
Permet de simuler des trades et de tester les fonctionnalités
sans avoir besoin des clés API réelles
"""
import os
import sys
import time
import logging
import random
import json
from datetime import datetime

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class MockExchangeConnector:
    """
    Simulateur d'échange pour les tests
    Imite le comportement d'un vrai exchange comme Kraken
    """
    
    def __init__(self):
        """Initialisation du simulateur"""
        self.balances = {
            'USDT': 1000.0,
            'BTC': 0.01,
            'ETH': 0.1,
            'XRP': 100.0,
            'DOGE': 1000.0,
            'GARI': 5000.0,
            'AUDIO': 500.0
        }
        
        self.market_prices = {
            'BTC/USDT': 65000.0,
            'ETH/USDT': 3500.0,
            'XRP/USDT': 0.50,
            'DOGE/USDT': 0.12,
            'GARI/USDT': 0.25,
            'AUDIO/USDT': 1.20
        }
        
        self.price_trends = {
            'BTC/USDT': 0.001,  # +0.1% par heure
            'ETH/USDT': 0.002,  # +0.2% par heure
            'XRP/USDT': 0.005,  # +0.5% par heure
            'DOGE/USDT': 0.008,  # +0.8% par heure
            'GARI/USDT': 0.015,  # +1.5% par heure
            'AUDIO/USDT': 0.02   # +2% par heure
        }
        
        self.volatility = {
            'BTC/USDT': 0.005,  # ±0.5%
            'ETH/USDT': 0.008,  # ±0.8%
            'XRP/USDT': 0.012,  # ±1.2%
            'DOGE/USDT': 0.018,  # ±1.8%
            'GARI/USDT': 0.025,  # ±2.5%
            'AUDIO/USDT': 0.03   # ±3.0%
        }
        
        self.transaction_fee = 0.0026  # 0.26%
        self.order_history = []
        
        # Démarrer la mise à jour des prix
        self.last_update = time.time()
    
    def _update_prices(self):
        """Met à jour les prix du marché simulé"""
        current_time = time.time()
        hours_elapsed = (current_time - self.last_update) / 3600.0
        
        if hours_elapsed < 0.001:  # Éviter les mises à jour trop fréquentes
            return
        
        for symbol, price in self.market_prices.items():
            # Appliquer la tendance
            trend_factor = self.price_trends.get(symbol, 0.0) * hours_elapsed
            
            # Appliquer la volatilité (mouvement aléatoire)
            vol = self.volatility.get(symbol, 0.0)
            random_factor = random.uniform(-vol, vol)
            
            # Calculer le nouveau prix
            new_price = price * (1 + trend_factor + random_factor)
            
            # Mettre à jour le prix
            self.market_prices[symbol] = new_price
        
        self.last_update = current_time
    
    def fetch_balance(self):
        """Simule la requête de solde"""
        return {
            'result': {asset: str(amount) for asset, amount in self.balances.items()}
        }
    
    def get_balances(self):
        """Récupère les soldes du compte"""
        return self.balances
    
    def get_ticker_price(self, symbol):
        """Récupère le prix actuel d'un actif"""
        self._update_prices()
        
        # Normaliser le format du symbole
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
        
        return self.market_prices.get(symbol)
    
    def buy(self, symbol, amount):
        """Simule un ordre d'achat"""
        self._update_prices()
        
        # Normaliser le format du symbole
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
        
        base_asset = symbol.split('/')[0]
        quote_asset = symbol.split('/')[1]
        
        price = self.market_prices.get(symbol)
        if not price:
            logger.error(f"Prix non disponible pour {symbol}")
            return None
        
        # Calculer le montant total avec les frais
        total_cost = amount * price * (1 + self.transaction_fee)
        
        # Vérifier si nous avons assez de fonds
        if self.balances.get(quote_asset, 0) < total_cost:
            logger.error(f"Solde insuffisant en {quote_asset} pour acheter {amount} {base_asset}")
            return None
        
        # Exécuter l'ordre
        self.balances[quote_asset] -= total_cost
        self.balances[base_asset] = self.balances.get(base_asset, 0) + amount
        
        # Enregistrer l'ordre
        order = {
            'type': 'buy',
            'symbol': symbol,
            'amount': amount,
            'price': price,
            'total': total_cost,
            'fee': total_cost - (amount * price),
            'timestamp': datetime.utcnow().isoformat()
        }
        self.order_history.append(order)
        
        logger.info(f"Achat simulé: {amount} {base_asset} à {price} {quote_asset}")
        return order
    
    def sell(self, symbol, amount):
        """Simule un ordre de vente"""
        self._update_prices()
        
        # Normaliser le format du symbole
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
        
        base_asset = symbol.split('/')[0]
        quote_asset = symbol.split('/')[1]
        
        price = self.market_prices.get(symbol)
        if not price:
            logger.error(f"Prix non disponible pour {symbol}")
            return None
        
        # Vérifier si nous avons assez de l'actif à vendre
        if self.balances.get(base_asset, 0) < amount:
            logger.error(f"Solde insuffisant en {base_asset} pour vendre {amount}")
            return None
        
        # Calculer le montant reçu après frais
        total_received = amount * price * (1 - self.transaction_fee)
        
        # Exécuter l'ordre
        self.balances[base_asset] -= amount
        self.balances[quote_asset] = self.balances.get(quote_asset, 0) + total_received
        
        # Enregistrer l'ordre
        order = {
            'type': 'sell',
            'symbol': symbol,
            'amount': amount,
            'price': price,
            'total': total_received,
            'fee': (amount * price) - total_received,
            'timestamp': datetime.utcnow().isoformat()
        }
        self.order_history.append(order)
        
        logger.info(f"Vente simulée: {amount} {base_asset} à {price} {quote_asset}")
        return order
    
    def get_ohlcv(self, symbol, timeframe='1h', limit=24):
        """Simule les données OHLCV historiques"""
        self._update_prices()
        
        # Normaliser le format du symbole
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
        
        price = self.market_prices.get(symbol)
        if not price:
            logger.error(f"Prix non disponible pour {symbol}")
            return []
        
        # Générer des données OHLCV simulées
        current_time = int(time.time())
        result = []
        
        # Mapping des timeframes vers les secondes
        timeframe_seconds = {
            '1m': 60, '5m': 300, '15m': 900, '30m': 1800,
            '1h': 3600, '4h': 14400, '1d': 86400, '1w': 604800
        }
        
        interval = timeframe_seconds.get(timeframe, 3600)  # 1h par défaut
        
        base_volatility = self.volatility.get(symbol, 0.01)
        base_price = price / (1 + self.price_trends.get(symbol, 0) * (limit/24))
        
        for i in range(limit):
            # Calculer l'heure de la bougie
            candle_time = current_time - (limit - i) * interval
            
            # Simuler l'évolution du prix
            trend_factor = self.price_trends.get(symbol, 0) * (i/24)
            candle_base_price = base_price * (1 + trend_factor)
            
            # Générer les valeurs OHLCV
            volatility = base_volatility * (1 + random.uniform(-0.5, 0.5))
            open_price = candle_base_price * (1 + random.uniform(-volatility, volatility))
            close_price = candle_base_price * (1 + random.uniform(-volatility, volatility))
            high_price = max(open_price, close_price) * (1 + random.uniform(0, volatility))
            low_price = min(open_price, close_price) * (1 - random.uniform(0, volatility))
            volume = candle_base_price * random.uniform(10, 100)
            
            candle = [
                candle_time * 1000,  # Timestamp en millisecondes
                open_price,
                high_price,
                low_price,
                close_price,
                volume
            ]
            
            result.append(candle)
        
        return result

def main():
    """Fonction de test principale"""
    print("-" * 80)
    print("INTERFACE DE TEST DU TRADER AVANCÉ")
    print("-" * 80)
    
    # Initialiser le connecteur simulé
    exchange = MockExchangeConnector()
    
    # Afficher les soldes initiaux
    balances = exchange.get_balances()
    print("Soldes initiaux:")
    for asset, amount in balances.items():
        price = exchange.get_ticker_price(f"{asset}/USDT") if asset != "USDT" else 1.0
        usdt_value = amount * price if price else 0
        print(f"  {asset}: {amount:.6f} ≈ ${usdt_value:.2f}")
    
    total_value = sum([amount * (exchange.get_ticker_price(f"{asset}/USDT") if asset != "USDT" else 1.0) 
                       for asset, amount in balances.items()])
    print(f"Valeur totale du portefeuille: ${total_value:.2f}")
    print("-" * 80)
    
    # Menu interactif
    while True:
        print("\nOptions disponibles:")
        print("1. Afficher les soldes")
        print("2. Afficher les prix du marché")
        print("3. Simuler un achat")
        print("4. Simuler une vente")
        print("5. Afficher l'historique des transactions")
        print("6. Avancer dans le temps (simuler volatilité)")
        print("7. Quitter")
        
        choice = input("\nEntrez votre choix (1-7): ")
        
        if choice == '1':
            # Afficher les soldes
            balances = exchange.get_balances()
            print("\nSoldes actuels:")
            for asset, amount in balances.items():
                price = exchange.get_ticker_price(f"{asset}/USDT") if asset != "USDT" else 1.0
                usdt_value = amount * price if price else 0
                print(f"  {asset}: {amount:.6f} ≈ ${usdt_value:.2f}")
            
            total_value = sum([amount * (exchange.get_ticker_price(f"{asset}/USDT") if asset != "USDT" else 1.0) 
                              for asset, amount in balances.items()])
            print(f"Valeur totale du portefeuille: ${total_value:.2f}")
        
        elif choice == '2':
            # Afficher les prix du marché
            exchange._update_prices()
            print("\nPrix actuels du marché:")
            for symbol, price in exchange.market_prices.items():
                trend = exchange.price_trends.get(symbol, 0) * 100
                volatility = exchange.volatility.get(symbol, 0) * 100
                print(f"  {symbol}: ${price:.6f} (Tendance: {trend:+.2f}%/h, Volatilité: ±{volatility:.2f}%)")
        
        elif choice == '3':
            # Simuler un achat
            print("\nPaires disponibles:")
            for i, symbol in enumerate(exchange.market_prices.keys(), 1):
                price = exchange.market_prices[symbol]
                print(f"  {i}. {symbol} - Prix actuel: ${price:.6f}")
            
            try:
                pair_idx = int(input("Entrez le numéro de la paire à acheter: ")) - 1
                symbols = list(exchange.market_prices.keys())
                symbol = symbols[pair_idx]
                
                amount = float(input(f"Entrez la quantité de {symbol.split('/')[0]} à acheter: "))
                
                result = exchange.buy(symbol, amount)
                if result:
                    print(f"Achat réussi: {amount} {symbol.split('/')[0]} à ${result['price']:.6f}")
                    print(f"Total payé: ${result['total']:.2f} (Frais: ${result['fee']:.2f})")
            except (ValueError, IndexError) as e:
                print(f"Erreur: {e}")
        
        elif choice == '4':
            # Simuler une vente
            balances = exchange.get_balances()
            print("\nActifs disponibles:")
            assets = [asset for asset, amount in balances.items() if asset != "USDT" and amount > 0]
            
            for i, asset in enumerate(assets, 1):
                amount = balances[asset]
                price = exchange.get_ticker_price(f"{asset}/USDT")
                usdt_value = amount * price if price else 0
                print(f"  {i}. {asset}: {amount:.6f} ≈ ${usdt_value:.2f}")
            
            try:
                asset_idx = int(input("Entrez le numéro de l'actif à vendre: ")) - 1
                asset = assets[asset_idx]
                
                max_amount = balances[asset]
                amount = float(input(f"Entrez la quantité de {asset} à vendre (max: {max_amount:.6f}): "))
                
                result = exchange.sell(f"{asset}/USDT", amount)
                if result:
                    print(f"Vente réussie: {amount} {asset} à ${result['price']:.6f}")
                    print(f"Total reçu: ${result['total']:.2f} (Frais: ${result['fee']:.2f})")
            except (ValueError, IndexError) as e:
                print(f"Erreur: {e}")
        
        elif choice == '5':
            # Afficher l'historique des transactions
            print("\nHistorique des transactions:")
            if not exchange.order_history:
                print("  Aucune transaction effectuée")
            else:
                for i, order in enumerate(exchange.order_history, 1):
                    symbol = order['symbol']
                    base_asset = symbol.split('/')[0]
                    quote_asset = symbol.split('/')[1]
                    
                    if order['type'] == 'buy':
                        print(f"  {i}. ACHAT: {order['amount']:.6f} {base_asset} à ${order['price']:.6f}")
                        print(f"     Total payé: ${order['total']:.2f} {quote_asset} (Frais: ${order['fee']:.2f})")
                    else:
                        print(f"  {i}. VENTE: {order['amount']:.6f} {base_asset} à ${order['price']:.6f}")
                        print(f"     Total reçu: ${order['total']:.2f} {quote_asset} (Frais: ${order['fee']:.2f})")
                    print(f"     Date: {order['timestamp']}")
                    print()
        
        elif choice == '6':
            # Avancer dans le temps (simuler volatilité)
            hours = float(input("Entrez le nombre d'heures à simuler (ex: 0.5 pour 30 minutes): "))
            
            # Sauvegarder les prix actuels
            old_prices = exchange.market_prices.copy()
            
            # Avancer le temps
            exchange.last_update -= hours * 3600
            exchange._update_prices()
            
            print(f"\nAvancé de {hours} heures. Nouveaux prix:")
            for symbol, price in exchange.market_prices.items():
                old_price = old_prices[symbol]
                change = ((price / old_price) - 1) * 100
                print(f"  {symbol}: ${price:.6f} ({change:+.2f}%)")
        
        elif choice == '7':
            # Quitter
            print("\nFin du test. Au revoir!")
            break
        
        else:
            print("\nChoix invalide. Veuillez réessayer.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nTest interrompu par l'utilisateur. Au revoir!")
    except Exception as e:
        logger.error(f"Erreur non gérée: {e}")
        print(f"\nUne erreur est survenue: {e}")