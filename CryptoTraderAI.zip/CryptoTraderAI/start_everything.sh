#!/bin/bash

# SCRIPT ULTIME DE DÉMARRAGE 24/7
# Ce script garantit que tout s'exécute en permanence
# Il est conçu pour être lancé au démarrage de Replit

echo "==================================================="
echo "DÉMARRAGE DU SYSTÈME DE TRADING 24/7 ULTRA-FIABLE"
echo "==================================================="
date

# Arrêter tous les processus existants pour éviter les doublons
echo "Arrêt de tous les processus en cours..."
pkill -f "ultra_stable_bot.py" > /dev/null 2>&1
pkill -f "never_stop.py" > /dev/null 2>&1
pkill -f "supervisor.py" > /dev/null 2>&1
pkill -f "multi_position_trader.py" > /dev/null 2>&1

# Attendre que tout soit bien arrêté
sleep 2

# Vérifier que les clés API sont disponibles
if [ -z "$KRAKEN_API_KEY" ] || [ -z "$KRAKEN_API_SECRET" ]; then
    echo "ERREUR: Clés API Kraken manquantes dans les variables d'environnement"
    echo "Veuillez définir KRAKEN_API_KEY et KRAKEN_API_SECRET"
    exit 1
fi

# Démarrer le bot ultra-stable directement
echo "Démarrage du bot de trading ultra-stable..."
nohup python3 ultra_stable_bot.py > bot_output.log 2>&1 &
BOT_PID=$!
echo "Bot démarré avec PID: $BOT_PID"

# Démarrer le superviseur minimaliste
echo "Démarrage du superviseur minimaliste..."
nohup python3 never_stop.py > supervisor_output.log 2>&1 &
SUPERVISOR_PID=$!
echo "Superviseur démarré avec PID: $SUPERVISOR_PID"

# Démarrer l'interface web Flask principale
echo "Démarrage de l'interface web..."
nohup python3 main.py > web_output.log 2>&1 &
WEB_PID=$!
echo "Interface web démarrée avec PID: $WEB_PID"

# Créer un fichier de statut
echo "$(date): Système démarré" > system_status.log
echo "BOT_PID=$BOT_PID" >> system_status.log
echo "SUPERVISOR_PID=$SUPERVISOR_PID" >> system_status.log
echo "WEB_PID=$WEB_PID" >> system_status.log

# Créer un script de surveillance minimaliste qui s'exécute en arrière-plan
cat > watchdog.sh << 'EOL'
#!/bin/bash
while true; do
    # Vérifier si les processus sont toujours en cours d'exécution
    if ! ps -p $BOT_PID > /dev/null; then
        echo "$(date): Bot arrêté, redémarrage..." >> system_status.log
        nohup python3 ultra_stable_bot.py > bot_output.log 2>&1 &
        BOT_PID=$!
        echo "BOT_PID=$BOT_PID" >> system_status.log
    fi
    
    if ! ps -p $SUPERVISOR_PID > /dev/null; then
        echo "$(date): Superviseur arrêté, redémarrage..." >> system_status.log
        nohup python3 never_stop.py > supervisor_output.log 2>&1 &
        SUPERVISOR_PID=$!
        echo "SUPERVISOR_PID=$SUPERVISOR_PID" >> system_status.log
    fi
    
    # Attendre avant la prochaine vérification
    sleep 60
done
EOL

chmod +x watchdog.sh
nohup ./watchdog.sh > watchdog_output.log 2>&1 &
WATCHDOG_PID=$!
echo "Watchdog démarré avec PID: $WATCHDOG_PID"
echo "WATCHDOG_PID=$WATCHDOG_PID" >> system_status.log

echo ""
echo "==================================================="
echo "SYSTÈME DÉMARRÉ AVEC SUCCÈS!"
echo "Bot ultra-stable avec triple protection anti-crash"
echo "Stratégie: utilisation de toutes les positions"
echo "          crypto-to-crypto selon le momentum"
echo "Vous pouvez fermer cette fenêtre, tout continuera"
echo "de fonctionner en arrière-plan 24/7"
echo "==================================================="
echo ""
echo "Vérifiez l'état avec: tail -f trader_ultra_stable.log"
echo "ou: cat system_status.log"