import ccxt
import logging

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Clés API
API_KEY = "9/KUxib19lkk7FukHnbupTEBYHIFcKsKtGAEW3/krj89u0jC/fYhrwfD"
API_SECRET = "RKJ9m8mLgfDNO7bMEvxubD6bY/avyqsQGe6Ev1APMBvBFCvBjXpKGyI5rmR1iJT8U5aVbuHJoY0OI9cprH9qSg=="

def test_direct_connection():
    """Test la connexion en utilisant directement les clés"""
    try:
        # Initialiser l'échange
        exchange = ccxt.kraken({
            'apiKey': API_KEY,
            'secret': API_SECRET,
            'enableRateLimit': True
        })
        
        # Test de fonction publique
        markets = exchange.load_markets()
        logger.info(f"Marchés chargés: {len(markets)} paires disponibles")
        
        # Test de fonction privée (nécessite authentification)
        balances = exchange.fetch_balance()
        
        logger.info("Authentification réussie! Balances:")
        for asset, balance in balances['total'].items():
            if float(balance) > 0:
                logger.info(f"  {asset}: {balance}")
        
        return True
        
    except Exception as e:
        logger.error(f"Erreur lors du test de la connexion: {e}")
        if "Invalid key" in str(e):
            logger.error("Il semble que les clés API ne soient pas valides ou n'aient pas les permissions nécessaires")
        return False

if __name__ == "__main__":
    if test_direct_connection():
        print("\n✅ TEST RÉUSSI: La connexion à l'API Kraken fonctionne correctement!")
    else:
        print("\n❌ TEST ÉCHOUÉ: Problème avec la connexion à l'API Kraken")