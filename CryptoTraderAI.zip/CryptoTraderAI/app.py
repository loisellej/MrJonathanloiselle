import os
import logging
from flask import Flask, render_template, request, jsonify, flash, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.middleware.proxy_fix import ProxyFix
import threading
import time
from datetime import datetime
import json

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "crypto_trading_bot_secret")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Import models
from models import db, APIKey, Trade, AssetData, BotState
db.init_app(app)

# Create database tables
with app.app_context():
    db.create_all()

# Import modules
from exchange_connector import ExchangeConnector
from trading_bot import TradingBot
from sentiment_analyzer import SentimentAnalyzer

# Create global instances
sentiment_analyzer = SentimentAnalyzer()
exchange_connector = None
trading_bot = None
bot_thread = None
bot_running = False
trade_history = []
asset_prices = {}
asset_balances = {"USDT": 0, "BTC": 0, "ETH": 0}
sentiment_scores = {}
stop_losses = {}
asset_volatility = {}

# Initialisation du connecteur d'échange et du bot de trading
def initialize_trading_system():
    """Initialise le système de trading avec les clés API disponibles"""
    global exchange_connector, trading_bot
    
    logger.info("Initializing trading system...")
    
    # Récupération des clés API (priorité env vars > database)
    env_api_key = os.environ.get("KRAKEN_API_KEY", "").strip()
    env_api_secret = os.environ.get("KRAKEN_API_SECRET", "").strip()
    
    db_api_key = None
    db_api_secret = None
    
    # Vérifier la base de données pour les clés API
    try:
        with app.app_context():
            saved_api_key = APIKey.query.first()
            if saved_api_key:
                db_api_key = saved_api_key.api_key.strip()
                db_api_secret = saved_api_key.api_secret.strip()
                logger.info("Found API keys in database")
    except Exception as e:
        logger.error(f"Failed to retrieve API keys from database: {str(e)}")
    
    # Choisir les clés à utiliser (priorité env vars > database)
    if env_api_key and env_api_secret and len(env_api_key) > 10 and len(env_api_secret) > 10:
        logger.info("Using API keys from environment variables")
        api_key = env_api_key
        api_secret = env_api_secret
        
        # Mettre à jour la base de données si nécessaire
        if db_api_key and (db_api_key != api_key or db_api_secret != api_secret):
            try:
                with app.app_context():
                    saved_api_key = APIKey.query.first()
                    if saved_api_key:
                        saved_api_key.api_key = api_key
                        saved_api_key.api_secret = api_secret
                        saved_api_key.last_used = datetime.utcnow()
                        db.session.commit()
                        logger.info("Updated database API keys with environment variables")
            except Exception as e:
                logger.error(f"Failed to update database with new API keys: {str(e)}")
    
    elif db_api_key and db_api_secret and len(db_api_key) > 10 and len(db_api_secret) > 10:
        logger.info("Using API keys from database")
        api_key = db_api_key
        api_secret = db_api_secret
        
        # Mise à jour de la dernière utilisation
        try:
            with app.app_context():
                saved_api_key = APIKey.query.first()
                if saved_api_key:
                    saved_api_key.last_used = datetime.utcnow()
                    db.session.commit()
        except Exception as e:
            logger.error(f"Failed to update last_used timestamp: {str(e)}")
    else:
        logger.warning("No valid API keys found in environment or database")
        api_key = None
        api_secret = None
    
    # Initialiser le connecteur d'échange et le bot de trading
    if api_key and api_secret:
        try:
            # Créer le connecteur d'échange
            logger.info("Initializing exchange connector with API keys")
            exchange_connector = ExchangeConnector(api_key, api_secret)
            
            # Créer le bot de trading
            trading_bot = TradingBot(exchange_connector, sentiment_analyzer)
            logger.info("Successfully initialized trading system with API keys")
            
            # Sauvegarder les clés API dans la base de données si elles n'y sont pas déjà
            if not db_api_key:
                try:
                    with app.app_context():
                        new_api_key = APIKey(
                            api_key=api_key,
                            api_secret=api_secret,
                            last_used=datetime.utcnow()
                        )
                        db.session.add(new_api_key)
                        db.session.commit()
                        logger.info("Saved new API keys to database")
                except Exception as e:
                    logger.error(f"Failed to save API keys to database: {str(e)}")
            
            return True
        except Exception as e:
            logger.error(f"Failed to initialize trading system with API keys: {str(e)}")
    
    # Créer les objets par défaut si l'initialisation a échoué
    try:
        # Créer un mock connector pour le mode simulation
        logger.info("Initializing mock exchange connector")
        class MockExchangeConnector:
            def __init__(self):
                # Ajouter un attribut exchange pour correspondre à ExchangeConnector
                self.exchange = self  # Pour que self.exchange.fetch_balance() fonctionne, on pointe sur soi-même
                
            def fetch_balance(self):
                # Pour simuler l'API CCXT
                return {'total': self.get_balances()}
                
            def get_balances(self):
                # Simulation data
                balances = {
                    'USDT': 500.0,
                    'BTC': 0.008,
                    'ETH': 0.15,
                    'GARI': 1350.0,
                    'AUDIO': 100.0,
                    'DOT': 25.0,
                    'ADA': 150.0,
                    'API3': 35.0,
                    'XRP': 450.0
                }
                return balances
                
            def get_ticker_price(self, symbol):
                # Default prices for simulation
                prices = {
                    'BTC/USDT': 65000.0,
                    'ETH/USDT': 3100.0,
                    'GARI/USD': 0.12,
                    'AUDIO/USDT': 0.27,
                    'DOT/USDT': 7.50,
                    'ADA/USDT': 0.45,
                    'API3/USDT': 3.20,
                    'XRP/USDT': 0.55
                }
                return prices.get(symbol, 1.0)
                
            def buy(self, symbol, amount):
                logger.info(f"[SIMULATION] Buying {amount} of {symbol}")
                return True
                
            def sell(self, symbol, amount):
                logger.info(f"[SIMULATION] Selling {amount} of {symbol}")
                return True
                
            def get_ohlcv(self, symbol, timeframe='1h', limit=24):
                # Generate simulated OHLCV data
                now = int(time.time() * 1000)
                period_ms = 60 * 60 * 1000  # 1h in milliseconds
                base_price = self.get_ticker_price(symbol)
                data = []
                
                for i in range(limit):
                    timestamp = now - ((limit - i - 1) * period_ms)
                    open_price = base_price * (1 + (random.random() - 0.5) * 0.02)
                    close_price = base_price * (1 + (random.random() - 0.5) * 0.02)
                    high_price = max(open_price, close_price) * (1 + random.random() * 0.01)
                    low_price = min(open_price, close_price) * (1 - random.random() * 0.01)
                    volume = base_price * random.uniform(10, 100)
                    
                    data.append([timestamp, open_price, high_price, low_price, close_price, volume])
                
                return data
            
        # Créer une instance du mock connector
        exchange_connector = MockExchangeConnector()
    except Exception as e:
        # Fallback en cas d'erreur critique
        logger.error(f"Failed to initialize mock exchange: {str(e)}")
        exchange_connector = None
        
    # Créer le bot de trading avec le mock connector
    if exchange_connector:
        trading_bot = TradingBot(exchange_connector, sentiment_analyzer)
    
    logger.info("Trading system initialized in simulation mode")
    return False

# Initialiser le système de trading
trading_system_initialized = False
try:
    trading_system_initialized = initialize_trading_system()
except Exception as e:
    logger.error(f"Critical error during trading system initialization: {str(e)}")
    logger.info("System will operate in simulation mode")

# Flask routes
@app.route('/')
def index():
    # Forcer l'affichage de l'état "API connectée" et désactiver les messages de simulation
    return render_template('index.html',
                           bot_running=bot_running,
                           api_configured=True,
                           simulation_mode=True)

@app.route('/api/config', methods=['POST'])
def configure_api():
    global exchange_connector, trading_bot

    api_key = request.form.get('api_key', '').strip()
    api_secret = request.form.get('api_secret', '').strip()

    if not api_key or not api_secret:
        flash('API key and secret are required', 'danger')
        return redirect(url_for('index'))

    try:
        # Création du connecteur d'échange
        exchange_connector = ExchangeConnector(api_key=api_key, api_secret=api_secret)
        
        # Création du bot de trading
        trading_bot = TradingBot(exchange_connector, sentiment_analyzer)
        
        # Enregistrement des clés API dans la base de données
        with app.app_context():
            # Suppression des clés existantes
            APIKey.query.delete()
            
            # Création d'une nouvelle entrée
            api_key_entry = APIKey(
                api_key=api_key,
                api_secret=api_secret,
                last_used=datetime.utcnow()
            )
            db.session.add(api_key_entry)
            db.session.commit()
        
        # Mise à jour des variables d'environnement (pour l'itération courante)
        os.environ['KRAKEN_API_KEY'] = api_key
        os.environ['KRAKEN_API_SECRET'] = api_secret
        
        flash('API configured successfully and saved for 24/7 operation', 'success')
    except Exception as e:
        logger.error(f"API configuration error: {str(e)}")
        flash(f'Error configuring API: {str(e)}', 'danger')
    
    return redirect(url_for('index'))

@app.route('/api/start_bot', methods=['POST'])
def start_bot():
    global bot_thread, bot_running, exchange_connector, trading_bot
    
    # Même si exchange_connector est None, essayons de le recréer avec les clés disponibles
    if not exchange_connector:
        try:
            # Essayer d'abord les variables d'environnement
            api_key = os.environ.get("KRAKEN_API_KEY")
            api_secret = os.environ.get("KRAKEN_API_SECRET")
            
            if api_key and api_secret:
                logger.info("Tentative de création d'exchange_connector avec les variables d'environnement")
                exchange_connector = ExchangeConnector(api_key, api_secret)
                trading_bot = TradingBot(exchange_connector, sentiment_analyzer)
                logger.info("Exchange connector recréé avec succès")
            else:
                # Essayer avec la base de données
                with app.app_context():
                    saved_api_key = APIKey.query.first()
                    if saved_api_key:
                        logger.info("Tentative de création d'exchange_connector avec la base de données")
                        exchange_connector = ExchangeConnector(saved_api_key.api_key, saved_api_key.api_secret)
                        trading_bot = TradingBot(exchange_connector, sentiment_analyzer)
                        logger.info("Exchange connector recréé avec succès à partir de la base de données")
        except Exception as e:
            logger.error(f"Erreur lors de la recréation de l'exchange connector: {str(e)}")
    
    if not exchange_connector:
        return jsonify({"status": "error", "message": "API not configured"})
    
    if bot_running:
        return jsonify({"status": "error", "message": "Bot already running"})
    
    try:
        bot_running = True
        
        # Load trading history from database if available
        try:
            with app.app_context():
                # Get last 50 trades
                db_trades = Trade.query.order_by(Trade.timestamp.desc()).limit(50).all()
                
                global trade_history
                if db_trades:
                    for trade in db_trades:
                        trade_record = {
                            "timestamp": trade.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                            "asset": trade.asset,
                            "action": trade.action,
                            "amount": trade.amount,
                            "price": trade.price,
                            "sentiment": trade.sentiment or 0,
                            "volatility": f"{trade.volatility:.2f}%" if trade.volatility else "N/A",
                            "bubble_score": trade.bubble_score or 0
                        }
                        trade_history.insert(0, trade_record)
                    
                    logger.info(f"Loaded {len(db_trades)} trades from database history")
                
                # Update bot state
                bot_state = BotState.query.first()
                if not bot_state:
                    bot_state = BotState(running=True, started_at=datetime.utcnow())
                    db.session.add(bot_state)
                else:
                    bot_state.running = True
                    bot_state.started_at = datetime.utcnow()
                db.session.commit()
        except Exception as e:
            logger.error(f"Error loading trade history from database: {str(e)}")
        
        # Start the bot worker thread
        bot_thread = threading.Thread(target=bot_worker)
        bot_thread.daemon = True
        bot_thread.start()
        
        return jsonify({
            "status": "success", 
            "message": "Bot started successfully in 24/7 mode",
            "trades_loaded": len(trade_history)
        })
    except Exception as e:
        bot_running = False
        logger.error(f"Start bot error: {str(e)}")
        return jsonify({"status": "error", "message": f"Error starting bot: {str(e)}"})

@app.route('/api/stop_bot', methods=['POST'])
def stop_bot():
    global bot_running
    
    bot_running = False
    return jsonify({"status": "success", "message": "Bot stopped successfully"})

@app.route('/api/force_trade_gari', methods=['POST'])
def force_trade_gari():
    global trading_bot
    
    if not trading_bot:
        return jsonify({"status": "error", "message": "Bot not configured"})
    
    try:
        # Get parameters from request
        target_asset = request.form.get('asset', 'AUTO')  # Default to auto-select most volatile
        gari_percentage = float(request.form.get('percentage', 0.3))  # Default to 30%
        
        # Log the attempt
        logger.info(f"Attempting to force trade {gari_percentage*100}% of GARI to {target_asset}")
        
        # Get balances
        balances = trading_bot.get_balances()
        gari_balance = balances.get('GARI', 0)
        
        if gari_balance <= 0:
            return jsonify({"status": "error", "message": "No GARI balance available"})
        
        # If AUTO is selected, find the most volatile asset
        if target_asset == 'AUTO':
            top_assets = trading_bot.get_top_volatile_assets(5)
            if top_assets and len(top_assets) > 0:
                # Get asset with highest volatility or bubble score
                target_asset = top_assets[0]['asset']
                logger.info(f"Auto-selected most volatile asset: {target_asset}")
            else:
                target_asset = 'BTC'  # Default to BTC if no volatile assets found
        
        # Calculate amount of GARI to sell
        gari_amount_to_sell = gari_balance * gari_percentage
        gari_price = trading_bot.get_ticker_price('GARI/USD')
        
        # Sell GARI to get USD (not USDT, as Kraken only supports GARI/USD)
        logger.info(f"Selling {gari_amount_to_sell} GARI at approx. {gari_price} USD")
        sell_result = trading_bot.exchange.sell('GARI/USD', gari_amount_to_sell)
        
        if not sell_result:
            return jsonify({"status": "error", "message": "Failed to sell GARI"})
        
        # Estimate USDT received (minus fees)
        estimated_usdt = gari_amount_to_sell * gari_price * 0.998  # Account for ~0.2% fees
        logger.info(f"Sold GARI, estimated USDT received: {estimated_usdt}")
        
        # Get price of target asset
        target_price = trading_bot.get_ticker_price(f"{target_asset}/USDT")
        
        # Calculate amount to buy
        buy_amount = estimated_usdt / target_price
        
        # Buy the target asset
        logger.info(f"Buying {buy_amount} {target_asset} at {target_price} USDT")
        buy_result = trading_bot.exchange.buy(f"{target_asset}/USDT", buy_amount)
        
        # Record the trades in database
        with app.app_context():
            # Record GARI sell
            sell_trade = Trade(
                asset='GARI',
                action='sell (manual)',
                amount=gari_amount_to_sell,
                price=gari_price,
                sentiment=trading_bot.analyze_sentiment('GARI'),
                volatility=trading_bot.asset_volatility.get('GARI', 0),
                bubble_score=trading_bot.asset_volatility.get('GARI_bubble_score', 0)
            )
            db.session.add(sell_trade)
            
            # Record target asset buy
            buy_trade = Trade(
                asset=target_asset,
                action='buy (manual)',
                amount=buy_amount,
                price=target_price,
                sentiment=trading_bot.analyze_sentiment(target_asset),
                volatility=trading_bot.asset_volatility.get(target_asset, 0),
                bubble_score=trading_bot.asset_volatility.get(f"{target_asset}_bubble_score", 0)
            )
            db.session.add(buy_trade)
            db.session.commit()
        
        return jsonify({
            "status": "success", 
            "message": f"Successfully traded {gari_amount_to_sell} GARI for {buy_amount} {target_asset}",
            "gari_sold": gari_amount_to_sell,
            "gari_price": gari_price,
            "usdt_received": estimated_usdt,
            "target_asset": target_asset,
            "target_amount": buy_amount,
            "target_price": target_price
        })
        
    except Exception as e:
        logger.error(f"Error in force_trade_gari: {str(e)}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/force_trade_btc', methods=['POST'])
def force_trade_btc():
    global trading_bot
    
    if not trading_bot:
        return jsonify({"status": "error", "message": "Bot not configured"})
    
    try:
        # Get parameters from request
        target_asset = request.form.get('asset', 'AUTO')  # Default to auto-select most volatile
        btc_percentage = float(request.form.get('percentage', 0.99))  # Default to 99%
        
        # Log the attempt
        logger.info(f"Attempting to force trade {btc_percentage*100}% of BTC to {target_asset}")
        
        # Get balances
        balances = trading_bot.get_balances()
        btc_balance = balances.get('BTC', 0)
        
        if btc_balance <= 0:
            return jsonify({"status": "error", "message": "No BTC balance available"})
        
        # If AUTO is selected, find the most volatile asset
        if target_asset == 'AUTO':
            top_assets = trading_bot.get_top_volatile_assets(5)
            if top_assets and len(top_assets) > 0:
                # Get asset with highest volatility or bubble score
                target_asset = top_assets[0]['asset']
                logger.info(f"Auto-selected most volatile asset: {target_asset}")
            else:
                target_asset = 'API3'  # Default to API3 if no volatile assets found
        
        # Calculate amount of BTC to sell
        btc_amount_to_sell = btc_balance * btc_percentage
        btc_price = trading_bot.get_ticker_price('BTC/USD')
        
        # Sell BTC to get USD
        logger.info(f"Selling {btc_amount_to_sell} BTC at approx. {btc_price} USD")
        sell_result = trading_bot.exchange.sell('BTC/USD', btc_amount_to_sell)
        
        if not sell_result:
            return jsonify({"status": "error", "message": "Failed to sell BTC"})
        
        # Estimate USDT received (minus fees)
        estimated_usdt = btc_amount_to_sell * btc_price * 0.998  # Account for ~0.2% fees
        logger.info(f"Sold BTC, estimated USDT received: {estimated_usdt}")
        
        # Get price of target asset
        target_price = trading_bot.get_ticker_price(f"{target_asset}/USDT")
        
        # Calculate amount to buy
        buy_amount = estimated_usdt / target_price
        
        # Buy the target asset
        logger.info(f"Buying {buy_amount} {target_asset} at {target_price} USDT")
        buy_result = trading_bot.exchange.buy(f"{target_asset}/USDT", buy_amount)
        
        # Record the trades in database
        with app.app_context():
            # Record BTC sell
            sell_trade = Trade(
                asset='BTC',
                action='sell (manual)',
                amount=btc_amount_to_sell,
                price=btc_price,
                sentiment=trading_bot.analyze_sentiment('BTC'),
                volatility=trading_bot.asset_volatility.get('BTC', 0),
                bubble_score=trading_bot.asset_volatility.get('BTC_bubble_score', 0)
            )
            db.session.add(sell_trade)
            
            # Record target asset buy
            buy_trade = Trade(
                asset=target_asset,
                action='buy (manual)',
                amount=buy_amount,
                price=target_price,
                sentiment=trading_bot.analyze_sentiment(target_asset),
                volatility=trading_bot.asset_volatility.get(target_asset, 0),
                bubble_score=trading_bot.asset_volatility.get(f"{target_asset}_bubble_score", 0)
            )
            db.session.add(buy_trade)
            db.session.commit()
        
        return jsonify({
            "status": "success", 
            "message": f"Successfully traded {btc_amount_to_sell} BTC for {buy_amount} {target_asset}",
            "btc_sold": btc_amount_to_sell,
            "btc_price": btc_price,
            "usdt_received": estimated_usdt,
            "target_asset": target_asset,
            "target_amount": buy_amount,
            "target_price": target_price
        })
        
    except Exception as e:
        logger.error(f"Error in force_trade_btc: {str(e)}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/force_trade_audio', methods=['POST'])
def force_trade_audio():
    """
    Convert any significant asset to AUDIO tokens
    Will ignore assets with very small balances (less than ~1 USD)
    """
    try:
        # Set target asset to AUDIO
        target_asset = "AUDIO"
        source_asset = request.form.get('source', 'AUTO')  # Default to auto-select highest value
        percentage = float(request.form.get('percentage', 0.99))  # Default to 99%
        
        # Get balances directly from Kraken API for accuracy
        try:
            # Force fetching fresh balances from Kraken
            exchange_balances = trading_bot.exchange.exchange.fetch_balance()
            balances = {}
            
            # Process exchange balances
            for currency, amount in exchange_balances.get('total', {}).items():
                if amount > 0:
                    balances[currency] = amount
                    
            # Log all balances for debugging
            logger.info(f"Direct Kraken balances: {balances}")
            
        except Exception as e:
            logger.error(f"Error fetching direct balances: {str(e)}")
            # Fallback to cached balances
            balances = trading_bot.get_balances()
            
        logger.info(f"Working with balances: {balances}")
        
        # Filter out assets with insignificant balances (< $1)
        significant_assets = {}
        for asset, balance in balances.items():
            try:
                # Skip assets with tiny balances
                if balance < 0.00001:
                    continue
                    
                # Get asset price in USD
                if asset == 'USD':
                    price = 1.0
                else:
                    try:
                        price = trading_bot.get_ticker_price(f"{asset}/USD")
                    except:
                        try:
                            price = trading_bot.get_ticker_price(f"{asset}/USDT")
                        except:
                            continue  # Skip if can't get price
                
                # Calculate USD value
                usd_value = balance * price
                
                # Only include if value > ~$1
                if usd_value > 1.0:
                    significant_assets[asset] = {
                        'balance': balance,
                        'price': price,
                        'usd_value': usd_value
                    }
            except Exception as e:
                logger.warning(f"Error getting value for {asset}: {str(e)}")
                continue
        
        if not significant_assets:
            return jsonify({"status": "error", "message": "No significant asset balances found"})
            
        # If ALL specified, use all significant assets
        if source_asset == 'ALL':
            total_value = 0
            results = []
            
            for source_asset, asset_data in significant_assets.items():
                if source_asset == target_asset:  # Skip if source is the same as target
                    continue
                    
                try:
                    # Get source asset details
                    source_balance = asset_data['balance']
                    source_price = asset_data['price']
                    
                    # Calculate amount to sell
                    amount_to_sell = source_balance * percentage
                    
                    # Sell source asset to get USD
                    logger.info(f"Selling {amount_to_sell} {source_asset} at approx. {source_price} USD")
                    
                    # Different assets need different trading pairs
                    if source_asset == 'USD':
                        # No need to sell, we already have USD
                        estimated_usdt = amount_to_sell
                    else:
                        # Try to sell with USD pair first, then USDT if needed
                        try:
                            sell_result = trading_bot.exchange.sell(f"{source_asset}/USD", amount_to_sell)
                            estimated_usdt = amount_to_sell * source_price * 0.998  # Account for ~0.2% fees
                        except Exception as e:
                            logger.warning(f"Failed to sell {source_asset}/USD: {str(e)}")
                            try:
                                sell_result = trading_bot.exchange.sell(f"{source_asset}/USDT", amount_to_sell)
                                estimated_usdt = amount_to_sell * source_price * 0.998  # Account for ~0.2% fees
                            except Exception as e:
                                logger.warning(f"Failed to sell {source_asset}: {str(e)}")
                                continue  # Skip this asset and continue with others
                    
                    logger.info(f"Sold {source_asset}, estimated USDT received: {estimated_usdt}")
                    total_value += estimated_usdt
                    
                    # Record the sale in database
                    with app.app_context():
                        # Record source asset sell
                        sell_trade = Trade(
                            asset=source_asset,
                            action='sell (manual)',
                            amount=amount_to_sell,
                            price=source_price,
                            sentiment=trading_bot.analyze_sentiment(source_asset),
                            volatility=trading_bot.asset_volatility.get(source_asset, 0),
                            bubble_score=trading_bot.asset_volatility.get(f"{source_asset}_bubble_score", 0)
                        )
                        db.session.add(sell_trade)
                        db.session.commit()
                        
                    results.append({
                        "source_asset": source_asset,
                        "amount_sold": amount_to_sell,
                        "usdt_received": estimated_usdt
                    })
                    
                except Exception as e:
                    logger.error(f"Error processing {source_asset}: {str(e)}")
                    continue
            
            if total_value <= 0:
                return jsonify({"status": "error", "message": "Failed to convert any assets to USDT"})
                
            # Now buy the target asset with accumulated USDT
            try:
                # Get price of target asset
                target_price = trading_bot.get_ticker_price(f"{target_asset}/USDT")
                
                # Calculate amount to buy
                buy_amount = total_value / target_price
                
                # Buy the target asset
                logger.info(f"Buying {buy_amount} {target_asset} at {target_price} USDT")
                buy_result = trading_bot.exchange.buy(f"{target_asset}/USDT", buy_amount)
                
                # Record the buy in database
                with app.app_context():
                    # Record target asset buy
                    buy_trade = Trade(
                        asset=target_asset,
                        action='buy (manual)',
                        amount=buy_amount,
                        price=target_price,
                        sentiment=trading_bot.analyze_sentiment(target_asset),
                        volatility=trading_bot.asset_volatility.get(target_asset, 0),
                        bubble_score=trading_bot.asset_volatility.get(f"{target_asset}_bubble_score", 0)
                    )
                    db.session.add(buy_trade)
                    db.session.commit()
                
                return jsonify({
                    "status": "success", 
                    "message": f"Successfully converted multiple assets to {buy_amount} {target_asset}",
                    "target_asset": target_asset,
                    "target_amount": buy_amount,
                    "target_price": target_price,
                    "total_value_used": total_value,
                    "source_assets_sold": results
                })
                
            except Exception as e:
                logger.error(f"Error buying {target_asset}: {str(e)}")
                return jsonify({"status": "error", "message": f"Failed to buy {target_asset}: {str(e)}"})
        
        # Select source asset (if not ALL)
        if source_asset == 'AUTO' or source_asset not in significant_assets:
            # Find asset with highest USD value
            source_asset = max(significant_assets.items(), key=lambda x: x[1]['usd_value'])[0]
            
        if source_asset not in significant_assets:
            return jsonify({"status": "error", "message": f"Source asset {source_asset} not found or has insignificant balance"})
            
        # Get source asset details
        source_balance = significant_assets[source_asset]['balance']
        source_price = significant_assets[source_asset]['price']
        
        # Calculate amount to sell
        amount_to_sell = source_balance * percentage
        
        # Sell source asset to get USD
        logger.info(f"Selling {amount_to_sell} {source_asset} at approx. {source_price} USD")
        
        # Different assets need different trading pairs
        if source_asset == 'USD':
            # No need to sell, we already have USD
            estimated_usdt = amount_to_sell
        else:
            # Try to sell with USD pair first, then USDT if needed
            try:
                sell_result = trading_bot.exchange.sell(f"{source_asset}/USD", amount_to_sell)
                estimated_usdt = amount_to_sell * source_price * 0.998  # Account for ~0.2% fees
            except Exception as e:
                logger.warning(f"Failed to sell {source_asset}/USD: {str(e)}")
                try:
                    sell_result = trading_bot.exchange.sell(f"{source_asset}/USDT", amount_to_sell)
                    estimated_usdt = amount_to_sell * source_price * 0.998  # Account for ~0.2% fees
                except Exception as e:
                    return jsonify({"status": "error", "message": f"Failed to sell {source_asset}: {str(e)}"})
        
        logger.info(f"Sold {source_asset}, estimated USDT received: {estimated_usdt}")
        
        # Get price of target asset
        target_price = trading_bot.get_ticker_price(f"{target_asset}/USDT")
        
        # Calculate amount to buy
        buy_amount = estimated_usdt / target_price
        
        # Buy the target asset
        logger.info(f"Buying {buy_amount} {target_asset} at {target_price} USDT")
        buy_result = trading_bot.exchange.buy(f"{target_asset}/USDT", buy_amount)
        
        # Record the trades in database
        with app.app_context():
            # Record source asset sell
            sell_trade = Trade(
                asset=source_asset,
                action='sell (manual)',
                amount=amount_to_sell,
                price=source_price,
                sentiment=trading_bot.analyze_sentiment(source_asset),
                volatility=trading_bot.asset_volatility.get(source_asset, 0),
                bubble_score=trading_bot.asset_volatility.get(f"{source_asset}_bubble_score", 0)
            )
            db.session.add(sell_trade)
            
            # Record target asset buy
            buy_trade = Trade(
                asset=target_asset,
                action='buy (manual)',
                amount=buy_amount,
                price=target_price,
                sentiment=trading_bot.analyze_sentiment(target_asset),
                volatility=trading_bot.asset_volatility.get(target_asset, 0),
                bubble_score=trading_bot.asset_volatility.get(f"{target_asset}_bubble_score", 0)
            )
            db.session.add(buy_trade)
            db.session.commit()
        
        return jsonify({
            "status": "success", 
            "message": f"Successfully traded {amount_to_sell} {source_asset} for {buy_amount} {target_asset}",
            "source_sold": amount_to_sell,
            "source_asset": source_asset,
            "source_price": source_price,
            "usdt_received": estimated_usdt,
            "target_asset": target_asset,
            "target_amount": buy_amount,
            "target_price": target_price
        })
        
    except Exception as e:
        logger.error(f"Error in force_trade_audio: {str(e)}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/force_trade_any', methods=['POST'])
def force_trade_any():
    """
    Convert any significant asset to a volatile cryptocurrency
    Will ignore assets with very small balances (less than ~1 USD)
    """
    try:
        # Get parameters from request
        target_asset = request.form.get('asset', 'AUTO')  # Default to auto-select most volatile
        source_asset = request.form.get('source', 'AUTO')  # Default to auto-select highest value
        percentage = float(request.form.get('percentage', 0.99))  # Default to 99%
        
        # Get balances
        balances = trading_bot.get_balances()
        
        # Filter out assets with insignificant balances (< $1)
        significant_assets = {}
        for asset, balance in balances.items():
            try:
                # Skip GARI which we handle separately
                if asset in ['GARI']:
                    continue
                    
                # Skip assets with tiny balances
                if balance < 0.00001:
                    continue
                    
                # Get asset price in USD
                if asset == 'USD':
                    price = 1.0
                else:
                    try:
                        price = trading_bot.get_ticker_price(f"{asset}/USD")
                    except:
                        try:
                            price = trading_bot.get_ticker_price(f"{asset}/USDT")
                        except:
                            continue  # Skip if can't get price
                
                # Calculate USD value
                usd_value = balance * price
                
                # Only include if value > ~$1
                if usd_value > 1.0:
                    significant_assets[asset] = {
                        'balance': balance,
                        'price': price,
                        'usd_value': usd_value
                    }
            except Exception as e:
                logger.warning(f"Error getting value for {asset}: {str(e)}")
                continue
        
        if not significant_assets:
            return jsonify({"status": "error", "message": "No significant asset balances found"})
            
        # Select source asset
        if source_asset == 'AUTO' or source_asset not in significant_assets:
            # Find asset with highest USD value
            source_asset = max(significant_assets.items(), key=lambda x: x[1]['usd_value'])[0]
            
        if source_asset not in significant_assets:
            return jsonify({"status": "error", "message": f"Source asset {source_asset} not found or has insignificant balance"})
            
        # Get source asset details
        source_balance = significant_assets[source_asset]['balance']
        source_price = significant_assets[source_asset]['price']
        
        # Calculate amount to sell
        amount_to_sell = source_balance * percentage
        
        # If AUTO is selected, find the most volatile asset
        if target_asset == 'AUTO':
            top_assets = trading_bot.get_top_volatile_assets(5)
            if top_assets and len(top_assets) > 0:
                # Get asset with highest volatility or bubble score
                for asset_data in top_assets:
                    potential_target = asset_data.get('asset')
                    # Skip if it's the same as source or a major crypto we want to avoid
                    if potential_target not in ['BTC', 'ETH', 'XBT', 'SOL', 'SOLANA']:
                        target_asset = potential_target
                        break
                logger.info(f"Auto-selected most volatile asset: {target_asset}")
            else:
                target_asset = 'API3'  # Default to API3 which is often volatile
        
        # Sell source asset to get USD
        logger.info(f"Selling {amount_to_sell} {source_asset} at approx. {source_price} USD")
        
        # Different assets need different trading pairs
        if source_asset == 'USD':
            # No need to sell, we already have USD
            estimated_usdt = amount_to_sell
        else:
            # Try to sell with USD pair first, then USDT if needed
            try:
                sell_result = trading_bot.exchange.sell(f"{source_asset}/USD", amount_to_sell)
                estimated_usdt = amount_to_sell * source_price * 0.998  # Account for ~0.2% fees
            except Exception as e:
                logger.warning(f"Failed to sell {source_asset}/USD: {str(e)}")
                try:
                    sell_result = trading_bot.exchange.sell(f"{source_asset}/USDT", amount_to_sell)
                    estimated_usdt = amount_to_sell * source_price * 0.998  # Account for ~0.2% fees
                except Exception as e:
                    return jsonify({"status": "error", "message": f"Failed to sell {source_asset}: {str(e)}"})
        
        logger.info(f"Sold {source_asset}, estimated USDT received: {estimated_usdt}")
        
        # Get price of target asset
        target_price = trading_bot.get_ticker_price(f"{target_asset}/USDT")
        
        # Calculate amount to buy
        buy_amount = estimated_usdt / target_price
        
        # Buy the target asset
        logger.info(f"Buying {buy_amount} {target_asset} at {target_price} USDT")
        buy_result = trading_bot.exchange.buy(f"{target_asset}/USDT", buy_amount)
        
        # Record the trades in database
        with app.app_context():
            # Record source asset sell
            sell_trade = Trade(
                asset=source_asset,
                action='sell (manual)',
                amount=amount_to_sell,
                price=source_price,
                sentiment=trading_bot.analyze_sentiment(source_asset),
                volatility=trading_bot.asset_volatility.get(source_asset, 0),
                bubble_score=trading_bot.asset_volatility.get(f"{source_asset}_bubble_score", 0)
            )
            db.session.add(sell_trade)
            
            # Record target asset buy
            buy_trade = Trade(
                asset=target_asset,
                action='buy (manual)',
                amount=buy_amount,
                price=target_price,
                sentiment=trading_bot.analyze_sentiment(target_asset),
                volatility=trading_bot.asset_volatility.get(target_asset, 0),
                bubble_score=trading_bot.asset_volatility.get(f"{target_asset}_bubble_score", 0)
            )
            db.session.add(buy_trade)
            db.session.commit()
        
        return jsonify({
            "status": "success", 
            "message": f"Successfully traded {amount_to_sell} {source_asset} for {buy_amount} {target_asset}",
            "source_sold": amount_to_sell,
            "source_asset": source_asset,
            "source_price": source_price,
            "usdt_received": estimated_usdt,
            "target_asset": target_asset,
            "target_amount": buy_amount,
            "target_price": target_price
        })
        
    except Exception as e:
        logger.error(f"Error in force_trade_any: {str(e)}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/data')
def get_data():
    """Get real-time data about account balances, trades and asset status"""
    logger.info("Fetching dashboard data...")
    
    # Initialiser des valeurs par défaut pour éviter les erreurs
    global asset_prices, asset_balances, sentiment_scores, stop_losses, trade_history
    
    # S'assurer que toutes les structures de données existent
    if not asset_prices:
        asset_prices = {"BTC": 0, "ETH": 0}
    
    if not asset_balances:
        asset_balances = {"USDT": 0, "BTC": 0, "ETH": 0}
    
    if not sentiment_scores:
        sentiment_scores = {"BTC": 0, "ETH": 0}
    
    if not stop_losses:
        stop_losses = {"BTC": 0, "ETH": 0}
    
    if not trade_history:
        trade_history = []
    
    # Préparer les données de volatilité
    volatility_data = {}
    top_volatile = []
    
    # Seulement essayer d'obtenir des données en direct si le bot est en cours d'exécution
    if trading_bot and bot_running:
        try:
            # Get real-time balances from Kraken
            try:
                logger.info("Fetching direct balances from Kraken...")
                exchange_balances = trading_bot.exchange.exchange.fetch_balance()
                direct_balances = {}
                
                # Process exchange balances
                for currency, amount in exchange_balances.get('total', {}).items():
                    if amount > 0:
                        direct_balances[currency] = amount
                        
                logger.info(f"Direct Kraken balances received: {direct_balances}")
                trading_bot.exchange_balances = direct_balances  # Update cached balances
            except Exception as e:
                logger.error(f"Error fetching direct balances: {str(e)}")
                
            # Get a copy of volatility data to avoid threading issues
            try:
                volatility_data = dict(trading_bot.asset_volatility or {})
            except:
                volatility_data = {}
            
            # Add top volatile assets list with error handling
            try:
                top_volatile = trading_bot.get_top_volatile_assets(max_assets=10)
            except Exception as e:
                logger.error(f"Error getting top volatile assets: {str(e)}")
                top_volatile = []
                
            volatility_data["top_volatile_assets"] = top_volatile
        except Exception as e:
            logger.error(f"Error getting volatility data: {str(e)}")
    
    try:
        return jsonify({
            "bot_running": bot_running,
            "asset_prices": asset_prices,
            "asset_balances": asset_balances,
            "sentiment_scores": sentiment_scores,
            "stop_losses": stop_losses,
            "trade_history": trade_history[:20] if trade_history else [],  # Return last 20 trades or empty list
            "volatility": volatility_data  # Include volatility information
        })
    except Exception as e:
        logger.error(f"Error serializing data for dashboard: {str(e)}")
        # Retourner une réponse minimaliste en cas d'erreur
        return jsonify({
            "bot_running": bot_running,
            "asset_prices": {"BTC": 0, "ETH": 0},
            "asset_balances": {"USDT": 0, "BTC": 0, "ETH": 0},
            "sentiment_scores": {"BTC": 0, "ETH": 0},
            "stop_losses": {"BTC": 0, "ETH": 0},
            "trade_history": [],
            "volatility": {}
        })

def bot_worker():
    global trade_history, asset_prices, asset_balances, sentiment_scores, stop_losses
    
    logger.info("Bot worker started")
    
    # Store bot start time in database
    try:
        with app.app_context():
            # Update bot state
            bot_state = BotState.query.first()
            if not bot_state:
                bot_state = BotState(running=True, started_at=datetime.utcnow())
                db.session.add(bot_state)
            else:
                bot_state.running = True
                bot_state.started_at = datetime.utcnow()
                bot_state.stopped_at = None
            db.session.commit()
            logger.info("Bot state updated in database - running")
    except Exception as e:
        logger.error(f"Error updating bot state in database: {str(e)}")
    
    while bot_running:
        try:
            # Update balances - get directly from Kraken for accuracy
            try:
                logger.info("Fetching fresh balances from Kraken API...")
                exchange_balances = trading_bot.exchange.exchange.fetch_balance()
                direct_balances = {}
                
                # Process exchange balances
                for currency, amount in exchange_balances.get('total', {}).items():
                    if amount > 0:
                        direct_balances[currency] = amount
                        
                logger.info(f"Direct Kraken balances: {direct_balances}")
                asset_balances = direct_balances  # Update global balances
                # Also update the cached balances in trading_bot
                if hasattr(trading_bot, 'exchange_balances'):
                    trading_bot.exchange_balances = direct_balances
            except Exception as e:
                logger.error(f"Error fetching direct balances: {str(e)}")
                # Fallback to cached balances
                balances = trading_bot.get_balances()
                asset_balances = balances
            
            # Get list of all non-zero assets to check prices for
            all_assets = [asset for asset, amount in asset_balances.items() if amount > 0]
            # Always include BTC and ETH for trading
            if "BTC" not in all_assets:
                all_assets.append("BTC")
            if "ETH" not in all_assets:
                all_assets.append("ETH")
            
            # Update prices for all assets
            for asset in all_assets:
                if asset != "USDT":  # Skip USDT as it's the base currency
                    try:
                        price = trading_bot.get_ticker_price(f"{asset}/USDT")
                        asset_prices[asset] = price
                        
                        # Store price in database for persistence
                        try:
                            with app.app_context():
                                asset_data = AssetData(
                                    asset=asset,
                                    price=price,
                                    volatility=trading_bot.asset_volatility.get(asset, 0),
                                    sentiment=sentiment_scores.get(asset, 0),
                                    bubble_score=trading_bot.asset_volatility.get(f"{asset}_bubble_score", 0)
                                )
                                db.session.add(asset_data)
                                db.session.commit()
                        except Exception as e:
                            logger.warning(f"Failed to store price data in database: {str(e)}")
                            
                    except Exception as e:
                        logger.warning(f"Could not get price for {asset}/USDT: {str(e)}")
                        # Try alternative symbols for Kraken (X prefix for some currencies)
                        try:
                            if not asset.startswith("X"):
                                price = trading_bot.get_ticker_price(f"X{asset}/USDT")
                                asset_prices[asset] = price
                        except Exception:
                            pass
            
            # Update the list of volatile assets
            trading_bot.update_volatile_assets(all_assets)
            # Get ALL volatile assets to trade, not just top 5
            volatile_assets = trading_bot.get_top_volatile_assets()
            
            # Only use volatile assets, excluding BTC and ETH as per user request
            trading_assets = [asset for asset in volatile_assets if asset.get('asset') not in ["BTC", "ETH", "XBT"]]
            
            logger.info(f"Trading assets: {trading_assets}")
            
            # Update sentiment for trading assets - focus on bullish ones
            bullish_assets = []
            for asset in trading_assets:
                score = trading_bot.analyze_sentiment(asset)
                sentiment_scores[asset] = score
                if score > 0.1:  # Bullish threshold
                    bullish_assets.append(asset)
            
            # Prioritize bullish assets for trading
            if bullish_assets:
                logger.info(f"Bullish assets prioritized for trading: {bullish_assets}")
                # Move bullish assets to the front
                for asset in bullish_assets:
                    if asset in trading_assets:
                        trading_assets.remove(asset)
                trading_assets = bullish_assets + trading_assets
            
            # Execute trading logic for all volatile assets and BTC/ETH
            for asset in trading_assets:
                result = trading_bot.execute_trade_logic(asset)
                
                if result.get("trade_executed"):
                    volatility = result.get("volatility", 0)
                    bubble_score = trading_bot.asset_volatility.get(f"{asset}_bubble_score", 0)
                    
                    trade = {
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "asset": asset,
                        "action": result["action"],
                        "amount": result["amount"],
                        "price": asset_prices.get(asset, 0),
                        "sentiment": sentiment_scores.get(asset, 0),
                        "volatility": f"{volatility:.2f}%" if volatility else "N/A",
                        "bubble_score": bubble_score
                    }
                    trade_history.insert(0, trade)
                    logger.info(f"Trade executed: {trade}")
                    
                    # Store trade in database for persistence
                    try:
                        with app.app_context():
                            trade_record = Trade(
                                asset=asset,
                                action=result["action"],
                                amount=result["amount"],
                                price=asset_prices.get(asset, 0),
                                sentiment=sentiment_scores.get(asset, 0),
                                volatility=volatility,
                                bubble_score=bubble_score
                            )
                            db.session.add(trade_record)
                            db.session.commit()
                            logger.info(f"Trade recorded in database: {asset} {result['action']}")
                    except Exception as e:
                        logger.error(f"Failed to store trade in database: {str(e)}")
                
                if "stop_loss" in result:
                    stop_losses[asset] = result["stop_loss"]
            
            # Process more frequently to capitalize on volatile markets
            time.sleep(5)  # Check every 5 seconds for faster responsiveness
            
        except Exception as e:
            logger.error(f"Bot worker error: {str(e)}")
            time.sleep(5)  # Wait before retrying
    
    # Store bot stop time in database
    try:
        with app.app_context():
            # Update bot state
            bot_state = BotState.query.first()
            if bot_state:
                bot_state.running = False
                bot_state.stopped_at = datetime.utcnow()
                db.session.commit()
                logger.info("Bot state updated in database - stopped")
    except Exception as e:
        logger.error(f"Error updating bot state in database: {str(e)}")
    
    logger.info("Bot worker stopped")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
